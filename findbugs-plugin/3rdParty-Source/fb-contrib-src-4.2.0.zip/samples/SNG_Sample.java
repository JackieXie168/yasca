import java.io.File;


public class SNG_Sample 
{
	private static byte[] EMPTY_BYTE_ARRAY = new byte[0];
	private Object f1 = null;
	private Object f2 = null;
	private File file = null;
	private byte[] buffer = null;
	
	public String badSNGFields()
	{
		if (f1 != null)
			return f2.toString();
		
		return null;
	}
	
	public String badSNGLocals(Object l1, Object l2) 
	{
		if (l1 != null)
			return l2.toString();
		
		return null;		
	}
	
	public boolean fpReturn(Object o) {
		return o != null;
	}
	
	public boolean fpAssign(Object o) {
		boolean b = o != null;
		return b;
	}
	
	public boolean fpField() {
		if (f1 != null)
			return true;
		
		return false;
	}
	
	public void fpAssert() {
		assert f1 != null && f1.equals(f2);
	}
	
	public Object fpSetNull(Object o) {
		if (o != null) 
			o = null;
		
		return o;
	}
	
	public void fpSetMemberNull() {
		if (f1 != null)
			f1 = null;
	}
	
	public void fpDual(Object o1, Object o2) {
		if (o1 == null || o2 == null) {
            throw new IllegalArgumentException("o1/o2 can not be null");
        }
	}
	
	 public void discard() {
         if (file != null) {
             file.delete();
         } else if (buffer != null) {
             buffer = EMPTY_BYTE_ARRAY;
         }
     }
}
