
public class TBP_Sample 
{
	public Boolean questionable(String in) {
		if (in.equals("Foo"))
			return Boolean.TRUE;
		
		return null;
	}
}
