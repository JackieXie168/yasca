

public class CE_Sample
{
	public void test()
	{
		Envy e = new Envy();
		e.a();
		e.b();
		test2();
		e.c();
		e.d();
		e.e();
		e.f();
	}
	
	public void test2()
	{
		
	}
}

class Envy
{
	public void a() {}
	
	public void b() {}
	
	public void c() {}
	
	public void d() {}
	
	public void e() {}
	
	public void f() {}
}

