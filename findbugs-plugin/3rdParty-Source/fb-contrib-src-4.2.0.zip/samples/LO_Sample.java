import org.apache.log4j.Logger;


@SuppressWarnings("all")
public class LO_Sample 
{
	private static Logger l1 = Logger.getLogger(String.class);
	private static Logger l2 = Logger.getLogger("com.foo.LO_Sample");
	
	public LO_Sample(Logger l3)
	{
		
	}
}
