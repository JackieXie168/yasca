import java.nio.ByteBuffer;
import java.util.Calendar;
import java.util.Date;

@SuppressWarnings("all")
public class RMC_Sample 
{
	String data;
	
	public boolean test1(Calendar c)
	{
		Date d = c.getTime();
		long l = d.getTime();
		Date e = c.getTime();
		long j = e.getTime();
		return l == j;
	}
    
    public void rmcFP(ByteBuffer bb)
    {
        int i = bb.getInt();
        int j = bb.getInt();
    }
    
    @Override
    public boolean equals(Object o)
    {
    	RMC_Sample rmc = (RMC_Sample)o;
    	if (data.equals("INF") || rmc.data.equals("INF"))
    		return false;
    	
    	return data.equals(rmc.data);
    }
}
