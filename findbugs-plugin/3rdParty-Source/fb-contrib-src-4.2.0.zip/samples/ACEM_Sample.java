

public abstract class ACEM_Sample
{
	public void test()
	{
	}
	
	public int test1()
	{
		throw new UnsupportedOperationException("Not implemented");
	}
}