import javax.swing.JFrame;

@SuppressWarnings("all")
public class NIR_Sample extends JFrame
{
	public static final int NIR_VALUE = 1;
	
	public NIR_Sample getSample()
	{
		return this;
	}
	
	public void test1()
	{
		System.out.println(getSample().NIR_VALUE);
	}
	
	public void test2()
	{
		System.out.println(getColorModel().TRANSLUCENT);
	}
}
