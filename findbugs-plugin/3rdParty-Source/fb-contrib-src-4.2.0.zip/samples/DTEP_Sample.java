
public class DTEP_Sample 
{
	public static final DTEP_Sample SAMPLE1 = new DTEP_Sample();
	public static final DTEP_Sample SAMPLE2 = new DTEP_Sample();
	
	private DTEP_Sample()
	{
		
	}
}
