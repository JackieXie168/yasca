/*
 * fb-contrib - Auxiliary detectors for Java programs
 * Copyright (C) 2005-2010 Dave Brosius
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.mebigfatguy.fbcontrib.detect;

import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import org.apache.bcel.Constants;
import org.apache.bcel.classfile.Code;
import org.apache.bcel.classfile.Field;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Method;
import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.FieldInstruction;
import org.apache.bcel.generic.GETFIELD;
import org.apache.bcel.generic.Instruction;
import org.apache.bcel.generic.InstructionHandle;

import edu.umd.cs.findbugs.BugInstance;
import edu.umd.cs.findbugs.BugReporter;
import edu.umd.cs.findbugs.BytecodeScanningDetector;
import edu.umd.cs.findbugs.FieldAnnotation;
import edu.umd.cs.findbugs.SourceLineAnnotation;
import edu.umd.cs.findbugs.ba.BasicBlock;
import edu.umd.cs.findbugs.ba.CFG;
import edu.umd.cs.findbugs.ba.CFGBuilderException;
import edu.umd.cs.findbugs.ba.ClassContext;
import edu.umd.cs.findbugs.ba.Edge;
import edu.umd.cs.findbugs.ba.BasicBlock.InstructionIterator;

/**
 * finds fields that are used in a locals only fashion, specifically private fields
 * that are accessed first in each method with a store vs. a load.
 */
public class FieldCouldBeLocal extends BytecodeScanningDetector
{
	private final BugReporter bugReporter;
	private ClassContext clsContext;
	private Map<String, FieldInfo> localizableFields;
	private CFG cfg;
	private ConstantPoolGen cpg;
	private BitSet visitedBlocks;
	
    /**
     * constructs a FCBL detector given the reporter to report bugs on.

     * @param bugReporter the sync of bug reports
     */	
	public FieldCouldBeLocal(BugReporter bugReporter) {
		this.bugReporter = bugReporter;
	}
	
	/**
	 * overrides the visitor to collect localizable fields, and then report those that
	 * survive all method checks.
	 * 
	 * @param classContext the context object that holds the JavaClass parsed
	 */
	@Override	
	public void visitClassContext(ClassContext classContext) {
		try {
	        localizableFields = new HashMap<String, FieldInfo>();
	        visitedBlocks = new BitSet();
			clsContext = classContext;
			JavaClass cls = classContext.getJavaClass();
			Field[] fields = cls.getFields();
			for (Field f : fields) {
				if ((!f.isStatic() && f.getName().indexOf('$') < 0) && f.isPrivate()) {
					FieldAnnotation fa = new FieldAnnotation(cls.getClassName(), f.getName(), f.getSignature(), false);
					localizableFields.put(f.getName(), new FieldInfo(fa));
				}
			}
			
			if (localizableFields.size() > 0) {
				super.visitClassContext(classContext);
				for (FieldInfo fi : localizableFields.values()) {
					FieldAnnotation fa = fi.getFieldAnnotation();
					SourceLineAnnotation sla = fi.getSrcLineAnnotation();
					BugInstance bug = new BugInstance(this, "FCBL_FIELD_COULD_BE_LOCAL", NORMAL_PRIORITY)
													.addClass(this)
													.addField(fa);
					if (sla != null)
						bug.addSourceLine(sla);
					bugReporter.reportBug(bug);
				}
			}
		} finally {
	        localizableFields = null;
	        visitedBlocks = null;
	        clsContext = null;
		}
	}
	
	/**
	 * overrides the visitor to navigate basic blocks looking for all first usages of fields, removing
	 * those that are read from first.
	 * 
	 * @param obj the context object of the currently parsed method
	 */
	@Override
	public void visitMethod(Method obj) {
		if (localizableFields.isEmpty())
			return;
		
		String methodName = obj.getName();
		if ("<clinit>".equals(methodName) || "<init>".equals(methodName))
			return;
		try {
			cpg = new ConstantPoolGen(getConstantPool());
			cfg = clsContext.getCFG(obj);
			BasicBlock bb = cfg.getEntry();
			Set<String> uncheckedFields = new HashSet<String>(localizableFields.keySet());	
			visitedBlocks.clear();
			checkBlock(bb, uncheckedFields);
		}
		catch (CFGBuilderException cbe) {
			localizableFields.clear();
		}
        finally {
            cfg = null;
            cpg = null;
        }
	}
	
	/**
	 * looks for methods that contain a GETFIELD or PUTFIELD opcodes
	 * 
	 * @param method the context object of the current method
	 * @return if the class uses synchronization
	 */
	public boolean prescreen(Method method) {
		BitSet bytecodeSet = getClassContext().getBytecodeSet(method);
		return (bytecodeSet != null) && (bytecodeSet.get(Constants.PUTFIELD) || bytecodeSet.get(Constants.GETFIELD));
	}
	
	/**
	 * implements the visitor to pass through constructors and static initializers to the
	 * byte code scanning code. These methods are not reported, but are used to build 
	 * SourceLineAnnotations for fields, if accessed.
	 * 
	 * @param obj the context object of the currently parsed code attribute
	 */
	@Override
	public void visitCode(Code obj) {
		Method m = getMethod();
		if (prescreen(m)) {
			String methodName = m.getName();
			if ("<clinit".equals(methodName) || "<init>".equals(methodName))
				super.visitCode(obj);
		}
	}
	
	/**
	 * implements the visitor to add SourceLineAnnotations for fields in constructors and static
	 * initializers.
	 * 
	 * @param seen the opcode of the currently visited instruction
	 */
	@Override
	public void sawOpcode(int seen) {
		if ((seen == GETFIELD) || (seen == PUTFIELD)) {
			String fieldName = getNameConstantOperand();
			FieldInfo fi = localizableFields.get(fieldName);
			if (fi != null) {
				SourceLineAnnotation sla = SourceLineAnnotation.fromVisitedInstruction(this);
				fi.setSrcLineAnnotation(sla);
			}
		}
	}
	
	/**
	 * looks in this basic block for the first access to the fields in uncheckedFields. Once found
	 * the item is removed from uncheckedFields, and removed from localizableFields if the access is 
	 * a GETFIELD. If any unchecked fields remain, this method is recursively called on all outgoing edges
	 * of this basic block.
	 * 
	 * @param bb this basic block
	 * @param uncheckedFields the list of fields to look for
	 */
	private void checkBlock(BasicBlock bb, Set<String> uncheckedFields) {
		LinkedList<BlockState> toBeProcessed = new LinkedList<BlockState>();
		toBeProcessed.add(new BlockState(bb, uncheckedFields));
		
		while (!toBeProcessed.isEmpty()) {
			if (localizableFields.isEmpty())
				return;
			BlockState bState = toBeProcessed.removeFirst();
			bb = bState.getBasicBlock();
			uncheckedFields = bState.getUncheckedFields();
			
			visitedBlocks.set(bb.getLabel());
			InstructionIterator ii = bb.instructionIterator();
			while ((uncheckedFields.size() > 0) && ii.hasNext()) {
				InstructionHandle ih = ii.next();
				Instruction ins = ih.getInstruction();
				if (ins instanceof FieldInstruction) {
					FieldInstruction fi = (FieldInstruction) ins;
					String fieldName = fi.getFieldName(cpg);
					boolean justRemoved = uncheckedFields.remove(fieldName);
					
					if (ins instanceof GETFIELD) {
						if (justRemoved) {
							localizableFields.remove(fieldName);
							if (localizableFields.isEmpty())
								return;
						}
					} else {
						FieldInfo finfo = localizableFields.get(fieldName);
						if (finfo != null)
							finfo.setSrcLineAnnotation(SourceLineAnnotation.fromVisitedInstruction(clsContext, this, ih.getPosition()));
					}
				} 
			}
			
			if (uncheckedFields.size() > 0) {
				Iterator<Edge> oei = cfg.outgoingEdgeIterator(bb);
				while (oei.hasNext()) {
					Edge e = oei.next();
					BasicBlock cb = e.getTarget();
					if (!visitedBlocks.get(cb.getLabel())) {
						toBeProcessed.addLast(new BlockState(cb, uncheckedFields));
					}
				}
			}
		}
	}
	
	/**
	 * holds information about a field and it's first usage
	 */
	private static class FieldInfo {
		private final FieldAnnotation fieldAnnotation;
		private SourceLineAnnotation srcLineAnnotation;
		
		/**
		 * creates a FieldInfo from an annotation, and assumes no source line information
		 * @param fa the field annotation for this field
		 */
		public FieldInfo(final FieldAnnotation fa) {
			fieldAnnotation = fa;
			srcLineAnnotation = null;
		}
		
		/**
		 * set the source line annotation of first use for this field
		 * @param sla the source line annotation
		 */
		public void setSrcLineAnnotation(final SourceLineAnnotation sla) {
			if (srcLineAnnotation == null)
				srcLineAnnotation = sla;
		}
		
		/**
		 * get the field annotation for this field
		 * @return the field annotation
		 */
		public FieldAnnotation getFieldAnnotation() {
			return fieldAnnotation;
		}
		
		/**
		 * get the source line annotation for the first use of this field
		 * @return the source line annotation
		 */
		public SourceLineAnnotation getSrcLineAnnotation() {
			return srcLineAnnotation;
		}
	}
	
	/**
	 * holds the parse state of the current basic block, and what fields are left to be checked
	 */
	private static class BlockState {
		private final BasicBlock basicBlock;
		private final Set<String> uncheckedFields;

		/**
		 * creates a BlockState consisting of the next basic block to parse, 
		 * and what fields are to be checked
		 * @param bb the basic block to parse
		 * @param fields the fields to look for first use
		 */
		public BlockState(final BasicBlock bb, final Set<String> fields) {
			basicBlock = bb;
			uncheckedFields = new HashSet<String>(fields);
		}
		
		/**
		 * get the basic block to parse
		 * @return the basic block
		 */
		public BasicBlock getBasicBlock() {
			return basicBlock;
		}
		
		/**
		 * get the unchecked fields to look for
		 * @return the unchecked fields
		 */
		public Set<String> getUncheckedFields() {
			return uncheckedFields;
		}
	}
}
