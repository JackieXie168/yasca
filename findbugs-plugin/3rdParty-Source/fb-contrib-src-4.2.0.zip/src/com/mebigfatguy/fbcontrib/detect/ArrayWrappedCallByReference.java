/*
 * fb-contrib - Auxiliary detectors for Java programs
 * Copyright (C) 2005-2010 Dave Brosius
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.mebigfatguy.fbcontrib.detect;

import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

import org.apache.bcel.Constants;
import org.apache.bcel.classfile.Code;
import org.apache.bcel.classfile.Method;
import org.apache.bcel.generic.Type;

import com.mebigfatguy.fbcontrib.utils.RegisterUtils;

import edu.umd.cs.findbugs.BugInstance;
import edu.umd.cs.findbugs.BugReporter;
import edu.umd.cs.findbugs.BytecodeScanningDetector;
import edu.umd.cs.findbugs.OpcodeStack;
import edu.umd.cs.findbugs.ba.ClassContext;

/**
 * looks for methods that use an array of length one to pass a variable to achieve call
 * by pointer ala C++. It is better to define a proper return class type that holds all
 * the relevant information retrieved from the called method.
 */
public class ArrayWrappedCallByReference extends BytecodeScanningDetector {
	
	static class WrapperInfo {
		public int wrappedReg;
		public boolean wasArg;
		
		public WrapperInfo(int reg) {
			wrappedReg = reg;
			wasArg = false;
		}
	}
	
	private BugReporter bugReporter;
	private OpcodeStack stack;
	private Map<Integer, WrapperInfo> wrappers;
	
    /**
     * constructs a AWCBR detector given the reporter to report bugs on

     * @param bugReporter the sync of bug reports
     */	
	public ArrayWrappedCallByReference(BugReporter bugReporter) {
		this.bugReporter = bugReporter;
	}
	
	/**
	 * implement the visitor to create and clear the stack and wrappers
	 *
	 * @param classContext the context object of the currently parsed class
	 */
	@Override
	public void visitClassContext(ClassContext classContext) {
		try {
			stack = new OpcodeStack();
			wrappers = new HashMap<Integer, WrapperInfo>();
			super.visitClassContext(classContext);
		} finally {
			stack = null;
			wrappers = null;
		}
	}
	
    /**
	 * looks for methods that contain a NEWARRAY or ANEWARRAY opcodes
	 * 
	 * @param method the context object of the current method
	 * @return if the class uses synchronization
	 */
	public boolean prescreen(Method method) {
		BitSet bytecodeSet = getClassContext().getBytecodeSet(method);
		return (bytecodeSet != null) && (bytecodeSet.get(Constants.NEWARRAY) || bytecodeSet.get(Constants.ANEWARRAY));
	}
	
	/**
	 * implements the visitor to reset the stack of opcodes
	 * 
	 * @param obj the context object for the currently parsed code block
	 */
	@Override
	public void visitCode(Code obj) {
		if (prescreen(getMethod())) {
			stack.resetForMethodEntry(this);
			wrappers.clear();
			super.visitCode(obj);
		}
	}
	
	/**
	 * implements the visitor to wrapped array parameter calls
	 * 
	 * @param seen the currently visitor opcode
	 */
	@Override
	public void sawOpcode(int seen) {
		Integer userValue = null;
		try {
			stack.mergeJumps(this);
			
			if ((seen == NEWARRAY) || (seen == ANEWARRAY)) {
				if (stack.getStackDepth() > 0) {
					OpcodeStack.Item itm = stack.getStackItem(0);
					Integer size = (Integer)itm.getConstant();
					if ((size != null) && (size.intValue() == 1)) {
						userValue = Integer.valueOf(-1);
					}
				}
			} else if ((seen >= IASTORE) && (seen <= SASTORE)) {
				if (stack.getStackDepth() >= 2) {
					OpcodeStack.Item itm = stack.getStackItem(2);
					int reg = itm.getRegisterNumber();
					if (reg != -1) {
						WrapperInfo wi = wrappers.get(Integer.valueOf(reg));
						if (wi != null) {
							OpcodeStack.Item elItm = stack.getStackItem(0);
							wi.wrappedReg = elItm.getRegisterNumber();
						}
					} else {
						OpcodeStack.Item elItm = stack.getStackItem(0);
						if (elItm.getRegisterNumber() != -1)
							userValue = Integer.valueOf(elItm.getRegisterNumber());
					}
				}
			} else if ((seen == ASTORE) || ((seen >= ASTORE_0) && (seen <= ASTORE_3))) {
				if (stack.getStackDepth() >= 1) {
					OpcodeStack.Item itm = stack.getStackItem(0);
					String sig = itm.getSignature();
					if ((sig.length() > 0) && (itm.getSignature().charAt(0) == '[')) {
						int reg = RegisterUtils.getAStoreReg(this, seen);
						Integer elReg = (Integer)itm.getUserValue();
						if (elReg != null)
							wrappers.put(Integer.valueOf(reg), new WrapperInfo(elReg.intValue()));
					} else {
						Integer elReg = (Integer)itm.getUserValue();
						if (elReg != null) {
							int reg = RegisterUtils.getAStoreReg(this, seen);
							if (elReg.intValue() == reg) {
								bugReporter.reportBug(new BugInstance(this, "AWCBR_ARRAY_WRAPPED_CALL_BY_REFERENCE", NORMAL_PRIORITY )
												.addClass(this)
												.addMethod(this)
												.addSourceLine(this));
							}
						}
					}
				}
			} else if ((seen == INVOKEVIRTUAL)
				   ||  (seen == INVOKEINTERFACE)
				   ||  (seen == INVOKESPECIAL)
				   ||  (seen == INVOKESTATIC)) {
				String sig = getSigConstantOperand();
				Type[] args = Type.getArgumentTypes(sig);
				if (stack.getStackDepth() >= args.length) {
					for (int i = 0; i < args.length; i++) {
						Type t = args[i];
						String argSig = t.getSignature();
						if ((argSig.length() > 0) && (argSig.charAt(0) == '[')) {
							OpcodeStack.Item itm = stack.getStackItem(args.length - i - 1);
							int arrayReg = itm.getRegisterNumber();
							WrapperInfo wi = wrappers.get(Integer.valueOf(arrayReg));
							if (wi != null)
								wi.wasArg = true;
						}
					}
				}
			} else if ((seen >= IALOAD) && (seen <= SALOAD)) {
				if (stack.getStackDepth() >= 2) {
					OpcodeStack.Item arItm = stack.getStackItem(1);
					int arReg = arItm.getRegisterNumber();
					WrapperInfo wi = wrappers.get(Integer.valueOf(arReg));
					if ((wi != null) && wi.wasArg) {
						userValue = Integer.valueOf(wi.wrappedReg);
					}
				}
			} else if ((seen == ALOAD) || ((seen >= ALOAD_0) && (seen <= ALOAD_3))) {
				int reg = RegisterUtils.getALoadReg(this, seen);
				WrapperInfo wi = wrappers.get(Integer.valueOf(reg));
				if (wi != null)
					userValue = Integer.valueOf(wi.wrappedReg);
			} else if (((seen == ISTORE) || ((seen >= ISTORE_0) && (seen <= ISTORE_3)))
				   ||  ((seen == LSTORE) || ((seen >= LSTORE_0) && (seen <= LSTORE_3)))
				   ||  ((seen == DSTORE) || ((seen >= DSTORE_0) && (seen <= DSTORE_3)))
				   ||  ((seen == FSTORE) || ((seen >= FSTORE_0) && (seen <= FSTORE_3)))) {
				if (stack.getStackDepth() >= 1) {
					OpcodeStack.Item itm = stack.getStackItem(0);
					Integer elReg = (Integer)itm.getUserValue();
					if (elReg != null) {
						int reg = RegisterUtils.getStoreReg(this, seen);
						if (elReg.intValue() == reg) {
							bugReporter.reportBug(new BugInstance(this, "AWCBR_ARRAY_WRAPPED_CALL_BY_REFERENCE", NORMAL_PRIORITY )
											.addClass(this)
											.addMethod(this)
											.addSourceLine(this));
						}
					}
				}
			}
		} finally {
			stack.sawOpcode(this, seen);
			if (userValue != null) {
				if (stack.getStackDepth() > 0) {
					OpcodeStack.Item itm = stack.getStackItem(0);
					itm.setUserValue(userValue);
				}
			}
		}
	}	
}
