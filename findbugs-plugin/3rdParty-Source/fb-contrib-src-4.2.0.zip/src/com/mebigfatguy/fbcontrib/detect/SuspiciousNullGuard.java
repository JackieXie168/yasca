/*
 * fb-contrib - Auxiliary detectors for Java programs
 * Copyright (C) 2005-2010 Dave Brosius
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.mebigfatguy.fbcontrib.detect;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.bcel.classfile.Code;
import org.apache.bcel.classfile.LocalVariable;
import org.apache.bcel.classfile.LocalVariableTable;

import com.mebigfatguy.fbcontrib.utils.RegisterUtils;

import edu.umd.cs.findbugs.BugInstance;
import edu.umd.cs.findbugs.BugReporter;
import edu.umd.cs.findbugs.BytecodeScanningDetector;
import edu.umd.cs.findbugs.OpcodeStack;
import edu.umd.cs.findbugs.ba.ClassContext;
import edu.umd.cs.findbugs.ba.XField;

/**
 * looks for code that checks to see if a field or local variable is not null,
 * before entering a code block either an if, or while statement, and then doesn't 
 * reference that field or local in the block of code that is guarded by the null 
 * check. It is likely that null check is being done on the wrong variable, either
 * because of a copy/paste error, or a change in implementation.
 */
public class SuspiciousNullGuard extends BytecodeScanningDetector {
	
	private BugReporter bugReporter;
	private OpcodeStack stack;
	private LocalVariableTable lvt;
	private Map<Integer, NullGuard> nullGuards;
	
	/**
     * constructs a SNG detector given the reporter to report bugs on
     * @param bugReporter the sync of bug reports
	 */
	public SuspiciousNullGuard(BugReporter bugReporter) {
		this.bugReporter = bugReporter;
	}
	
	/**
	 * overrides the visitor to initialize and tear down the opcode stack
	 * 
	 * @param classContext the context object of the currently parsed class
	 */
	@Override
	public void visitClassContext(ClassContext classContext) {
		try {
			stack = new OpcodeStack();
			nullGuards = new HashMap<Integer, NullGuard>();
			super.visitClassContext(classContext);
		} finally {
			stack = null;
		}
	}
	
	/**
	 * overrides the visitor to reset the stack
	 * 
	 * @param obj the context object of the currently parsed code block
	 */
	@Override
	public void visitCode(Code obj) {
		try {
			stack.resetForMethodEntry(this);
			lvt = getMethod().getLocalVariableTable();
			nullGuards.clear();
			super.visitCode(obj);
		} finally {
			lvt = null;
		}
	}
	
	/**
	 * overrides the visitor to look for bad null guards
	 * 
	 * @param seen the opcode of the currently visited instruction
	 */
	@Override
	public void sawOpcode(int seen) {
		try {
			Integer pc = Integer.valueOf(getPC());
			NullGuard guard = nullGuards.remove(pc);
			if ((guard != null) && guard.sawSignatureOfGuard()) {
				boolean localBug = guard.getRegister() >= 0;
				bugReporter.reportBug(new BugInstance(this, localBug ? "SNG_SUSPICIOUS_NULL_LOCAL_GUARD" : "SNG_SUSPICIOUS_NULL_FIELD_GUARD", localBug ? NORMAL_PRIORITY : LOW_PRIORITY)
						                    .addClass(this)
						                    .addMethod(this)
						                    .addSourceLine(this, guard.getLocation()));
			}
			
			switch (seen) {
				case IFNULL: {
					if (stack.getStackDepth() > 0) {
						OpcodeStack.Item item = stack.getStackItem(0);
						int reg = item.getRegisterNumber();
						Integer target = Integer.valueOf(getBranchTarget());
						if (reg >= 0) {
							nullGuards.put(target, new NullGuard(reg, pc.intValue(), item.getSignature()));
						} else {
							XField xf = item.getXField();
							if (xf != null) {
								nullGuards.put(target, new NullGuard(xf, pc.intValue(), item.getSignature()));
							}
						}
					}
				}
				break;
				
				case ALOAD:
				case ALOAD_0:
				case ALOAD_1:
				case ALOAD_2:
				case ALOAD_3: {
					if (lvt != null) {
						LocalVariable lv = lvt.getLocalVariable(RegisterUtils.getALoadReg(this, seen), getNextPC());
						if (lv != null) {
							markNullGuards(lv.getSignature());
						}
					}
				}
				break;
					
				case ASTORE:
				case ASTORE_0:
				case ASTORE_1:
				case ASTORE_2:
				case ASTORE_3: {
					removeGuardForRegister(RegisterUtils.getAStoreReg(this, seen));
				}
				break;
				
				case GETFIELD: {
					markNullGuards(getSigConstantOperand());
				}
				break;
				
				case PUTFIELD: {
					removeGuardForField(getXField());
				}
				break;
				
				case INVOKEVIRTUAL:
				case INVOKEINTERFACE: {
					if (nullGuards.size() > 0) {
						String clsName = getClassConstantOperand();
						String methodName = getNameConstantOperand();
						if ("java/io/PrintStream".equals(clsName) && methodName.startsWith("print")) {
							nullGuards.clear();
						}
					}
				}
				break;
				
				case IFNONNULL:
				case ATHROW: {
					nullGuards.clear();					
				}
				break;
				
				case GOTO: {
					if (stack.getStackDepth() > 0) {
						nullGuards.clear();
					}
				}
				break;
			}
		} finally {
			stack.sawOpcode(this, seen);
			if (stack.getStackDepth() > 0) {
				OpcodeStack.Item item = stack.getStackItem(0);
				int reg = item.getRegisterNumber();
				if (reg >= 0) {
					removeGuardForRegister(reg);
				} else {
					XField field = item.getXField();
					if (field != null)
						removeGuardForField(field);
				}
			}
		}
	}
	
	private void markNullGuards(String signature) {
		for (NullGuard ng : nullGuards.values()) {
			if (ng.getSignature().equals(signature)) {
				ng.markSignatureOfGuard();
			}
		}
	}
	
	private void removeGuardForRegister(int reg) {
		Iterator<NullGuard> it = nullGuards.values().iterator();
		while (it.hasNext()) {
			NullGuard guard = it.next();
			if (reg == guard.getRegister()) {
				it.remove();
			}
		}
	}
	
	private void removeGuardForField(XField field) {
		Iterator<NullGuard> it = nullGuards.values().iterator();
		while (it.hasNext()) {
			NullGuard guard = it.next();
			if (field != null) {
				if (field.equals(guard.getField())) {
					it.remove();
				}
			}
		}
	}
	
	static class NullGuard {
		int register;
		XField field;
		int location;
		String signature;
		boolean sawSignature = false;
		
		public NullGuard(int reg, int start, String guardSignature) {
			register = reg;
			field = null;
			location = start;
			signature = guardSignature;
		}


		public NullGuard(XField xf, int start, String guardSignature) {
			register = -1;
			field = xf;
			location = start;
			signature = guardSignature;
		}

		public int getRegister() {
			return register;
		}
		
		public XField getField() {
			return field;
		}
		
		public int getLocation() {
			return location;
		}
		
		public String getSignature() {
			return signature;
		}
		
		public void markSignatureOfGuard() {
			sawSignature = true;
		}
		
		public boolean sawSignatureOfGuard() {
			return sawSignature;
		}
	}
}
