/*
 * fb-contrib - Auxiliary detectors for Java programs
 * Copyright (C) 2005-2009 Dave Brosius
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.mebigfatguy.fbcontrib.utils;

import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Method;

public class SignatureUtils {
	
	public static boolean isInheritedMethod(JavaClass cls, String methodName, String signature) throws ClassNotFoundException {
		JavaClass[] infs = cls.getAllInterfaces();
		if (findInheritedMethod(infs, methodName, signature) != null) {
			return true;
		}
		
		JavaClass[] supers = cls.getSuperClasses();
		for (int i = 0; i < supers.length; i++) {
			if ("java.lang.Object".equals(supers[i].getClassName())) {
				supers[i] = null;
			}
		}
		return findInheritedMethod(supers, methodName, signature) != null;
	}
	
	/**
	 * returns whether or not the two packages have the same first 'depth' parts, if they exist
	 * 
	 * @param packName1 the first package to check
	 * @param packName2 the second package to check
	 * @param depth the number of package parts to check
	 * 
	 * @return if they are similar
	 */
	public static boolean similarPackages(String packName1, String packName2, int depth) {
		if (depth == 0)
			return true;
		
		packName1 = packName1.replace('/', '.');
		packName2 = packName2.replace('/', '.');
		
		int dot1 = packName1.indexOf('.');
		int dot2 = packName2.indexOf('.');
		if (dot1 < 0)
			return (dot2 < 0);
		else if (dot2 < 0)
			return false;
		
		String s1 = packName1.substring(0, dot1);
		String s2 = packName2.substring(0, dot2);
		
		if (!s1.equals(s2))
			return false;
		
		return similarPackages(packName1.substring(dot1+1), packName2.substring(dot2+1), depth-1);
	}

	
	private static JavaClass findInheritedMethod(JavaClass[] classes, String methodName, String signature) {
		for (JavaClass cls : classes) {
			if (cls != null) {
				Method[] methods = cls.getMethods();
				for (Method m : methods) {
					if (!m.isPrivate()) {
						if (m.getName().equals(methodName)) {
							if (m.getSignature().equals(signature))
								return cls;
						}
					}
				}
			}
		}
		return null;
	}
}
