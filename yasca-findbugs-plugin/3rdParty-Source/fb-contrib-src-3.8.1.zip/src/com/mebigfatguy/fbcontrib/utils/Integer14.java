/*
 * fb-contrib - Auxiliary detectors for Java programs
 * Copyright (C) 2005-2009 Dave Brosius
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.mebigfatguy.fbcontrib.utils;

public class Integer14
{
    public static final int MIN_CACHE = -10;
    public static final int MAX_CACHE = 256;
    
    private static final Integer[] cachedInts = new Integer[MAX_CACHE-MIN_CACHE+1];
    static {
        for (int i = MIN_CACHE; i <= MAX_CACHE; i++)
            cachedInts[i-MIN_CACHE] = new Integer(i);
    }
    
    private Integer14()
    {}
    
    public static Integer valueOf(int i) 
    {
        if ((i < MIN_CACHE) || (i > MAX_CACHE))
            return new Integer(i);
        return cachedInts[i-MIN_CACHE];
    }
}
