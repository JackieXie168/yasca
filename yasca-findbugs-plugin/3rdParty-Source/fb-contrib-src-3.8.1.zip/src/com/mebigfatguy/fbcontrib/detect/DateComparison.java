/*
 * fb-contrib - Auxiliary detectors for Java programs
 * Copyright (C) 2005-2009 Dave Brosius
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.mebigfatguy.fbcontrib.detect;

import java.util.HashSet;
import java.util.Set;

import org.apache.bcel.classfile.Method;

import com.mebigfatguy.fbcontrib.utils.RegisterUtils;

import edu.umd.cs.findbugs.BugInstance;
import edu.umd.cs.findbugs.BugReporter;
import edu.umd.cs.findbugs.BytecodeScanningDetector;


/**
 * Looks for inefficient comparison of Date objects using two comparisons when one would do.
 */
public class DateComparison extends BytecodeScanningDetector
{
	private static final int SEEN_NOTHING = 0;
	private static final int SEEN_LOAD1_1 = 1;
	private static final int SEEN_LOAD1_2 = 2;
	private static final int SEEN_CMP_1 = 3;
	private static final int SEEN_IFNE = 4;
	private static final int SEEN_LOAD2_1 = 5;
	private static final int SEEN_LOAD2_2 = 6;
	private static final int SEEN_CMP_2 = 7;
	
	private static final Set<String> dateClasses = new HashSet<String>();
	static {
		dateClasses.add("java.util.Date");
		dateClasses.add("java.sql.Date");
		dateClasses.add("java.sql.Timestamp");
	}
	
    private BugReporter bugReporter;
    private int state;
    private int register1_1;
    private int register1_2;
    private int register2_1;
    private int register2_2;

    /**
     * constructs a DDC detector given the reporter to report bugs on
     * @param bugReporter the sync of bug reports
	 */
    public DateComparison(BugReporter bugReporter) {
        this.bugReporter = bugReporter;
    }

	/**
	 * overrides the visitor to reset the registers
	 * 
	 * @param obj the method of the currently parsed method
	 */
	@Override
	public void visit(Method obj) {
        state = SEEN_NOTHING;
        register1_1 = -1;
        register1_2 = -1;
        register2_1 = -1;
        register2_2 = -1;
        super.visit(obj);
    }

	/**
	 * overrides the visitor to look for double date compares using the same registers
	 * 
	 * @param seen the current opcode parsed.
	 */
	@Override
	public void sawOpcode(int seen) {
        switch (state) {
        	case SEEN_NOTHING:
        		if ((seen == ALOAD) || ((seen >= ALOAD_0) && (seen <= ALOAD_3))) {
        			register1_1 = RegisterUtils.getALoadReg(this, seen);
        			state = SEEN_LOAD1_1;
                }
        	break;
        	
        	case SEEN_LOAD1_1:
        		if ((seen == ALOAD) || ((seen >= ALOAD_0) && (seen <= ALOAD_3)))
        			register1_2 = RegisterUtils.getALoadReg(this, seen);
        			
        		if (register1_2 > -1)
        			state = SEEN_LOAD1_2;
        		else
        			state = SEEN_NOTHING;
        	break;
        	
        	case SEEN_LOAD1_2:
        		if (seen == INVOKEVIRTUAL) {
        			String cls = getDottedClassConstantOperand();
        			if (dateClasses.contains(cls)) {
        				String methodName = getNameConstantOperand();
        				if ("equals".equals(methodName)
        				||  "after".equals(methodName)
        				||  "before".equals(methodName)) {
        					state = SEEN_CMP_1;
        				}
        			}
        		}
        		if (state != SEEN_CMP_1)
        			state = SEEN_NOTHING;
        	break;
        	
        	case SEEN_CMP_1:
        		if (seen == IFNE)
        			state = SEEN_IFNE;
        		else
        			state = SEEN_NOTHING;
        	break;

			case SEEN_IFNE:
				if ((seen == ALOAD) || ((seen >= ALOAD_0) && (seen <= ALOAD_3)))
	    			register2_1 = RegisterUtils.getALoadReg(this, seen);
	    			
	    		if (register2_1 > -1)
	    			state = SEEN_LOAD2_1;
	    		else
	    			state = SEEN_NOTHING;
	    	break;

			case SEEN_LOAD2_1:
				if ((seen == ALOAD) || ((seen >= ALOAD_0) && (seen <= ALOAD_3)))
	    			register2_2 = RegisterUtils.getALoadReg(this, seen);
	    			
	    		if ((register2_2 > -1) 
	    		&&  ( ((register1_1 == register2_1) && (register1_2 == register2_2))
	    		    ||((register1_1 == register2_2) && (register1_2 == register2_1))))
	    				state = SEEN_LOAD2_2;
	    		else
	    			state = SEEN_NOTHING;
	    	break;
	    	
	    	case SEEN_LOAD2_2:
        		if (seen == INVOKEVIRTUAL) {
        			String cls = getDottedClassConstantOperand();
        			if (dateClasses.contains(cls)) {
        				String methodName = getNameConstantOperand();
        				if ("equals".equals(methodName)
        				||  "after".equals(methodName)
        				||  "before".equals(methodName)) {
        					state = SEEN_CMP_2;
        				}
        			}
        		}
        		if (state != SEEN_CMP_2)
        			state = SEEN_NOTHING;
	    	break;
	    	
	    	case SEEN_CMP_2:
	    		if (seen == IFEQ) {
	    			bugReporter.reportBug(new BugInstance("DDC_DOUBLE_DATE_COMPARISON", NORMAL_PRIORITY)
								.addClassAndMethod(this)
								.addSourceLine(this));
	    		}
	    		state = SEEN_NOTHING;
	    	break;
        }
    }
}

