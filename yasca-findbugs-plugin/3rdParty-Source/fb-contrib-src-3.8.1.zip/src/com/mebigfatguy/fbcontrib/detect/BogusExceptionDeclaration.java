package com.mebigfatguy.fbcontrib.detect;

import java.util.HashSet;
import java.util.Set;

import org.apache.bcel.Repository;
import org.apache.bcel.classfile.Code;
import org.apache.bcel.classfile.ExceptionTable;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Method;

import edu.umd.cs.findbugs.BugInstance;
import edu.umd.cs.findbugs.BugReporter;
import edu.umd.cs.findbugs.BytecodeScanningDetector;
import edu.umd.cs.findbugs.ba.ClassContext;

/**
 * looks for constructors, private methods or static methods that declare that they
 * throw specific checked exceptions, but that do not. This just causes callers of 
 * these methods to do extra work to handle an exception that will never be thrown.
 */
public class BogusExceptionDeclaration extends BytecodeScanningDetector {
	private static JavaClass runtimeExceptionClass;
	private static final Set<String> safeClasses = new HashSet<String>();
	static {
		try {
			safeClasses.add("java/lang/Object");
			safeClasses.add("java/lang/String");
			safeClasses.add("java/lang/Integer");
			safeClasses.add("java/lang/Long");
			safeClasses.add("java/lang/Float");
			safeClasses.add("java/lang/Double");
			safeClasses.add("java/lang/Short");
			safeClasses.add("java/lang/Boolean");
			
			runtimeExceptionClass = Repository.lookupClass("java/lang/RuntimeException");
		} catch (ClassNotFoundException cnfe) {
			runtimeExceptionClass = null;
		}
	}
	private final BugReporter bugReporter;
	private Set<String> declaredCheckedExceptions;
	
	public BogusExceptionDeclaration(BugReporter bugReporter) {
		this.bugReporter = bugReporter;
	}
	
	
	@Override
	public void visitClassContext(ClassContext classContext) {
		try {
			if (runtimeExceptionClass != null) {
				declaredCheckedExceptions = new HashSet<String>();
				super.visitClassContext(classContext);
			}
		} finally {
			declaredCheckedExceptions = null;
		}
	}
	
	/**
	 * implements the visitor to see if the method declares that it throws any
	 * checked exceptions.
	 * 
	 * @param obj the context object of the currently parsed code block
	 */
	@Override
	public void visitCode(Code obj) {
		declaredCheckedExceptions.clear();
		Method method = getMethod();
		if (method.isStatic() || method.isPrivate() || "<init>".equals(method.getName())) {
			ExceptionTable et = method.getExceptionTable();
			if (et != null) {
				String[] exNames = et.getExceptionNames();
				for (String exName : exNames) {
					try {
						JavaClass exCls = Repository.lookupClass(exName);
						if (!exCls.instanceOf(runtimeExceptionClass)) {
							declaredCheckedExceptions.add(exName);
						}
					} catch (ClassNotFoundException cnfe) {
						bugReporter.reportMissingClass(cnfe);
					}
				}
				if (!declaredCheckedExceptions.isEmpty()) {
					super.visitCode(obj);
					if (!declaredCheckedExceptions.isEmpty()) {
						BugInstance bi = new BugInstance(this, "BED_BOGUS_EXCEPTION_DECLARATION", NORMAL_PRIORITY)
									.addClass(this)
									.addMethod(this)
									.addSourceLine(this, 0);
						for (String ex : declaredCheckedExceptions) {
							bi.addString(ex.replaceAll("/", "."));
						}
						bugReporter.reportBug(bi);
					}
				}
			}
		}
	}
	
	/**
	 * implements the visitor to look for method calls that could throw the exceptions
	 * that are listed in the declaration.
	 */
	@Override
	public void sawOpcode(int seen) {
		if (declaredCheckedExceptions.isEmpty()) {
			return;
		}
		
		if ((seen == INVOKEVIRTUAL) 
		||  (seen == INVOKEINTERFACE)
		||  (seen == INVOKESPECIAL)
		||  (seen == INVOKESTATIC)) {
			String clsName = getClassConstantOperand();
			if (!safeClasses.contains(clsName)) {
				try {
					JavaClass cls = Repository.lookupClass(clsName);
					Method[] methods = cls.getMethods();
					String methodName = getNameConstantOperand();
					String signature = getSigConstantOperand();
					boolean found = false;
					for (Method m : methods) {
						if (m.getName().equals(methodName) && m.getSignature().equals(signature)) {
							ExceptionTable et = m.getExceptionTable();
							if (et != null) {
								String[] thrownExceptions = et.getExceptionNames();
								for (String thrownException : thrownExceptions) {
									declaredCheckedExceptions.remove(thrownException);
									JavaClass exCls = Repository.lookupClass(thrownException);
									JavaClass superCls = exCls.getSuperClass();
									do {
										exCls = superCls;
										if (exCls != null) {
    										declaredCheckedExceptions.remove(exCls.getClassName());
    										superCls = exCls.getSuperClass();
										} else {
										    break;
										}
									} while (!declaredCheckedExceptions.isEmpty() && !"java.lang.Exception".equals(exCls.getClassName()) && !"java.lang.Error".equals(exCls.getClassName()));
										
								}
							} else {
								declaredCheckedExceptions.clear();
							}
							found = true;
							break;
						}
					}
					
					if (!found) {
						declaredCheckedExceptions.clear();
					}
				}
				catch (ClassNotFoundException cnfe) {
					bugReporter.reportMissingClass(cnfe);
					declaredCheckedExceptions.clear();
				}
			}
		}
	}
}
