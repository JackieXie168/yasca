/*
 * fb-contrib - Auxiliary detectors for Java programs
 * Copyright (C) 2005-2009 Dave Brosius
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.mebigfatguy.fbcontrib.detect;

import org.apache.bcel.classfile.Code;
import org.apache.bcel.classfile.Constant;
import org.apache.bcel.classfile.ConstantClass;
import org.apache.bcel.classfile.ConstantPool;
import org.apache.bcel.classfile.ConstantUtf8;

import edu.umd.cs.findbugs.BugInstance;
import edu.umd.cs.findbugs.BugReporter;
import edu.umd.cs.findbugs.BytecodeScanningDetector;
import edu.umd.cs.findbugs.OpcodeStack;
import edu.umd.cs.findbugs.ba.ClassContext;

public class LoggerOddities extends BytecodeScanningDetector {
	private final BugReporter bugReporter;
	private OpcodeStack stack;
	private String clsName;
	
    /**
     * constructs a LO detector given the reporter to report bugs on.

     * @param bugReporter the sync of bug reports
     */
	public LoggerOddities(final BugReporter bugReporter) {
		this.bugReporter = bugReporter;
	}
	
    
	/**
	 * implements the visitor to discover what the class name is if it is a normal class,
	 * or the owning class, if the class is an anonymous class.
	 * 
	 * @param classContext the context object of the currently parsed class
	 */
    @Override
    public void visitClassContext(ClassContext classContext) {
        try {
            stack = new OpcodeStack();
            clsName = classContext.getJavaClass().getClassName();
            int subclassIndex = clsName.indexOf('$');
            while (subclassIndex >= 0) {
                String simpleName = clsName.substring(subclassIndex+1);
                try {
                    Integer.parseInt(simpleName);
                    clsName = clsName.substring(0, subclassIndex);
                    subclassIndex = clsName.indexOf('$');
                } catch (NumberFormatException nfe) {
                    subclassIndex = -1;
                }
            }
            clsName = clsName.replace('.', '/');
            super.visitClassContext(classContext);
        } finally {
            stack = null;
        }
    }
    
    /**
     * implements the visitor to reset the stack
     * 
     * @param obj the context object of the currently parsed code block
     */
    @Override
    public void visitCode(Code obj) {
        stack.resetForMethodEntry(this);
        super.visitCode(obj);
    }
    
    /**
     * implements the visitor to look for calls to Logger.getLogger with the wrong class name
     * 
     * @param seen the opcode of the currently parsed instruction
     */
    @Override
    public void sawOpcode(int seen) {
        String ldcClassName = null;
        try {
            if ((seen == LDC) || (seen == LDC_W)) {
                Constant c = getConstantRefOperand();
                if (c instanceof ConstantClass) {
                    ConstantPool pool = getConstantPool();
                    ldcClassName = ((ConstantUtf8)pool.getConstant(((ConstantClass) c).getNameIndex())).getBytes();
                }
            } else if (seen == INVOKESTATIC) {
                String callingClsName = getClassConstantOperand();
                String mthName = getNameConstantOperand();
                
                String loggingClassName = null;

                if ("org/slf4j/LoggerFactory".equals(callingClsName)
                &&  "getLogger".equals(mthName)) {
                    String signature = getSigConstantOperand();
                    
                    if ("(Ljava/lang/Class;)Lorg/slf4j/Logger;".equals(signature)) {
                    	if (stack.getStackDepth() > 0) {
	                        OpcodeStack.Item item = stack.getStackItem(0);
	                        loggingClassName = (String)item.getUserValue();
	                    }
                    } else if ("(Ljava/lang/String;)Lorg/slf4j/Logger;".equals(signature)) {
                    	if (stack.getStackDepth() > 0) {
	                        OpcodeStack.Item item = stack.getStackItem(0);
	                        loggingClassName = (String)item.getConstant();
	                        if (loggingClassName != null)
	                        	loggingClassName = loggingClassName.replace('.', '/');
	                    }
                    }                	
                } else if ("org/apache/log4j/Logger".equals(callingClsName)
                       &&  "getLogger".equals(mthName)) {
                    String signature = getSigConstantOperand();
                    
                    if ("(Ljava/lang/Class;)Lorg/apache/log4j/Logger;".equals(signature)) {
                    	if (stack.getStackDepth() > 0) {
	                        OpcodeStack.Item item = stack.getStackItem(0);
	                        loggingClassName = (String)item.getUserValue();
	                    }
                    } else if ("(Ljava/lang/String;)Lorg/apache/log4j/Logger;".equals(signature)) {
                    	if (stack.getStackDepth() > 0) {
	                        OpcodeStack.Item item = stack.getStackItem(0);
	                        loggingClassName = (String)item.getConstant();
	                        if (loggingClassName != null)
	                        	loggingClassName = loggingClassName.replace('.', '/');
	                    }
                    } else if ("(Ljava/lang/String;Lorg/apache/log4j/spi/LoggerFactory;)Lorg/apache/log4j/Logger;".equals(signature)) {
                    	if (stack.getStackDepth() > 1) {
	                        OpcodeStack.Item item = stack.getStackItem(1);
	                        loggingClassName = (String)item.getConstant();
	                        if (loggingClassName != null)
	                        	loggingClassName = loggingClassName.replace('.', '/');
	                    }
                    }
                }

                if (loggingClassName != null) {
                    if (stack.getStackDepth() > 0) {
                        if (!loggingClassName.equals(clsName)) {
                            bugReporter.reportBug(new BugInstance(this, "LO_SUSPECT_LOG_CLASS", (callingClsName.indexOf('$') >= 0) ? LOW_PRIORITY : NORMAL_PRIORITY)
                                        .addClass(this)
                                        .addMethod(this)
                                        .addSourceLine(this));
                        }
                    }
                }
            }
        } finally {
            stack.sawOpcode(this, seen);
            if (ldcClassName != null) {
                if (stack.getStackDepth() > 0) {
                    OpcodeStack.Item item = stack.getStackItem(0);
                    item.setUserValue(ldcClassName);
                }
            }
        }
    }
}
