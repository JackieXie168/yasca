/*
 * fb-contrib - Auxiliary detectors for Java programs
 * Copyright (C) 2005-2009 Dave Brosius
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.mebigfatguy.fbcontrib.detect;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.bcel.Repository;
import org.apache.bcel.classfile.Code;
import org.apache.bcel.classfile.Field;
import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.generic.Type;

import com.mebigfatguy.fbcontrib.utils.Integer14;
import com.mebigfatguy.fbcontrib.utils.RegisterUtils;

import edu.umd.cs.findbugs.BugInstance;
import edu.umd.cs.findbugs.BugReporter;
import edu.umd.cs.findbugs.BytecodeScanningDetector;
import edu.umd.cs.findbugs.FieldAnnotation;
import edu.umd.cs.findbugs.OpcodeStack;
import edu.umd.cs.findbugs.SourceLineAnnotation;
import edu.umd.cs.findbugs.ba.ClassContext;
import edu.umd.cs.findbugs.ba.XFactory;
import edu.umd.cs.findbugs.ba.XField;

/**
 * looks for interfaces that ignore 508 compliance, including not using JLabel.setLabelFor,
 * Using null layouts, 
 */
public class Section508Compliance extends BytecodeScanningDetector 
{
	private static JavaClass windowClass;
	private static JavaClass componentClass;
	private static JavaClass jcomponentClass;
	private static JavaClass accessibleClass;
	static {
		try {
			windowClass = Repository.lookupClass("java/awt/Window");
		} catch (ClassNotFoundException cnfe) {
			windowClass = null;
		}
		try {
			componentClass = Repository.lookupClass("javax/awt/Component");
		} catch (ClassNotFoundException cnfe) {
			componentClass = null;
		}
		try {
			jcomponentClass = Repository.lookupClass("javax/swing/JComponent");
		} catch (ClassNotFoundException cnfe) {
			jcomponentClass = null;
		}
		try {
			accessibleClass = Repository.lookupClass("javax.accessibility.Accessible");
		} catch (ClassNotFoundException cnfe) {
			accessibleClass = null;
		}
	}
	private BugReporter bugReporter;
	private OpcodeStack stack;
	private Set<XField> fieldLabels;
	private Map<Integer, SourceLineAnnotation> localLabels;
	
	/**
     * constructs a S508C detector given the reporter to report bugs on
     * @param bugReporter the sync of bug reports
	 */
	public Section508Compliance(BugReporter bugReporter) {
		this.bugReporter = bugReporter;
	}
	
	/**
	 * implements the visitor to create and clear the stack
	 * 
	 * @param classContext the context object of the currently visited class
	 */
	@Override
	public void visitClassContext(ClassContext classContext) {
		try {
			if ((jcomponentClass != null) && (accessibleClass != null)) {
				JavaClass cls = classContext.getJavaClass();
				if (cls.instanceOf(jcomponentClass)) {
					if (!cls.implementationOf(accessibleClass)) {
						bugReporter.reportBug(new BugInstance(this, "S508C_NON_ACCESSIBLE_JCOMPONENT", NORMAL_PRIORITY)
										.addClass(cls));
					}
				}
			}
			
			stack = new OpcodeStack();
			fieldLabels = new HashSet<XField>();
			localLabels = new HashMap<Integer, SourceLineAnnotation>();
			super.visitClassContext(classContext);
			for (XField fa : fieldLabels) {
				bugReporter.reportBug(new BugInstance(this, "S508C_NO_SETLABELFOR", NORMAL_PRIORITY)
								.addClass(this)
								.addField(fa));
			}
		} catch (ClassNotFoundException cnfe) {
			bugReporter.reportMissingClass(cnfe);
		} finally {
			stack = null;
			fieldLabels = null;
			localLabels = null;
		}
	}
	
	/**
	 * looks for fields that are JLabels and stores them in a set
	 * 
	 * @param obj the field object of the current field
	 */
	@Override
	public void visitField(Field obj) {
		String fieldSig = obj.getSignature();
		if ("Ljavax/swing/JLabel;".equals(fieldSig)) {
			FieldAnnotation fa = FieldAnnotation.fromVisitedField(this);

			fieldLabels.add(XFactory.createXField(fa));
		}
	}
	
	/**
	 * implements the visitor to reset the stack
	 * 
	 * @param obj the context object for the currently visited code block
	 */
	@Override
	public void visitCode(Code obj) {
		stack.resetForMethodEntry(this);
		localLabels.clear();
		super.visitCode(obj);
		for (SourceLineAnnotation sla : localLabels.values()) {
			BugInstance bug = new BugInstance(this, "S508C_NO_SETLABELFOR", NORMAL_PRIORITY)
									.addClass(this)
									.addMethod(this);
									
			if (sla != null)
				bug.addSourceLine(sla);
			
			bugReporter.reportBug(bug);
		}
	}
	
	/**
	 * implements the visitor to find 508 compliance concerns
	 * 
	 * @param seen the opcode of the currently parsed instruction
	 */
	@Override
	public void sawOpcode(int seen) {
        boolean sawTextLabel = false;
		try {
			stack.mergeJumps(this);
			if ((seen == ASTORE) || ((seen >= ASTORE_0) && (seen <= ASTORE_3))) {
				if (stack.getStackDepth() > 0) {
					OpcodeStack.Item item = stack.getStackItem(0);
					if ("Ljavax/swing/JLabel;".equals(item.getSignature())
                    &&  (item.getUserValue() != null)) {
						int reg = RegisterUtils.getAStoreReg(this, seen);
						localLabels.put(Integer14.valueOf(reg), SourceLineAnnotation.fromVisitedInstruction(this));
					}
				}
            } else if (seen == PUTFIELD) {
                if (stack.getStackDepth() > 0) {
                    OpcodeStack.Item item = stack.getStackItem(0);
                    if (item.getUserValue() == null) {
                        FieldAnnotation fa = new FieldAnnotation(getClassName(), getNameConstantOperand(), getSigConstantOperand(), false);
                        if (fa != null)
                            fieldLabels.remove(XFactory.createXField(fa));
                    }
                }
            } else if (seen == INVOKESPECIAL) {
                String className = getClassConstantOperand();
                String methodName = getNameConstantOperand();
                if ("javax/swing/JLabel".equals(className)
                &&  "<init>".equals(methodName)) {
                    String signature = getSigConstantOperand();
                    if (signature.indexOf("Ljava/lang/String;") >= 0) {
                        sawTextLabel = true;
                    }
                }
			} else if (seen == INVOKEVIRTUAL) {
				String className = getClassConstantOperand();
				String methodName = getNameConstantOperand();
				
				if ("java/awt/Container".equals(className)) {
					if ("setLayout".equals(methodName)) {
						if (stack.getStackDepth() > 0) {
							OpcodeStack.Item item = stack.getStackItem(0);
							if (item.isNull())
								bugReporter.reportBug(new BugInstance(this, "S508C_NULL_LAYOUT", NORMAL_PRIORITY)
												.addClass(this)
												.addMethod(this)
												.addSourceLine(this));
						}
					}
				} else if ("javax/swing/JLabel".equals(className)) {
					if ("setLabelFor".equals(methodName)) {
						if (stack.getStackDepth() > 1) {
							OpcodeStack.Item item = stack.getStackItem(1);
							XField field = item.getXField();
							if (field != null)
								fieldLabels.remove(field);
							else {
								int reg = item.getRegisterNumber();
								if (reg >= 0) {
									localLabels.remove(Integer14.valueOf(reg));
								}
							}
						}
					}
				} else if ("setSize".equals(methodName)) {
					int argCount = Type.getArgumentTypes(getSigConstantOperand()).length;
					if ((windowClass != null) && (stack.getStackDepth() > argCount)) {
						OpcodeStack.Item item = stack.getStackItem(argCount);
						JavaClass cls = item.getJavaClass();
						if (cls.instanceOf(windowClass)) {
							bugReporter.reportBug(new BugInstance(this, "S508C_NO_SETSIZE", NORMAL_PRIORITY)
											.addClass(this)
											.addMethod(this)
											.addSourceLine(this));
						}
					}
				} 
				
				if ("setBackground".equals(methodName)
				||  "setForeground".equals(methodName)) {
					int argCount = Type.getArgumentTypes(getSigConstantOperand()).length;
					if (stack.getStackDepth() > argCount) {
						OpcodeStack.Item item = stack.getStackItem(argCount);
						JavaClass cls = item.getJavaClass();
						if (((jcomponentClass != null) && cls.instanceOf(jcomponentClass)) 
						||  ((componentClass != null) && cls.instanceOf(componentClass))) {
							bugReporter.reportBug(new BugInstance(this, "S508C_SET_COMP_COLOR", NORMAL_PRIORITY)
									.addClass(this)
									.addMethod(this)
									.addSourceLine(this));
						}
					}			
				}
			}
		} catch (ClassNotFoundException cnfe) {
			bugReporter.reportMissingClass(cnfe);
		} finally {
			stack.sawOpcode(this, seen);
            if (sawTextLabel) {
                if (stack.getStackDepth() > 0) {
                    OpcodeStack.Item item = stack.getStackItem(0);
                    item.setUserValue(Boolean.TRUE);
                }
            }
		}
	}
}
