package com.mebigfatguy.fbcontrib.detect;

import java.util.HashMap;
import java.util.Map;

import org.apache.bcel.classfile.JavaClass;
import org.apache.bcel.classfile.Method;

import com.mebigfatguy.fbcontrib.utils.Integer14;

import edu.umd.cs.findbugs.BugInstance;
import edu.umd.cs.findbugs.BugReporter;
import edu.umd.cs.findbugs.Detector;
import edu.umd.cs.findbugs.ba.ClassContext;
import edu.umd.cs.findbugs.ba.XFactory;
import edu.umd.cs.findbugs.visitclass.PreorderVisitor;

/** looks for classes that define both static and instance methods with the same name.
 * This 'overloading' is confusing as one method is instance based the other class based,
 * and points to a confusion in implementation.
 */
public class MisleadingOverloadModel  extends PreorderVisitor implements Detector
{
	private static final Integer INSTANCE = Integer14.valueOf(0);
	private static final Integer STATIC = Integer14.valueOf(1);
	private static final Integer BOTH = Integer14.valueOf(2);
	
	private BugReporter bugReporter;
	
	/**
     * constructs a MOM detector given the reporter to report bugs on
     * @param bugReporter the sync of bug reports
	 */
	public MisleadingOverloadModel(BugReporter bugReporter) {
		this.bugReporter = bugReporter;
	}
	
	public void visitClassContext(ClassContext classContext) {
		Map<String, Integer> declMethods = new HashMap<String, Integer>();
		JavaClass cls = classContext.getJavaClass();
		String clsName = cls.getClassName();
		Method[] methods = cls.getMethods();
		for (Method m : methods) {
			String methodName = m.getName();
			boolean report;
			Integer newType;
			if (m.isStatic()) {
				report = declMethods.get(methodName) == INSTANCE;
				if (report)
					newType = BOTH;
				else
					newType = STATIC;
			} else {
				report = declMethods.get(m.getName()) == STATIC;
				if (report)
					newType = BOTH;
				else
					newType = INSTANCE;
			}
			
			declMethods.put(methodName, newType);
			if (report) {
				bugReporter.reportBug(new BugInstance(this, "MOM_MISLEADING_OVERLOAD_MODEL", NORMAL_PRIORITY)
							.addClass(cls)
							.addMethod(XFactory.createXMethod(clsName, m))
							.addString(methodName));
			}
		}
	}

	/** implements the visitor to do nothing */
	public void report() {
	}
}
