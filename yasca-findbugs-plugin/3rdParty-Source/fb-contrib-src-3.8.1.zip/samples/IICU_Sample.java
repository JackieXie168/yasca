import javax.xml.datatype.XMLGregorianCalendar;

import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;


public class IICU_Sample 
{
	public void test()
	{
		XMLGregorianCalendar cal = new XMLGregorianCalendarImpl();
	}
}
