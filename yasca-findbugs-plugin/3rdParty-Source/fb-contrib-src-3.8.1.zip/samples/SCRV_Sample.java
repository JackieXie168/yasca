
public class SCRV_Sample implements Comparable<SCRV_Sample>
{
	int i = 0;
	
	public int compareTo(SCRV_Sample that)
	{
		return i < that.i ? -1 : (i == that.i) ? 0 : 1;
	}
}
