
public class MOM_Sample 
{
	public void test(int i) 
	{	
	}
	
	public static void test(int i, int j) 
	{	
	}
}
