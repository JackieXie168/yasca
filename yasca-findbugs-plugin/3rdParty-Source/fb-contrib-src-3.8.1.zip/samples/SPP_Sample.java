import java.math.BigDecimal;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

public class SPP_Sample 
{
	private static final double pi = 3.14;
	private static final double e = 2.72;
	public static final String FALSE_POSITIVE = "INTERN_OK_HERE".intern();
	
	static enum Flap { Smack, Jack };
	
	public void testSPPBitSet(BitSet b)
	{
		b.set(-1);
	}
	
	public String testSPPIntern()
	{
		return "FOO".intern(); //and yes i've seen this!
	}
	
	public String testSBWithChars()
	{
		StringBuffer sb = new StringBuffer('v');
		sb.append("ictory");
		return sb.toString();
	}
	
	public double area(double radius)
	{
		return pi * radius * radius;
	}
	
	public void testStutter(String s)
	{
		String a = a = s;
	}
	
	public void testNAN(double d)
	{
		if (d == Double.NaN)
			System.out.println("It's a nan");
	}
	
	public void testNAN(float f)
	{
		if (f == Float.NaN)
			System.out.println("It's a nan");
	}
	
	public void testBigDecimal()
	{
		BigDecimal d = new BigDecimal(2.1);
	}
    
    public void testEmptySB()
    {
        StringBuffer sb = new StringBuffer("");
    }
    
    public void equalsOnEnum(Flap f)
    {
    	if (f.equals(Flap.Jack))
    		System.out.println("Flap Jacks");
    }
    
    public void testCPPBoolean(Boolean a, Boolean b, Boolean c, Boolean d, Boolean e)
	{
		if (b && b.booleanValue())
			System.out.println("Booya");
		if (e && e.booleanValue())
			System.out.println("Booya");
	}
    
    public char usechatAt(String s)
    {
    	if (s.length() > 0)
    		return s.toCharArray()[0];
    	return ' ';
    }
    
    public boolean testUselessTrinary(boolean b)
    {
    	return (b ? true : false);
    }
    
    public boolean testFPUselessTrinary(boolean a, boolean b)
    {
    	if (a && b)
    		return a || b;
    	
    	return a && b;
    }
    
    public boolean testFPTrinaryOnInt(String s)
    {
    	return (s.length() != 0);
    }
    
    public void testSuspiciousStringTests(String s)
    {
        int a = 0, b = 0, c = 0, d = 0;
        String e = "Foo";
        
    	if ((s == null) || (s.length() > 0))
    		System.out.println("Booya");
    	if ((s == null) || (s.length() != 0))
    		System.out.println("Booya");
    	if ((s != null) && (s.length() == 0))
    		System.out.println("Booya");
    	
        if ((e == null) || (e.length() > 0))
            System.out.println("Booya");
        if ((e == null) || (e.length() != 0))
            System.out.println("Booya");
        if ((e != null) && (e.length() == 0))
            System.out.println("Booya");
    }
    
    public void testFPSST(String s)
    {
        int a = 0, b = 0, c = 0, d = 0;
        String e = "Foo";
        
        if ((s == null) || (s.length() == 0))
            System.out.println("Booya");
        
        if ((s != null) && (s.length() >= 0))
            System.out.println("Booya");
        
        if ((s != null) && (s.length() != 0))
            System.out.println("Booya");
            
        if ((e == null) || (e.length() == 0))
            System.out.println("Booya");
        
        if ((e != null) && (e.length() >= 0))
            System.out.println("Booya");
        
        if ((e != null) && (e.length() != 0))
            System.out.println("Booya");
        
        Set<String> m = new HashSet<String>();
        Iterator<String> it = m.iterator();
        while (it.hasNext())
        {
            s = it.next();
            if ((s == null) || (s.length() == 0))
            {
                continue;
            }
            
            System.out.println("Booya");
        }
    }
    
    public void sbToString(StringBuffer sb)
    {
    	if (sb.toString().length() == 0)
    		System.out.println("Booya");
    	else if (sb.toString().equals(""))
    		System.out.println("Booya");
    }
    
    public String cpNullOrZero(StringTokenizer tokenizer)
    {
    	while (tokenizer.hasMoreTokens())
        {
            String sField = tokenizer.nextToken();

            if ((sField == null) || (sField.length() == 0))
            {
                continue;
            }

            return sField;
        }
    	
    	return null;
    }
    
    public boolean testCalBeforeAfter(Calendar c, Date d)
    {
    	return c.after(d) || c.before(d);
    }
    
    public void testUseContainsKey(Map m)
    {
    	if (m.keySet().contains("Foo"))
    		System.out.println("Yup");
    }
    
    public void testCollectionSizeEqualsZero(Set<String> s)
    {
    	if (s.size() == 0)
    		System.out.println("empty");
    }
    
    public boolean testDerivedGregorianCalendar()
    {
    	Calendar c = new GregorianCalendar() {};
    	Calendar s = new GregorianCalendar();
    	
    	return s.after(c);
    }
    
    public void testGetProperties()
    {
    	String lf = System.getProperties().getProperty("line.separator");
    }
}
