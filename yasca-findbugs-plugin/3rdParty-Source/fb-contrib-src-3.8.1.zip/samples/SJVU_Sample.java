
public class SJVU_Sample 
{
	public void test14using15(int i)
	{
		Integer ii = Integer.valueOf(i);
		StringBuilder sb = new StringBuilder();
		sb.append(ii.intValue());
	}
	
	
}
