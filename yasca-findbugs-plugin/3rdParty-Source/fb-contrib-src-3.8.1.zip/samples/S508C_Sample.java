import java.awt.Color;
import java.awt.Container;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class S508C_Sample extends JFrame 
{
	private JLabel fLabel = new JLabel("Hello");
    private JLabel imgLabel = new JLabel(new ImageIcon("/boo.gif"));
	private JComponent c = new MyComponent();
	
	public S508C_Sample() {
		Container cp = getContentPane();
		cp.setLayout(null);
		
		cp.add(fLabel);
		JLabel lLabel = new JLabel("there");
		lLabel.setBackground(new Color(255, 0, 0));
		lLabel.setForeground(new Color(255, 255, 100));
		cp.add(lLabel);
        
        JLabel picLabel = new JLabel(new ImageIcon("/foo.gif"));
        cp.add(picLabel);
		cp.add(c);
		
		setSize(300, 200);
	}
}

class MyComponent extends JComponent
{
	
}
