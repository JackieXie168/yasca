/* IMPLEMENTATION MODULE Scanner */
#define M2_IMPORT_Scanner

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif
/*223*/ STRING * Scanner_cwd = NULL;
/*227*/ int Scanner_print_file_name = 0;
/*236*/ int Scanner_print_path_fmt = 0;
/*239*/ int Scanner_ctrl_check = 0;
/*242*/ int Scanner_ascii_ext_check = 0;
/*245*/ int Scanner_tab_size = 0;
/*246*/ int Scanner_print_notices = 0;
/*247*/ int Scanner_print_warnings = 0;
/*248*/ int Scanner_print_errors = 0;
/*249*/ int Scanner_print_context = 0;
/*250*/ int Scanner_print_source = 0;
/*254*/ int Scanner_print_line_numbers = 0;
/*257*/ STRING * Scanner_fn = NULL;
/*260*/ int Scanner_sym = 0;
/*264*/ STRING * Scanner_s = NULL;
/*273*/ int Scanner_warning_counter = 0;
/*273*/ int Scanner_error_counter = 0;

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_io
#    include "io.c"
#endif

#ifndef M2_IMPORT_buffer
#    include "buffer.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

#ifndef M2_IMPORT_FileName
#    include "FileName.c"
#endif

#ifndef M2_IMPORT_Tokens
#    include "Tokens.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

void Scanner_0err_entry_get(int i, char **m, char **f, int *l);
/* 83*/ void * Scanner_fd = NULL;
/* 85*/ int Scanner_code = 0;
/* 88*/ STRING * Scanner_line = NULL;
/* 91*/ int Scanner_line_n = 0;
/* 94*/ int Scanner_line_idx = 0;
/* 97*/ int Scanner_line_pos = 0;
/*106*/ STRING * Scanner_c = NULL;

/*108*/ STRING *
/*108*/ Scanner_mn(RECORD *Scanner_c, RECORD *Scanner_m)
/*108*/ {
/*108*/ 	return m2runtime_concat_STRING(0, m2runtime_CHR(96), (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_c, 8, Scanner_0err_entry_get, 0), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_m, 8, Scanner_0err_entry_get, 1), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"()'", 1);
/*112*/ }


/*113*/ STRING *
/*113*/ Scanner_fmt_fn(STRING *Scanner_abs_path)
/*113*/ {
/*115*/ 	STRING * Scanner_r = NULL;
/*115*/ 	switch(Scanner_print_path_fmt){

/*117*/ 	case 0:
/*118*/ 	return Scanner_abs_path;
/*120*/ 	break;

/*120*/ 	case 1:
/*121*/ 	return FileName_Relative(m2runtime_concat_STRING(0, Scanner_cwd, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"/*", 1), Scanner_abs_path);
/*123*/ 	break;

/*123*/ 	case 2:
/*124*/ 	Scanner_r = FileName_Relative(m2runtime_concat_STRING(0, Scanner_cwd, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"/*", 1), Scanner_abs_path);
/*125*/ 	if( (m2runtime_length(Scanner_r) < m2runtime_length(Scanner_abs_path)) ){
/*126*/ 		return Scanner_r;
/*128*/ 	} else {
/*128*/ 		return Scanner_abs_path;
/*131*/ 	}
/*131*/ 	break;

/*131*/ 	default: m2runtime_missing_case_in_switch(Scanner_0err_entry_get, 2);
/*132*/ 	}
/*132*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 3);
/*132*/ 	return NULL;
/*134*/ }


/*136*/ RECORD *
/*136*/ Scanner_here(void)
/*136*/ {
/*136*/ 	return (
/*136*/ 		push((char*) alloc_RECORD(16, 1)),
/*136*/ 		push((char*) Scanner_fn),
/*136*/ 		*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*136*/ 		*(int*) (tos()+12) = Scanner_line_n,
/*138*/ 		(RECORD*) pop()
/*138*/ 	);
/*140*/ }


/*142*/ STRING *
/*142*/ Scanner_reference(RECORD *Scanner_w)
/*142*/ {
/*142*/ 	if( Scanner_w == NULL ){
/*143*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"?:?";
/*144*/ 	} else if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Scanner_w, 8, Scanner_0err_entry_get, 4), Scanner_fn) == 0 ){
/*145*/ 		return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"line ", m2runtime_itos( *(int *)m2runtime_dereference_rhs_RECORD(Scanner_w, 12, Scanner_0err_entry_get, 5)), 1);
/*147*/ 	} else {
/*147*/ 		return m2runtime_concat_STRING(0, Scanner_fmt_fn((STRING *)m2runtime_dereference_rhs_RECORD(Scanner_w, 8, Scanner_0err_entry_get, 6)), m2runtime_CHR(58), m2runtime_itos( *(int *)m2runtime_dereference_rhs_RECORD(Scanner_w, 12, Scanner_0err_entry_get, 7)), 1);
/*150*/ 	}
/*150*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 8);
/*150*/ 	return NULL;
/*152*/ }


/*154*/ void
/*154*/ Scanner_PrintWhere(RECORD *Scanner_w)
/*154*/ {
/*154*/ 	if( (Scanner_print_context || Scanner_print_source) ){
/*156*/ 		m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"**** ");
/*159*/ 	}
/*159*/ 	if( Scanner_w == NULL ){
/*160*/ 		m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"?: ");
/*162*/ 	} else {
/*162*/ 		if( (Scanner_print_file_name || !Scanner_print_source || (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Scanner_w, 8, Scanner_0err_entry_get, 9), Scanner_fn) != 0)) ){
/*165*/ 			m2_print(m2runtime_concat_STRING(0, Scanner_fmt_fn((STRING *)m2runtime_dereference_rhs_RECORD(Scanner_w, 8, Scanner_0err_entry_get, 10)), m2runtime_CHR(58), 1));
/*167*/ 		}
/*167*/ 		m2_print(m2runtime_concat_STRING(0, m2runtime_itos( *(int *)m2runtime_dereference_rhs_RECORD(Scanner_w, 12, Scanner_0err_entry_get, 11)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", 1));
/*170*/ 	}
/*172*/ }


/*174*/ void
/*174*/ Scanner_PrintCurrPos(void)
/*174*/ {
/*175*/ 	if( Scanner_print_context ){
/*176*/ 		m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\012\011", Scanner_line, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\012\011", str_repeat(m2runtime_CHR(32), (Scanner_line_pos - 1)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"\134_ HERE\012", 1));
/*179*/ 	}
/*179*/ 	Scanner_PrintWhere(Scanner_here());
/*183*/ }


/*185*/ void
/*185*/ Scanner_Fatal(STRING *Scanner_s)
/*185*/ {
/*185*/ 	Scanner_PrintCurrPos();
/*186*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"FATAL ERROR: ", Scanner_s, m2runtime_CHR(10), 1));
/*187*/ 	m2runtime_exit(1);
/*191*/ }


/*193*/ void
/*193*/ Scanner_UnexpectedSymbol(void)
/*193*/ {
/*193*/ 	Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"unexpected symbol ", Tokens_CodeToName(Scanner_sym), 1));
/*194*/ 	m2runtime_exit(1);
/*198*/ }


/*200*/ void
/*200*/ Scanner_Error(STRING *Scanner_s)
/*200*/ {
/*200*/ 	m2_inc(&Scanner_error_counter, 1);
/*201*/ 	if( !Scanner_print_errors ){
/*203*/ 		return ;
/*204*/ 	}
/*204*/ 	Scanner_PrintCurrPos();
/*205*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"ERROR: ", Scanner_s, m2runtime_CHR(10), 1));
/*209*/ }


/*211*/ void
/*211*/ Scanner_Error2(RECORD *Scanner_w, STRING *Scanner_s)
/*211*/ {
/*211*/ 	m2_inc(&Scanner_error_counter, 1);
/*212*/ 	if( !Scanner_print_errors ){
/*214*/ 		return ;
/*215*/ 	}
/*215*/ 	Scanner_PrintWhere(Scanner_w);
/*216*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"ERROR: ", Scanner_s, m2runtime_CHR(10), 1));
/*220*/ }


/*222*/ void
/*222*/ Scanner_Warning(STRING *Scanner_s)
/*222*/ {
/*222*/ 	m2_inc(&Scanner_warning_counter, 1);
/*223*/ 	if( !Scanner_print_warnings ){
/*225*/ 		return ;
/*226*/ 	}
/*226*/ 	Scanner_PrintCurrPos();
/*227*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"Warning: ", Scanner_s, m2runtime_CHR(10), 1));
/*231*/ }


/*233*/ void
/*233*/ Scanner_Warning2(RECORD *Scanner_w, STRING *Scanner_s)
/*233*/ {
/*233*/ 	m2_inc(&Scanner_warning_counter, 1);
/*234*/ 	if( !Scanner_print_warnings ){
/*236*/ 		return ;
/*237*/ 	}
/*237*/ 	Scanner_PrintWhere(Scanner_w);
/*238*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"Warning: ", Scanner_s, m2runtime_CHR(10), 1));
/*242*/ }


/*244*/ void
/*244*/ Scanner_Notice(STRING *Scanner_s)
/*244*/ {
/*244*/ 	if( !Scanner_print_notices ){
/*246*/ 		return ;
/*247*/ 	}
/*247*/ 	Scanner_PrintCurrPos();
/*248*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"notice: ", Scanner_s, m2runtime_CHR(10), 1));
/*252*/ }


/*254*/ void
/*254*/ Scanner_Notice2(RECORD *Scanner_w, STRING *Scanner_s)
/*254*/ {
/*254*/ 	if( !Scanner_print_notices ){
/*256*/ 		return ;
/*257*/ 	}
/*257*/ 	Scanner_PrintWhere(Scanner_w);
/*258*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"notice: ", Scanner_s, m2runtime_CHR(10), 1));
/*262*/ }


/*264*/ STRING *
/*264*/ Scanner_SymToName(int Scanner_code)
/*264*/ {
/*264*/ 	return Tokens_CodeToName(Scanner_code);
/*268*/ }


/*270*/ void
/*270*/ Scanner_Expect(int Scanner_es, STRING *Scanner_err)
/*270*/ {
/*270*/ 	if( (Scanner_sym == Scanner_es) ){
/*272*/ 		return ;
/*273*/ 	}
/*273*/ 	Scanner_Fatal(m2runtime_concat_STRING(0, Scanner_err, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)", found symbol ", Scanner_SymToName(Scanner_sym), 1));
/*276*/ }


/*278*/ void
/*278*/ Scanner_PrintLineSource(void)
/*278*/ {
/*278*/ 	if( Scanner_print_line_numbers ){
/*279*/ 		m2_print(m2runtime_itos(Scanner_line_n));
/*281*/ 	}
/*281*/ 	m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)":\011");
/*282*/ 	m2_print(Scanner_line);
/*283*/ 	m2_print(m2runtime_CHR(10));
/*287*/ }


/*289*/ void
/*289*/ Scanner_ReadCh(void)
/*289*/ {
/*290*/ 	if( Scanner_c == NULL ){
/*291*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0 ){
/*292*/ 		m2_inc(&Scanner_line_pos, Scanner_tab_size);
/*293*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0 ){
/*294*/ 		m2_inc(&Scanner_line_n, 1);
/*295*/ 		Scanner_line_pos = 1;
/*297*/ 	} else {
/*297*/ 		m2_inc(&Scanner_line_pos, 1);
/*301*/ 	}
/*301*/ 	if( Scanner_line == NULL ){
/*302*/ 		Scanner_c = NULL;
/*303*/ 	} else if( (Scanner_line_idx < m2runtime_length(Scanner_line)) ){
/*304*/ 		Scanner_c = m2runtime_substr(Scanner_line, Scanner_line_idx, 0, 0, Scanner_0err_entry_get, 12);
/*305*/ 		m2_inc(&Scanner_line_idx, 1);
/*306*/ 	} else if( (Scanner_line_idx == m2runtime_length(Scanner_line)) ){
/*307*/ 		Scanner_c = m2runtime_CHR(10);
/*308*/ 		m2_inc(&Scanner_line_idx, 1);
/*310*/ 	} else {
/*310*/ 		m2runtime_ERROR_CODE = 0;
/*310*/ 		Scanner_line = io_ReadLine(1, Scanner_fd);
/*311*/ 		switch( m2runtime_ERROR_CODE ){

/*311*/ 		case 0:  break;
/*311*/ 		default:
/*311*/ 			m2runtime_HALT(Scanner_0err_entry_get, 13, m2runtime_ERROR_MESSAGE);
/*311*/ 		}
/*311*/ 		if( Scanner_line == NULL ){
/*312*/ 			Scanner_c = NULL;
/*313*/ 		} else if( (m2runtime_length(Scanner_line) == 0) ){
/*314*/ 			Scanner_c = m2runtime_CHR(10);
/*316*/ 		} else {
/*316*/ 			Scanner_c = m2runtime_substr(Scanner_line, 0, 0, 0, Scanner_0err_entry_get, 14);
/*318*/ 		}
/*318*/ 		Scanner_line_idx = 1;
/*319*/ 		if( (Scanner_print_source && (Scanner_line != NULL)) ){
/*320*/ 			Scanner_PrintLineSource();
/*323*/ 		}
/*324*/ 	}
/*324*/ 	if( Globals_DEBUG ){
/*325*/ 		m2_print(Scanner_c);
/*328*/ 	}
/*331*/ }

/*336*/ void * Scanner_b = NULL;
/*342*/ ARRAY * Scanner_php_keywords = NULL;
/*346*/ ARRAY * Scanner_phplint_keywords = NULL;

/*351*/ int
/*351*/ Scanner_SearchKeyword(STRING *Scanner_word, ARRAY *Scanner_list)
/*351*/ {
/*351*/ 	int Scanner_r = 0;
/*351*/ 	int Scanner_i = 0;
/*351*/ 	int Scanner_b = 0;
/*351*/ 	int Scanner_a = 0;
/*353*/ 	int Scanner_k = 0;
/*353*/ 	Scanner_a = 0;
/*354*/ 	Scanner_b = (m2runtime_count(Scanner_list) - 1);
/*356*/ 	do{
/*356*/ 		Scanner_i = (((Scanner_a + Scanner_b)) / 2);
/*357*/ 		Scanner_r = m2runtime_strcmp(Scanner_word, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Scanner_list, Scanner_i, Scanner_0err_entry_get, 15), 8, Scanner_0err_entry_get, 16));
/*358*/ 		if( (Scanner_r < 0) ){
/*359*/ 			Scanner_b = (Scanner_i - 1);
/*360*/ 		} else if( (Scanner_r > 0) ){
/*361*/ 			Scanner_a = (Scanner_i + 1);
/*363*/ 		} else {
/*363*/ 			Scanner_k =  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Scanner_list, Scanner_i, Scanner_0err_entry_get, 17), 12, Scanner_0err_entry_get, 18);
/*364*/ 			if( (Scanner_k == 2) ){
/*365*/ 				Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"unimplemented keyword `", Scanner_word, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"'. I'm sorry...", 1));
/*367*/ 			}
/*367*/ 			return Scanner_k;
/*369*/ 		}
/*369*/ 		if( (Scanner_a > Scanner_b) ){
/*370*/ 			return 1;
/*373*/ 		}
/*374*/ 	}while(TRUE);
/*374*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 19);
/*374*/ 	return 0;
/*376*/ }


/*378*/ int
/*378*/ Scanner_SearchPhpKeyword(STRING *Scanner_k)
/*378*/ {
/*378*/ 	return Scanner_SearchKeyword(Scanner_k, Scanner_php_keywords);
/*382*/ }


/*384*/ void
/*384*/ Scanner_InitScanner(void)
/*384*/ {
/*384*/ 	Scanner_php_keywords = (
/*385*/ 		push((char*) alloc_ARRAY(4, 1)),
/*385*/ 		push((char*) (
/*385*/ 			push((char*) alloc_RECORD(16, 1)),
/*385*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE"),
/*385*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*385*/ 			*(int*) (tos()+12) = 65,
/*386*/ 			(RECORD*) pop()
/*386*/ 		)),
/*386*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*386*/ 		push((char*) (
/*386*/ 			push((char*) alloc_RECORD(16, 1)),
/*386*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL"),
/*386*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*386*/ 			*(int*) (tos()+12) = 63,
/*387*/ 			(RECORD*) pop()
/*387*/ 		)),
/*387*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*387*/ 		push((char*) (
/*387*/ 			push((char*) alloc_RECORD(16, 1)),
/*387*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE"),
/*387*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*387*/ 			*(int*) (tos()+12) = 66,
/*388*/ 			(RECORD*) pop()
/*388*/ 		)),
/*388*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),2) = (RECORD*) tos(), pop(),
/*388*/ 		push((char*) (
/*388*/ 			push((char*) alloc_RECORD(16, 1)),
/*388*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"abstract"),
/*388*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*388*/ 			*(int*) (tos()+12) = 91,
/*389*/ 			(RECORD*) pop()
/*389*/ 		)),
/*389*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),3) = (RECORD*) tos(), pop(),
/*389*/ 		push((char*) (
/*389*/ 			push((char*) alloc_RECORD(16, 1)),
/*389*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"and"),
/*389*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*389*/ 			*(int*) (tos()+12) = 58,
/*390*/ 			(RECORD*) pop()
/*390*/ 		)),
/*390*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),4) = (RECORD*) tos(), pop(),
/*390*/ 		push((char*) (
/*390*/ 			push((char*) alloc_RECORD(16, 1)),
/*390*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array"),
/*390*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*390*/ 			*(int*) (tos()+12) = 70,
/*391*/ 			(RECORD*) pop()
/*391*/ 		)),
/*391*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),5) = (RECORD*) tos(), pop(),
/*391*/ 		push((char*) (
/*391*/ 			push((char*) alloc_RECORD(16, 1)),
/*391*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"as"),
/*391*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*391*/ 			*(int*) (tos()+12) = 23,
/*392*/ 			(RECORD*) pop()
/*392*/ 		)),
/*392*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),6) = (RECORD*) tos(), pop(),
/*392*/ 		push((char*) (
/*392*/ 			push((char*) alloc_RECORD(16, 1)),
/*392*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"bool"),
/*392*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*392*/ 			*(int*) (tos()+12) = 64,
/*393*/ 			(RECORD*) pop()
/*393*/ 		)),
/*393*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),7) = (RECORD*) tos(), pop(),
/*393*/ 		push((char*) (
/*393*/ 			push((char*) alloc_RECORD(16, 1)),
/*393*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean"),
/*393*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*393*/ 			*(int*) (tos()+12) = 64,
/*394*/ 			(RECORD*) pop()
/*394*/ 		)),
/*394*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),8) = (RECORD*) tos(), pop(),
/*394*/ 		push((char*) (
/*394*/ 			push((char*) alloc_RECORD(16, 1)),
/*394*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"break"),
/*394*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*394*/ 			*(int*) (tos()+12) = 111,
/*395*/ 			(RECORD*) pop()
/*395*/ 		)),
/*395*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),9) = (RECORD*) tos(), pop(),
/*395*/ 		push((char*) (
/*395*/ 			push((char*) alloc_RECORD(16, 1)),
/*395*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"case"),
/*395*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*395*/ 			*(int*) (tos()+12) = 110,
/*396*/ 			(RECORD*) pop()
/*396*/ 		)),
/*396*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),10) = (RECORD*) tos(), pop(),
/*396*/ 		push((char*) (
/*396*/ 			push((char*) alloc_RECORD(16, 1)),
/*396*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"catch"),
/*396*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*396*/ 			*(int*) (tos()+12) = 119,
/*397*/ 			(RECORD*) pop()
/*397*/ 		)),
/*397*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),11) = (RECORD*) tos(), pop(),
/*397*/ 		push((char*) (
/*397*/ 			push((char*) alloc_RECORD(16, 1)),
/*397*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class"),
/*397*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*397*/ 			*(int*) (tos()+12) = 93,
/*398*/ 			(RECORD*) pop()
/*398*/ 		)),
/*398*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),12) = (RECORD*) tos(), pop(),
/*398*/ 		push((char*) (
/*398*/ 			push((char*) alloc_RECORD(16, 1)),
/*398*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"clone"),
/*398*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*398*/ 			*(int*) (tos()+12) = 106,
/*399*/ 			(RECORD*) pop()
/*399*/ 		)),
/*399*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),13) = (RECORD*) tos(), pop(),
/*399*/ 		push((char*) (
/*399*/ 			push((char*) alloc_RECORD(16, 1)),
/*399*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"const"),
/*399*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*399*/ 			*(int*) (tos()+12) = 96,
/*400*/ 			(RECORD*) pop()
/*400*/ 		)),
/*400*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),14) = (RECORD*) tos(), pop(),
/*400*/ 		push((char*) (
/*400*/ 			push((char*) alloc_RECORD(16, 1)),
/*400*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"continue"),
/*400*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*400*/ 			*(int*) (tos()+12) = 121,
/*401*/ 			(RECORD*) pop()
/*401*/ 		)),
/*401*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),15) = (RECORD*) tos(), pop(),
/*401*/ 		push((char*) (
/*401*/ 			push((char*) alloc_RECORD(16, 1)),
/*401*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"declare"),
/*401*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*401*/ 			*(int*) (tos()+12) = 9,
/*402*/ 			(RECORD*) pop()
/*402*/ 		)),
/*402*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),16) = (RECORD*) tos(), pop(),
/*402*/ 		push((char*) (
/*402*/ 			push((char*) alloc_RECORD(16, 1)),
/*402*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"default"),
/*402*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*402*/ 			*(int*) (tos()+12) = 112,
/*403*/ 			(RECORD*) pop()
/*403*/ 		)),
/*403*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),17) = (RECORD*) tos(), pop(),
/*403*/ 		push((char*) (
/*403*/ 			push((char*) alloc_RECORD(16, 1)),
/*403*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"define"),
/*403*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*403*/ 			*(int*) (tos()+12) = 7,
/*404*/ 			(RECORD*) pop()
/*404*/ 		)),
/*404*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),18) = (RECORD*) tos(), pop(),
/*404*/ 		push((char*) (
/*404*/ 			push((char*) alloc_RECORD(16, 1)),
/*404*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"die"),
/*404*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*404*/ 			*(int*) (tos()+12) = 113,
/*405*/ 			(RECORD*) pop()
/*405*/ 		)),
/*405*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),19) = (RECORD*) tos(), pop(),
/*405*/ 		push((char*) (
/*405*/ 			push((char*) alloc_RECORD(16, 1)),
/*405*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"do"),
/*405*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*405*/ 			*(int*) (tos()+12) = 117,
/*406*/ 			(RECORD*) pop()
/*406*/ 		)),
/*406*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),20) = (RECORD*) tos(), pop(),
/*406*/ 		push((char*) (
/*406*/ 			push((char*) alloc_RECORD(16, 1)),
/*406*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"double"),
/*406*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*406*/ 			*(int*) (tos()+12) = 68,
/*407*/ 			(RECORD*) pop()
/*407*/ 		)),
/*407*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),21) = (RECORD*) tos(), pop(),
/*407*/ 		push((char*) (
/*407*/ 			push((char*) alloc_RECORD(16, 1)),
/*407*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"echo"),
/*407*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*407*/ 			*(int*) (tos()+12) = 114,
/*408*/ 			(RECORD*) pop()
/*408*/ 		)),
/*408*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),22) = (RECORD*) tos(), pop(),
/*408*/ 		push((char*) (
/*408*/ 			push((char*) alloc_RECORD(16, 1)),
/*408*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"else"),
/*408*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*408*/ 			*(int*) (tos()+12) = 26,
/*409*/ 			(RECORD*) pop()
/*409*/ 		)),
/*409*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),23) = (RECORD*) tos(), pop(),
/*409*/ 		push((char*) (
/*409*/ 			push((char*) alloc_RECORD(16, 1)),
/*409*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"elseif"),
/*409*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*409*/ 			*(int*) (tos()+12) = 27,
/*410*/ 			(RECORD*) pop()
/*410*/ 		)),
/*410*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),24) = (RECORD*) tos(), pop(),
/*410*/ 		push((char*) (
/*410*/ 			push((char*) alloc_RECORD(16, 1)),
/*410*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"enddeclare"),
/*410*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*410*/ 			*(int*) (tos()+12) = 2,
/*411*/ 			(RECORD*) pop()
/*411*/ 		)),
/*411*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),25) = (RECORD*) tos(), pop(),
/*411*/ 		push((char*) (
/*411*/ 			push((char*) alloc_RECORD(16, 1)),
/*411*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"endfor"),
/*411*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*411*/ 			*(int*) (tos()+12) = 2,
/*412*/ 			(RECORD*) pop()
/*412*/ 		)),
/*412*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),26) = (RECORD*) tos(), pop(),
/*412*/ 		push((char*) (
/*412*/ 			push((char*) alloc_RECORD(16, 1)),
/*412*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"endforeach"),
/*412*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*412*/ 			*(int*) (tos()+12) = 2,
/*413*/ 			(RECORD*) pop()
/*413*/ 		)),
/*413*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),27) = (RECORD*) tos(), pop(),
/*413*/ 		push((char*) (
/*413*/ 			push((char*) alloc_RECORD(16, 1)),
/*413*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"endif"),
/*413*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*413*/ 			*(int*) (tos()+12) = 2,
/*414*/ 			(RECORD*) pop()
/*414*/ 		)),
/*414*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),28) = (RECORD*) tos(), pop(),
/*414*/ 		push((char*) (
/*414*/ 			push((char*) alloc_RECORD(16, 1)),
/*414*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"endswitch"),
/*414*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*414*/ 			*(int*) (tos()+12) = 2,
/*415*/ 			(RECORD*) pop()
/*415*/ 		)),
/*415*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),29) = (RECORD*) tos(), pop(),
/*415*/ 		push((char*) (
/*415*/ 			push((char*) alloc_RECORD(16, 1)),
/*415*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"endwhile"),
/*415*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*415*/ 			*(int*) (tos()+12) = 2,
/*416*/ 			(RECORD*) pop()
/*416*/ 		)),
/*416*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),30) = (RECORD*) tos(), pop(),
/*416*/ 		push((char*) (
/*416*/ 			push((char*) alloc_RECORD(16, 1)),
/*416*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"exit"),
/*416*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*416*/ 			*(int*) (tos()+12) = 113,
/*417*/ 			(RECORD*) pop()
/*417*/ 		)),
/*417*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),31) = (RECORD*) tos(), pop(),
/*417*/ 		push((char*) (
/*417*/ 			push((char*) alloc_RECORD(16, 1)),
/*417*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"extends"),
/*417*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*417*/ 			*(int*) (tos()+12) = 94,
/*418*/ 			(RECORD*) pop()
/*418*/ 		)),
/*418*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),32) = (RECORD*) tos(), pop(),
/*418*/ 		push((char*) (
/*418*/ 			push((char*) alloc_RECORD(16, 1)),
/*418*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"false"),
/*418*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*418*/ 			*(int*) (tos()+12) = 65,
/*419*/ 			(RECORD*) pop()
/*419*/ 		)),
/*419*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),33) = (RECORD*) tos(), pop(),
/*419*/ 		push((char*) (
/*419*/ 			push((char*) alloc_RECORD(16, 1)),
/*419*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"final"),
/*419*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*419*/ 			*(int*) (tos()+12) = 102,
/*420*/ 			(RECORD*) pop()
/*420*/ 		)),
/*420*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),34) = (RECORD*) tos(), pop(),
/*420*/ 		push((char*) (
/*420*/ 			push((char*) alloc_RECORD(16, 1)),
/*420*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float"),
/*420*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*420*/ 			*(int*) (tos()+12) = 68,
/*421*/ 			(RECORD*) pop()
/*421*/ 		)),
/*421*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),35) = (RECORD*) tos(), pop(),
/*421*/ 		push((char*) (
/*421*/ 			push((char*) alloc_RECORD(16, 1)),
/*421*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"for"),
/*421*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*421*/ 			*(int*) (tos()+12) = 21,
/*422*/ 			(RECORD*) pop()
/*422*/ 		)),
/*422*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),36) = (RECORD*) tos(), pop(),
/*422*/ 		push((char*) (
/*422*/ 			push((char*) alloc_RECORD(16, 1)),
/*422*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"foreach"),
/*422*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*422*/ 			*(int*) (tos()+12) = 22,
/*423*/ 			(RECORD*) pop()
/*423*/ 		)),
/*423*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),37) = (RECORD*) tos(), pop(),
/*423*/ 		push((char*) (
/*423*/ 			push((char*) alloc_RECORD(16, 1)),
/*423*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function"),
/*423*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*423*/ 			*(int*) (tos()+12) = 8,
/*424*/ 			(RECORD*) pop()
/*424*/ 		)),
/*424*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),38) = (RECORD*) tos(), pop(),
/*424*/ 		push((char*) (
/*424*/ 			push((char*) alloc_RECORD(16, 1)),
/*424*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"global"),
/*424*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*424*/ 			*(int*) (tos()+12) = 62,
/*425*/ 			(RECORD*) pop()
/*425*/ 		)),
/*425*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),39) = (RECORD*) tos(), pop(),
/*425*/ 		push((char*) (
/*425*/ 			push((char*) alloc_RECORD(16, 1)),
/*425*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"if"),
/*425*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*425*/ 			*(int*) (tos()+12) = 25,
/*426*/ 			(RECORD*) pop()
/*426*/ 		)),
/*426*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),40) = (RECORD*) tos(), pop(),
/*426*/ 		push((char*) (
/*426*/ 			push((char*) alloc_RECORD(16, 1)),
/*426*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"implements"),
/*426*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*426*/ 			*(int*) (tos()+12) = 95,
/*427*/ 			(RECORD*) pop()
/*427*/ 		)),
/*427*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),41) = (RECORD*) tos(), pop(),
/*427*/ 		push((char*) (
/*427*/ 			push((char*) alloc_RECORD(16, 1)),
/*427*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"include"),
/*427*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*427*/ 			*(int*) (tos()+12) = 123,
/*428*/ 			(RECORD*) pop()
/*428*/ 		)),
/*428*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),42) = (RECORD*) tos(), pop(),
/*428*/ 		push((char*) (
/*428*/ 			push((char*) alloc_RECORD(16, 1)),
/*428*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"include_once"),
/*428*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*428*/ 			*(int*) (tos()+12) = 124,
/*429*/ 			(RECORD*) pop()
/*429*/ 		)),
/*429*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),43) = (RECORD*) tos(), pop(),
/*429*/ 		push((char*) (
/*429*/ 			push((char*) alloc_RECORD(16, 1)),
/*429*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"instanceof"),
/*429*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*429*/ 			*(int*) (tos()+12) = 107,
/*430*/ 			(RECORD*) pop()
/*430*/ 		)),
/*430*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),44) = (RECORD*) tos(), pop(),
/*430*/ 		push((char*) (
/*430*/ 			push((char*) alloc_RECORD(16, 1)),
/*430*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int"),
/*430*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*430*/ 			*(int*) (tos()+12) = 67,
/*431*/ 			(RECORD*) pop()
/*431*/ 		)),
/*431*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),45) = (RECORD*) tos(), pop(),
/*431*/ 		push((char*) (
/*431*/ 			push((char*) alloc_RECORD(16, 1)),
/*431*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"integer"),
/*431*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*431*/ 			*(int*) (tos()+12) = 67,
/*432*/ 			(RECORD*) pop()
/*432*/ 		)),
/*432*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),46) = (RECORD*) tos(), pop(),
/*432*/ 		push((char*) (
/*432*/ 			push((char*) alloc_RECORD(16, 1)),
/*432*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"interface"),
/*432*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*432*/ 			*(int*) (tos()+12) = 92,
/*433*/ 			(RECORD*) pop()
/*433*/ 		)),
/*433*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),47) = (RECORD*) tos(), pop(),
/*433*/ 		push((char*) (
/*433*/ 			push((char*) alloc_RECORD(16, 1)),
/*433*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"isset"),
/*433*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*433*/ 			*(int*) (tos()+12) = 122,
/*434*/ 			(RECORD*) pop()
/*434*/ 		)),
/*434*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),48) = (RECORD*) tos(), pop(),
/*434*/ 		push((char*) (
/*434*/ 			push((char*) alloc_RECORD(16, 1)),
/*434*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"list"),
/*434*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*434*/ 			*(int*) (tos()+12) = 108,
/*435*/ 			(RECORD*) pop()
/*435*/ 		)),
/*435*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),49) = (RECORD*) tos(), pop(),
/*435*/ 		push((char*) (
/*435*/ 			push((char*) alloc_RECORD(16, 1)),
/*435*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"new"),
/*435*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*435*/ 			*(int*) (tos()+12) = 105,
/*436*/ 			(RECORD*) pop()
/*436*/ 		)),
/*436*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),50) = (RECORD*) tos(), pop(),
/*436*/ 		push((char*) (
/*436*/ 			push((char*) alloc_RECORD(16, 1)),
/*436*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"null"),
/*436*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*436*/ 			*(int*) (tos()+12) = 63,
/*437*/ 			(RECORD*) pop()
/*437*/ 		)),
/*437*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),51) = (RECORD*) tos(), pop(),
/*437*/ 		push((char*) (
/*437*/ 			push((char*) alloc_RECORD(16, 1)),
/*437*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object"),
/*437*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*437*/ 			*(int*) (tos()+12) = 71,
/*438*/ 			(RECORD*) pop()
/*438*/ 		)),
/*438*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),52) = (RECORD*) tos(), pop(),
/*438*/ 		push((char*) (
/*438*/ 			push((char*) alloc_RECORD(16, 1)),
/*438*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"or"),
/*438*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*438*/ 			*(int*) (tos()+12) = 56,
/*439*/ 			(RECORD*) pop()
/*439*/ 		)),
/*439*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),53) = (RECORD*) tos(), pop(),
/*439*/ 		push((char*) (
/*439*/ 			push((char*) alloc_RECORD(16, 1)),
/*439*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"parent"),
/*439*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*439*/ 			*(int*) (tos()+12) = 104,
/*440*/ 			(RECORD*) pop()
/*440*/ 		)),
/*440*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),54) = (RECORD*) tos(), pop(),
/*440*/ 		push((char*) (
/*440*/ 			push((char*) alloc_RECORD(16, 1)),
/*440*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"print"),
/*440*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*440*/ 			*(int*) (tos()+12) = 115,
/*441*/ 			(RECORD*) pop()
/*441*/ 		)),
/*441*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),55) = (RECORD*) tos(), pop(),
/*441*/ 		push((char*) (
/*441*/ 			push((char*) alloc_RECORD(16, 1)),
/*441*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"private"),
/*441*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*441*/ 			*(int*) (tos()+12) = 99,
/*442*/ 			(RECORD*) pop()
/*442*/ 		)),
/*442*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),56) = (RECORD*) tos(), pop(),
/*442*/ 		push((char*) (
/*442*/ 			push((char*) alloc_RECORD(16, 1)),
/*442*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"protected"),
/*442*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*442*/ 			*(int*) (tos()+12) = 100,
/*443*/ 			(RECORD*) pop()
/*443*/ 		)),
/*443*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),57) = (RECORD*) tos(), pop(),
/*443*/ 		push((char*) (
/*443*/ 			push((char*) alloc_RECORD(16, 1)),
/*443*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"public"),
/*443*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*443*/ 			*(int*) (tos()+12) = 98,
/*444*/ 			(RECORD*) pop()
/*444*/ 		)),
/*444*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),58) = (RECORD*) tos(), pop(),
/*444*/ 		push((char*) (
/*444*/ 			push((char*) alloc_RECORD(16, 1)),
/*444*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"real"),
/*444*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*444*/ 			*(int*) (tos()+12) = 68,
/*445*/ 			(RECORD*) pop()
/*445*/ 		)),
/*445*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),59) = (RECORD*) tos(), pop(),
/*445*/ 		push((char*) (
/*445*/ 			push((char*) alloc_RECORD(16, 1)),
/*445*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"require"),
/*445*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*445*/ 			*(int*) (tos()+12) = 125,
/*446*/ 			(RECORD*) pop()
/*446*/ 		)),
/*446*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),60) = (RECORD*) tos(), pop(),
/*446*/ 		push((char*) (
/*446*/ 			push((char*) alloc_RECORD(16, 1)),
/*446*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"require_once"),
/*446*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*446*/ 			*(int*) (tos()+12) = 126,
/*447*/ 			(RECORD*) pop()
/*447*/ 		)),
/*447*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),61) = (RECORD*) tos(), pop(),
/*447*/ 		push((char*) (
/*447*/ 			push((char*) alloc_RECORD(16, 1)),
/*447*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"return"),
/*447*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*447*/ 			*(int*) (tos()+12) = 28,
/*448*/ 			(RECORD*) pop()
/*448*/ 		)),
/*448*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),62) = (RECORD*) tos(), pop(),
/*448*/ 		push((char*) (
/*448*/ 			push((char*) alloc_RECORD(16, 1)),
/*448*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"self"),
/*448*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*448*/ 			*(int*) (tos()+12) = 103,
/*449*/ 			(RECORD*) pop()
/*449*/ 		)),
/*449*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),63) = (RECORD*) tos(), pop(),
/*449*/ 		push((char*) (
/*449*/ 			push((char*) alloc_RECORD(16, 1)),
/*449*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"static"),
/*449*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*449*/ 			*(int*) (tos()+12) = 101,
/*450*/ 			(RECORD*) pop()
/*450*/ 		)),
/*450*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),64) = (RECORD*) tos(), pop(),
/*450*/ 		push((char*) (
/*450*/ 			push((char*) alloc_RECORD(16, 1)),
/*450*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string"),
/*450*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*450*/ 			*(int*) (tos()+12) = 69,
/*451*/ 			(RECORD*) pop()
/*451*/ 		)),
/*451*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),65) = (RECORD*) tos(), pop(),
/*451*/ 		push((char*) (
/*451*/ 			push((char*) alloc_RECORD(16, 1)),
/*451*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"switch"),
/*451*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*451*/ 			*(int*) (tos()+12) = 109,
/*452*/ 			(RECORD*) pop()
/*452*/ 		)),
/*452*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),66) = (RECORD*) tos(), pop(),
/*452*/ 		push((char*) (
/*452*/ 			push((char*) alloc_RECORD(16, 1)),
/*452*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"throw"),
/*452*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*452*/ 			*(int*) (tos()+12) = 120,
/*453*/ 			(RECORD*) pop()
/*453*/ 		)),
/*453*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),67) = (RECORD*) tos(), pop(),
/*453*/ 		push((char*) (
/*453*/ 			push((char*) alloc_RECORD(16, 1)),
/*453*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"trigger_error"),
/*453*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*453*/ 			*(int*) (tos()+12) = 116,
/*454*/ 			(RECORD*) pop()
/*454*/ 		)),
/*454*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),68) = (RECORD*) tos(), pop(),
/*454*/ 		push((char*) (
/*454*/ 			push((char*) alloc_RECORD(16, 1)),
/*454*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"true"),
/*454*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*454*/ 			*(int*) (tos()+12) = 66,
/*455*/ 			(RECORD*) pop()
/*455*/ 		)),
/*455*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),69) = (RECORD*) tos(), pop(),
/*455*/ 		push((char*) (
/*455*/ 			push((char*) alloc_RECORD(16, 1)),
/*455*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"try"),
/*455*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*455*/ 			*(int*) (tos()+12) = 118,
/*456*/ 			(RECORD*) pop()
/*456*/ 		)),
/*456*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),70) = (RECORD*) tos(), pop(),
/*456*/ 		push((char*) (
/*456*/ 			push((char*) alloc_RECORD(16, 1)),
/*456*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"use"),
/*456*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*456*/ 			*(int*) (tos()+12) = 2,
/*457*/ 			(RECORD*) pop()
/*457*/ 		)),
/*457*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),71) = (RECORD*) tos(), pop(),
/*457*/ 		push((char*) (
/*457*/ 			push((char*) alloc_RECORD(16, 1)),
/*457*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"var"),
/*457*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*457*/ 			*(int*) (tos()+12) = 97,
/*458*/ 			(RECORD*) pop()
/*458*/ 		)),
/*458*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),72) = (RECORD*) tos(), pop(),
/*458*/ 		push((char*) (
/*458*/ 			push((char*) alloc_RECORD(16, 1)),
/*458*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"while"),
/*458*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*458*/ 			*(int*) (tos()+12) = 24,
/*459*/ 			(RECORD*) pop()
/*459*/ 		)),
/*459*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),73) = (RECORD*) tos(), pop(),
/*459*/ 		push((char*) (
/*459*/ 			push((char*) alloc_RECORD(16, 1)),
/*459*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"xor"),
/*459*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*459*/ 			*(int*) (tos()+12) = 89,
/*461*/ 			(RECORD*) pop()
/*461*/ 		)),
/*461*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),74) = (RECORD*) tos(), pop(),
/*462*/ 		(ARRAY*) pop()
/*462*/ 	);
/*462*/ 	Scanner_phplint_keywords = (
/*463*/ 		push((char*) alloc_ARRAY(4, 1)),
/*463*/ 		push((char*) (
/*463*/ 			push((char*) alloc_RECORD(16, 1)),
/*463*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"abstract"),
/*463*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*463*/ 			*(int*) (tos()+12) = 164,
/*464*/ 			(RECORD*) pop()
/*464*/ 		)),
/*464*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*464*/ 		push((char*) (
/*464*/ 			push((char*) alloc_RECORD(16, 1)),
/*464*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"args"),
/*464*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*464*/ 			*(int*) (tos()+12) = 148,
/*465*/ 			(RECORD*) pop()
/*465*/ 		)),
/*465*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*465*/ 		push((char*) (
/*465*/ 			push((char*) alloc_RECORD(16, 1)),
/*465*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array"),
/*465*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*465*/ 			*(int*) (tos()+12) = 141,
/*466*/ 			(RECORD*) pop()
/*466*/ 		)),
/*466*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),2) = (RECORD*) tos(), pop(),
/*466*/ 		push((char*) (
/*466*/ 			push((char*) alloc_RECORD(16, 1)),
/*466*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"bool"),
/*466*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*466*/ 			*(int*) (tos()+12) = 137,
/*467*/ 			(RECORD*) pop()
/*467*/ 		)),
/*467*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),3) = (RECORD*) tos(), pop(),
/*467*/ 		push((char*) (
/*467*/ 			push((char*) alloc_RECORD(16, 1)),
/*467*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean"),
/*467*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*467*/ 			*(int*) (tos()+12) = 137,
/*468*/ 			(RECORD*) pop()
/*468*/ 		)),
/*468*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),4) = (RECORD*) tos(), pop(),
/*468*/ 		push((char*) (
/*468*/ 			push((char*) alloc_RECORD(16, 1)),
/*468*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class"),
/*468*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*468*/ 			*(int*) (tos()+12) = 135,
/*469*/ 			(RECORD*) pop()
/*469*/ 		)),
/*469*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),5) = (RECORD*) tos(), pop(),
/*469*/ 		push((char*) (
/*469*/ 			push((char*) alloc_RECORD(16, 1)),
/*469*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"double"),
/*469*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*469*/ 			*(int*) (tos()+12) = 139,
/*470*/ 			(RECORD*) pop()
/*470*/ 		)),
/*470*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),6) = (RECORD*) tos(), pop(),
/*470*/ 		push((char*) (
/*470*/ 			push((char*) alloc_RECORD(16, 1)),
/*470*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"else"),
/*470*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*470*/ 			*(int*) (tos()+12) = 157,
/*471*/ 			(RECORD*) pop()
/*471*/ 		)),
/*471*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),7) = (RECORD*) tos(), pop(),
/*471*/ 		push((char*) (
/*471*/ 			push((char*) alloc_RECORD(16, 1)),
/*471*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"end_if_php_ver"),
/*471*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*471*/ 			*(int*) (tos()+12) = 158,
/*472*/ 			(RECORD*) pop()
/*472*/ 		)),
/*472*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),8) = (RECORD*) tos(), pop(),
/*472*/ 		push((char*) (
/*472*/ 			push((char*) alloc_RECORD(16, 1)),
/*472*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"final"),
/*472*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*472*/ 			*(int*) (tos()+12) = 166,
/*473*/ 			(RECORD*) pop()
/*473*/ 		)),
/*473*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),9) = (RECORD*) tos(), pop(),
/*473*/ 		push((char*) (
/*473*/ 			push((char*) alloc_RECORD(16, 1)),
/*473*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float"),
/*473*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*473*/ 			*(int*) (tos()+12) = 139,
/*474*/ 			(RECORD*) pop()
/*474*/ 		)),
/*474*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),10) = (RECORD*) tos(), pop(),
/*474*/ 		push((char*) (
/*474*/ 			push((char*) alloc_RECORD(16, 1)),
/*474*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"forward"),
/*474*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*474*/ 			*(int*) (tos()+12) = 133,
/*475*/ 			(RECORD*) pop()
/*475*/ 		)),
/*475*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),11) = (RECORD*) tos(), pop(),
/*475*/ 		push((char*) (
/*475*/ 			push((char*) alloc_RECORD(16, 1)),
/*475*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function"),
/*475*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*475*/ 			*(int*) (tos()+12) = 134,
/*476*/ 			(RECORD*) pop()
/*476*/ 		)),
/*476*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),12) = (RECORD*) tos(), pop(),
/*476*/ 		push((char*) (
/*476*/ 			push((char*) alloc_RECORD(16, 1)),
/*476*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"if_php_ver_4"),
/*476*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*476*/ 			*(int*) (tos()+12) = 155,
/*477*/ 			(RECORD*) pop()
/*477*/ 		)),
/*477*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),13) = (RECORD*) tos(), pop(),
/*477*/ 		push((char*) (
/*477*/ 			push((char*) alloc_RECORD(16, 1)),
/*477*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"if_php_ver_5"),
/*477*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*477*/ 			*(int*) (tos()+12) = 156,
/*478*/ 			(RECORD*) pop()
/*478*/ 		)),
/*478*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),14) = (RECORD*) tos(), pop(),
/*478*/ 		push((char*) (
/*478*/ 			push((char*) alloc_RECORD(16, 1)),
/*478*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int"),
/*478*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*478*/ 			*(int*) (tos()+12) = 138,
/*479*/ 			(RECORD*) pop()
/*479*/ 		)),
/*479*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),15) = (RECORD*) tos(), pop(),
/*479*/ 		push((char*) (
/*479*/ 			push((char*) alloc_RECORD(16, 1)),
/*479*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"integer"),
/*479*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*479*/ 			*(int*) (tos()+12) = 138,
/*480*/ 			(RECORD*) pop()
/*480*/ 		)),
/*480*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),16) = (RECORD*) tos(), pop(),
/*480*/ 		push((char*) (
/*480*/ 			push((char*) alloc_RECORD(16, 1)),
/*480*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"missing_break"),
/*480*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*480*/ 			*(int*) (tos()+12) = 159,
/*481*/ 			(RECORD*) pop()
/*481*/ 		)),
/*481*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),17) = (RECORD*) tos(), pop(),
/*481*/ 		push((char*) (
/*481*/ 			push((char*) alloc_RECORD(16, 1)),
/*481*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"missing_default"),
/*481*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*481*/ 			*(int*) (tos()+12) = 160,
/*482*/ 			(RECORD*) pop()
/*482*/ 		)),
/*482*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),18) = (RECORD*) tos(), pop(),
/*482*/ 		push((char*) (
/*482*/ 			push((char*) alloc_RECORD(16, 1)),
/*482*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"mixed"),
/*482*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*482*/ 			*(int*) (tos()+12) = 142,
/*483*/ 			(RECORD*) pop()
/*483*/ 		)),
/*483*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),19) = (RECORD*) tos(), pop(),
/*483*/ 		push((char*) (
/*483*/ 			push((char*) alloc_RECORD(16, 1)),
/*483*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object"),
/*483*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*483*/ 			*(int*) (tos()+12) = 144,
/*484*/ 			(RECORD*) pop()
/*484*/ 		)),
/*484*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),20) = (RECORD*) tos(), pop(),
/*484*/ 		push((char*) (
/*484*/ 			push((char*) alloc_RECORD(16, 1)),
/*484*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"parent"),
/*484*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*484*/ 			*(int*) (tos()+12) = 168,
/*485*/ 			(RECORD*) pop()
/*485*/ 		)),
/*485*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),21) = (RECORD*) tos(), pop(),
/*485*/ 		push((char*) (
/*485*/ 			push((char*) alloc_RECORD(16, 1)),
/*485*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"private"),
/*485*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*485*/ 			*(int*) (tos()+12) = 163,
/*486*/ 			(RECORD*) pop()
/*486*/ 		)),
/*486*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),22) = (RECORD*) tos(), pop(),
/*486*/ 		push((char*) (
/*486*/ 			push((char*) alloc_RECORD(16, 1)),
/*486*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"protected"),
/*486*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*486*/ 			*(int*) (tos()+12) = 162,
/*487*/ 			(RECORD*) pop()
/*487*/ 		)),
/*487*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),23) = (RECORD*) tos(), pop(),
/*487*/ 		push((char*) (
/*487*/ 			push((char*) alloc_RECORD(16, 1)),
/*487*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"public"),
/*487*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*487*/ 			*(int*) (tos()+12) = 161,
/*488*/ 			(RECORD*) pop()
/*488*/ 		)),
/*488*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),24) = (RECORD*) tos(), pop(),
/*488*/ 		push((char*) (
/*488*/ 			push((char*) alloc_RECORD(16, 1)),
/*488*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"require_module"),
/*488*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*488*/ 			*(int*) (tos()+12) = 127,
/*489*/ 			(RECORD*) pop()
/*489*/ 		)),
/*489*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),25) = (RECORD*) tos(), pop(),
/*489*/ 		push((char*) (
/*489*/ 			push((char*) alloc_RECORD(16, 1)),
/*489*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"resource"),
/*489*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*489*/ 			*(int*) (tos()+12) = 143,
/*490*/ 			(RECORD*) pop()
/*490*/ 		)),
/*490*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),26) = (RECORD*) tos(), pop(),
/*490*/ 		push((char*) (
/*490*/ 			push((char*) alloc_RECORD(16, 1)),
/*490*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"self"),
/*490*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*490*/ 			*(int*) (tos()+12) = 167,
/*491*/ 			(RECORD*) pop()
/*491*/ 		)),
/*491*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),27) = (RECORD*) tos(), pop(),
/*491*/ 		push((char*) (
/*491*/ 			push((char*) alloc_RECORD(16, 1)),
/*491*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"static"),
/*491*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*491*/ 			*(int*) (tos()+12) = 165,
/*492*/ 			(RECORD*) pop()
/*492*/ 		)),
/*492*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),28) = (RECORD*) tos(), pop(),
/*492*/ 		push((char*) (
/*492*/ 			push((char*) alloc_RECORD(16, 1)),
/*492*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string"),
/*492*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*492*/ 			*(int*) (tos()+12) = 140,
/*493*/ 			(RECORD*) pop()
/*493*/ 		)),
/*493*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),29) = (RECORD*) tos(), pop(),
/*493*/ 		push((char*) (
/*493*/ 			push((char*) alloc_RECORD(16, 1)),
/*493*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"throws"),
/*493*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*493*/ 			*(int*) (tos()+12) = 169,
/*494*/ 			(RECORD*) pop()
/*494*/ 		)),
/*494*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),30) = (RECORD*) tos(), pop(),
/*494*/ 		push((char*) (
/*494*/ 			push((char*) alloc_RECORD(16, 1)),
/*494*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"void"),
/*494*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*494*/ 			*(int*) (tos()+12) = 136,
/*496*/ 			(RECORD*) pop()
/*496*/ 		)),
/*496*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),31) = (RECORD*) tos(), pop(),
/*498*/ 		(ARRAY*) pop()
/*498*/ 	);
/*500*/ }


/*503*/ void
/*503*/ Scanner_FindOpenTag(void)
/*503*/ {

/*505*/ 	int
/*505*/ 	Scanner_is_space(STRING *Scanner_c)
/*505*/ 	{
/*505*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(13)) == 0));
/*509*/ 	}

/*511*/ 	do{
/*511*/ 		if( Scanner_c == NULL ){
/*512*/ 			Scanner_sym = 0;
/*514*/ 			return ;
/*514*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(60)) == 0 ){
/*515*/ 			Scanner_ReadCh();
/*516*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(63)) == 0 ){
/*519*/ 				goto m2runtime_loop_1;
/*520*/ 			}
/*520*/ 		} else {
/*520*/ 			Scanner_ReadCh();
/*523*/ 		}
/*523*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*523*/ 	Scanner_ReadCh();
/*524*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*525*/ 		Scanner_sym = 5;
/*526*/ 		Scanner_ReadCh();
/*527*/ 		Scanner_code = 1;
/*529*/ 		return ;
/*530*/ 	}
/*530*/ 	if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(112)) == 0) && (((Scanner_line_idx + 2) <= m2runtime_length(Scanner_line))) && (m2runtime_strcmp(m2runtime_substr(Scanner_line, Scanner_line_idx, (Scanner_line_idx + 2), 1, Scanner_0err_entry_get, 20), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"hp") == 0) && (((((Scanner_line_idx + 2) >= m2runtime_length(Scanner_line))) || Scanner_is_space(m2runtime_substr(Scanner_line, (Scanner_line_idx + 2), 0, 0, Scanner_0err_entry_get, 21))))) ){
/*534*/ 		Scanner_ReadCh();
/*535*/ 		Scanner_ReadCh();
/*536*/ 		Scanner_ReadCh();
/*538*/ 	}
/*538*/ 	Scanner_sym = 4;
/*539*/ 	Scanner_code = 1;
/*541*/ 	return ;
/*544*/ }


/*553*/ void
/*553*/ Scanner_SkipNewLineAfterCloseTag(void)
/*553*/ {
/*553*/ 	Scanner_ReadCh();
/*554*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0 ){
/*555*/ 		Scanner_ReadCh();
/*556*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(13)) == 0 ){
/*557*/ 		Scanner_ReadCh();
/*558*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0 ){
/*559*/ 			Scanner_ReadCh();
/*561*/ 		}
/*563*/ 	}
/*565*/ }


/*569*/ int
/*569*/ Scanner_SkipSingleLineComment(void)
/*569*/ {
/*571*/ 	STRING * Scanner_prev = NULL;
/*572*/ 	do{
/*572*/ 		Scanner_prev = Scanner_c;
/*573*/ 		Scanner_ReadCh();
/*574*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0 ){
/*575*/ 			Scanner_ReadCh();
/*576*/ 			return FALSE;
/*577*/ 		} else if( Scanner_c == NULL ){
/*578*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"premature end of the file or missing closing tag");
/*579*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0) && (m2runtime_strcmp(Scanner_prev, m2runtime_CHR(63)) == 0)) ){
/*580*/ 			Scanner_SkipNewLineAfterCloseTag();
/*581*/ 			return TRUE;
/*584*/ 		}
/*585*/ 	}while(TRUE);
/*585*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 22);
/*585*/ 	return 0;
/*587*/ }


/*593*/ int
/*593*/ Scanner_SkipSpaces(void)
/*593*/ {
/*593*/ 	while( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(35)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(13)) == 0)) ){
/*595*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(35)) == 0 ){
/*596*/ 			if( Scanner_SkipSingleLineComment() ){
/*597*/ 				return TRUE;
/*600*/ 			}
/*600*/ 		} else {
/*600*/ 			Scanner_ReadCh();
/*603*/ 		}
/*603*/ 	}
/*603*/ 	return FALSE;
/*607*/ }


/*613*/ void
/*613*/ Scanner_SkipMultilineComment(void)
/*613*/ {
/*614*/ 	int Scanner_start_line_n = 0;
/*616*/ 	STRING * Scanner_c2 = NULL;
/*616*/ 	STRING * Scanner_c1 = NULL;
/*616*/ 	if( Globals_DEBUG ){
/*617*/ 		m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"[comment start]");
/*619*/ 	}
/*619*/ 	buffer_Set((void *)&Scanner_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"/*");
/*620*/ 	Scanner_start_line_n = Scanner_line_n;
/*622*/ 	do{
/*622*/ 		buffer_AddString((void *)&Scanner_b, Scanner_c);
/*623*/ 		if( Scanner_c == NULL ){
/*624*/ 			Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"missing closing '*/' in comment beginning in line ", m2runtime_itos(Scanner_start_line_n), 1));
/*626*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0) && (m2runtime_strcmp(Scanner_c1, m2runtime_CHR(47)) == 0)) ){
/*627*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"possible nested multiline comment in comment beginning in line ", m2runtime_itos(Scanner_start_line_n), 1));
/*628*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0) && (m2runtime_strcmp(Scanner_c1, m2runtime_CHR(42)) == 0)) ){
/*629*/ 			if( m2runtime_strcmp(Scanner_c2, m2runtime_CHR(46)) == 0 ){
/*630*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\74,\0,\0,\0)"possible missing `.' in multiline comment beginning in line ", m2runtime_itos(Scanner_start_line_n), 1));
/*632*/ 			}
/*632*/ 			if( Globals_DEBUG ){
/*633*/ 				m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"[comment end]");
/*635*/ 			}
/*635*/ 			Scanner_ReadCh();
/*636*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*638*/ 			return ;
/*639*/ 		}
/*639*/ 		Scanner_c2 = Scanner_c1;
/*640*/ 		Scanner_c1 = Scanner_c;
/*641*/ 		Scanner_ReadCh();
/*644*/ 	}while(TRUE);
/*646*/ }


/*648*/ STRING *
/*648*/ Scanner_ReportChar(int Scanner_ch)
/*648*/ {
/*648*/ 	if( (((Scanner_ch >= 32)) && ((Scanner_ch <= 126))) ){
/*649*/ 		return m2runtime_concat_STRING(0, m2runtime_CHR(96), m2runtime_CHR(Scanner_ch), m2runtime_CHR(39), 1);
/*650*/ 	} else if( (Scanner_ch == 9) ){
/*651*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"horizontal tabulator, HT, 9";
/*652*/ 	} else if( (Scanner_ch == 10) ){
/*653*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"line feed, LF, 10";
/*654*/ 	} else if( (Scanner_ch == 13) ){
/*655*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"carriage return, CR, 13";
/*656*/ 	} else if( (Scanner_ch == 127) ){
/*657*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"delete, DEL, 127";
/*658*/ 	} else if( (Scanner_ch > 127) ){
/*659*/ 		return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"code ", m2runtime_itos(Scanner_ch), 1);
/*661*/ 	} else {
/*661*/ 		return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"control code ", m2runtime_itos(Scanner_ch), 1);
/*664*/ 	}
/*664*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 23);
/*664*/ 	return NULL;
/*666*/ }


/*668*/ void
/*668*/ Scanner_ReportCTRL(int Scanner_ch)
/*668*/ {
/*668*/ 	if( !Scanner_ctrl_check ){
/*670*/ 		return ;
/*671*/ 	}
/*671*/ 	Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"found control character (", Scanner_ReportChar(Scanner_ch), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\103,\0,\0,\0)") in literal string. This msg is reported only once for each string", 1));
/*676*/ }


/*678*/ void
/*678*/ Scanner_ReportASCIIExt(int Scanner_ch, STRING *Scanner_in)
/*678*/ {
/*678*/ 	if( !Scanner_ascii_ext_check ){
/*680*/ 		return ;
/*681*/ 	}
/*681*/ 	Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"non-ASCII character code in ", Scanner_in, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" (", Scanner_ReportChar(Scanner_ch), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"). This msg is reported only once for each ", Scanner_in, 1));
/*686*/ }


/*692*/ int
/*692*/ Scanner_is_id_first_char(STRING *Scanner_c)
/*692*/ {
/*693*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(97)) >= 0 ){
/*694*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(122)) <= 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(128)) >= 0));
/*695*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(65)) >= 0 ){
/*696*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(90)) <= 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(95)) == 0));
/*698*/ 	} else {
/*698*/ 		return FALSE;
/*705*/ 	}
/*705*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 24);
/*705*/ 	return 0;
/*707*/ }


/*709*/ int
/*709*/ Scanner_is_id_char(STRING *Scanner_c)
/*709*/ {
/*709*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(97)) >= 0 ){
/*710*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(122)) <= 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(127)) >= 0));
/*711*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(65)) >= 0 ){
/*712*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(90)) <= 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(95)) == 0));
/*714*/ 	} else {
/*714*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(57)) <= 0));
/*722*/ 	}
/*722*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 25);
/*722*/ 	return 0;
/*724*/ }


/*726*/ int
/*726*/ Scanner_is_digit(STRING *Scanner_c)
/*726*/ {
/*726*/ 	return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(57)) <= 0));
/*730*/ }


/*732*/ int
/*732*/ Scanner_is_hex(STRING *Scanner_c)
/*732*/ {
/*732*/ 	return (((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(57)) <= 0)) || ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(65)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(70)) <= 0)) || ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(97)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(102)) <= 0)));
/*738*/ }


/*740*/ int
/*740*/ Scanner_hex(STRING *Scanner_c)
/*740*/ {
/*740*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(57)) <= 0 ){
/*741*/ 		return (m2runtime_ASC(Scanner_c) - m2runtime_ASC(m2runtime_CHR(48)));
/*742*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(90)) <= 0 ){
/*743*/ 		return ((10 + m2runtime_ASC(Scanner_c)) - m2runtime_ASC(m2runtime_CHR(65)));
/*745*/ 	} else {
/*745*/ 		return ((10 + m2runtime_ASC(Scanner_c)) - m2runtime_ASC(m2runtime_CHR(97)));
/*748*/ 	}
/*748*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 26);
/*748*/ 	return 0;
/*751*/ }

/*752*/ STRING * Scanner_here_doc_id = NULL;
/*753*/ STRING * Scanner_end4 = NULL;
/*753*/ STRING * Scanner_end3 = NULL;
/*753*/ STRING * Scanner_end2 = NULL;
/*753*/ STRING * Scanner_end1 = NULL;
/*756*/ int Scanner_start_line_n = 0;

/*771*/ int
/*771*/ Scanner_ParseDoubleQuotedString(void)
/*771*/ {

/*772*/ 	STRING *
/*772*/ 	Scanner_ParseEscapeCode(void)
/*772*/ 	{
/*774*/ 		int Scanner_x = 0;
/*774*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(110)) == 0 ){
/*775*/ 			Scanner_ReadCh();
/*776*/ 			return m2runtime_CHR(10);
/*777*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(114)) == 0 ){
/*778*/ 			Scanner_ReadCh();
/*779*/ 			return m2runtime_CHR(13);
/*780*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(116)) == 0 ){
/*781*/ 			Scanner_ReadCh();
/*782*/ 			return m2runtime_CHR(9);
/*783*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(92)) == 0 ){
/*784*/ 			Scanner_ReadCh();
/*785*/ 			return m2runtime_CHR(92);
/*786*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*787*/ 			Scanner_ReadCh();
/*788*/ 			return m2runtime_CHR(36);
/*789*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(34)) == 0 ){
/*790*/ 			Scanner_ReadCh();
/*791*/ 			return m2runtime_CHR(34);
/*792*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0)) ){
/*793*/ 			Scanner_x = (m2runtime_ASC(Scanner_c) - m2runtime_ASC(m2runtime_CHR(48)));
/*794*/ 			Scanner_ReadCh();
/*795*/ 			if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0)) ){
/*796*/ 				Scanner_x = (((8 * Scanner_x) + m2runtime_ASC(Scanner_c)) - m2runtime_ASC(m2runtime_CHR(48)));
/*797*/ 				Scanner_ReadCh();
/*798*/ 				if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0)) ){
/*799*/ 					Scanner_x = (((8 * Scanner_x) + m2runtime_ASC(Scanner_c)) - m2runtime_ASC(m2runtime_CHR(48)));
/*800*/ 					Scanner_ReadCh();
/*803*/ 				}
/*803*/ 			}
/*803*/ 			if( (Scanner_x > 255) ){
/*804*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"invalid octal code in escape sequence: too big");
/*805*/ 				return NULL;
/*807*/ 			}
/*807*/ 			return m2runtime_CHR(Scanner_x);
/*808*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(120)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(88)) == 0)) ){
/*809*/ 			Scanner_ReadCh();
/*810*/ 			if( !Scanner_is_hex(Scanner_c) ){
/*811*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"invalid hexadecimal digit in escape sequence");
/*812*/ 				return NULL;
/*814*/ 			}
/*814*/ 			Scanner_x = Scanner_hex(Scanner_c);
/*815*/ 			Scanner_ReadCh();
/*816*/ 			if( Scanner_is_hex(Scanner_c) ){
/*817*/ 				Scanner_x = ((16 * Scanner_x) + Scanner_hex(Scanner_c));
/*818*/ 				Scanner_ReadCh();
/*820*/ 			}
/*820*/ 			return m2runtime_CHR(Scanner_x);
/*822*/ 		} else {
/*822*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"invalid escape sequence");
/*823*/ 			return m2runtime_concat_STRING(0, m2runtime_CHR(92), Scanner_c, 1);
/*826*/ 		}
/*826*/ 		m2runtime_missing_return(Scanner_0err_entry_get, 27);
/*826*/ 		return NULL;
/*829*/ 	}

/*830*/ 	int Scanner_i = 0;
/*830*/ 	int Scanner_ch = 0;
/*832*/ 	int Scanner_report_ascii_ext = 0;
/*832*/ 	int Scanner_report_ctrl = 0;
/*832*/ 	buffer_Empty((void *)&Scanner_b);
/*833*/ 	Scanner_report_ctrl = Scanner_ctrl_check;
/*834*/ 	Scanner_report_ascii_ext = Scanner_ascii_ext_check;
/*836*/ 	do{
/*836*/ 		if( Scanner_c == NULL ){
/*837*/ 			if( Scanner_here_doc_id == NULL ){
/*838*/ 				Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\61,\0,\0,\0)"missing terminating \042 character in literal string");
/*840*/ 			} else {
/*840*/ 				Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"here-doc `<<< ", Scanner_here_doc_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"' not closed", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)" beginning in line ", m2runtime_itos(Scanner_start_line_n), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)". Expected a line containing exactly `", Scanner_here_doc_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)"' possibly followed by `;' then a new-line, no spaces allowed.", 1));
/*846*/ 			}
/*847*/ 		}
/*847*/ 		Scanner_ch = m2runtime_ASC(Scanner_c);
/*850*/ 		if( Scanner_here_doc_id == NULL ){
/*852*/ 			if( (Scanner_report_ctrl && ((((Scanner_ch < 32)) || ((Scanner_ch == 127))))) ){
/*853*/ 				Scanner_ReportCTRL(Scanner_ch);
/*854*/ 				Scanner_report_ctrl = FALSE;
/*857*/ 			}
/*858*/ 		} else {
/*858*/ 			if( (Scanner_report_ctrl && ((((Scanner_ch < 32)) || ((Scanner_ch == 127)))) && ((Scanner_ch != 10)) && ((Scanner_ch != 13)) && ((Scanner_ch != 9))) ){
/*860*/ 				Scanner_ReportCTRL(Scanner_ch);
/*861*/ 				Scanner_report_ctrl = FALSE;
/*864*/ 			}
/*866*/ 		}
/*866*/ 		if( (Scanner_report_ascii_ext && ((Scanner_ch > 127))) ){
/*867*/ 			Scanner_ReportASCIIExt(Scanner_ch, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"literal string");
/*868*/ 			Scanner_report_ascii_ext = FALSE;
/*874*/ 		}
/*874*/ 		if( ((Scanner_here_doc_id == NULL) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(34)) == 0)) ){
/*877*/ 			Scanner_ReadCh();
/*879*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*880*/ 			if( (Scanner_code == 4) ){
/*881*/ 				Scanner_code = 1;
/*882*/ 				if( m2runtime_strcmp(Scanner_s, EMPTY_STRING) <= 0 ){
/*886*/ 					return TRUE;
/*889*/ 				} else {
/*889*/ 					Scanner_sym = 36;
/*890*/ 					return FALSE;
/*893*/ 				}
/*893*/ 			} else {
/*893*/ 				Scanner_code = 1;
/*894*/ 				Scanner_sym = 34;
/*895*/ 				return FALSE;
/*901*/ 			}
/*901*/ 		} else if( ((Scanner_here_doc_id != NULL) && ((Scanner_line_idx == 1)) && (((m2runtime_strcmp(Scanner_line, Scanner_end1) == 0) || (m2runtime_strcmp(Scanner_line, Scanner_end2) == 0) || (m2runtime_strcmp(Scanner_line, Scanner_end3) == 0) || (m2runtime_strcmp(Scanner_line, Scanner_end4) == 0)))) ){
/*906*/ 			{
/*906*/ 				int m2runtime_for_limit_1;
/*906*/ 				Scanner_i = 1;
/*906*/ 				m2runtime_for_limit_1 = m2runtime_length(Scanner_here_doc_id);
/*907*/ 				for( ; Scanner_i <= m2runtime_for_limit_1; Scanner_i += 1 ){
/*907*/ 					Scanner_ReadCh();
/*910*/ 				}
/*910*/ 			}
/*910*/ 			Scanner_here_doc_id = NULL;
/*912*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*913*/ 			if( (Scanner_code == 4) ){
/*914*/ 				Scanner_code = 1;
/*915*/ 				if( m2runtime_strcmp(Scanner_s, EMPTY_STRING) <= 0 ){
/*919*/ 					return TRUE;
/*922*/ 				} else {
/*922*/ 					Scanner_sym = 36;
/*923*/ 					return FALSE;
/*926*/ 				}
/*926*/ 			} else {
/*926*/ 				Scanner_code = 1;
/*927*/ 				Scanner_sym = 37;
/*928*/ 				return FALSE;
/*931*/ 			}
/*931*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(92)) == 0 ){
/*932*/ 			Scanner_ReadCh();
/*933*/ 			buffer_AddString((void *)&Scanner_b, Scanner_ParseEscapeCode());
/*934*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(123)) == 0 ){
/*935*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*936*/ 			Scanner_ReadCh();
/*937*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*938*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"embedded variable in string:", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)" curly braces notation not allowed", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)" (PHPLint limitation)", 1));
/*941*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*942*/ 				Scanner_ReadCh();
/*944*/ 			}
/*944*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*945*/ 			Scanner_ReadCh();
/*946*/ 			if( Scanner_is_id_first_char(Scanner_c) ){
/*952*/ 				Scanner_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"DUMMY_CONTINUATION_DOUBLE_QUOTED_STRING";
/*953*/ 				if( (Scanner_code == 1) ){
/*959*/ 					Scanner_code = 3;
/*960*/ 					if( Scanner_here_doc_id == NULL ){
/*961*/ 						Scanner_sym = 34;
/*963*/ 					} else {
/*963*/ 						Scanner_sym = 37;
/*965*/ 					}
/*965*/ 					return FALSE;
/*972*/ 				} else {
/*972*/ 					Scanner_code = 3;
/*973*/ 					Scanner_sym = 36;
/*974*/ 					return m2runtime_strcmp(Scanner_s, EMPTY_STRING) <= 0;
/*977*/ 				}
/*977*/ 			} else {
/*977*/ 				if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(91)) == 0 ){
/*979*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"embedded variable in string:", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" array selector not allowed", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)" (PHPLint limitation)", 1));
/*982*/ 				} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(123)) == 0 ){
/*984*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"embedded variable in string:", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)" curly braces notation not allowed", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)" (PHPLint limitation)", 1));
/*988*/ 				}
/*988*/ 				buffer_AddString((void *)&Scanner_b, m2runtime_CHR(36));
/*991*/ 			}
/*991*/ 		} else {
/*991*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*992*/ 			Scanner_ReadCh();
/*995*/ 		}
/*996*/ 	}while(TRUE);
/*996*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 28);
/*996*/ 	return 0;
/*998*/ }


/*999*/ int
/*999*/ Scanner_ParseHereDoc(void)
/*999*/ {
/*1001*/ 	STRING * Scanner_id = NULL;
/*1004*/ 	Scanner_start_line_n = Scanner_line_n;
/*1006*/ 	while( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0)) ){
/*1007*/ 		Scanner_ReadCh();
/*1011*/ 	}
/*1011*/ 	if( !Scanner_is_id_first_char(Scanner_c) ){
/*1012*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"expected identifier after `<<<'");
/*1014*/ 	}
/*1014*/ 	buffer_Set((void *)&Scanner_b, Scanner_c);
/*1015*/ 	Scanner_ReadCh();
/*1016*/ 	while( Scanner_is_id_char(Scanner_c) ){
/*1017*/ 		buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1018*/ 		Scanner_ReadCh();
/*1020*/ 	}
/*1020*/ 	Scanner_id = buffer_ToString(Scanner_b);
/*1022*/ 	if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0)) ){
/*1023*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"spaces not allowed after `<<<", Scanner_id, m2runtime_CHR(39), 1));
/*1025*/ 	}
/*1025*/ 	while( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(13)) == 0)) ){
/*1026*/ 		Scanner_ReadCh();
/*1029*/ 	}
/*1029*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) != 0 ){
/*1030*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"expected end of the line (ASCII code LF) after here-doc ID");
/*1032*/ 	}
/*1032*/ 	Scanner_ReadCh();
/*1034*/ 	Scanner_here_doc_id = Scanner_id;
/*1035*/ 	Scanner_end1 = Scanner_id;
/*1036*/ 	Scanner_end2 = m2runtime_concat_STRING(0, Scanner_id, m2runtime_CHR(13), 1);
/*1037*/ 	Scanner_end3 = m2runtime_concat_STRING(0, Scanner_id, m2runtime_CHR(59), 1);
/*1038*/ 	Scanner_end4 = m2runtime_concat_STRING(0, Scanner_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)";\015", 1);
/*1040*/ 	return Scanner_ParseDoubleQuotedString();
/*1044*/ }


/*1046*/ STRING *
/*1046*/ Scanner_ParseSingleQuotedString(void)
/*1046*/ {
/*1047*/ 	int Scanner_ch = 0;
/*1047*/ 	int Scanner_start_line_n = 0;
/*1048*/ 	int Scanner_skip = 0;
/*1050*/ 	int Scanner_report_ascii_ext = 0;
/*1050*/ 	int Scanner_report_ctrl = 0;
/*1050*/ 	buffer_Empty((void *)&Scanner_b);
/*1051*/ 	Scanner_skip = FALSE;
/*1052*/ 	Scanner_report_ctrl = Scanner_ctrl_check;
/*1053*/ 	Scanner_report_ascii_ext = Scanner_ascii_ext_check;
/*1054*/ 	Scanner_start_line_n = Scanner_line_n;
/*1055*/ 	Scanner_ReadCh();
/*1057*/ 	do{
/*1057*/ 		if( Scanner_c == NULL ){
/*1058*/ 			Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\74,\0,\0,\0)"missing terminating ' character in string beginning in line ", m2runtime_itos(Scanner_start_line_n), 1));
/*1060*/ 		}
/*1060*/ 		Scanner_ch = m2runtime_ASC(Scanner_c);
/*1061*/ 		if( (Scanner_report_ctrl && ((((Scanner_ch < 32)) || ((Scanner_ch == 127))))) ){
/*1062*/ 			Scanner_ReportCTRL(Scanner_ch);
/*1063*/ 			Scanner_report_ctrl = FALSE;
/*1065*/ 		}
/*1065*/ 		if( (Scanner_report_ascii_ext && ((Scanner_ch > 127))) ){
/*1066*/ 			Scanner_ReportASCIIExt(Scanner_ch, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"literal string");
/*1067*/ 			Scanner_report_ascii_ext = FALSE;
/*1069*/ 		}
/*1069*/ 		if( Scanner_skip ){
/*1070*/ 			if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(39)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(92)) == 0)) ){
/*1071*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1073*/ 			} else {
/*1073*/ 				buffer_AddString((void *)&Scanner_b, m2runtime_CHR(92));
/*1074*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1075*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"invalid escape sequence");
/*1077*/ 			}
/*1077*/ 			Scanner_skip = FALSE;
/*1078*/ 			Scanner_ReadCh();
/*1079*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(39)) == 0 ){
/*1080*/ 			Scanner_ReadCh();
/*1081*/ 			return buffer_ToString(Scanner_b);
/*1082*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(92)) == 0 ){
/*1083*/ 			Scanner_skip = TRUE;
/*1084*/ 			Scanner_ReadCh();
/*1086*/ 		} else {
/*1086*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1087*/ 			Scanner_ReadCh();
/*1090*/ 		}
/*1091*/ 	}while(TRUE);
/*1091*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 29);
/*1091*/ 	return NULL;
/*1093*/ }


/*1101*/ void
/*1101*/ Scanner_ParseKeyword(void)
/*1101*/ {
/*1101*/ 	int Scanner_report_ascii_ext = 0;
/*1103*/ 	STRING * Scanner_low = NULL;
/*1103*/ 	buffer_Empty((void *)&Scanner_b);
/*1104*/ 	Scanner_report_ascii_ext = Scanner_ascii_ext_check;
/*1106*/ 	do{
/*1106*/ 		if( (Scanner_report_ascii_ext && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(127)) >= 0)) ){
/*1107*/ 			Scanner_ReportASCIIExt(m2runtime_ASC(Scanner_c), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"identifier");
/*1108*/ 			Scanner_report_ascii_ext = FALSE;
/*1110*/ 		}
/*1110*/ 		buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1111*/ 		Scanner_ReadCh();
/*1112*/ 		if( !Scanner_is_id_char(Scanner_c) ){
/*1113*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*1116*/ 			goto m2runtime_loop_1;
/*1117*/ 		}
/*1120*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1120*/ 	if( (Scanner_code == 2) ){
/*1121*/ 		Scanner_sym = Scanner_SearchKeyword(Scanner_s, Scanner_phplint_keywords);
/*1122*/ 		if( (Scanner_sym != 1) ){
/*1124*/ 			return ;
/*1125*/ 		}
/*1125*/ 		Scanner_sym = Scanner_SearchKeyword(Scanner_s, Scanner_php_keywords);
/*1126*/ 		if( (Scanner_sym != 1) ){
/*1127*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid keyword `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"' inside PHPLint meta-code", 1));
/*1128*/ 			Scanner_sym = 1;
/*1130*/ 			return ;
/*1132*/ 		}
/*1132*/ 	} else {
/*1132*/ 		Scanner_sym = Scanner_SearchKeyword(Scanner_s, Scanner_php_keywords);
/*1133*/ 		if( (Scanner_sym != 1) ){
/*1135*/ 			return ;
/*1136*/ 		}
/*1136*/ 		Scanner_sym = Scanner_SearchKeyword(Scanner_s, Scanner_phplint_keywords);
/*1137*/ 		if( (Scanner_sym != 1) ){
/*1138*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"invalid PHPLint keyword `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"' inside PHP code", 1));
/*1139*/ 			Scanner_sym = 1;
/*1141*/ 			return ;
/*1143*/ 		}
/*1145*/ 	}
/*1145*/ 	Scanner_low = str_tolower(Scanner_s);
/*1146*/ 	Scanner_sym = Scanner_SearchKeyword(Scanner_low, Scanner_php_keywords);
/*1147*/ 	if( (Scanner_sym != 1) ){
/*1148*/ 		Scanner_Warning(m2runtime_concat_STRING(0, m2runtime_CHR(96), Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"': invalid identifier similar to the keyword `", Scanner_low, m2runtime_CHR(39), 1));
/*1152*/ 		return ;
/*1155*/ 	}
/*1155*/ 	Scanner_sym = Scanner_SearchKeyword(Scanner_low, Scanner_phplint_keywords);
/*1156*/ 	if( (Scanner_sym != 1) ){
/*1157*/ 		Scanner_Error(m2runtime_concat_STRING(0, m2runtime_CHR(96), Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"': invalid identifier similar to the PHPLint keyword `", Scanner_low, m2runtime_CHR(39), 1));
/*1158*/ 		Scanner_sym = 1;
/*1160*/ 		return ;
/*1163*/ 	}
/*1165*/ }


/*1167*/ int
/*1167*/ Scanner_ParseNumber(void)
/*1167*/ {

/*1170*/ 	void
/*1170*/ 	Scanner_ParseFloat(void)
/*1170*/ 	{
/*1170*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1171*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1172*/ 			Scanner_ReadCh();
/*1173*/ 			if( !Scanner_is_digit(Scanner_c) ){
/*1174*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\70,\0,\0,\0)"literal float number: required digit after decimal point");
/*1176*/ 				return ;
/*1178*/ 			}
/*1178*/ 			do {
/*1178*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1179*/ 				Scanner_ReadCh();
/*1180*/ 			} while( !( !Scanner_is_digit(Scanner_c) ));
/*1182*/ 		}
/*1182*/ 		if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(101)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(69)) == 0)) ){
/*1183*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1184*/ 			Scanner_ReadCh();
/*1185*/ 			if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(43)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(45)) == 0)) ){
/*1186*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1187*/ 				Scanner_ReadCh();
/*1189*/ 			}
/*1189*/ 			if( !Scanner_is_digit(Scanner_c) ){
/*1190*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"literal float number: required digit in exponent");
/*1193*/ 			}
/*1193*/ 			do {
/*1193*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1194*/ 				Scanner_ReadCh();
/*1195*/ 			} while( !( !Scanner_is_digit(Scanner_c) ));
/*1197*/ 		}
/*1197*/ 		Scanner_s = buffer_ToString(Scanner_b);
/*1200*/ 	}

/*1202*/ 	int Scanner_n = 0;
/*1206*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) == 0 ){
/*1207*/ 		Scanner_ReadCh();
/*1208*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(120)) == 0 ){
/*1210*/ 			Scanner_ReadCh();
/*1211*/ 			if( !Scanner_is_hex(Scanner_c) ){
/*1212*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"invalid hexadecimal number");
/*1215*/ 			} else {
/*1215*/ 				do {
/*1215*/ 					Scanner_n = (((unsigned int) Scanner_n << 4) + Scanner_hex(Scanner_c));
/*1216*/ 					Scanner_ReadCh();
/*1217*/ 				} while( !( !Scanner_is_hex(Scanner_c) ));
/*1219*/ 			}
/*1219*/ 			Scanner_s = m2runtime_itos(Scanner_n);
/*1220*/ 			return 38;
/*1221*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0)) ){
/*1224*/ 			do {
/*1224*/ 				Scanner_n = ((8 * Scanner_n) + m2_stoi(Scanner_c));
/*1225*/ 				Scanner_ReadCh();
/*1226*/ 			} while( !( !(((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0))) ));
/*1227*/ 			if( Scanner_is_digit(Scanner_c) ){
/*1228*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"invalid digit `", Scanner_c, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"' in octal number", 1));
/*1229*/ 				Scanner_ReadCh();
/*1231*/ 			}
/*1231*/ 			Scanner_s = m2runtime_itos(Scanner_n);
/*1232*/ 			return 38;
/*1233*/ 		} else if( Scanner_is_digit(Scanner_c) ){
/*1234*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"invalid digit `", Scanner_c, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"' in octal number", 1));
/*1235*/ 			Scanner_ReadCh();
/*1236*/ 			Scanner_s = m2runtime_CHR(48);
/*1237*/ 			return 38;
/*1238*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1240*/ 			buffer_Empty((void *)&Scanner_b);
/*1241*/ 			buffer_AddString((void *)&Scanner_b, m2runtime_CHR(48));
/*1242*/ 			Scanner_ParseFloat();
/*1243*/ 			return 39;
/*1246*/ 		} else {
/*1246*/ 			Scanner_s = m2runtime_CHR(48);
/*1247*/ 			return 38;
/*1250*/ 		}
/*1250*/ 	} else {
/*1250*/ 		buffer_Empty((void *)&Scanner_b);
/*1252*/ 		do {
/*1252*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1253*/ 			Scanner_ReadCh();
/*1254*/ 		} while( !( !Scanner_is_digit(Scanner_c) ));
/*1255*/ 		if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(101)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(101)) == 0)) ){
/*1256*/ 			Scanner_ParseFloat();
/*1257*/ 			return 39;
/*1259*/ 		} else {
/*1259*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*1260*/ 			return 38;
/*1263*/ 		}
/*1264*/ 	}
/*1264*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 30);
/*1264*/ 	return 0;
/*1266*/ }


/*1267*/ void
/*1267*/ Scanner_ParseDoc(void)
/*1267*/ {
/*1269*/ 	int Scanner_line_start = 0;
/*1269*/ 	Scanner_line_start = Scanner_line_n;
/*1270*/ 	while( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0)) ){
/*1271*/ 		Scanner_ReadCh();
/*1273*/ 	}
/*1273*/ 	buffer_Empty((void *)&Scanner_b);
/*1275*/ 	do{
/*1275*/ 		if( Scanner_c == NULL ){
/*1276*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"unclosed DOC comment openend in line ", m2runtime_itos(Scanner_line_start), 1));
/*1279*/ 			goto m2runtime_loop_1;
/*1279*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1280*/ 			Scanner_ReadCh();
/*1281*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1282*/ 				Scanner_ReadCh();
/*1283*/ 				if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1284*/ 					Scanner_ReadCh();
/*1287*/ 					goto m2runtime_loop_1;
/*1287*/ 				} else {
/*1287*/ 					buffer_AddString((void *)&Scanner_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)".*");
/*1290*/ 				}
/*1290*/ 			} else {
/*1290*/ 				buffer_AddString((void *)&Scanner_b, m2runtime_CHR(46));
/*1292*/ 			}
/*1292*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1293*/ 			Scanner_ReadCh();
/*1294*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1295*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"missing `.' in closing `.*/'");
/*1296*/ 				Scanner_ReadCh();
/*1299*/ 				goto m2runtime_loop_1;
/*1299*/ 			} else {
/*1299*/ 				buffer_AddString((void *)&Scanner_b, m2runtime_CHR(42));
/*1302*/ 			}
/*1302*/ 		} else {
/*1302*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1303*/ 			Scanner_ReadCh();
/*1306*/ 		}
/*1306*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1306*/ 	Scanner_s = buffer_ToString(Scanner_b);
/*1310*/ }


/*1312*/ void
/*1312*/ Scanner_ParseVarName(void)
/*1312*/ {
/*1312*/ 	Scanner_ReadCh();
/*1313*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*1314*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\110,\0,\0,\0)"unsupported variable-variable feature $$var -- trying to continue anyway");
/*1316*/ 		do {
/*1316*/ 			Scanner_ReadCh();
/*1317*/ 		} while( !( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) != 0 ));
/*1319*/ 	}
/*1319*/ 	if( !Scanner_is_id_first_char(Scanner_c) ){
/*1320*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"missing variable name after `$'");
/*1322*/ 	}
/*1322*/ 	Scanner_ParseKeyword();
/*1323*/ 	if( (Scanner_sym != 1) ){
/*1324*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the name `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"' is a keyword.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)" This is deprecated by PHP and forbidden by PHPLint.", 1));
/*1328*/ 	}
/*1330*/ }


/*1339*/ int
/*1339*/ Scanner_ParseXCode(void)
/*1339*/ {
/*1339*/ 	if( Scanner_SkipSpaces() ){
/*1340*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"unexpected closing tag inside meta-code");
/*1343*/ 	}
/*1343*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(40)) == 0 ){
/*1344*/ 		Scanner_sym = 149;
/*1345*/ 		Scanner_ReadCh();
/*1346*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(41)) == 0 ){
/*1347*/ 		Scanner_sym = 150;
/*1348*/ 		Scanner_ReadCh();
/*1349*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(91)) == 0 ){
/*1350*/ 		Scanner_sym = 151;
/*1351*/ 		Scanner_ReadCh();
/*1352*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(93)) == 0 ){
/*1353*/ 		Scanner_sym = 152;
/*1354*/ 		Scanner_ReadCh();
/*1355*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(123)) == 0 ){
/*1356*/ 		Scanner_sym = 153;
/*1357*/ 		Scanner_ReadCh();
/*1358*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(125)) == 0 ){
/*1359*/ 		Scanner_sym = 154;
/*1360*/ 		Scanner_ReadCh();
/*1361*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(38)) == 0 ){
/*1362*/ 		Scanner_sym = 147;
/*1363*/ 		Scanner_ReadCh();
/*1364*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1365*/ 		Scanner_sym = 132;
/*1366*/ 		Scanner_ReadCh();
/*1367*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*1368*/ 		Scanner_ParseVarName();
/*1369*/ 		Scanner_sym = 146;
/*1370*/ 	} else if( Scanner_is_id_first_char(Scanner_c) ){
/*1371*/ 		Scanner_ParseKeyword();
/*1372*/ 		if( (Scanner_sym == 1) ){
/*1373*/ 			if( m2runtime_strcmp(Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"DOC") == 0 ){
/*1374*/ 				Scanner_ParseDoc();
/*1375*/ 				Scanner_code = 1;
/*1376*/ 				Scanner_sym = 170;
/*1378*/ 			} else {
/*1378*/ 				Scanner_sym = 145;
/*1381*/ 			}
/*1381*/ 		}
/*1381*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1382*/ 		Scanner_ReadCh();
/*1383*/ 		if( ((Scanner_c == NULL) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) != 0)) ){
/*1384*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid syntax in extended code");
/*1385*/ 			return TRUE;
/*1387*/ 		}
/*1387*/ 		Scanner_ReadCh();
/*1388*/ 		if( ((Scanner_c == NULL) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) != 0)) ){
/*1389*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid syntax in extended code");
/*1390*/ 			return TRUE;
/*1392*/ 		}
/*1392*/ 		Scanner_ReadCh();
/*1393*/ 		Scanner_code = 1;
/*1394*/ 		return TRUE;
/*1395*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(44)) == 0 ){
/*1396*/ 		Scanner_ReadCh();
/*1397*/ 		Scanner_sym = 131;
/*1398*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(39)) == 0 ){
/*1399*/ 		Scanner_s = Scanner_ParseSingleQuotedString();
/*1400*/ 		Scanner_sym = 128;
/*1401*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(59)) == 0 ){
/*1402*/ 		Scanner_ReadCh();
/*1403*/ 		Scanner_sym = 129;
/*1404*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(58)) == 0 ){
/*1405*/ 		Scanner_ReadCh();
/*1406*/ 		Scanner_sym = 130;
/*1407*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1408*/ 		Scanner_ReadCh();
/*1409*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1410*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"expected `.*/', found `*/' (missing `.')");
/*1411*/ 			Scanner_ReadCh();
/*1412*/ 			Scanner_code = 1;
/*1413*/ 			return TRUE;
/*1415*/ 		} else {
/*1415*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"unexpected char `*' in extended code");
/*1418*/ 		}
/*1418*/ 	} else {
/*1418*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"unexpected char ", Scanner_ReportChar(m2runtime_ASC(Scanner_c)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)" in extended code - ignore", 1));
/*1419*/ 		Scanner_ReadCh();
/*1421*/ 	}
/*1421*/ 	return FALSE;
/*1425*/ }


/*1432*/ int
/*1432*/ Scanner_ParseCode(void)
/*1432*/ {
/*1432*/ 	if( Scanner_SkipSpaces() ){
/*1434*/ 		Scanner_code = 0;
/*1435*/ 		Scanner_sym = 6;
/*1436*/ 		return FALSE;
/*1439*/ 	}
/*1439*/ 	if( Scanner_is_id_first_char(Scanner_c) ){
/*1440*/ 		Scanner_ParseKeyword();
/*1441*/ 		if( (Scanner_sym == 1) ){
/*1442*/ 			Scanner_sym = 29;
/*1445*/ 		}
/*1445*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*1446*/ 		Scanner_ParseVarName();
/*1447*/ 		Scanner_sym = 20;
/*1449*/ 	} else if( Scanner_is_digit(Scanner_c) ){
/*1450*/ 		Scanner_sym = Scanner_ParseNumber();
/*1452*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(34)) == 0 ){
/*1453*/ 		Scanner_ReadCh();
/*1454*/ 		return Scanner_ParseDoubleQuotedString();
/*1456*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(39)) == 0 ){
/*1457*/ 		Scanner_s = Scanner_ParseSingleQuotedString();
/*1458*/ 		Scanner_sym = 33;
/*1460*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(96)) == 0 ){
/*1461*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"unimplemented execution operator \042`\042. Use shell_exec() instead.");
/*1462*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(64)) == 0 ){
/*1462*/ 		Scanner_sym = 59;
/*1462*/ 		Scanner_ReadCh();
/*1463*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(123)) == 0 ){
/*1463*/ 		Scanner_sym = 10;
/*1463*/ 		Scanner_ReadCh();
/*1464*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(125)) == 0 ){
/*1464*/ 		Scanner_sym = 11;
/*1464*/ 		Scanner_ReadCh();
/*1465*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(91)) == 0 ){
/*1465*/ 		Scanner_sym = 14;
/*1465*/ 		Scanner_ReadCh();
/*1466*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(93)) == 0 ){
/*1466*/ 		Scanner_sym = 15;
/*1466*/ 		Scanner_ReadCh();
/*1467*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(40)) == 0 ){
/*1467*/ 		Scanner_sym = 12;
/*1467*/ 		Scanner_ReadCh();
/*1468*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(41)) == 0 ){
/*1468*/ 		Scanner_sym = 13;
/*1468*/ 		Scanner_ReadCh();
/*1469*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(44)) == 0 ){
/*1469*/ 		Scanner_sym = 16;
/*1469*/ 		Scanner_ReadCh();
/*1470*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(59)) == 0 ){
/*1470*/ 		Scanner_sym = 17;
/*1470*/ 		Scanner_ReadCh();
/*1471*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(126)) == 0 ){
/*1471*/ 		Scanner_sym = 90;
/*1471*/ 		Scanner_ReadCh();
/*1473*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(58)) == 0 ){
/*1474*/ 		Scanner_ReadCh();
/*1475*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(58)) == 0 ){
/*1476*/ 			Scanner_ReadCh();
/*1477*/ 			Scanner_sym = 19;
/*1479*/ 		} else {
/*1479*/ 			Scanner_sym = 18;
/*1482*/ 		}
/*1482*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(63)) == 0 ){
/*1483*/ 		Scanner_ReadCh();
/*1484*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1485*/ 			Scanner_SkipNewLineAfterCloseTag();
/*1486*/ 			Scanner_code = 0;
/*1487*/ 			Scanner_sym = 6;
/*1489*/ 		} else {
/*1489*/ 			Scanner_sym = 30;
/*1492*/ 		}
/*1492*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(43)) == 0 ){
/*1493*/ 		Scanner_ReadCh();
/*1494*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(43)) == 0 ){
/*1495*/ 			Scanner_ReadCh();
/*1496*/ 			Scanner_sym = 52;
/*1497*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1498*/ 			Scanner_ReadCh();
/*1499*/ 			Scanner_sym = 76;
/*1501*/ 		} else {
/*1501*/ 			Scanner_sym = 40;
/*1504*/ 		}
/*1504*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(45)) == 0 ){
/*1505*/ 		Scanner_ReadCh();
/*1506*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1507*/ 			Scanner_ReadCh();
/*1508*/ 			Scanner_sym = 61;
/*1509*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(45)) == 0 ){
/*1510*/ 			Scanner_ReadCh();
/*1511*/ 			Scanner_sym = 53;
/*1512*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1513*/ 			Scanner_ReadCh();
/*1514*/ 			Scanner_sym = 77;
/*1516*/ 		} else {
/*1516*/ 			Scanner_sym = 41;
/*1519*/ 		}
/*1519*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1520*/ 		Scanner_ReadCh();
/*1521*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1522*/ 			Scanner_ReadCh();
/*1523*/ 			Scanner_sym = 78;
/*1525*/ 		} else {
/*1525*/ 			Scanner_sym = 42;
/*1528*/ 		}
/*1528*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1529*/ 		Scanner_ReadCh();
/*1530*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1531*/ 			Scanner_ReadCh();
/*1532*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1534*/ 				Scanner_code = 2;
/*1535*/ 				Scanner_ReadCh();
/*1536*/ 				return TRUE;
/*1538*/ 			} else {
/*1538*/ 				Scanner_SkipMultilineComment();
/*1539*/ 				if( (((m2runtime_length(Scanner_s) > 5)) && (m2runtime_strcmp(m2runtime_substr(Scanner_s, 0, 3, 1, Scanner_0err_entry_get, 31), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"/**") == 0)) ){
/*1541*/ 					Scanner_sym = 171;
/*1544*/ 				} else {
/*1544*/ 					return TRUE;
/*1547*/ 				}
/*1547*/ 			}
/*1547*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1548*/ 			if( Scanner_SkipSingleLineComment() ){
/*1550*/ 				Scanner_code = 0;
/*1551*/ 				Scanner_sym = 6;
/*1552*/ 				return FALSE;
/*1554*/ 			}
/*1554*/ 			return TRUE;
/*1555*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1556*/ 			Scanner_sym = 79;
/*1557*/ 			Scanner_ReadCh();
/*1559*/ 		} else {
/*1559*/ 			Scanner_sym = 43;
/*1562*/ 		}
/*1562*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(37)) == 0 ){
/*1563*/ 		Scanner_ReadCh();
/*1564*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1565*/ 			Scanner_sym = 80;
/*1566*/ 			Scanner_ReadCh();
/*1568*/ 		} else {
/*1568*/ 			Scanner_sym = 74;
/*1571*/ 		}
/*1571*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1572*/ 		Scanner_ReadCh();
/*1573*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1574*/ 			Scanner_ReadCh();
/*1575*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1576*/ 				Scanner_ReadCh();
/*1577*/ 				Scanner_sym = 45;
/*1579*/ 			} else {
/*1579*/ 				Scanner_sym = 44;
/*1581*/ 			}
/*1581*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1582*/ 			Scanner_ReadCh();
/*1583*/ 			Scanner_sym = 32;
/*1585*/ 		} else {
/*1585*/ 			Scanner_sym = 31;
/*1588*/ 		}
/*1588*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(60)) == 0 ){
/*1589*/ 		Scanner_ReadCh();
/*1590*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1591*/ 			Scanner_sym = 51;
/*1592*/ 			Scanner_ReadCh();
/*1593*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1594*/ 			Scanner_sym = 46;
/*1595*/ 			Scanner_ReadCh();
/*1596*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(60)) == 0 ){
/*1597*/ 			Scanner_ReadCh();
/*1598*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1599*/ 				Scanner_ReadCh();
/*1600*/ 				Scanner_sym = 84;
/*1601*/ 			} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(60)) == 0 ){
/*1602*/ 				Scanner_ReadCh();
/*1603*/ 				return Scanner_ParseHereDoc();
/*1605*/ 			} else {
/*1605*/ 				Scanner_sym = 86;
/*1608*/ 			}
/*1608*/ 		} else {
/*1608*/ 			Scanner_sym = 50;
/*1611*/ 		}
/*1611*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1612*/ 		Scanner_ReadCh();
/*1613*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1614*/ 			Scanner_sym = 49;
/*1615*/ 			Scanner_ReadCh();
/*1616*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1617*/ 			Scanner_ReadCh();
/*1618*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1619*/ 				Scanner_ReadCh();
/*1620*/ 				Scanner_sym = 85;
/*1622*/ 			} else {
/*1622*/ 				Scanner_sym = 87;
/*1625*/ 			}
/*1625*/ 		} else {
/*1625*/ 			Scanner_sym = 48;
/*1628*/ 		}
/*1628*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(33)) == 0 ){
/*1629*/ 		Scanner_ReadCh();
/*1630*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1631*/ 			Scanner_ReadCh();
/*1632*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1633*/ 				Scanner_ReadCh();
/*1634*/ 				Scanner_sym = 47;
/*1636*/ 			} else {
/*1636*/ 				Scanner_sym = 46;
/*1639*/ 			}
/*1639*/ 		} else {
/*1639*/ 			Scanner_sym = 54;
/*1642*/ 		}
/*1642*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(124)) == 0 ){
/*1643*/ 		Scanner_ReadCh();
/*1644*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(124)) == 0 ){
/*1645*/ 			Scanner_ReadCh();
/*1646*/ 			Scanner_sym = 55;
/*1647*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1648*/ 			Scanner_sym = 82;
/*1649*/ 			Scanner_ReadCh();
/*1651*/ 		} else {
/*1651*/ 			Scanner_sym = 72;
/*1654*/ 		}
/*1654*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(38)) == 0 ){
/*1655*/ 		Scanner_ReadCh();
/*1656*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(38)) == 0 ){
/*1657*/ 			Scanner_ReadCh();
/*1658*/ 			Scanner_sym = 57;
/*1659*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1660*/ 			Scanner_sym = 81;
/*1661*/ 			Scanner_ReadCh();
/*1663*/ 		} else {
/*1663*/ 			Scanner_sym = 73;
/*1666*/ 		}
/*1666*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1667*/ 		Scanner_ReadCh();
/*1668*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1669*/ 			Scanner_ReadCh();
/*1670*/ 			Scanner_sym = 75;
/*1672*/ 		} else {
/*1672*/ 			Scanner_sym = 60;
/*1675*/ 		}
/*1675*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(94)) == 0 ){
/*1676*/ 		Scanner_ReadCh();
/*1677*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1678*/ 			Scanner_sym = 83;
/*1679*/ 			Scanner_ReadCh();
/*1681*/ 		} else {
/*1681*/ 			Scanner_sym = 88;
/*1684*/ 		}
/*1684*/ 	} else if( Scanner_c == NULL ){
/*1685*/ 		Scanner_sym = 0;
/*1688*/ 	} else {
/*1688*/ 		Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"unexpected character ", Scanner_ReportChar(m2runtime_ASC(Scanner_c)), 1));
/*1691*/ 	}
/*1691*/ 	return FALSE;
/*1695*/ }


/*1696*/ void
/*1696*/ Scanner_ReadSym(void)
/*1696*/ {
/*1698*/ 	int Scanner_new_sym_found = 0;
/*1699*/ 	do {
/*1700*/ 		Scanner_new_sym_found = FALSE;
/*1702*/ 		switch(Scanner_code){

/*1704*/ 		case 0:
/*1705*/ 		Scanner_FindOpenTag();
/*1707*/ 		break;

/*1707*/ 		case 1:
/*1708*/ 		Scanner_new_sym_found = Scanner_ParseCode();
/*1710*/ 		break;

/*1710*/ 		case 2:
/*1711*/ 		Scanner_new_sym_found = Scanner_ParseXCode();
/*1713*/ 		break;

/*1713*/ 		case 3:
/*1720*/ 		Scanner_ParseKeyword();
/*1721*/ 		if( (Scanner_sym != 1) ){
/*1722*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the name `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"' is a keyword.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)" This is deprecated by PHP and forbidden by PHPLint.", 1));
/*1725*/ 		}
/*1725*/ 		Scanner_sym = 35;
/*1726*/ 		Scanner_code = 4;
/*1728*/ 		break;

/*1728*/ 		case 4:
/*1735*/ 		Scanner_new_sym_found = Scanner_ParseDoubleQuotedString();
/*1738*/ 		break;

/*1738*/ 		default: m2runtime_missing_case_in_switch(Scanner_0err_entry_get, 32);
/*1739*/ 		}
/*1739*/ 	} while( !( !Scanner_new_sym_found ));
/*1741*/ 	if( Globals_DEBUG ){
/*1742*/ 		m2_print(m2runtime_CHR(91));
/*1743*/ 		m2_print(Tokens_CodeToName(Scanner_sym));
/*1744*/ 		m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"]\012");
/*1747*/ 	}
/*1749*/ }


/*1751*/ int
/*1751*/ Scanner_Open(STRING *Scanner_abs_fn)
/*1751*/ {
/*1751*/ 	Scanner_fn = Scanner_abs_fn;
/*1752*/ 	m2runtime_ERROR_CODE = 0;
/*1752*/ 	io_Open(1, (void *)&Scanner_fd, Scanner_fn, m2runtime_CHR(114));
/*1754*/ 	switch( m2runtime_ERROR_CODE ){

/*1754*/ 	case 0:  break;
/*1754*/ 	default:
/*1754*/ 		Scanner_Error(m2runtime_ERROR_MESSAGE);
/*1755*/ 		return FALSE;
/*1758*/ 	}
/*1758*/ 	if( Scanner_print_source ){
/*1759*/ 		m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"\012BEGIN parsing of ", Scanner_fmt_fn(Scanner_abs_fn), m2runtime_CHR(10), 1));
/*1762*/ 	}
/*1762*/ 	Scanner_code = 0;
/*1763*/ 	m2runtime_ERROR_CODE = 0;
/*1763*/ 	Scanner_line = io_ReadLine(1, Scanner_fd);
/*1764*/ 	switch( m2runtime_ERROR_CODE ){

/*1764*/ 	case 0:  break;
/*1764*/ 	default:
/*1764*/ 		m2runtime_HALT(Scanner_0err_entry_get, 33, m2runtime_ERROR_MESSAGE);
/*1764*/ 	}
/*1764*/ 	Scanner_line_n = 1;
/*1765*/ 	Scanner_line_idx = 0;
/*1766*/ 	Scanner_line_pos = 0;
/*1767*/ 	Scanner_c = NULL;
/*1769*/ 	if( Scanner_print_source ){
/*1770*/ 		Scanner_PrintLineSource();
/*1773*/ 	}
/*1773*/ 	Scanner_ReadCh();
/*1774*/ 	Scanner_ReadSym();
/*1775*/ 	return TRUE;
/*1779*/ }


/*1780*/ RECORD *
/*1780*/ Scanner_Suspend(void)
/*1780*/ {
/*1782*/ 	RECORD * Scanner_r = NULL;
/*1782*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 28, Scanner_0err_entry_get, 34) = Scanner_code;
/*1783*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 48, Scanner_0err_entry_get, 35) = Scanner_sym;
/*1784*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 12, Scanner_0err_entry_get, 36) = Scanner_fn;
/*1785*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 16, Scanner_0err_entry_get, 37) = Scanner_fd;
/*1786*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 20, Scanner_0err_entry_get, 38) = Scanner_line;
/*1787*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 52, Scanner_0err_entry_get, 39) = Scanner_line_n;
/*1788*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 56, Scanner_0err_entry_get, 40) = Scanner_line_idx;
/*1789*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 60, Scanner_0err_entry_get, 41) = Scanner_line_pos;
/*1790*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 24, Scanner_0err_entry_get, 42) = Scanner_c;
/*1791*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 8, Scanner_0err_entry_get, 43) = Scanner_s;
/*1792*/ 	return Scanner_r;
/*1796*/ }


/*1798*/ void
/*1798*/ Scanner_Resume(RECORD *Scanner_r)
/*1798*/ {
/*1798*/ 	Scanner_code =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 28, Scanner_0err_entry_get, 44);
/*1799*/ 	Scanner_sym =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 48, Scanner_0err_entry_get, 45);
/*1800*/ 	Scanner_fn = (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_r, 12, Scanner_0err_entry_get, 46);
/*1801*/ 	Scanner_fd = (void *)m2runtime_dereference_rhs_RECORD(Scanner_r, 16, Scanner_0err_entry_get, 47);
/*1802*/ 	Scanner_line = (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_r, 20, Scanner_0err_entry_get, 48);
/*1803*/ 	Scanner_line_n =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 52, Scanner_0err_entry_get, 49);
/*1804*/ 	Scanner_line_idx =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 56, Scanner_0err_entry_get, 50);
/*1805*/ 	Scanner_line_pos =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 60, Scanner_0err_entry_get, 51);
/*1806*/ 	Scanner_c = (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_r, 24, Scanner_0err_entry_get, 52);
/*1807*/ 	Scanner_s = (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_r, 8, Scanner_0err_entry_get, 53);
/*1811*/ }


/*1813*/ void
/*1813*/ Scanner_Close(void)
/*1813*/ {
/*1813*/ 	if( Scanner_print_source ){
/*1814*/ 		m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"END parsing of ", Scanner_fmt_fn(Scanner_fn), m2runtime_CHR(10), 1));
/*1816*/ 	}
/*1816*/ 	m2runtime_ERROR_CODE = 0;
/*1816*/ 	io_Close(1, (void *)&Scanner_fd);
/*1817*/ 	switch( m2runtime_ERROR_CODE ){

/*1817*/ 	case 0:  break;
/*1817*/ 	default:
/*1817*/ 		m2runtime_HALT(Scanner_0err_entry_get, 54, m2runtime_ERROR_MESSAGE);
/*1817*/ 	}
/*1817*/ 	Scanner_fn = NULL;
/*1822*/ }


char * Scanner_0func[] = {
    "mn",
    "fmt_fn",
    "reference",
    "PrintWhere",
    "ReadCh",
    "SearchKeyword",
    "FindOpenTag",
    "SkipSingleLineComment",
    "ReportChar",
    "is_id_first_char",
    "is_id_char",
    "hex",
    "ParseEscapeCode",
    "ParseDoubleQuotedString",
    "ParseSingleQuotedString",
    "ParseNumber",
    "ParseCode",
    "ReadSym",
    "Open",
    "Suspend",
    "Resume",
    "Close"
};

int Scanner_0err_entry[] = {
    0 /* mn */, 108,
    0 /* mn */, 108,
    1 /* fmt_fn */, 130,
    1 /* fmt_fn */, 131,
    2 /* reference */, 144,
    2 /* reference */, 145,
    2 /* reference */, 147,
    2 /* reference */, 147,
    2 /* reference */, 149,
    3 /* PrintWhere */, 164,
    3 /* PrintWhere */, 165,
    3 /* PrintWhere */, 167,
    4 /* ReadCh */, 304,
    4 /* ReadCh */, 310,
    4 /* ReadCh */, 316,
    5 /* SearchKeyword */, 357,
    5 /* SearchKeyword */, 357,
    5 /* SearchKeyword */, 363,
    5 /* SearchKeyword */, 363,
    5 /* SearchKeyword */, 373,
    6 /* FindOpenTag */, 531,
    6 /* FindOpenTag */, 533,
    7 /* SkipSingleLineComment */, 584,
    8 /* ReportChar */, 663,
    9 /* is_id_first_char */, 704,
    10 /* is_id_char */, 721,
    11 /* hex */, 747,
    12 /* ParseEscapeCode */, 825,
    13 /* ParseDoubleQuotedString */, 995,
    14 /* ParseSingleQuotedString */, 1090,
    15 /* ParseNumber */, 1263,
    16 /* ParseCode */, 1539,
    17 /* ReadSym */, 1737,
    18 /* Open */, 1763,
    19 /* Suspend */, 1782,
    19 /* Suspend */, 1783,
    19 /* Suspend */, 1784,
    19 /* Suspend */, 1785,
    19 /* Suspend */, 1786,
    19 /* Suspend */, 1787,
    19 /* Suspend */, 1788,
    19 /* Suspend */, 1789,
    19 /* Suspend */, 1790,
    19 /* Suspend */, 1791,
    20 /* Resume */, 1798,
    20 /* Resume */, 1799,
    20 /* Resume */, 1800,
    20 /* Resume */, 1801,
    20 /* Resume */, 1802,
    20 /* Resume */, 1803,
    20 /* Resume */, 1804,
    20 /* Resume */, 1805,
    20 /* Resume */, 1806,
    20 /* Resume */, 1807,
    21 /* Close */, 1816
};

void Scanner_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Scanner";
    *f = Scanner_0func[ Scanner_0err_entry[2*i] ];
    *l = Scanner_0err_entry[2*i + 1];
}
