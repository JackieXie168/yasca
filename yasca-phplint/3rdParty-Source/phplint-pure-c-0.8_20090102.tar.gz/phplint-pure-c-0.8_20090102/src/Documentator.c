/* IMPLEMENTATION MODULE Documentator */
#define M2_IMPORT_Documentator

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

#ifndef M2_IMPORT_io
#    include "io.c"
#endif

#ifndef M2_IMPORT_Classes
#    include "Classes.c"
#endif

#ifndef M2_IMPORT_buffer
#    include "buffer.c"
#endif

#ifndef M2_IMPORT_FileName
#    include "FileName.c"
#endif

void Documentator_0err_entry_get(int i, char **m, char **f, int *l);
/* 18*/ int Documentator_generate = 0;
/* 21*/ STRING * Documentator_extension = NULL;
/* 24*/ STRING * Documentator_page_footer = NULL;
/* 24*/ STRING * Documentator_page_header = NULL;
/* 33*/ ARRAY * Documentator_ref_remap = NULL;
/* 34*/ int Documentator_php_ver = 0;
/* 36*/ STRING * Documentator_fn = NULL;
/* 37*/ STRING * Documentator_package_descr = NULL;
/* 38*/ ARRAY * Documentator_required_packages = NULL;
/* 39*/ ARRAY * Documentator_include_path = NULL;
/* 40*/ ARRAY * Documentator_consts = NULL;
/* 41*/ ARRAY * Documentator_vars = NULL;
/* 42*/ ARRAY * Documentator_funcs = NULL;
/* 44*/ ARRAY * Documentator_classes = NULL;
/* 47*/ void * Documentator_fd = NULL;
/* 51*/ STRING * Documentator_fn_remapped = NULL;
/* 59*/ RECORD * Documentator_curr_class = NULL;
/* 67*/ STRING * Documentator_see = NULL;
/* 67*/ STRING * Documentator_deprecated = NULL;
/* 67*/ STRING * Documentator_since = NULL;
/* 67*/ STRING * Documentator_authors = NULL;
/* 67*/ STRING * Documentator_license = NULL;
/* 67*/ STRING * Documentator_copyright = NULL;
/* 67*/ STRING * Documentator_version = NULL;
/* 67*/ STRING * Documentator_package = NULL;
/* 70*/ int Documentator_prev_item_big_vspace = 0;
/* 73*/ STRING * Documentator_private_items = NULL;

/* 75*/ void
/* 75*/ Documentator_DocError(STRING *Documentator_msg)
/* 75*/ {
/* 75*/ 	m2_print(m2runtime_concat_STRING(0, Documentator_fn, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)": DOC ERROR: ", Documentator_msg, m2runtime_CHR(10), 1));
/* 79*/ }


/* 81*/ void
/* 81*/ Documentator_p(STRING *Documentator_s)
/* 81*/ {
/* 81*/ 	m2runtime_ERROR_CODE = 0;
/* 81*/ 	io_Write(1, *(void **)(void *)&Documentator_fd, Documentator_s);
/* 82*/ 	switch( m2runtime_ERROR_CODE ){

/* 82*/ 	case 0:  break;
/* 82*/ 	default:
/* 82*/ 		m2runtime_HALT(Documentator_0err_entry_get, 0, m2runtime_ERROR_MESSAGE);
/* 83*/ 	}
/* 85*/ }


/* 87*/ int
/* 87*/ Documentator_is_space(STRING *Documentator_c)
/* 87*/ {
/* 87*/ 	return ((m2runtime_strcmp(Documentator_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Documentator_c, m2runtime_CHR(9)) == 0) || (m2runtime_strcmp(Documentator_c, m2runtime_CHR(10)) == 0) || (m2runtime_strcmp(Documentator_c, m2runtime_CHR(13)) == 0));
/* 91*/ }


/* 93*/ STRING *
/* 93*/ Documentator_Anchor(STRING *Documentator_url, STRING *Documentator_text)
/* 93*/ {
/* 93*/ 	return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"<A href=\042", Documentator_url, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\042>", Documentator_text, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</A>", 1);
/* 97*/ }


/*107*/ STRING *
/*107*/ Documentator_RefMap(STRING *Documentator_f)
/*107*/ {
/*108*/ 	STRING * Documentator_t = NULL;
/*110*/ 	int Documentator_i = 0;
/*110*/ 	{
/*110*/ 		int m2runtime_for_limit_1;
/*110*/ 		Documentator_i = 0;
/*110*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_ref_remap) - 1);
/*111*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 2 ){
/*111*/ 			Documentator_t = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_ref_remap, Documentator_i, Documentator_0err_entry_get, 1);
/*112*/ 			if( (((m2runtime_length(Documentator_t) <= m2runtime_length(Documentator_f))) && (m2runtime_strcmp(m2runtime_substr(Documentator_f, 0, m2runtime_length(Documentator_t), 1, Documentator_0err_entry_get, 2), Documentator_t) == 0)) ){
/*113*/ 				return m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_ref_remap, (Documentator_i + 1), Documentator_0err_entry_get, 3), m2runtime_substr(Documentator_f, m2runtime_length(Documentator_t), m2runtime_length(Documentator_f), 1, Documentator_0err_entry_get, 4), 1);
/*116*/ 			}
/*116*/ 		}
/*116*/ 	}
/*116*/ 	return Documentator_f;
/*120*/ }


/*136*/ STRING *
/*136*/ Documentator_ItemToUrl(STRING *Documentator_t)
/*136*/ {

/*138*/ 	STRING *
/*138*/ 	Documentator_err(STRING *Documentator_msg)
/*138*/ 	{
/*138*/ 		Documentator_DocError(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"<@item ", Documentator_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)">: ", Documentator_msg, m2runtime_CHR(10), 1));
/*139*/ 		return m2runtime_CHR(35);
/*143*/ 	}


/*144*/ 	RECORD *
/*144*/ 	Documentator_SearchConst(STRING *Documentator_n)
/*144*/ 	{
/*146*/ 		int Documentator_i = 0;
/*146*/ 		{
/*146*/ 			int m2runtime_for_limit_1;
/*146*/ 			Documentator_i = 0;
/*146*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*147*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*147*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 5), 8, Documentator_0err_entry_get, 6), Documentator_n) == 0 ){
/*148*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 7);
/*151*/ 				}
/*151*/ 			}
/*151*/ 		}
/*151*/ 		return NULL;
/*155*/ 	}


/*156*/ 	RECORD *
/*156*/ 	Documentator_SearchVar(STRING *Documentator_n)
/*156*/ 	{
/*158*/ 		int Documentator_i = 0;
/*158*/ 		{
/*158*/ 			int m2runtime_for_limit_1;
/*158*/ 			Documentator_i = 0;
/*158*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_vars) - 1);
/*159*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*159*/ 				if( (((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_vars, Documentator_i, Documentator_0err_entry_get, 8) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_vars, Documentator_i, Documentator_0err_entry_get, 9), 8, Documentator_0err_entry_get, 10), Documentator_n) == 0)) ){
/*160*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_vars, Documentator_i, Documentator_0err_entry_get, 11);
/*163*/ 				}
/*163*/ 			}
/*163*/ 		}
/*163*/ 		return NULL;
/*167*/ 	}


/*168*/ 	RECORD *
/*168*/ 	Documentator_SearchFunc(STRING *Documentator_n)
/*168*/ 	{
/*170*/ 		int Documentator_i = 0;
/*170*/ 		{
/*170*/ 			int m2runtime_for_limit_1;
/*170*/ 			Documentator_i = 0;
/*170*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_funcs) - 1);
/*171*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*171*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_funcs, Documentator_i, Documentator_0err_entry_get, 12), 8, Documentator_0err_entry_get, 13), Documentator_n) == 0 ){
/*172*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_funcs, Documentator_i, Documentator_0err_entry_get, 14);
/*175*/ 				}
/*175*/ 			}
/*175*/ 		}
/*175*/ 		return NULL;
/*179*/ 	}


/*180*/ 	RECORD *
/*180*/ 	Documentator_SearchClass(STRING *Documentator_n)
/*180*/ 	{
/*182*/ 		int Documentator_i = 0;
/*182*/ 		{
/*182*/ 			int m2runtime_for_limit_1;
/*182*/ 			Documentator_i = 0;
/*182*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_classes) - 1);
/*183*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*183*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_classes, Documentator_i, Documentator_0err_entry_get, 15), 8, Documentator_0err_entry_get, 16), Documentator_n) == 0 ){
/*184*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_classes, Documentator_i, Documentator_0err_entry_get, 17);
/*187*/ 				}
/*187*/ 			}
/*187*/ 		}
/*187*/ 		return NULL;
/*191*/ 	}


/*192*/ 	RECORD *
/*192*/ 	Documentator_SearchClassConst(RECORD *Documentator_cl, STRING *Documentator_n)
/*192*/ 	{
/*192*/ 		int Documentator_i = 0;
/*194*/ 		ARRAY * Documentator_consts = NULL;
/*194*/ 		Documentator_consts = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 28, Documentator_0err_entry_get, 18);
/*195*/ 		{
/*195*/ 			int m2runtime_for_limit_1;
/*195*/ 			Documentator_i = 0;
/*195*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*196*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*196*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 19), 8, Documentator_0err_entry_get, 20), Documentator_n) == 0 ){
/*197*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 21);
/*200*/ 				}
/*200*/ 			}
/*200*/ 		}
/*200*/ 		return NULL;
/*204*/ 	}


/*205*/ 	RECORD *
/*205*/ 	Documentator_SearchClassVar(RECORD *Documentator_cl, STRING *Documentator_n)
/*205*/ 	{
/*205*/ 		int Documentator_i = 0;
/*207*/ 		ARRAY * Documentator_p = NULL;
/*207*/ 		Documentator_p = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 32, Documentator_0err_entry_get, 22);
/*208*/ 		{
/*208*/ 			int m2runtime_for_limit_1;
/*208*/ 			Documentator_i = 0;
/*208*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_p) - 1);
/*209*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*209*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_p, Documentator_i, Documentator_0err_entry_get, 23), 8, Documentator_0err_entry_get, 24), Documentator_n) == 0 ){
/*210*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_p, Documentator_i, Documentator_0err_entry_get, 25);
/*213*/ 				}
/*213*/ 			}
/*213*/ 		}
/*213*/ 		return NULL;
/*217*/ 	}


/*218*/ 	RECORD *
/*218*/ 	Documentator_SearchClassFunc(RECORD *Documentator_cl, STRING *Documentator_n)
/*218*/ 	{
/*218*/ 		int Documentator_i = 0;
/*220*/ 		ARRAY * Documentator_m = NULL;
/*220*/ 		Documentator_m = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 36, Documentator_0err_entry_get, 26);
/*221*/ 		{
/*221*/ 			int m2runtime_for_limit_1;
/*221*/ 			Documentator_i = 0;
/*221*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_m) - 1);
/*222*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*222*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_m, Documentator_i, Documentator_0err_entry_get, 27), 8, Documentator_0err_entry_get, 28), Documentator_n) == 0 ){
/*223*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_m, Documentator_i, Documentator_0err_entry_get, 29);
/*226*/ 				}
/*226*/ 			}
/*226*/ 		}
/*226*/ 		return NULL;
/*230*/ 	}


/*231*/ 	STRING *
/*231*/ 	Documentator_report(RECORD *Documentator_decl_in)
/*231*/ 	{
/*233*/ 		int Documentator_i = 0;
/*233*/ 		if( Documentator_decl_in == NULL ){
/*234*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"not declared / not assigned");
/*236*/ 		}
/*236*/ 		Documentator_i = str_find(Documentator_t, m2runtime_CHR(40));
/*237*/ 		if( (Documentator_i >= 0) ){
/*238*/ 			Documentator_t = m2runtime_concat_STRING(0, m2runtime_substr(Documentator_t, 0, Documentator_i, 1, Documentator_0err_entry_get, 30), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1);
/*240*/ 		}
/*240*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_decl_in, 8, Documentator_0err_entry_get, 31), Documentator_fn) == 0 ){
/*241*/ 			return m2runtime_concat_STRING(0, m2runtime_CHR(35), Documentator_t, 1);
/*243*/ 		} else {
/*243*/ 			return FileName_Relative(Documentator_fn_remapped, Documentator_RefMap(m2runtime_concat_STRING(0, FileName_DropExtension((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_decl_in, 8, Documentator_0err_entry_get, 32)), Documentator_extension, m2runtime_CHR(35), Documentator_t, 1)));
/*247*/ 		}
/*247*/ 		m2runtime_missing_return(Documentator_0err_entry_get, 33);
/*247*/ 		return NULL;
/*249*/ 	}

/*250*/ 	STRING * Documentator_n = NULL;
/*251*/ 	int Documentator_j = 0;
/*252*/ 	int Documentator_tlen = 0;
/*253*/ 	RECORD * Documentator_c = NULL;
/*254*/ 	RECORD * Documentator_v = NULL;
/*255*/ 	RECORD * Documentator_f = NULL;
/*256*/ 	RECORD * Documentator_cl = NULL;
/*259*/ 	RECORD * Documentator_cl_c = NULL;
/*259*/ 	Documentator_tlen = m2runtime_length(Documentator_t);
/*260*/ 	if( (Documentator_tlen == 0) ){
/*261*/ 		return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"empty target");
/*264*/ 	}
/*264*/ 	if( m2runtime_strcmp(m2runtime_substr(Documentator_t, 0, 0, 0, Documentator_0err_entry_get, 34), m2runtime_CHR(36)) == 0 ){
/*265*/ 		Documentator_v = Documentator_SearchVar(m2runtime_substr(Documentator_t, 1, Documentator_tlen, 1, Documentator_0err_entry_get, 35));
/*266*/ 		if( Documentator_v == NULL ){
/*267*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"variable not found in global scope");
/*269*/ 		} else {
/*269*/ 			return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_v, 12, Documentator_0err_entry_get, 36));
/*272*/ 		}
/*273*/ 	}
/*273*/ 	Documentator_j = str_find(Documentator_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::");
/*274*/ 	if( (Documentator_j >= 0) ){
/*277*/ 		if( (Documentator_j == 0) ){
/*278*/ 			if( Documentator_curr_class == NULL ){
/*279*/ 				Documentator_DocError((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"missing class name");
/*280*/ 				Documentator_cl = NULL;
/*282*/ 			} else {
/*282*/ 				Documentator_cl = Documentator_curr_class;
/*283*/ 				Documentator_t = m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 8, Documentator_0err_entry_get, 37), Documentator_t, 1);
/*284*/ 				Documentator_j = m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 8, Documentator_0err_entry_get, 38));
/*285*/ 				Documentator_tlen = m2runtime_length(Documentator_t);
/*288*/ 			}
/*288*/ 		} else {
/*288*/ 			Documentator_cl = Documentator_SearchClass(m2runtime_substr(Documentator_t, 0, Documentator_j, 1, Documentator_0err_entry_get, 39));
/*290*/ 		}
/*290*/ 		if( Documentator_cl == NULL ){
/*291*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"class not found");
/*296*/ 		}
/*296*/ 		Documentator_n = m2runtime_substr(Documentator_t, (Documentator_j + 2), Documentator_tlen, 1, Documentator_0err_entry_get, 40);
/*298*/ 		if( (((m2runtime_length(Documentator_n) >= 1)) && (m2runtime_strcmp(m2runtime_substr(Documentator_n, 0, 0, 0, Documentator_0err_entry_get, 41), m2runtime_CHR(36)) == 0)) ){
/*299*/ 			if( Documentator_SearchClassVar(Documentator_cl, m2runtime_substr(Documentator_n, 1, m2runtime_length(Documentator_n), 1, Documentator_0err_entry_get, 42)) == NULL ){
/*300*/ 				return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"property not found");
/*302*/ 			} else {
/*302*/ 				return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 43));
/*305*/ 			}
/*306*/ 		}
/*306*/ 		if( (((m2runtime_length(Documentator_n) >= 2)) && (m2runtime_strcmp(m2runtime_substr(Documentator_n, (m2runtime_length(Documentator_n) - 1), 0, 0, Documentator_0err_entry_get, 44), m2runtime_CHR(41)) == 0)) ){
/*307*/ 			Documentator_j = str_find(Documentator_n, m2runtime_CHR(40));
/*308*/ 			if( (Documentator_j < 0) ){
/*309*/ 				return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"missing ( in method name");
/*311*/ 			}
/*311*/ 			if( Documentator_SearchClassFunc(Documentator_cl, m2runtime_substr(Documentator_n, 0, Documentator_j, 1, Documentator_0err_entry_get, 45)) == NULL ){
/*312*/ 				return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"method not found");
/*314*/ 			} else {
/*314*/ 				return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 46));
/*317*/ 			}
/*318*/ 		}
/*318*/ 		Documentator_cl_c = Documentator_SearchClassConst(Documentator_cl, Documentator_n);
/*319*/ 		if( Documentator_cl_c != NULL ){
/*320*/ 			return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl_c, 16, Documentator_0err_entry_get, 47));
/*323*/ 		}
/*323*/ 		return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"class constant not found");
/*326*/ 	}
/*326*/ 	if( (((Documentator_tlen > 2)) && (m2runtime_strcmp(m2runtime_substr(Documentator_t, (Documentator_tlen - 1), 0, 0, Documentator_0err_entry_get, 48), m2runtime_CHR(41)) == 0)) ){
/*327*/ 		Documentator_j = str_find(Documentator_t, m2runtime_CHR(40));
/*328*/ 		if( (Documentator_j < 0) ){
/*329*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"missing ( in function name");
/*331*/ 		}
/*331*/ 		Documentator_f = Documentator_SearchFunc(m2runtime_substr(Documentator_t, 0, Documentator_j, 1, Documentator_0err_entry_get, 49));
/*332*/ 		if( Documentator_f == NULL ){
/*333*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"function not found");
/*335*/ 		}
/*335*/ 		return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_f, 16, Documentator_0err_entry_get, 50));
/*338*/ 	}
/*338*/ 	Documentator_cl = Documentator_SearchClass(Documentator_t);
/*339*/ 	if( Documentator_cl != NULL ){
/*340*/ 		return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 51));
/*343*/ 	}
/*343*/ 	Documentator_c = Documentator_SearchConst(Documentator_t);
/*344*/ 	if( Documentator_c != NULL ){
/*345*/ 		return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 52));
/*348*/ 	}
/*348*/ 	return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"constant / class not found");
/*352*/ }


/*353*/ void
/*353*/ Documentator_AnchorToClass(RECORD *Documentator_c)
/*353*/ {
/*355*/ 	STRING * Documentator_name = NULL;
/*355*/ 	Documentator_name = (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 53);
/*356*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 64, Documentator_0err_entry_get, 54) ){
/*357*/ 		Documentator_DocError(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"the class ", Documentator_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)" is private and cannot be referenced", 1));
/*358*/ 		Documentator_p(Documentator_name);
/*360*/ 	} else {
/*360*/ 		Documentator_p(Documentator_Anchor(Documentator_ItemToUrl(Documentator_name), Documentator_name));
/*363*/ 	}
/*365*/ }


/*366*/ STRING *
/*366*/ Documentator_ResolveTag(STRING *Documentator_tag, STRING *Documentator_arg)
/*366*/ {
/*368*/ 	STRING * Documentator_s = NULL;
/*368*/ 	if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"package") == 0 ){
/*369*/ 		Documentator_package = Documentator_arg;
/*370*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"version") == 0 ){
/*371*/ 		Documentator_version = Documentator_arg;
/*372*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"copyright") == 0 ){
/*373*/ 		Documentator_copyright = Documentator_arg;
/*374*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"license") == 0 ){
/*375*/ 		Documentator_license = Documentator_arg;
/*376*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"author") == 0 ){
/*377*/ 		if( (m2runtime_length(Documentator_authors) == 0) ){
/*378*/ 			Documentator_authors = Documentator_arg;
/*380*/ 		} else {
/*380*/ 			Documentator_authors = m2runtime_concat_STRING(0, Documentator_authors, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ", Documentator_arg, 1);
/*382*/ 		}
/*382*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"since") == 0 ){
/*383*/ 		Documentator_since = Documentator_arg;
/*384*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"item") == 0 ){
/*385*/ 		return Documentator_Anchor(Documentator_ItemToUrl(Documentator_arg), Documentator_arg);
/*386*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"deprecated") == 0 ){
/*387*/ 		Documentator_deprecated = Documentator_arg;
/*388*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"see") == 0 ){
/*389*/ 		Documentator_s = Documentator_Anchor(Documentator_ItemToUrl(Documentator_arg), Documentator_arg);
/*390*/ 		if( (m2runtime_length(Documentator_see) == 0) ){
/*391*/ 			Documentator_see = Documentator_s;
/*393*/ 		} else {
/*393*/ 			Documentator_see = m2runtime_concat_STRING(0, Documentator_see, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ", Documentator_s, 1);
/*396*/ 		}
/*396*/ 	} else {
/*396*/ 		Documentator_DocError(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"undefined tag <@", Documentator_tag, m2runtime_CHR(62), 1));
/*398*/ 	}
/*398*/ 	return EMPTY_STRING;
/*402*/ }


/*407*/ STRING *
/*407*/ Documentator_ResolveTags(STRING *Documentator_s)
/*407*/ {
/*408*/ 	int Documentator_i = 0;
/*409*/ 	STRING * Documentator_r = NULL;
/*409*/ 	STRING * Documentator_arg = NULL;
/*409*/ 	STRING * Documentator_tag = NULL;
/*410*/ 	int Documentator_l = 0;
/*412*/ 	int Documentator_recursive_tags = 0;
/*413*/ 	do {
/*413*/ 		Documentator_i = str_find(Documentator_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"<@");
/*414*/ 		if( (Documentator_i < 0) ){
/*415*/ 			return m2runtime_concat_STRING(0, Documentator_r, Documentator_s, 1);
/*417*/ 		}
/*417*/ 		Documentator_r = m2runtime_concat_STRING(0, Documentator_r, m2runtime_substr(Documentator_s, 0, Documentator_i, 1, Documentator_0err_entry_get, 55), 1);
/*418*/ 		m2_inc(&Documentator_i, 2);
/*421*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 56))) ){
/*422*/ 			m2_inc(&Documentator_i, 1);
/*426*/ 		}
/*426*/ 		Documentator_tag = NULL;
/*427*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && !Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 57)) && (m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 58), m2runtime_CHR(62)) != 0)) ){
/*428*/ 			Documentator_tag = m2runtime_concat_STRING(0, Documentator_tag, m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 59), 1);
/*429*/ 			m2_inc(&Documentator_i, 1);
/*433*/ 		}
/*433*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 60))) ){
/*434*/ 			m2_inc(&Documentator_i, 1);
/*438*/ 		}
/*438*/ 		Documentator_arg = NULL;
/*439*/ 		Documentator_recursive_tags = FALSE;
/*440*/ 		Documentator_l = 0;
/*441*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && ((((Documentator_l > 0)) || (m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 61), m2runtime_CHR(62)) != 0)))) ){
/*442*/ 			Documentator_arg = m2runtime_concat_STRING(0, Documentator_arg, m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 62), 1);
/*443*/ 			if( m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 63), m2runtime_CHR(60)) == 0 ){
/*444*/ 				Documentator_recursive_tags = TRUE;
/*445*/ 				m2_inc(&Documentator_l, 1);
/*447*/ 			}
/*447*/ 			if( m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 64), m2runtime_CHR(62)) == 0 ){
/*448*/ 				m2_inc(&Documentator_l, -1);
/*450*/ 			}
/*450*/ 			m2_inc(&Documentator_i, 1);
/*454*/ 		}
/*454*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 65))) ){
/*455*/ 			m2_inc(&Documentator_i, 1);
/*458*/ 		}
/*458*/ 		if( (((Documentator_i == m2runtime_length(Documentator_s))) || (m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 66), m2runtime_CHR(62)) != 0)) ){
/*459*/ 			Documentator_DocError(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"missing closing > IN <@", Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"...>\012", 1));
/*461*/ 		} else {
/*461*/ 			m2_inc(&Documentator_i, 1);
/*464*/ 		}
/*464*/ 		if( Documentator_recursive_tags ){
/*465*/ 			Documentator_arg = Documentator_ResolveTags(Documentator_arg);
/*468*/ 		}
/*468*/ 		Documentator_r = m2runtime_concat_STRING(0, Documentator_r, Documentator_ResolveTag(Documentator_tag, Documentator_arg), 1);
/*469*/ 		Documentator_s = m2runtime_substr(Documentator_s, Documentator_i, m2runtime_length(Documentator_s), 1, Documentator_0err_entry_get, 67);
/*470*/ 	} while( !( (m2runtime_length(Documentator_s) == 0) ));
/*471*/ 	return Documentator_r;
/*475*/ }


/*476*/ STRING *
/*476*/ Documentator_trim(STRING *Documentator_s)
/*476*/ {
/*478*/ 	int Documentator_len = 0;
/*478*/ 	int Documentator_j = 0;
/*478*/ 	int Documentator_i = 0;
/*478*/ 	Documentator_len = m2runtime_length(Documentator_s);
/*479*/ 	if( (Documentator_len == 0) ){
/*480*/ 		return NULL;
/*483*/ 	}
/*483*/ 	Documentator_i = 0;
/*484*/ 	while( (((Documentator_i < Documentator_len)) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 68))) ){
/*485*/ 		m2_inc(&Documentator_i, 1);
/*488*/ 	}
/*488*/ 	Documentator_j = (Documentator_len - 1);
/*489*/ 	while( (((Documentator_j >= Documentator_i)) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 69))) ){
/*490*/ 		m2_inc(&Documentator_j, -1);
/*493*/ 	}
/*493*/ 	return m2runtime_substr(Documentator_s, Documentator_i, (Documentator_j + 1), 1, Documentator_0err_entry_get, 70);
/*497*/ }


/*499*/ void
/*499*/ Documentator_VSpaceBeforeItem(int Documentator_big)
/*499*/ {
/*499*/ 	if( Documentator_prev_item_big_vspace ){
/*501*/ 		return ;
/*501*/ 	} else if( Documentator_big ){
/*502*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"<PRE>\012\012</PRE>\012");
/*504*/ 	} else {
/*504*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<P>\012");
/*507*/ 	}
/*509*/ }


/*511*/ void
/*511*/ Documentator_VSpaceAfterItem(int Documentator_big)
/*511*/ {
/*511*/ 	if( Documentator_big ){
/*512*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"<PRE>\012\012</PRE>\012");
/*514*/ 	}
/*514*/ 	Documentator_prev_item_big_vspace = Documentator_big;
/*518*/ }


/*520*/ void
/*520*/ Documentator_ItemAnchor(STRING *Documentator_s)
/*520*/ {
/*520*/ 	Documentator_p(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"\012<A name=\042", Documentator_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"\042></A>\012", 1));
/*524*/ }


/*532*/ void
/*532*/ Documentator_DocString(STRING *Documentator_s)
/*532*/ {

/*534*/ 	STRING *
/*534*/ 	Documentator_hex(int Documentator_h)
/*534*/ 	{
/*534*/ 		if( (Documentator_h < 10) ){
/*535*/ 			return m2runtime_CHR((m2runtime_ASC(m2runtime_CHR(48)) + Documentator_h));
/*537*/ 		} else {
/*537*/ 			return m2runtime_CHR(((m2runtime_ASC(m2runtime_CHR(65)) + Documentator_h) - 10));
/*540*/ 		}
/*540*/ 		m2runtime_missing_return(Documentator_0err_entry_get, 71);
/*540*/ 		return NULL;
/*542*/ 	}

/*543*/ 	STRING * Documentator_c = NULL;
/*545*/ 	int Documentator_ch = 0;
/*545*/ 	int Documentator_i = 0;
/*545*/ 	if( m2runtime_strcmp(Documentator_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL") == 0 ){
/*547*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL");
/*549*/ 		return ;
/*550*/ 	}
/*550*/ 	Documentator_p(m2runtime_CHR(34));
/*551*/ 	{
/*551*/ 		int m2runtime_for_limit_1;
/*551*/ 		Documentator_i = 0;
/*551*/ 		m2runtime_for_limit_1 = (m2runtime_length(Documentator_s) - 1);
/*552*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*552*/ 			Documentator_c = m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 72);
/*553*/ 			Documentator_ch = m2runtime_ASC(Documentator_c);
/*555*/ 			if( (((Documentator_ch <= 31)) || ((Documentator_ch >= 127))) ){
/*556*/ 				if( (Documentator_ch == 10) ){
/*556*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134n");
/*557*/ 				} else if( (Documentator_ch == 13) ){
/*557*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134r");
/*558*/ 				} else if( (Documentator_ch == 9) ){
/*558*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134t");
/*560*/ 				} else {
/*560*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134x");
/*561*/ 					Documentator_p(Documentator_hex((Documentator_ch / 16)));
/*562*/ 					Documentator_p(Documentator_hex((Documentator_ch % 16)));
/*565*/ 				}
/*565*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(32)) == 0 ){
/*565*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"&nbsp;");
/*566*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(92)) == 0 ){
/*566*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134\134");
/*567*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(34)) == 0 ){
/*567*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134\042");
/*568*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(38)) == 0 ){
/*568*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"&amp;");
/*569*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(60)) == 0 ){
/*569*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&lt;");
/*570*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(62)) == 0 ){
/*570*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&gt;");
/*571*/ 			} else {
/*571*/ 				Documentator_p(Documentator_c);
/*574*/ 			}
/*574*/ 		}
/*574*/ 	}
/*574*/ 	Documentator_p(m2runtime_CHR(34));
/*578*/ }


/*580*/ void
/*580*/ Documentator_DocValue(RECORD *Documentator_t, STRING *Documentator_v)
/*580*/ {
/*580*/ 	if( Documentator_t == NULL ){
/*581*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"<I>FIXME_UNKNOWN_TYPE</I>");
/*583*/ 		return ;
/*584*/ 	}
/*584*/ 	if( Documentator_v == NULL ){
/*585*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"<I>FIXME_UNKNOWN_VALUE</I>");
/*587*/ 		return ;
/*588*/ 	}
/*588*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 16, Documentator_0err_entry_get, 73) == 5) ){
/*589*/ 		if( m2runtime_strcmp(Documentator_v, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"NIL") == 0 ){
/*590*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL");
/*593*/ 		} else {
/*593*/ 			Documentator_DocString(Documentator_v);
/*595*/ 		}
/*595*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 16, Documentator_0err_entry_get, 74) == 0) ){
/*596*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL");
/*598*/ 	} else {
/*598*/ 		Documentator_p(Documentator_v);
/*601*/ 	}
/*603*/ }


/*605*/ void
/*605*/ Documentator_sort(ARRAY *Documentator_a)
/*605*/ {
/*606*/ 	int Documentator_j = 0;
/*606*/ 	int Documentator_i = 0;
/*608*/ 	STRING * Documentator_t = NULL;
/*608*/ 	{
/*608*/ 		int m2runtime_for_limit_1;
/*608*/ 		Documentator_i = 0;
/*608*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_a) - 2);
/*609*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*609*/ 			{
/*609*/ 				int m2runtime_for_limit_2;
/*609*/ 				Documentator_j = (Documentator_i + 1);
/*609*/ 				m2runtime_for_limit_2 = (m2runtime_count(Documentator_a) - 1);
/*610*/ 				for( ; Documentator_j <= m2runtime_for_limit_2; Documentator_j += 1 ){
/*610*/ 					if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_a, Documentator_j, Documentator_0err_entry_get, 75), (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_a, Documentator_i, Documentator_0err_entry_get, 76)) > 0 ){
/*611*/ 						Documentator_t = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_a, Documentator_j, Documentator_0err_entry_get, 77);
/*611*/ 						*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_a, 4, 1, Documentator_j, Documentator_0err_entry_get, 78) = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_a, Documentator_i, Documentator_0err_entry_get, 79);
/*611*/ 						*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_a, 4, 1, Documentator_i, Documentator_0err_entry_get, 80) = Documentator_t;
/*614*/ 					}
/*615*/ 				}
/*615*/ 			}
/*616*/ 		}
/*616*/ 	}
/*619*/ }

/*622*/ void * Documentator_descr = NULL;

/*631*/ void
/*631*/ Documentator_DocDescr(int Documentator_pkg_descr, STRING *Documentator_s)
/*631*/ {
/*632*/ 	int Documentator_i = 0;
/*633*/ 	STRING * Documentator_long = NULL;
/*633*/ 	STRING * Documentator_short = NULL;
/*634*/ 	STRING * Documentator_path = NULL;
/*635*/ 	RECORD * Documentator_pkg = NULL;
/*637*/ 	int Documentator_none = 0;
/*640*/ 	if( (!Documentator_pkg_descr && (Documentator_s == NULL)) ){
/*642*/ 		return ;
/*645*/ 	}
/*645*/ 	Documentator_package = NULL;
/*646*/ 	Documentator_version = NULL;
/*647*/ 	Documentator_copyright = NULL;
/*648*/ 	Documentator_license = NULL;
/*649*/ 	Documentator_authors = NULL;
/*650*/ 	Documentator_since = NULL;
/*651*/ 	Documentator_deprecated = NULL;
/*652*/ 	Documentator_see = NULL;
/*658*/ 	Documentator_i = str_find(Documentator_s, m2runtime_CHR(10));
/*659*/ 	if( (Documentator_i < 0) ){
/*660*/ 		Documentator_short = Documentator_ResolveTags(Documentator_trim(Documentator_s));
/*661*/ 		Documentator_long = EMPTY_STRING;
/*663*/ 	} else {
/*663*/ 		Documentator_short = Documentator_ResolveTags(Documentator_trim(m2runtime_substr(Documentator_s, 0, Documentator_i, 1, Documentator_0err_entry_get, 81)));
/*664*/ 		Documentator_long = Documentator_ResolveTags(Documentator_trim(m2runtime_substr(Documentator_s, (Documentator_i + 1), m2runtime_length(Documentator_s), 1, Documentator_0err_entry_get, 82)));
/*671*/ 	}
/*671*/ 	buffer_Empty((void *)&Documentator_descr);
/*673*/ 	if( Documentator_pkg_descr ){
/*674*/ 		if( Documentator_package == NULL ){
/*675*/ 			Documentator_package = FileName_DropExtension(FileName_Basename(Documentator_fn));
/*677*/ 		}
/*677*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<H1>", Documentator_package, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</H1>\012", 1));
/*681*/ 	} else {
/*682*/ 	}
/*682*/ 	if( m2runtime_strcmp(Documentator_short, EMPTY_STRING) > 0 ){
/*683*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<P>", Documentator_short, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</P>", 1));
/*686*/ 	}
/*686*/ 	if( Documentator_version != NULL ){
/*687*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"<P><B>Version:</B> ", Documentator_version, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*690*/ 	}
/*690*/ 	if( Documentator_copyright != NULL ){
/*691*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"<P><B>Copyright:</B> ", Documentator_copyright, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*694*/ 	}
/*694*/ 	if( Documentator_license != NULL ){
/*695*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"<P><B>License:</B> ", Documentator_license, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*698*/ 	}
/*698*/ 	if( Documentator_pkg_descr ){
/*700*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"<P><B>PHP version:</B> ");
/*701*/ 		if( (Documentator_php_ver == 4) ){
/*702*/ 			buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"4</P>\012");
/*704*/ 		} else {
/*704*/ 			buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"5</P>\012");
/*707*/ 		}
/*707*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"<P><B>Required modules:</B>\012");
/*708*/ 		Documentator_none = TRUE;
/*709*/ 		{
/*709*/ 			int m2runtime_for_limit_1;
/*709*/ 			Documentator_i = 0;
/*709*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_required_packages) - 1);
/*710*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*710*/ 				Documentator_pkg = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_required_packages, Documentator_i, Documentator_0err_entry_get, 83);
/*711*/ 				if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 84), Documentator_fn) != 0) &&  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 20, Documentator_0err_entry_get, 85)) ){
/*712*/ 					if( !Documentator_none ){
/*713*/ 						buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*715*/ 					}
/*715*/ 					Documentator_none = FALSE;
/*716*/ 					Documentator_path = FileName_Relative(Documentator_fn_remapped, Documentator_RefMap(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 86), Documentator_extension, 1)));
/*718*/ 					buffer_AddString((void *)&Documentator_descr, Documentator_Anchor(Documentator_path, FileName_Basename((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 87))));
/*721*/ 				}
/*721*/ 			}
/*721*/ 		}
/*721*/ 		if( Documentator_none ){
/*722*/ 			buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"<I>none</I>");
/*724*/ 		}
/*724*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<P>\012");
/*726*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"<P><B>Required packages:</B>\012");
/*727*/ 		Documentator_none = TRUE;
/*728*/ 		{
/*728*/ 			int m2runtime_for_limit_1;
/*728*/ 			Documentator_i = 0;
/*728*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_required_packages) - 1);
/*729*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*729*/ 				Documentator_pkg = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_required_packages, Documentator_i, Documentator_0err_entry_get, 88);
/*730*/ 				if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 89), Documentator_fn) != 0) && ! *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 20, Documentator_0err_entry_get, 90)) ){
/*731*/ 					if( !Documentator_none ){
/*732*/ 						buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*734*/ 					}
/*734*/ 					Documentator_none = FALSE;
/*735*/ 					Documentator_path = FileName_Relative(Documentator_fn_remapped, Documentator_RefMap(m2runtime_concat_STRING(0, FileName_DropExtension((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 91)), Documentator_extension, 1)));
/*737*/ 					buffer_AddString((void *)&Documentator_descr, Documentator_Anchor(Documentator_path, FileName_Basename(FileName_Relative(Documentator_fn_remapped, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 92)))));
/*745*/ 				}
/*745*/ 			}
/*745*/ 		}
/*745*/ 		if( Documentator_none ){
/*746*/ 			buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"<I>none</I>");
/*748*/ 		}
/*748*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<P>\012");
/*751*/ 	}
/*751*/ 	if( (m2runtime_count(Documentator_include_path) > 0) ){
/*752*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"<P><B>include_path must resolve these packages:</B>\012");
/*753*/ 		{
/*753*/ 			int m2runtime_for_limit_1;
/*753*/ 			Documentator_i = 0;
/*753*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_include_path) - 1);
/*754*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*754*/ 				if( (Documentator_i > 0) ){
/*755*/ 					buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*757*/ 				}
/*757*/ 				buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<code>");
/*758*/ 				buffer_AddString((void *)&Documentator_descr, (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_include_path, Documentator_i, Documentator_0err_entry_get, 93));
/*759*/ 				buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</code>");
/*761*/ 			}
/*761*/ 		}
/*761*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012");
/*764*/ 	}
/*764*/ 	if( Documentator_authors != NULL ){
/*765*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"<P><B>Author:</B> ", Documentator_authors, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*768*/ 	}
/*768*/ 	if( Documentator_since != NULL ){
/*769*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"<P><B>Since:</B> ", Documentator_since, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*772*/ 	}
/*772*/ 	if( Documentator_deprecated != NULL ){
/*773*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"<P><B>Deprecated:</B> ", Documentator_deprecated, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*776*/ 	}
/*776*/ 	if( m2runtime_strcmp(Documentator_long, EMPTY_STRING) > 0 ){
/*777*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<P>\012", Documentator_long, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"\012</P>\012", 1));
/*780*/ 	}
/*780*/ 	if( m2runtime_strcmp(Documentator_see, EMPTY_STRING) > 0 ){
/*781*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"<P><b>See also:</b> ", Documentator_see, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"\012</P>\012", 1));
/*784*/ 	}
/*784*/ 	if( Documentator_pkg_descr ){
/*785*/ 		Documentator_p(buffer_ToString(Documentator_descr));
/*786*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"<HR>\012");
/*788*/ 	} else {
/*788*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"<BLOCKQUOTE>\012");
/*789*/ 		Documentator_p(buffer_ToString(Documentator_descr));
/*790*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"</BLOCKQUOTE>\012");
/*793*/ 	}
/*795*/ }


/*797*/ void
/*797*/ Documentator_AddPrivateItem(STRING *Documentator_item)
/*797*/ {
/*797*/ 	Documentator_private_items = m2runtime_concat_STRING(0, Documentator_private_items, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<code>", Documentator_item, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"</code><br>\012", 1);
/*801*/ }


/*803*/ void
/*803*/ Documentator_DocConst(RECORD *Documentator_c)
/*803*/ {
/*803*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 32, Documentator_0err_entry_get, 94) ){
/*804*/ 		Documentator_AddPrivateItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 95));
/*806*/ 		return ;
/*807*/ 	}
/*807*/ 	Documentator_VSpaceBeforeItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 24, Documentator_0err_entry_get, 96) != NULL);
/*808*/ 	Documentator_ItemAnchor((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 97));
/*809*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"<CODE><B>");
/*810*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 98));
/*811*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</B> = ");
/*812*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 99) == NULL ){
/*813*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"<i>FAILED_TO_PARSE</i>");
/*815*/ 	} else {
/*815*/ 		Documentator_DocValue((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 100), 8, Documentator_0err_entry_get, 101), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 102), 12, Documentator_0err_entry_get, 103));
/*817*/ 	}
/*817*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*818*/ 	Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 24, Documentator_0err_entry_get, 104));
/*819*/ 	Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 24, Documentator_0err_entry_get, 105), NULL) > 0);
/*823*/ }


/*829*/ STRING *
/*829*/ Documentator_DocType(RECORD *Documentator_t)
/*829*/ {

/*830*/ 	STRING *
/*830*/ 	Documentator_ArrayToString(RECORD *Documentator_t)
/*830*/ 	{
/*832*/ 		STRING * Documentator_x = NULL;
/*832*/ 		switch( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 20, Documentator_0err_entry_get, 106)){

/*833*/ 		case 1:
/*833*/ 		Documentator_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"[]";
/*834*/ 		break;

/*834*/ 		case 3:
/*834*/ 		Documentator_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"[int]";
/*835*/ 		break;

/*835*/ 		case 5:
/*835*/ 		Documentator_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"[string]";
/*836*/ 		break;

/*836*/ 		case 7:
/*836*/ 		Documentator_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"[mixed]";
/*838*/ 		break;

/*838*/ 		default: m2runtime_missing_case_in_switch(Documentator_0err_entry_get, 107);
/*838*/ 		}
/*838*/ 		Documentator_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_t, 8, Documentator_0err_entry_get, 108);
/*839*/ 		if( Documentator_t == NULL ){
/*840*/ 			return Documentator_x;
/*841*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 16, Documentator_0err_entry_get, 109) == 6) ){
/*842*/ 			return m2runtime_concat_STRING(0, Documentator_x, Documentator_ArrayToString(Documentator_t), 1);
/*844*/ 		} else {
/*844*/ 			return m2runtime_concat_STRING(0, Documentator_x, Documentator_DocType(Documentator_t), 1);
/*847*/ 		}
/*847*/ 		m2runtime_missing_return(Documentator_0err_entry_get, 110);
/*847*/ 		return NULL;
/*848*/ 	}

/*850*/ 	RECORD * Documentator_c = NULL;
/*850*/ 	if( Documentator_t == NULL ){
/*851*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"FIXME_UNKNOWN_TYPE";
/*853*/ 	} else {
/*853*/ 		switch( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 16, Documentator_0err_entry_get, 111)){

/*854*/ 		case 0:
/*854*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"null";
/*855*/ 		break;

/*855*/ 		case 1:
/*855*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"void";
/*856*/ 		break;

/*856*/ 		case 2:
/*856*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean";
/*857*/ 		break;

/*857*/ 		case 3:
/*857*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int";
/*858*/ 		break;

/*858*/ 		case 4:
/*858*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float";
/*859*/ 		break;

/*859*/ 		case 5:
/*859*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string";
/*860*/ 		break;

/*860*/ 		case 6:
/*861*/ 		if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 20, Documentator_0err_entry_get, 112) == 1)) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_t, 8, Documentator_0err_entry_get, 113) == NULL)) ){
/*862*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array";
/*864*/ 		} else {
/*864*/ 			return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array", Documentator_ArrayToString(Documentator_t), 1);
/*866*/ 		}
/*866*/ 		break;

/*866*/ 		case 7:
/*866*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"mixed";
/*867*/ 		break;

/*867*/ 		case 8:
/*867*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"resource";
/*868*/ 		break;

/*868*/ 		case 9:
/*869*/ 		Documentator_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_t, 12, Documentator_0err_entry_get, 114);
/*870*/ 		if( Documentator_c == NULL ){
/*871*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object";
/*872*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 64, Documentator_0err_entry_get, 115) ){
/*873*/ 			return (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 116);
/*875*/ 		} else {
/*875*/ 			return Documentator_Anchor(Documentator_ItemToUrl((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 117)), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 118));
/*878*/ 		}
/*878*/ 		break;

/*878*/ 		default: m2runtime_missing_case_in_switch(Documentator_0err_entry_get, 119);
/*879*/ 		}
/*880*/ 	}
/*880*/ 	m2runtime_missing_return(Documentator_0err_entry_get, 120);
/*880*/ 	return NULL;
/*882*/ }


/*884*/ void
/*884*/ Documentator_DocVar(RECORD *Documentator_v)
/*884*/ {
/*884*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_v, 36, Documentator_0err_entry_get, 121) ){
/*885*/ 		Documentator_AddPrivateItem(m2runtime_concat_STRING(0, m2runtime_CHR(36), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 8, Documentator_0err_entry_get, 122), 1));
/*887*/ 		return ;
/*888*/ 	}
/*888*/ 	Documentator_VSpaceBeforeItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 28, Documentator_0err_entry_get, 123) != NULL);
/*889*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, m2runtime_CHR(36), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 8, Documentator_0err_entry_get, 124), 1));
/*890*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"<CODE><I>");
/*891*/ 	Documentator_p(Documentator_DocType((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_v, 20, Documentator_0err_entry_get, 125)));
/*892*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"</I> <B>$");
/*893*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 8, Documentator_0err_entry_get, 126));
/*894*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</B>");
/*899*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*900*/ 	Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 28, Documentator_0err_entry_get, 127));
/*901*/ 	Documentator_VSpaceAfterItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 28, Documentator_0err_entry_get, 128) != NULL);
/*905*/ }


/*907*/ void
/*907*/ Documentator_DocSignature(STRING *Documentator_name, RECORD *Documentator_s)
/*907*/ {
/*908*/ 	int Documentator_i = 0;
/*909*/ 	ARRAY * Documentator_args = NULL;
/*911*/ 	RECORD * Documentator_a = NULL;
/*911*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<I>");
/*912*/ 	Documentator_p(Documentator_DocType((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_s, 8, Documentator_0err_entry_get, 129)));
/*913*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</I> ");
/*914*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_s, 16, Documentator_0err_entry_get, 130) ){
/*915*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"&amp; ");
/*917*/ 	}
/*917*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<B>");
/*918*/ 	Documentator_p(Documentator_name);
/*919*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</B>(");
/*920*/ 	Documentator_args = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_s, 12, Documentator_0err_entry_get, 131);
/*921*/ 	{
/*921*/ 		int m2runtime_for_limit_1;
/*921*/ 		Documentator_i = 0;
/*921*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_args) - 1);
/*922*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*922*/ 			Documentator_a = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 132);
/*923*/ 			if( (Documentator_i > 0) ){
/*924*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*926*/ 			}
/*926*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<I>");
/*927*/ 			Documentator_p(Documentator_DocType((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_a, 12, Documentator_0err_entry_get, 133)));
/*928*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"</I>&nbsp;");
/*929*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_a, 20, Documentator_0err_entry_get, 134) ){
/*930*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"&amp; ");
/*932*/ 			}
/*932*/ 			Documentator_p(m2runtime_CHR(36));
/*933*/ 			Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_a, 8, Documentator_0err_entry_get, 135));
/*934*/ 			if( (Documentator_i >=  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_s, 20, Documentator_0err_entry_get, 136)) ){
/*935*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)" = ");
/*936*/ 				Documentator_DocValue((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_a, 12, Documentator_0err_entry_get, 137), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_a, 16, Documentator_0err_entry_get, 138));
/*939*/ 			}
/*939*/ 		}
/*939*/ 	}
/*939*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_s, 24, Documentator_0err_entry_get, 139) ){
/*940*/ 		if( (Documentator_i == 0) ){
/*941*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"...");
/*943*/ 		} else {
/*943*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)", ...");
/*946*/ 		}
/*946*/ 	}
/*946*/ 	Documentator_p(m2runtime_CHR(41));
/*951*/ }

/*957*/ ARRAY * Documentator_errors = NULL;

/*959*/ void
/*959*/ Documentator_DocRaisedErrors(int Documentator_errs)
/*959*/ {
/*960*/ 	int Documentator_i = 0;
/*962*/ 	int Documentator_more = 0;
/*962*/ 	if( (Documentator_errs == 0) ){
/*964*/ 		return ;
/*966*/ 	}
/*966*/ 	if( Documentator_errors == NULL ){
/*967*/ 		Documentator_errors = (
/*968*/ 			push((char*) alloc_ARRAY(4, 1)),
/*968*/ 			push((char*) (
/*968*/ 				push((char*) alloc_RECORD(16, 1)),
/*968*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"E_ERROR "),
/*968*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*968*/ 				*(int*) (tos()+12) = 1,
/*969*/ 				(RECORD*) pop()
/*969*/ 			)),
/*969*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*969*/ 			push((char*) (
/*969*/ 				push((char*) alloc_RECORD(16, 1)),
/*969*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"E_WARNING "),
/*969*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*969*/ 				*(int*) (tos()+12) = 2,
/*970*/ 				(RECORD*) pop()
/*970*/ 			)),
/*970*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*970*/ 			push((char*) (
/*970*/ 				push((char*) alloc_RECORD(16, 1)),
/*970*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"E_PARSE "),
/*970*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*970*/ 				*(int*) (tos()+12) = 4,
/*971*/ 				(RECORD*) pop()
/*971*/ 			)),
/*971*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),2) = (RECORD*) tos(), pop(),
/*971*/ 			push((char*) (
/*971*/ 				push((char*) alloc_RECORD(16, 1)),
/*971*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"E_NOTICE"),
/*971*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*971*/ 				*(int*) (tos()+12) = 8,
/*972*/ 				(RECORD*) pop()
/*972*/ 			)),
/*972*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),3) = (RECORD*) tos(), pop(),
/*972*/ 			push((char*) (
/*972*/ 				push((char*) alloc_RECORD(16, 1)),
/*972*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"E_CORE_ERROR"),
/*972*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*972*/ 				*(int*) (tos()+12) = 16,
/*973*/ 				(RECORD*) pop()
/*973*/ 			)),
/*973*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),4) = (RECORD*) tos(), pop(),
/*973*/ 			push((char*) (
/*973*/ 				push((char*) alloc_RECORD(16, 1)),
/*973*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"E_CORE_WARNING "),
/*973*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*973*/ 				*(int*) (tos()+12) = 32,
/*974*/ 				(RECORD*) pop()
/*974*/ 			)),
/*974*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),5) = (RECORD*) tos(), pop(),
/*974*/ 			push((char*) (
/*974*/ 				push((char*) alloc_RECORD(16, 1)),
/*974*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"E_COMPILE_ERROR"),
/*974*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*974*/ 				*(int*) (tos()+12) = 64,
/*975*/ 				(RECORD*) pop()
/*975*/ 			)),
/*975*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),6) = (RECORD*) tos(), pop(),
/*975*/ 			push((char*) (
/*975*/ 				push((char*) alloc_RECORD(16, 1)),
/*975*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"E_COMPILE_WARNING"),
/*975*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*975*/ 				*(int*) (tos()+12) = 128,
/*976*/ 				(RECORD*) pop()
/*976*/ 			)),
/*976*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),7) = (RECORD*) tos(), pop(),
/*976*/ 			push((char*) (
/*976*/ 				push((char*) alloc_RECORD(16, 1)),
/*976*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"E_USER_ERROR"),
/*976*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*976*/ 				*(int*) (tos()+12) = 256,
/*977*/ 				(RECORD*) pop()
/*977*/ 			)),
/*977*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),8) = (RECORD*) tos(), pop(),
/*977*/ 			push((char*) (
/*977*/ 				push((char*) alloc_RECORD(16, 1)),
/*977*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"E_USER_WARNING"),
/*977*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*977*/ 				*(int*) (tos()+12) = 512,
/*978*/ 				(RECORD*) pop()
/*978*/ 			)),
/*978*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),9) = (RECORD*) tos(), pop(),
/*978*/ 			push((char*) (
/*978*/ 				push((char*) alloc_RECORD(16, 1)),
/*978*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"E_USER_NOTICE"),
/*978*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*978*/ 				*(int*) (tos()+12) = 1024,
/*979*/ 				(RECORD*) pop()
/*979*/ 			)),
/*979*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),10) = (RECORD*) tos(), pop(),
/*979*/ 			push((char*) (
/*979*/ 				push((char*) alloc_RECORD(16, 1)),
/*979*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"E_STRICT"),
/*979*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*979*/ 				*(int*) (tos()+12) = 2048,
/*980*/ 				(RECORD*) pop()
/*980*/ 			)),
/*980*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),11) = (RECORD*) tos(), pop(),
/*980*/ 			push((char*) (
/*980*/ 				push((char*) alloc_RECORD(16, 1)),
/*980*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"E_RECOVERABLE_ERROR"),
/*980*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*980*/ 				*(int*) (tos()+12) = 4096,
/*982*/ 				(RECORD*) pop()
/*982*/ 			)),
/*982*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),12) = (RECORD*) tos(), pop(),
/*983*/ 			(ARRAY*) pop()
/*983*/ 		);
/*984*/ 	}
/*984*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"<br><i>triggers</i> ");
/*985*/ 	{
/*985*/ 		int m2runtime_for_limit_1;
/*985*/ 		Documentator_i = 0;
/*985*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_errors) - 1);
/*986*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*986*/ 			if( ((Documentator_errs &  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_errors, Documentator_i, Documentator_0err_entry_get, 140), 12, Documentator_0err_entry_get, 141)) != 0) ){
/*987*/ 				if( Documentator_more ){
/*988*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*990*/ 				}
/*990*/ 				Documentator_p(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_errors, Documentator_i, Documentator_0err_entry_get, 142), 8, Documentator_0err_entry_get, 143), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</CODE>", 1));
/*991*/ 				Documentator_more = TRUE;
/*994*/ 			}
/*994*/ 		}
/*994*/ 	}
/*994*/ 	Documentator_p(m2runtime_CHR(10));
/*998*/ }


/*1000*/ void
/*1000*/ Documentator_DocThrownExceptions(ARRAY *Documentator_exc)
/*1000*/ {
/*1001*/ 	int Documentator_i = 0;
/*1003*/ 	RECORD * Documentator_e = NULL;
/*1003*/ 	if( (m2runtime_count(Documentator_exc) == 0) ){
/*1005*/ 		return ;
/*1006*/ 	}
/*1006*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"<br><i>throws</i> ");
/*1007*/ 	Documentator_exc = Classes_Sort(Documentator_exc);
/*1008*/ 	{
/*1008*/ 		int m2runtime_for_limit_1;
/*1008*/ 		Documentator_i = 0;
/*1008*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_exc) - 1);
/*1009*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1009*/ 			if( (Documentator_i > 0) ){
/*1010*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*1012*/ 			}
/*1012*/ 			Documentator_e = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_exc, Documentator_i, Documentator_0err_entry_get, 144);
/*1013*/ 			if( Documentator_e == NULL ){
/*1014*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"<i>FIXME_UNKNOWN_EXCEPTION</i>");
/*1016*/ 			} else {
/*1016*/ 				Documentator_AnchorToClass(Documentator_e);
/*1019*/ 			}
/*1020*/ 		}
/*1020*/ 	}
/*1022*/ }


/*1024*/ void
/*1024*/ Documentator_DocFunc(RECORD *Documentator_f)
/*1024*/ {
/*1024*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_f, 48, Documentator_0err_entry_get, 145) ){
/*1025*/ 		Documentator_AddPrivateItem(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 8, Documentator_0err_entry_get, 146), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1027*/ 		return ;
/*1028*/ 	}
/*1028*/ 	Documentator_VSpaceBeforeItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 36, Documentator_0err_entry_get, 147) != NULL);
/*1029*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 8, Documentator_0err_entry_get, 148), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1030*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>");
/*1031*/ 	Documentator_DocSignature((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 8, Documentator_0err_entry_get, 149), (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_f, 28, Documentator_0err_entry_get, 150));
/*1032*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1033*/ 	Documentator_DocRaisedErrors( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_f, 56, Documentator_0err_entry_get, 151));
/*1034*/ 	Documentator_DocThrownExceptions((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_f, 32, Documentator_0err_entry_get, 152));
/*1035*/ 	Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 36, Documentator_0err_entry_get, 153));
/*1036*/ 	Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 36, Documentator_0err_entry_get, 154), NULL) > 0);
/*1040*/ }


/*1047*/ void
/*1047*/ Documentator_DocClassConst(RECORD *Documentator_cl, RECORD *Documentator_parent, RECORD *Documentator_c)
/*1047*/ {
/*1047*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 28, Documentator_0err_entry_get, 155) == 0) ){
/*1049*/ 		return ;
/*1050*/ 	}
/*1050*/ 	Documentator_VSpaceBeforeItem(((Documentator_parent == NULL) && ((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 156) != NULL)));
/*1051*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 8, Documentator_0err_entry_get, 157), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 158), 1));
/*1052*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"<CODE>const <B>");
/*1053*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 159));
/*1054*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</B> = ");
/*1055*/ 	Documentator_DocValue((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 160), 8, Documentator_0err_entry_get, 161), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 162), 12, Documentator_0err_entry_get, 163));
/*1056*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1057*/ 	if( Documentator_parent == NULL ){
/*1058*/ 		Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 164));
/*1059*/ 		Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 165), NULL) > 0);
/*1061*/ 	} else {
/*1061*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"<BR><I>inherited from</i> <CODE>");
/*1062*/ 		Documentator_p(Documentator_Anchor(Documentator_ItemToUrl(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 166), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 167), 1)), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 168)));
/*1063*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1064*/ 		Documentator_VSpaceAfterItem(FALSE);
/*1067*/ 	}
/*1069*/ }


/*1071*/ void
/*1071*/ Documentator_DocClassProperty(RECORD *Documentator_c, RECORD *Documentator_parent, RECORD *Documentator_pr)
/*1071*/ {
/*1071*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 32, Documentator_0err_entry_get, 169) == 0) ){
/*1072*/ 		if( ((Documentator_parent == NULL) && ((Documentator_php_ver == 4))) ){
/*1073*/ 			Documentator_AddPrivateItem(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 170), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 8, Documentator_0err_entry_get, 171), 1));
/*1076*/ 		}
/*1076*/ 		return ;
/*1077*/ 	}
/*1077*/ 	Documentator_VSpaceBeforeItem(((Documentator_parent == NULL) && ((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 24, Documentator_0err_entry_get, 172) != NULL)));
/*1078*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 173), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 8, Documentator_0err_entry_get, 174), 1));
/*1079*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>");
/*1080*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 32, Documentator_0err_entry_get, 175) == 1) ){
/*1081*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"protected ");
/*1083*/ 	}
/*1083*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 36, Documentator_0err_entry_get, 176) ){
/*1084*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"static ");
/*1091*/ 	}
/*1091*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<I>");
/*1092*/ 	Documentator_p(Documentator_DocType((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 12, Documentator_0err_entry_get, 177)));
/*1093*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"</I> <B>$");
/*1094*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 8, Documentator_0err_entry_get, 178));
/*1095*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</B>");
/*1096*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 12, Documentator_0err_entry_get, 179) != NULL) && ((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 16, Documentator_0err_entry_get, 180) != NULL)) ){
/*1097*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)" = ");
/*1098*/ 		Documentator_DocValue((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 12, Documentator_0err_entry_get, 181), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 16, Documentator_0err_entry_get, 182));
/*1100*/ 	}
/*1100*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1101*/ 	if( Documentator_parent == NULL ){
/*1102*/ 		Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 24, Documentator_0err_entry_get, 183));
/*1103*/ 		Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 24, Documentator_0err_entry_get, 184), NULL) > 0);
/*1105*/ 	} else {
/*1105*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"<BR><I>inherited from</i> <CODE>");
/*1106*/ 		Documentator_p(Documentator_Anchor(Documentator_ItemToUrl(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 185), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 8, Documentator_0err_entry_get, 186), 1)), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 187)));
/*1107*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1108*/ 		Documentator_VSpaceAfterItem(FALSE);
/*1111*/ 	}
/*1113*/ }


/*1115*/ void
/*1115*/ Documentator_DocClassMethod(RECORD *Documentator_c, RECORD *Documentator_parent, RECORD *Documentator_m)
/*1115*/ {
/*1115*/ 	if( ((Documentator_parent == NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 48, Documentator_0err_entry_get, 188) == 0))) ){
/*1116*/ 		if( (Documentator_php_ver == 4) ){
/*1117*/ 			Documentator_AddPrivateItem(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 189), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 190), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1120*/ 		}
/*1120*/ 		return ;
/*1122*/ 	}
/*1122*/ 	Documentator_VSpaceBeforeItem(((Documentator_parent == NULL) && ((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 32, Documentator_0err_entry_get, 191) != NULL)));
/*1123*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 192), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 193), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1124*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>");
/*1125*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 44, Documentator_0err_entry_get, 194) && ! *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 76, Documentator_0err_entry_get, 195)) ){
/*1125*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"abstract ");
/*1126*/ 	}
/*1126*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 48, Documentator_0err_entry_get, 196) == 1) ){
/*1126*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"protected ");
/*1127*/ 	}
/*1127*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 52, Documentator_0err_entry_get, 197) ){
/*1127*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"static ");
/*1128*/ 	}
/*1128*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 56, Documentator_0err_entry_get, 198) ){
/*1128*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"final ");
/*1129*/ 	}
/*1129*/ 	Documentator_DocSignature((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 199), (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_m, 16, Documentator_0err_entry_get, 200));
/*1130*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1131*/ 	Documentator_DocRaisedErrors( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 68, Documentator_0err_entry_get, 201));
/*1132*/ 	Documentator_DocThrownExceptions((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_m, 28, Documentator_0err_entry_get, 202));
/*1133*/ 	if( Documentator_parent == NULL ){
/*1134*/ 		Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 32, Documentator_0err_entry_get, 203));
/*1135*/ 		Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 32, Documentator_0err_entry_get, 204), NULL) > 0);
/*1137*/ 	} else {
/*1137*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"<BR><I>inherited from</i> <CODE>");
/*1138*/ 		Documentator_p(Documentator_Anchor(Documentator_ItemToUrl(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 205), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 206), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1)), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 207)));
/*1139*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1140*/ 		Documentator_VSpaceAfterItem(FALSE);
/*1143*/ 	}
/*1145*/ }


/*1146*/ int
/*1146*/ Documentator_NotInList(STRING *Documentator_name, ARRAY **Documentator_l)
/*1146*/ {
/*1148*/ 	int Documentator_i = 0;
/*1148*/ 	{
/*1148*/ 		int m2runtime_for_limit_1;
/*1148*/ 		Documentator_i = 0;
/*1148*/ 		m2runtime_for_limit_1 = (m2runtime_count(*Documentator_l) - 1);
/*1149*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1149*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_ARRAY(*Documentator_l, Documentator_i, Documentator_0err_entry_get, 208), Documentator_name) == 0 ){
/*1150*/ 				return FALSE;
/*1153*/ 			}
/*1153*/ 		}
/*1153*/ 	}
/*1153*/ 	*(STRING **)m2runtime_dereference_lhs_ARRAY(Documentator_l, 4, 1, Documentator_i, Documentator_0err_entry_get, 209) = Documentator_name;
/*1154*/ 	return TRUE;
/*1158*/ }


/*1160*/ void
/*1160*/ Documentator_DocInheritedConsts(RECORD *Documentator_cl)
/*1160*/ {
/*1161*/ 	ARRAY * Documentator_l = NULL;
/*1162*/ 	ARRAY * Documentator_consts = NULL;
/*1163*/ 	RECORD * Documentator_p = NULL;
/*1165*/ 	int Documentator_i = 0;
/*1165*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 210) == NULL ){
/*1167*/ 		return ;
/*1168*/ 	}
/*1168*/ 	Documentator_consts = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 28, Documentator_0err_entry_get, 211);
/*1169*/ 	{
/*1169*/ 		int m2runtime_for_limit_1;
/*1169*/ 		Documentator_i = 0;
/*1169*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*1170*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1170*/ 			*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_l, 4, 1, Documentator_i, Documentator_0err_entry_get, 212) = (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 213), 8, Documentator_0err_entry_get, 214);
/*1172*/ 		}
/*1172*/ 	}
/*1172*/ 	Documentator_p = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 215);
/*1174*/ 	do {
/*1174*/ 		Documentator_consts = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_p, 28, Documentator_0err_entry_get, 216);
/*1175*/ 		{
/*1175*/ 			int m2runtime_for_limit_1;
/*1175*/ 			Documentator_i = 0;
/*1175*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*1176*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1176*/ 				if( ((( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 217), 28, Documentator_0err_entry_get, 218) != 0)) && Documentator_NotInList((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 219), 8, Documentator_0err_entry_get, 220), &Documentator_l)) ){
/*1178*/ 					Documentator_DocClassConst(Documentator_cl, Documentator_p, (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 221));
/*1181*/ 				}
/*1181*/ 			}
/*1181*/ 		}
/*1181*/ 		Documentator_p = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_p, 16, Documentator_0err_entry_get, 222);
/*1182*/ 	} while( !( Documentator_p == NULL ));
/*1186*/ }


/*1188*/ void
/*1188*/ Documentator_DocInheritedProperties(RECORD *Documentator_cl)
/*1188*/ {
/*1189*/ 	ARRAY * Documentator_l = NULL;
/*1190*/ 	ARRAY * Documentator_properties = NULL;
/*1192*/ 	int Documentator_i = 0;

/*1194*/ 	void
/*1194*/ 	Documentator_ScanProperties(RECORD *Documentator_c)
/*1194*/ 	{
/*1195*/ 		ARRAY * Documentator_properties = NULL;
/*1197*/ 		int Documentator_i = 0;
/*1197*/ 		if( Documentator_c == NULL ){
/*1199*/ 			return ;
/*1200*/ 		}
/*1200*/ 		Documentator_properties = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 32, Documentator_0err_entry_get, 223);
/*1201*/ 		{
/*1201*/ 			int m2runtime_for_limit_1;
/*1201*/ 			Documentator_i = 0;
/*1201*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_properties) - 1);
/*1202*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1202*/ 				if( (!(( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_properties, Documentator_i, Documentator_0err_entry_get, 224), 32, Documentator_0err_entry_get, 225) == 0)) && Documentator_NotInList((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_properties, Documentator_i, Documentator_0err_entry_get, 226), 8, Documentator_0err_entry_get, 227), &Documentator_l)) ){
/*1204*/ 					Documentator_DocClassProperty(Documentator_cl, Documentator_c, (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_properties, Documentator_i, Documentator_0err_entry_get, 228));
/*1207*/ 				}
/*1208*/ 			}
/*1208*/ 		}
/*1209*/ 	}


/*1210*/ 	void
/*1210*/ 	Documentator_ScanPropertiesRecursive(RECORD *Documentator_c)
/*1210*/ 	{
/*1212*/ 		int Documentator_i = 0;
/*1212*/ 		if( Documentator_c == NULL ){
/*1214*/ 			return ;
/*1215*/ 		}
/*1215*/ 		Documentator_ScanProperties(Documentator_c);
/*1216*/ 		Documentator_ScanPropertiesRecursive((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 229));
/*1217*/ 		{
/*1217*/ 			int m2runtime_for_limit_1;
/*1217*/ 			Documentator_i = 0;
/*1217*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 230)) - 1);
/*1218*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1218*/ 				Documentator_ScanPropertiesRecursive((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 231), Documentator_i, Documentator_0err_entry_get, 232));
/*1221*/ 			}
/*1221*/ 		}
/*1223*/ 	}

/*1223*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 233) == NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 234) == NULL)) ){
/*1225*/ 		return ;
/*1228*/ 	}
/*1228*/ 	Documentator_properties = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 32, Documentator_0err_entry_get, 235);
/*1229*/ 	{
/*1229*/ 		int m2runtime_for_limit_1;
/*1229*/ 		Documentator_i = 0;
/*1229*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_properties) - 1);
/*1230*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1230*/ 			*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_l, 4, 1, Documentator_i, Documentator_0err_entry_get, 236) = (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_properties, Documentator_i, Documentator_0err_entry_get, 237), 8, Documentator_0err_entry_get, 238);
/*1234*/ 		}
/*1234*/ 	}
/*1234*/ 	Documentator_ScanPropertiesRecursive((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 239));
/*1237*/ 	if( !(( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 72, Documentator_0err_entry_get, 240) ||  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 76, Documentator_0err_entry_get, 241))) ){
/*1239*/ 		return ;
/*1240*/ 	}
/*1240*/ 	{
/*1240*/ 		int m2runtime_for_limit_1;
/*1240*/ 		Documentator_i = 0;
/*1240*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 242)) - 1);
/*1241*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1241*/ 			Documentator_ScanPropertiesRecursive((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 243), Documentator_i, Documentator_0err_entry_get, 244));
/*1244*/ 		}
/*1244*/ 	}
/*1246*/ }


/*1248*/ void
/*1248*/ Documentator_DocInheritedMethods(RECORD *Documentator_cl)
/*1248*/ {
/*1249*/ 	ARRAY * Documentator_l = NULL;
/*1250*/ 	ARRAY * Documentator_methods = NULL;
/*1252*/ 	int Documentator_i = 0;

/*1254*/ 	void
/*1254*/ 	Documentator_ScanMethods(RECORD *Documentator_c)
/*1254*/ 	{
/*1255*/ 		ARRAY * Documentator_methods = NULL;
/*1256*/ 		int Documentator_i = 0;
/*1258*/ 		RECORD * Documentator_m = NULL;
/*1258*/ 		if( Documentator_c == NULL ){
/*1260*/ 			return ;
/*1261*/ 		}
/*1261*/ 		Documentator_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 36, Documentator_0err_entry_get, 245);
/*1262*/ 		{
/*1262*/ 			int m2runtime_for_limit_1;
/*1262*/ 			Documentator_i = 0;
/*1262*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_methods) - 1);
/*1263*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1263*/ 				Documentator_m = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_methods, Documentator_i, Documentator_0err_entry_get, 246);
/*1264*/ 				if( (!(( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 48, Documentator_0err_entry_get, 247) == 0)) && Documentator_NotInList((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 248), &Documentator_l)) ){
/*1265*/ 					Documentator_DocClassMethod(Documentator_cl, Documentator_c, Documentator_m);
/*1268*/ 				}
/*1269*/ 			}
/*1269*/ 		}
/*1270*/ 	}


/*1271*/ 	void
/*1271*/ 	Documentator_ScanMethodsRecursive(RECORD *Documentator_c)
/*1271*/ 	{
/*1273*/ 		int Documentator_i = 0;
/*1273*/ 		if( Documentator_c == NULL ){
/*1275*/ 			return ;
/*1276*/ 		}
/*1276*/ 		Documentator_ScanMethods(Documentator_c);
/*1277*/ 		Documentator_ScanMethodsRecursive((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 249));
/*1278*/ 		{
/*1278*/ 			int m2runtime_for_limit_1;
/*1278*/ 			Documentator_i = 0;
/*1278*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 250)) - 1);
/*1279*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1279*/ 				Documentator_ScanMethodsRecursive((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 251), Documentator_i, Documentator_0err_entry_get, 252));
/*1282*/ 			}
/*1282*/ 		}
/*1284*/ 	}

/*1284*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 253) == NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 254) == NULL)) ){
/*1286*/ 		return ;
/*1289*/ 	}
/*1289*/ 	Documentator_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 36, Documentator_0err_entry_get, 255);
/*1290*/ 	{
/*1290*/ 		int m2runtime_for_limit_1;
/*1290*/ 		Documentator_i = 0;
/*1290*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_methods) - 1);
/*1291*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1291*/ 			*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_l, 4, 1, Documentator_i, Documentator_0err_entry_get, 256) = (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_methods, Documentator_i, Documentator_0err_entry_get, 257), 8, Documentator_0err_entry_get, 258);
/*1295*/ 		}
/*1295*/ 	}
/*1295*/ 	Documentator_ScanMethodsRecursive((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 259));
/*1298*/ 	if( !(( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 72, Documentator_0err_entry_get, 260) ||  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 76, Documentator_0err_entry_get, 261))) ){
/*1300*/ 		return ;
/*1301*/ 	}
/*1301*/ 	{
/*1301*/ 		int m2runtime_for_limit_1;
/*1301*/ 		Documentator_i = 0;
/*1301*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 262)) - 1);
/*1302*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1302*/ 			Documentator_ScanMethodsRecursive((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 263), Documentator_i, Documentator_0err_entry_get, 264));
/*1305*/ 		}
/*1305*/ 	}
/*1307*/ }


/*1309*/ void
/*1309*/ Documentator_DocClass(RECORD *Documentator_c)
/*1309*/ {
/*1310*/ 	int Documentator_i = 0;
/*1312*/ 	RECORD * Documentator_parent = NULL;
/*1312*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 64, Documentator_0err_entry_get, 265) ){
/*1313*/ 		Documentator_AddPrivateItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 266));
/*1315*/ 		return ;
/*1316*/ 	}
/*1316*/ 	Documentator_VSpaceBeforeItem(TRUE);
/*1317*/ 	Documentator_curr_class = Documentator_c;
/*1318*/ 	Documentator_ItemAnchor((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 267));
/*1319*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>");
/*1320*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 72, Documentator_0err_entry_get, 268) ){
/*1321*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"abstract ");
/*1323*/ 	}
/*1323*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 68, Documentator_0err_entry_get, 269) ){
/*1324*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"final ");
/*1326*/ 	}
/*1326*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 76, Documentator_0err_entry_get, 270) ){
/*1327*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"interface");
/*1329*/ 	} else {
/*1329*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class");
/*1331*/ 	}
/*1331*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" <B>");
/*1332*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 271));
/*1333*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</B>");
/*1335*/ 	Documentator_parent = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 272);
/*1336*/ 	if( Documentator_parent != NULL ){
/*1337*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)" extends ");
/*1338*/ 		Documentator_AnchorToClass(Documentator_parent);
/*1341*/ 	}
/*1341*/ 	if( (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 273) != NULL ){
/*1342*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 76, Documentator_0err_entry_get, 274) ){
/*1343*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)" extends ");
/*1345*/ 		} else {
/*1345*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" implements ");
/*1347*/ 		}
/*1347*/ 		{
/*1347*/ 			int m2runtime_for_limit_1;
/*1347*/ 			Documentator_i = 0;
/*1347*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 275)) - 1);
/*1348*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1348*/ 				if( (Documentator_i > 0) ){
/*1349*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*1351*/ 				}
/*1351*/ 				Documentator_AnchorToClass((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 276), Documentator_i, Documentator_0err_entry_get, 277));
/*1354*/ 			}
/*1354*/ 		}
/*1355*/ 	}
/*1355*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1356*/ 	Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 52, Documentator_0err_entry_get, 278));
/*1357*/ 	Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 52, Documentator_0err_entry_get, 279), NULL) > 0);
/*1359*/ 	Documentator_VSpaceBeforeItem(FALSE);
/*1360*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"<CODE>{</CODE>\012<BLOCKQUOTE>\012");
/*1361*/ 	Documentator_VSpaceAfterItem(FALSE);
/*1363*/ 	{
/*1363*/ 		int m2runtime_for_limit_1;
/*1363*/ 		Documentator_i = 0;
/*1363*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 28, Documentator_0err_entry_get, 280)) - 1);
/*1364*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1364*/ 			Documentator_DocClassConst(Documentator_c, NULL, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 28, Documentator_0err_entry_get, 281), Documentator_i, Documentator_0err_entry_get, 282));
/*1366*/ 		}
/*1366*/ 	}
/*1366*/ 	Documentator_DocInheritedConsts(Documentator_c);
/*1368*/ 	{
/*1368*/ 		int m2runtime_for_limit_1;
/*1368*/ 		Documentator_i = 0;
/*1368*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 32, Documentator_0err_entry_get, 283)) - 1);
/*1369*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1369*/ 			Documentator_DocClassProperty(Documentator_c, NULL, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 32, Documentator_0err_entry_get, 284), Documentator_i, Documentator_0err_entry_get, 285));
/*1371*/ 		}
/*1371*/ 	}
/*1371*/ 	Documentator_DocInheritedProperties(Documentator_c);
/*1373*/ 	{
/*1373*/ 		int m2runtime_for_limit_1;
/*1373*/ 		Documentator_i = 0;
/*1373*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 36, Documentator_0err_entry_get, 286)) - 1);
/*1374*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1374*/ 			Documentator_DocClassMethod(Documentator_c, NULL, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 36, Documentator_0err_entry_get, 287), Documentator_i, Documentator_0err_entry_get, 288));
/*1376*/ 		}
/*1376*/ 	}
/*1376*/ 	Documentator_DocInheritedMethods(Documentator_c);
/*1378*/ 	Documentator_VSpaceBeforeItem(FALSE);
/*1379*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"</BLOCKQUOTE>\012<CODE>}</CODE>\012");
/*1380*/ 	Documentator_VSpaceAfterItem(TRUE);
/*1382*/ 	Documentator_curr_class = NULL;
/*1386*/ }


/*1388*/ void
/*1388*/ Documentator_Help(void)
/*1388*/ {
/*1388*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"PHPLint Documentator\012\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"Options:\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"  --doc                 generate documentation\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\114,\0,\0,\0)"  --doc-extension EXT   extension of the generated documents (def. \042.html\042)\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"  --doc-page-header H   header text of the generated HTML page\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"  --doc-page-footer F   footer text of the generated HTML page\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\104,\0,\0,\0)"  --doc-ref-remap A B   remap HTML anchors references from A* to B*\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"\012More help: www.icosaedro.it/phplint/\012\012", 1));
/*1403*/ }


/*1405*/ void
/*1405*/ Documentator_Init(void)
/*1405*/ {
/*1412*/ 	Documentator_extension = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)".html";
/*1413*/ 	Documentator_page_header = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"<HTML><BODY>\012";
/*1414*/ 	Documentator_page_footer = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"\012<HR><P align=right>", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"<FONT size='-2'>Generated by ", Documentator_Anchor((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"http://www.icosaedro.it/phplint/", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"PHPLint Documentator"), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"</FONT></P>\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"</BODY></HTML>\012", 1);
/*1422*/ }


/*1423*/ int
/*1423*/ Documentator_ParseParameter(int Documentator_i, ARRAY *Documentator_args)
/*1423*/ {
/*1425*/ 	STRING * Documentator_arg = NULL;
/*1425*/ 	Documentator_arg = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 289);
/*1426*/ 	if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"--doc-help") == 0 ){
/*1427*/ 		Documentator_Help();
/*1428*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"--doc") == 0 ){
/*1429*/ 		Documentator_generate = TRUE;
/*1430*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"--doc-extension") == 0 ){
/*1431*/ 		m2_inc(&Documentator_i, 1);
/*1432*/ 		if( (Documentator_i >= m2runtime_count(Documentator_args)) ){
/*1433*/ 			m2_error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"phplint: missing argument for --doc-extension\012");
/*1434*/ 			m2runtime_exit(1);
/*1436*/ 		}
/*1436*/ 		Documentator_extension = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 290);
/*1437*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"--doc-page-header") == 0 ){
/*1438*/ 		m2_inc(&Documentator_i, 1);
/*1439*/ 		if( (Documentator_i >= m2runtime_count(Documentator_args)) ){
/*1440*/ 			m2_error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"phplint: missing argument for --doc-page-header\012");
/*1441*/ 			m2runtime_exit(1);
/*1443*/ 		}
/*1443*/ 		Documentator_page_header = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 291);
/*1444*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"--doc-page-footer") == 0 ){
/*1445*/ 		m2_inc(&Documentator_i, 1);
/*1446*/ 		if( (Documentator_i >= m2runtime_count(Documentator_args)) ){
/*1447*/ 			m2_error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"phplint: missing argument for --doc-page-footer\012");
/*1448*/ 			m2runtime_exit(1);
/*1450*/ 		}
/*1450*/ 		Documentator_page_footer = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 292);
/*1451*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"--doc-ref-remap") == 0 ){
/*1452*/ 		if( ((Documentator_i + 2) >= m2runtime_count(Documentator_args)) ){
/*1453*/ 			m2_error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"phplint: more args required for --doc-ref-remap\012");
/*1454*/ 			m2runtime_exit(1);
/*1456*/ 		}
/*1456*/ 		*(STRING **)m2runtime_dereference_lhs_ARRAY_next(&Documentator_ref_remap, 4, 1, Documentator_0err_entry_get, 293) = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, (Documentator_i + 1), Documentator_0err_entry_get, 294);
/*1457*/ 		*(STRING **)m2runtime_dereference_lhs_ARRAY_next(&Documentator_ref_remap, 4, 1, Documentator_0err_entry_get, 295) = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, (Documentator_i + 2), Documentator_0err_entry_get, 296);
/*1458*/ 		m2_inc(&Documentator_i, 2);
/*1460*/ 	} else {
/*1460*/ 		m2_error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"phplint: unknown option `", Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"'\012", 1));
/*1461*/ 		m2runtime_exit(1);
/*1464*/ 	}
/*1464*/ 	return Documentator_i;
/*1468*/ }


/*1479*/ void
/*1479*/ Documentator_Generate(int Documentator__php_ver, STRING *Documentator__fn, STRING *Documentator__package_descr, ARRAY *Documentator__required_packages, ARRAY *Documentator__include_path, ARRAY *Documentator__consts, ARRAY *Documentator__vars, ARRAY *Documentator__funcs, ARRAY *Documentator__classes)
/*1479*/ {
/*1480*/ 	int Documentator_i = 0;
/*1481*/ 	RECORD * Documentator_c = NULL;
/*1482*/ 	RECORD * Documentator_v = NULL;
/*1483*/ 	RECORD * Documentator_f = NULL;
/*1485*/ 	RECORD * Documentator_cl = NULL;
/*1486*/ 	if( !Documentator_generate ){
/*1488*/ 		return ;
/*1490*/ 	}
/*1490*/ 	Documentator_php_ver = Documentator__php_ver;
/*1491*/ 	Documentator_fn = Documentator__fn;
/*1492*/ 	Documentator_package_descr = Documentator__package_descr;
/*1493*/ 	Documentator_required_packages = Documentator__required_packages;
/*1494*/ 	Documentator_sort(Documentator__include_path);
/*1495*/ 	Documentator_include_path = Documentator__include_path;
/*1496*/ 	Documentator_consts = Documentator__consts;
/*1497*/ 	Documentator_vars = Documentator__vars;
/*1498*/ 	Documentator_funcs = Documentator__funcs;
/*1499*/ 	Documentator_classes = Documentator__classes;
/*1501*/ 	Documentator_prev_item_big_vspace = FALSE;
/*1502*/ 	Documentator_private_items = NULL;
/*1504*/ 	Documentator_fn_remapped = Documentator_RefMap(m2runtime_concat_STRING(0, FileName_DropExtension(Documentator_fn), Documentator_extension, 1));
/*1506*/ 	m2runtime_ERROR_CODE = 0;
/*1506*/ 	io_Open(1, (void *)&Documentator_fd, m2runtime_concat_STRING(0, FileName_DropExtension(Documentator_fn), Documentator_extension, 1), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"cwt");
/*1507*/ 	switch( m2runtime_ERROR_CODE ){

/*1507*/ 	case 0:  break;
/*1507*/ 	default:
/*1507*/ 		m2runtime_HALT(Documentator_0err_entry_get, 297, m2runtime_ERROR_MESSAGE);
/*1508*/ 	}
/*1508*/ 	Documentator_p(Documentator_page_header);
/*1510*/ 	Documentator_DocDescr(TRUE, Documentator_package_descr);
/*1512*/ 	{
/*1512*/ 		int m2runtime_for_limit_1;
/*1512*/ 		Documentator_i = 0;
/*1512*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*1513*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1513*/ 			Documentator_c = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 298);
/*1514*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 299) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 300), 8, Documentator_0err_entry_get, 301), Documentator_fn) == 0)) ){
/*1515*/ 				Documentator_DocConst(Documentator_c);
/*1518*/ 			}
/*1519*/ 		}
/*1519*/ 	}
/*1519*/ 	{
/*1519*/ 		int m2runtime_for_limit_1;
/*1519*/ 		Documentator_i = 0;
/*1519*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_vars) - 1);
/*1520*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1520*/ 			Documentator_v = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_vars, Documentator_i, Documentator_0err_entry_get, 302);
/*1521*/ 			if( ((Documentator_v != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_v, 12, Documentator_0err_entry_get, 303) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_v, 12, Documentator_0err_entry_get, 304), 8, Documentator_0err_entry_get, 305), Documentator_fn) == 0)) ){
/*1522*/ 				Documentator_DocVar(Documentator_v);
/*1525*/ 			}
/*1526*/ 		}
/*1526*/ 	}
/*1526*/ 	{
/*1526*/ 		int m2runtime_for_limit_1;
/*1526*/ 		Documentator_i = 0;
/*1526*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_funcs) - 1);
/*1527*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1527*/ 			Documentator_f = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_funcs, Documentator_i, Documentator_0err_entry_get, 306);
/*1528*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_f, 16, Documentator_0err_entry_get, 307) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_f, 16, Documentator_0err_entry_get, 308), 8, Documentator_0err_entry_get, 309), Documentator_fn) == 0)) ){
/*1529*/ 				Documentator_DocFunc(Documentator_f);
/*1532*/ 			}
/*1533*/ 		}
/*1533*/ 	}
/*1533*/ 	{
/*1533*/ 		int m2runtime_for_limit_1;
/*1533*/ 		Documentator_i = 0;
/*1533*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_classes) - 1);
/*1534*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1534*/ 			Documentator_cl = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_classes, Documentator_i, Documentator_0err_entry_get, 310);
/*1535*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 311) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 312), 8, Documentator_0err_entry_get, 313), Documentator_fn) == 0)) ){
/*1536*/ 				Documentator_DocClass(Documentator_cl);
/*1539*/ 			}
/*1540*/ 		}
/*1540*/ 	}
/*1540*/ 	if( m2runtime_strcmp(Documentator_private_items, NULL) > 0 ){
/*1541*/ 		Documentator_VSpaceBeforeItem(TRUE);
/*1542*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"<h2>Private items</h2>\012<blockquote>\012");
/*1543*/ 		Documentator_p(Documentator_private_items);
/*1544*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"\012</blockquote>\012");
/*1547*/ 	}
/*1547*/ 	Documentator_p(Documentator_page_footer);
/*1549*/ 	m2runtime_ERROR_CODE = 0;
/*1549*/ 	io_Close(1, (void *)&Documentator_fd);
/*1550*/ 	switch( m2runtime_ERROR_CODE ){

/*1550*/ 	case 0:  break;
/*1550*/ 	default:
/*1550*/ 		m2runtime_HALT(Documentator_0err_entry_get, 314, m2runtime_ERROR_MESSAGE);
/*1551*/ 	}
/*1553*/ }


/*1556*/ STRING *
/*1556*/ Documentator_ExtractDeprecated(STRING *Documentator_descr)
/*1556*/ {

/*1559*/ 	STRING *
/*1559*/ 	Documentator_trim_to_linear_string(STRING *Documentator_s)
/*1559*/ 	{
/*1559*/ 		int Documentator_len = 0;
/*1561*/ 		STRING * Documentator_s2 = NULL;
/*1561*/ 		Documentator_s = Documentator_trim(Documentator_s);
/*1562*/ 		Documentator_len = m2runtime_length(Documentator_s);
/*1563*/ 		if( (Documentator_len > 240) ){
/*1564*/ 			Documentator_s = m2runtime_concat_STRING(0, m2runtime_substr(Documentator_s, 0, (240 - 5), 1, Documentator_0err_entry_get, 315), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"[...]", 1);
/*1566*/ 		}
/*1566*/ 		Documentator_s = str_substitute(Documentator_s, m2runtime_CHR(9), m2runtime_CHR(32));
/*1567*/ 		Documentator_s = str_substitute(Documentator_s, m2runtime_CHR(13), m2runtime_CHR(32));
/*1568*/ 		Documentator_s = str_substitute(Documentator_s, m2runtime_CHR(10), m2runtime_CHR(32));
/*1570*/ 		do{
/*1570*/ 			Documentator_s2 = str_substitute(Documentator_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"  ", m2runtime_CHR(32));
/*1571*/ 			if( m2runtime_strcmp(Documentator_s2, Documentator_s) == 0 ){
/*1574*/ 				goto m2runtime_loop_1;
/*1574*/ 			}
/*1574*/ 			Documentator_s = Documentator_s2;
/*1576*/ 		}while(TRUE);
m2runtime_loop_1: ;
/*1576*/ 		return Documentator_s;
/*1581*/ 	}

/*1584*/ 	int Documentator_nest_level = 0;
/*1584*/ 	int Documentator_len = 0;
/*1584*/ 	int Documentator_j = 0;
/*1584*/ 	int Documentator_i = 0;
/*1586*/ 	STRING * Documentator_deprecated = NULL;
/*1589*/ 	do{
/*1589*/ 		Documentator_i = str_find(Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"<@deprecated");
/*1590*/ 		if( (Documentator_i < 0) ){
/*1591*/ 			return Documentator_trim_to_linear_string(Documentator_deprecated);
/*1597*/ 		}
/*1597*/ 		Documentator_i = (Documentator_i + m2runtime_length((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"<@deprecated"));
/*1598*/ 		Documentator_j = Documentator_i;
/*1599*/ 		Documentator_len = m2runtime_length(Documentator_descr);
/*1600*/ 		Documentator_nest_level = 1;
/*1602*/ 		do{
/*1602*/ 			if( (Documentator_j >= Documentator_len) ){
/*1603*/ 				Documentator_j = Documentator_len;
/*1606*/ 				goto m2runtime_loop_2;
/*1606*/ 			}
/*1606*/ 			if( m2runtime_strcmp(m2runtime_substr(Documentator_descr, Documentator_j, 0, 0, Documentator_0err_entry_get, 316), m2runtime_CHR(60)) == 0 ){
/*1607*/ 				m2_inc(&Documentator_nest_level, 1);
/*1608*/ 			} else if( m2runtime_strcmp(m2runtime_substr(Documentator_descr, Documentator_j, 0, 0, Documentator_0err_entry_get, 317), m2runtime_CHR(62)) == 0 ){
/*1609*/ 				m2_inc(&Documentator_nest_level, -1);
/*1610*/ 				if( (Documentator_nest_level <= 0) ){
/*1613*/ 					goto m2runtime_loop_2;
/*1614*/ 				}
/*1614*/ 			}
/*1614*/ 			m2_inc(&Documentator_j, 1);
/*1616*/ 		}while(TRUE);
m2runtime_loop_2: ;
/*1616*/ 		if( m2runtime_strcmp(Documentator_deprecated, EMPTY_STRING) > 0 ){
/*1617*/ 			Documentator_deprecated = m2runtime_concat_STRING(0, Documentator_deprecated, m2runtime_CHR(32), 1);
/*1619*/ 		}
/*1619*/ 		Documentator_deprecated = m2runtime_concat_STRING(0, Documentator_deprecated, m2runtime_substr(Documentator_descr, Documentator_i, Documentator_j, 1, Documentator_0err_entry_get, 318), 1);
/*1620*/ 		if( (Documentator_j >= Documentator_len) ){
/*1621*/ 			return Documentator_trim_to_linear_string(Documentator_deprecated);
/*1625*/ 		}
/*1625*/ 		Documentator_descr = m2runtime_substr(Documentator_descr, Documentator_j, Documentator_len, 1, Documentator_0err_entry_get, 319);
/*1628*/ 	}while(TRUE);
/*1628*/ 	m2runtime_missing_return(Documentator_0err_entry_get, 320);
/*1628*/ 	return NULL;
/*1631*/ }


char * Documentator_0func[] = {
    "p",
    "RefMap",
    "SearchConst",
    "SearchVar",
    "SearchFunc",
    "SearchClass",
    "SearchClassConst",
    "SearchClassVar",
    "SearchClassFunc",
    "report",
    "ItemToUrl",
    "AnchorToClass",
    "ResolveTags",
    "trim",
    "hex",
    "DocString",
    "DocValue",
    "sort",
    "DocDescr",
    "DocConst",
    "ArrayToString",
    "DocType",
    "DocVar",
    "DocSignature",
    "DocRaisedErrors",
    "DocThrownExceptions",
    "DocFunc",
    "DocClassConst",
    "DocClassProperty",
    "DocClassMethod",
    "NotInList",
    "DocInheritedConsts",
    "ScanProperties",
    "ScanPropertiesRecursive",
    "DocInheritedProperties",
    "ScanMethods",
    "ScanMethodsRecursive",
    "DocInheritedMethods",
    "DocClass",
    "ParseParameter",
    "Generate",
    "trim_to_linear_string",
    "ExtractDeprecated"
};

int Documentator_0err_entry[] = {
    0 /* p */, 81,
    1 /* RefMap */, 112,
    1 /* RefMap */, 112,
    1 /* RefMap */, 113,
    1 /* RefMap */, 113,
    2 /* SearchConst */, 147,
    2 /* SearchConst */, 147,
    2 /* SearchConst */, 149,
    3 /* SearchVar */, 159,
    3 /* SearchVar */, 159,
    3 /* SearchVar */, 159,
    3 /* SearchVar */, 161,
    4 /* SearchFunc */, 171,
    4 /* SearchFunc */, 171,
    4 /* SearchFunc */, 173,
    5 /* SearchClass */, 183,
    5 /* SearchClass */, 183,
    5 /* SearchClass */, 185,
    6 /* SearchClassConst */, 194,
    6 /* SearchClassConst */, 196,
    6 /* SearchClassConst */, 196,
    6 /* SearchClassConst */, 198,
    7 /* SearchClassVar */, 207,
    7 /* SearchClassVar */, 209,
    7 /* SearchClassVar */, 209,
    7 /* SearchClassVar */, 211,
    8 /* SearchClassFunc */, 220,
    8 /* SearchClassFunc */, 222,
    8 /* SearchClassFunc */, 222,
    8 /* SearchClassFunc */, 224,
    9 /* report */, 238,
    9 /* report */, 240,
    9 /* report */, 244,
    9 /* report */, 246,
    10 /* ItemToUrl */, 264,
    10 /* ItemToUrl */, 265,
    10 /* ItemToUrl */, 269,
    10 /* ItemToUrl */, 283,
    10 /* ItemToUrl */, 284,
    10 /* ItemToUrl */, 288,
    10 /* ItemToUrl */, 296,
    10 /* ItemToUrl */, 298,
    10 /* ItemToUrl */, 299,
    10 /* ItemToUrl */, 302,
    10 /* ItemToUrl */, 306,
    10 /* ItemToUrl */, 311,
    10 /* ItemToUrl */, 314,
    10 /* ItemToUrl */, 320,
    10 /* ItemToUrl */, 326,
    10 /* ItemToUrl */, 331,
    10 /* ItemToUrl */, 335,
    10 /* ItemToUrl */, 340,
    10 /* ItemToUrl */, 345,
    11 /* AnchorToClass */, 355,
    11 /* AnchorToClass */, 356,
    12 /* ResolveTags */, 417,
    12 /* ResolveTags */, 421,
    12 /* ResolveTags */, 427,
    12 /* ResolveTags */, 427,
    12 /* ResolveTags */, 428,
    12 /* ResolveTags */, 433,
    12 /* ResolveTags */, 441,
    12 /* ResolveTags */, 442,
    12 /* ResolveTags */, 443,
    12 /* ResolveTags */, 447,
    12 /* ResolveTags */, 454,
    12 /* ResolveTags */, 458,
    12 /* ResolveTags */, 469,
    13 /* trim */, 484,
    13 /* trim */, 489,
    13 /* trim */, 493,
    14 /* hex */, 539,
    15 /* DocString */, 552,
    16 /* DocValue */, 588,
    16 /* DocValue */, 595,
    17 /* sort */, 610,
    17 /* sort */, 610,
    17 /* sort */, 611,
    17 /* sort */, 611,
    17 /* sort */, 611,
    17 /* sort */, 611,
    18 /* DocDescr */, 663,
    18 /* DocDescr */, 664,
    18 /* DocDescr */, 711,
    18 /* DocDescr */, 711,
    18 /* DocDescr */, 711,
    18 /* DocDescr */, 717,
    18 /* DocDescr */, 718,
    18 /* DocDescr */, 730,
    18 /* DocDescr */, 730,
    18 /* DocDescr */, 730,
    18 /* DocDescr */, 736,
    18 /* DocDescr */, 740,
    18 /* DocDescr */, 758,
    19 /* DocConst */, 803,
    19 /* DocConst */, 804,
    19 /* DocConst */, 807,
    19 /* DocConst */, 808,
    19 /* DocConst */, 810,
    19 /* DocConst */, 812,
    19 /* DocConst */, 815,
    19 /* DocConst */, 815,
    19 /* DocConst */, 815,
    19 /* DocConst */, 815,
    19 /* DocConst */, 818,
    19 /* DocConst */, 819,
    20 /* ArrayToString */, 832,
    20 /* ArrayToString */, 837,
    20 /* ArrayToString */, 838,
    20 /* ArrayToString */, 841,
    20 /* ArrayToString */, 846,
    21 /* DocType */, 853,
    21 /* DocType */, 861,
    21 /* DocType */, 861,
    21 /* DocType */, 869,
    21 /* DocType */, 872,
    21 /* DocType */, 873,
    21 /* DocType */, 875,
    21 /* DocType */, 875,
    21 /* DocType */, 877,
    21 /* DocType */, 879,
    22 /* DocVar */, 884,
    22 /* DocVar */, 885,
    22 /* DocVar */, 888,
    22 /* DocVar */, 889,
    22 /* DocVar */, 891,
    22 /* DocVar */, 893,
    22 /* DocVar */, 900,
    22 /* DocVar */, 901,
    23 /* DocSignature */, 912,
    23 /* DocSignature */, 914,
    23 /* DocSignature */, 920,
    23 /* DocSignature */, 923,
    23 /* DocSignature */, 927,
    23 /* DocSignature */, 929,
    23 /* DocSignature */, 933,
    23 /* DocSignature */, 934,
    23 /* DocSignature */, 936,
    23 /* DocSignature */, 936,
    23 /* DocSignature */, 939,
    24 /* DocRaisedErrors */, 986,
    24 /* DocRaisedErrors */, 986,
    24 /* DocRaisedErrors */, 990,
    24 /* DocRaisedErrors */, 990,
    25 /* DocThrownExceptions */, 1013,
    26 /* DocFunc */, 1024,
    26 /* DocFunc */, 1025,
    26 /* DocFunc */, 1028,
    26 /* DocFunc */, 1029,
    26 /* DocFunc */, 1031,
    26 /* DocFunc */, 1031,
    26 /* DocFunc */, 1033,
    26 /* DocFunc */, 1034,
    26 /* DocFunc */, 1035,
    26 /* DocFunc */, 1036,
    27 /* DocClassConst */, 1047,
    27 /* DocClassConst */, 1050,
    27 /* DocClassConst */, 1051,
    27 /* DocClassConst */, 1051,
    27 /* DocClassConst */, 1053,
    27 /* DocClassConst */, 1055,
    27 /* DocClassConst */, 1055,
    27 /* DocClassConst */, 1055,
    27 /* DocClassConst */, 1055,
    27 /* DocClassConst */, 1058,
    27 /* DocClassConst */, 1059,
    27 /* DocClassConst */, 1062,
    27 /* DocClassConst */, 1062,
    27 /* DocClassConst */, 1062,
    28 /* DocClassProperty */, 1071,
    28 /* DocClassProperty */, 1073,
    28 /* DocClassProperty */, 1073,
    28 /* DocClassProperty */, 1077,
    28 /* DocClassProperty */, 1078,
    28 /* DocClassProperty */, 1078,
    28 /* DocClassProperty */, 1080,
    28 /* DocClassProperty */, 1083,
    28 /* DocClassProperty */, 1092,
    28 /* DocClassProperty */, 1094,
    28 /* DocClassProperty */, 1096,
    28 /* DocClassProperty */, 1096,
    28 /* DocClassProperty */, 1098,
    28 /* DocClassProperty */, 1098,
    28 /* DocClassProperty */, 1102,
    28 /* DocClassProperty */, 1103,
    28 /* DocClassProperty */, 1106,
    28 /* DocClassProperty */, 1106,
    28 /* DocClassProperty */, 1106,
    29 /* DocClassMethod */, 1115,
    29 /* DocClassMethod */, 1117,
    29 /* DocClassMethod */, 1117,
    29 /* DocClassMethod */, 1122,
    29 /* DocClassMethod */, 1123,
    29 /* DocClassMethod */, 1123,
    29 /* DocClassMethod */, 1125,
    29 /* DocClassMethod */, 1125,
    29 /* DocClassMethod */, 1126,
    29 /* DocClassMethod */, 1127,
    29 /* DocClassMethod */, 1128,
    29 /* DocClassMethod */, 1129,
    29 /* DocClassMethod */, 1129,
    29 /* DocClassMethod */, 1131,
    29 /* DocClassMethod */, 1132,
    29 /* DocClassMethod */, 1134,
    29 /* DocClassMethod */, 1135,
    29 /* DocClassMethod */, 1138,
    29 /* DocClassMethod */, 1138,
    29 /* DocClassMethod */, 1138,
    30 /* NotInList */, 1149,
    30 /* NotInList */, 1153,
    31 /* DocInheritedConsts */, 1165,
    31 /* DocInheritedConsts */, 1168,
    31 /* DocInheritedConsts */, 1170,
    31 /* DocInheritedConsts */, 1170,
    31 /* DocInheritedConsts */, 1170,
    31 /* DocInheritedConsts */, 1172,
    31 /* DocInheritedConsts */, 1174,
    31 /* DocInheritedConsts */, 1176,
    31 /* DocInheritedConsts */, 1176,
    31 /* DocInheritedConsts */, 1177,
    31 /* DocInheritedConsts */, 1177,
    31 /* DocInheritedConsts */, 1178,
    31 /* DocInheritedConsts */, 1181,
    32 /* ScanProperties */, 1200,
    32 /* ScanProperties */, 1202,
    32 /* ScanProperties */, 1202,
    32 /* ScanProperties */, 1203,
    32 /* ScanProperties */, 1203,
    32 /* ScanProperties */, 1204,
    33 /* ScanPropertiesRecursive */, 1216,
    33 /* ScanPropertiesRecursive */, 1217,
    33 /* ScanPropertiesRecursive */, 1218,
    33 /* ScanPropertiesRecursive */, 1218,
    34 /* DocInheritedProperties */, 1223,
    34 /* DocInheritedProperties */, 1223,
    34 /* DocInheritedProperties */, 1228,
    34 /* DocInheritedProperties */, 1230,
    34 /* DocInheritedProperties */, 1230,
    34 /* DocInheritedProperties */, 1230,
    34 /* DocInheritedProperties */, 1234,
    34 /* DocInheritedProperties */, 1237,
    34 /* DocInheritedProperties */, 1237,
    34 /* DocInheritedProperties */, 1240,
    34 /* DocInheritedProperties */, 1241,
    34 /* DocInheritedProperties */, 1241,
    35 /* ScanMethods */, 1261,
    35 /* ScanMethods */, 1264,
    35 /* ScanMethods */, 1264,
    35 /* ScanMethods */, 1264,
    36 /* ScanMethodsRecursive */, 1277,
    36 /* ScanMethodsRecursive */, 1278,
    36 /* ScanMethodsRecursive */, 1279,
    36 /* ScanMethodsRecursive */, 1279,
    37 /* DocInheritedMethods */, 1284,
    37 /* DocInheritedMethods */, 1284,
    37 /* DocInheritedMethods */, 1289,
    37 /* DocInheritedMethods */, 1291,
    37 /* DocInheritedMethods */, 1291,
    37 /* DocInheritedMethods */, 1291,
    37 /* DocInheritedMethods */, 1295,
    37 /* DocInheritedMethods */, 1298,
    37 /* DocInheritedMethods */, 1298,
    37 /* DocInheritedMethods */, 1301,
    37 /* DocInheritedMethods */, 1302,
    37 /* DocInheritedMethods */, 1302,
    38 /* DocClass */, 1312,
    38 /* DocClass */, 1313,
    38 /* DocClass */, 1318,
    38 /* DocClass */, 1320,
    38 /* DocClass */, 1323,
    38 /* DocClass */, 1326,
    38 /* DocClass */, 1332,
    38 /* DocClass */, 1335,
    38 /* DocClass */, 1341,
    38 /* DocClass */, 1342,
    38 /* DocClass */, 1347,
    38 /* DocClass */, 1351,
    38 /* DocClass */, 1351,
    38 /* DocClass */, 1356,
    38 /* DocClass */, 1357,
    38 /* DocClass */, 1363,
    38 /* DocClass */, 1364,
    38 /* DocClass */, 1364,
    38 /* DocClass */, 1368,
    38 /* DocClass */, 1369,
    38 /* DocClass */, 1369,
    38 /* DocClass */, 1373,
    38 /* DocClass */, 1374,
    38 /* DocClass */, 1374,
    39 /* ParseParameter */, 1426,
    39 /* ParseParameter */, 1437,
    39 /* ParseParameter */, 1444,
    39 /* ParseParameter */, 1451,
    39 /* ParseParameter */, 1456,
    39 /* ParseParameter */, 1457,
    39 /* ParseParameter */, 1457,
    39 /* ParseParameter */, 1458,
    40 /* Generate */, 1506,
    40 /* Generate */, 1514,
    40 /* Generate */, 1514,
    40 /* Generate */, 1514,
    40 /* Generate */, 1514,
    40 /* Generate */, 1521,
    40 /* Generate */, 1521,
    40 /* Generate */, 1521,
    40 /* Generate */, 1521,
    40 /* Generate */, 1528,
    40 /* Generate */, 1528,
    40 /* Generate */, 1528,
    40 /* Generate */, 1528,
    40 /* Generate */, 1535,
    40 /* Generate */, 1535,
    40 /* Generate */, 1535,
    40 /* Generate */, 1535,
    40 /* Generate */, 1549,
    41 /* trim_to_linear_string */, 1564,
    42 /* ExtractDeprecated */, 1606,
    42 /* ExtractDeprecated */, 1608,
    42 /* ExtractDeprecated */, 1619,
    42 /* ExtractDeprecated */, 1625,
    42 /* ExtractDeprecated */, 1627
};

void Documentator_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Documentator";
    *f = Documentator_0func[ Documentator_0err_entry[2*i] ];
    *l = Documentator_0err_entry[2*i + 1];
}
