/* IMPLEMENTATION MODULE Proto */
#define M2_IMPORT_Proto

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

#ifndef M2_IMPORT_Accounting
#    include "Accounting.c"
#endif

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_Exceptions
#    include "Exceptions.c"
#endif

#ifndef M2_IMPORT_Expressions
#    include "Expressions.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

void Proto_0err_entry_get(int i, char **m, char **f, int *l);

/* 14*/ void
/* 14*/ Proto_ParseArgsListDecl(RECORD *Proto_sign, STRING *Proto_function_or_method)
/* 14*/ {
/* 15*/ 	RECORD * Proto_a = NULL;
/* 16*/ 	RECORD * Proto_v = NULL;
/* 18*/ 	int Proto_opt_arg = 0;
/* 18*/ 	Scanner_Expect(149, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"expected '(' in ", Proto_function_or_method, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/* 19*/ 	Scanner_ReadSym();
/* 22*/ 	do{
/* 22*/ 		if( (Scanner_sym == 150) ){
/* 25*/ 			goto m2runtime_loop_1;
/* 26*/ 		}
/* 26*/ 		if( (Scanner_sym == 148) ){
/* 27*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 24, Proto_0err_entry_get, 0) = TRUE;
/* 28*/ 			Scanner_ReadSym();
/* 31*/ 			goto m2runtime_loop_1;
/* 35*/ 		}
/* 35*/ 		Proto_a = NULL;
/* 36*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_a, 24, 3, 12, Proto_0err_entry_get, 1) = Expressions_ParseType(FALSE);
/* 37*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Proto_a, 12, Proto_0err_entry_get, 2) == NULL ){
/* 38*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"missing type of the argument");
/* 39*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_a, 24, 3, 12, Proto_0err_entry_get, 3) = Globals_mixed_type;
/* 40*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Proto_a, 12, Proto_0err_entry_get, 4) == Globals_void_type ){
/* 41*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"argument of type `void' not allowed");
/* 47*/ 		}
/* 47*/ 		if( (Scanner_sym == 147) ){
/* 48*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Proto_a, 24, 3, 20, Proto_0err_entry_get, 5) = TRUE;
/* 49*/ 			Scanner_ReadSym();
/* 55*/ 		}
/* 55*/ 		Scanner_Expect(146, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"expected name of the formal argument in ", Proto_function_or_method, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/* 57*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_a, 24, 3, 8, Proto_0err_entry_get, 6) = Scanner_s;
/* 62*/ 		Accounting_AccountVarLHS(Scanner_s, FALSE);
/* 63*/ 		Proto_v = Search_SearchVar(Scanner_s, Globals_scope);
/* 64*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_v, 52, 7, 48, Proto_0err_entry_get, 7) = 100;
/* 65*/ 		Scanner_ReadSym();
/* 70*/ 		if( (Scanner_sym == 132) ){
/* 71*/ 			if( (((Globals_php_ver == 4)) &&  *(int *)m2runtime_dereference_rhs_RECORD(Proto_a, 20, Proto_0err_entry_get, 8)) ){
/* 72*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\111,\0,\0,\0)"can't assign default value to formal argument passed by reference (PHP 5)");
/* 74*/ 			}
/* 74*/ 			Proto_opt_arg = TRUE;
/* 75*/ 			Scanner_ReadSym();
/* 76*/ 		} else if( Proto_opt_arg ){
/* 77*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"missing default value for argument `$", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_a, 8, Proto_0err_entry_get, 9), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"'. Hint: mandatory arguments can't follow the default ones.", 1));
/* 80*/ 		}
/* 80*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_v, 52, 7, 20, Proto_0err_entry_get, 10) = (RECORD *)m2runtime_dereference_rhs_RECORD(Proto_a, 12, Proto_0err_entry_get, 11);
/* 81*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_v, 52, 7, 24, Proto_0err_entry_get, 12) = NULL;
/* 82*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 12, Proto_0err_entry_get, 13), 4, 1, Proto_0err_entry_get, 14) = Proto_a;
/* 83*/ 		if( !Proto_opt_arg ){
/* 84*/ 			m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 20, Proto_0err_entry_get, 15), 1);
/* 87*/ 		}
/* 87*/ 		if( (Scanner_sym == 131) ){
/* 88*/ 			Scanner_ReadSym();
/* 89*/ 			if( (Scanner_sym == 148) ){
/* 90*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 24, Proto_0err_entry_get, 16) = TRUE;
/* 91*/ 				Scanner_ReadSym();
/* 94*/ 				goto m2runtime_loop_1;
/* 96*/ 			}
/* 97*/ 		} else {
/* 99*/ 			goto m2runtime_loop_1;
/*100*/ 		}
/*100*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*100*/ 	Scanner_Expect(150, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected ')' or ',' in ", Proto_function_or_method, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/*102*/ 	Scanner_ReadSym();
/*106*/ }


/*108*/ void
/*108*/ Proto_ForwFuncDecl(int Proto_private, RECORD *Proto_t)
/*108*/ {
/*109*/ 	RECORD * Proto_sign = NULL;
/*111*/ 	RECORD * Proto_parent_func = NULL;
/*111*/ 	RECORD * Proto_f = NULL;
/*112*/ 	if( Proto_t == NULL ){
/*113*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"missing or invalid return type in function prototype");
/*115*/ 	}
/*115*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 8, Proto_0err_entry_get, 17) = Proto_t;
/*116*/ 	Scanner_ReadSym();
/*118*/ 	if( (Scanner_sym == 147) ){
/*119*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 16, Proto_0err_entry_get, 18) = TRUE;
/*120*/ 		if( (Globals_php_ver == 5) ){
/*121*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"obsolete syntax `function &func()', don't use in PHP 5");
/*123*/ 		}
/*123*/ 		Scanner_ReadSym();
/*130*/ 	}
/*130*/ 	Scanner_Expect(145, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"expected function name after `function'");
/*131*/ 	Proto_f = Search_SearchFunc(Scanner_s, FALSE);
/*132*/ 	if( Proto_f == NULL ){
/*133*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_f, 60, 9, 8, Proto_0err_entry_get, 19) = Scanner_s;
/*134*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_f, 60, 9, 12, Proto_0err_entry_get, 20) = str_toupper(Scanner_s);
/*135*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_f, 60, 9, 44, Proto_0err_entry_get, 21) = TRUE;
/*136*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_f, 60, 9, 48, Proto_0err_entry_get, 22) = Proto_private;
/*137*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_f, 60, 9, 16, Proto_0err_entry_get, 23) = Scanner_here();
/*138*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_f, 60, 9, 52, Proto_0err_entry_get, 24) = 0;
/*139*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_f, 60, 9, 24, Proto_0err_entry_get, 25) = NULL;
/*140*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_f, 60, 9, 28, Proto_0err_entry_get, 26) = Proto_sign;
/*141*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_funcs, 4, 1, Proto_0err_entry_get, 27) = Proto_f;
/*143*/ 	} else {
/*143*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_f, 16, Proto_0err_entry_get, 28)), 1));
/*145*/ 	}
/*145*/ 	Proto_parent_func = Globals_curr_func;
/*146*/ 	Globals_curr_func = Proto_f;
/*147*/ 	m2_inc(&Globals_scope, 1);
/*148*/ 	Scanner_ReadSym();
/*153*/ 	Proto_ParseArgsListDecl(Proto_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function");
/*159*/ 	if( (Scanner_sym == 169) ){
/*160*/ 		Exceptions_ParseThrows();
/*163*/ 	}
/*163*/ 	Scanner_Expect(129, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"expected `;' after function prototype");
/*164*/ 	Scanner_ReadSym();
/*166*/ 	Expressions_CleanCurrentScope();
/*167*/ 	m2_inc(&Globals_scope, -1);
/*168*/ 	Globals_curr_func = Proto_parent_func;
/*186*/ }


/*189*/ void
/*189*/ Proto_ParseMethodProto(int Proto_visibility, int Proto_abstract, int Proto_final, int Proto_static, RECORD *Proto_t)
/*189*/ {
/*190*/ 	RECORD * Proto_old_m = NULL;
/*190*/ 	RECORD * Proto_m = NULL;
/*191*/ 	int Proto_i = 0;
/*192*/ 	RECORD * Proto_sign = NULL;
/*193*/ 	RECORD * Proto_this = NULL;
/*194*/ 	int Proto_guess = 0;
/*230*/ 	int Proto_is_destructor = 0;
/*230*/ 	int Proto_is_constructor = 0;
/*233*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 76, Proto_0err_entry_get, 29) ){
/*234*/ 		Proto_abstract = TRUE;
/*235*/ 		if( (Proto_visibility != 2) ){
/*236*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"interface methods must be `public'");
/*237*/ 			Proto_visibility = 2;
/*239*/ 		}
/*239*/ 		if( Proto_final ){
/*240*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"interface methods cannot be `final'");
/*241*/ 			Proto_final = FALSE;
/*244*/ 		}
/*244*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 72, Proto_0err_entry_get, 30) ){
/*245*/ 		if( Proto_abstract ){
/*246*/ 			if( (Proto_visibility == 0) ){
/*247*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"abstract methods cannot be `private'");
/*248*/ 				Proto_visibility = 1;
/*250*/ 			}
/*250*/ 			if( Proto_static ){
/*251*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"abstract methods cannot be static");
/*252*/ 				Proto_static = FALSE;
/*254*/ 			}
/*254*/ 			if( Proto_final ){
/*255*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"abstract methods cannot be `final'");
/*256*/ 				Proto_final = FALSE;
/*259*/ 			}
/*259*/ 		} else {
/*259*/ 			if( (Proto_final && ((Proto_visibility == 0))) ){
/*260*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"a private method is implicitly `final'");
/*261*/ 				Proto_final = FALSE;
/*264*/ 			}
/*265*/ 		}
/*266*/ 	} else {
/*266*/ 		if( Proto_abstract ){
/*267*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"abstract method in non-abstract class");
/*268*/ 			Proto_abstract = FALSE;
/*270*/ 		}
/*270*/ 		if( (Proto_final && ((Proto_visibility == 0))) ){
/*271*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"a private method is implicitly `final'");
/*272*/ 			Proto_final = FALSE;
/*276*/ 		}
/*277*/ 	}
/*277*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 40, Proto_0err_entry_get, 31) = TRUE;
/*278*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 44, Proto_0err_entry_get, 32) = Proto_abstract;
/*279*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 48, Proto_0err_entry_get, 33) = Proto_visibility;
/*280*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 52, Proto_0err_entry_get, 34) = Proto_static;
/*281*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 56, Proto_0err_entry_get, 35) = Proto_final;
/*283*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 8, Proto_0err_entry_get, 36) = Proto_t;
/*284*/ 	if( Proto_t == NULL ){
/*285*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\130,\0,\0,\0)"missing return type in method prototype -- assuming `void' and trying to continue anyway");
/*286*/ 		Proto_guess = TRUE;
/*287*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 8, Proto_0err_entry_get, 37) = Globals_void_type;
/*290*/ 	}
/*290*/ 	Scanner_ReadSym();
/*295*/ 	if( (Scanner_sym == 147) ){
/*296*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 16, Proto_0err_entry_get, 38) = TRUE;
/*297*/ 		if( (Globals_php_ver == 5) ){
/*298*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"obsolete syntax `function &func()', don't use in PHP 5");
/*300*/ 		}
/*300*/ 		Scanner_ReadSym();
/*306*/ 	}
/*306*/ 	Scanner_Expect(145, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"expected method name");
/*307*/ 	Proto_old_m = Search_SearchClassMethod(Globals_curr_class, Scanner_s, FALSE);
/*308*/ 	if( Proto_old_m != NULL ){
/*309*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Proto_old_m, 20, Proto_0err_entry_get, 39) != NULL ){
/*310*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"method `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"()' already defined in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_old_m, 20, Proto_0err_entry_get, 40)), 1));
/*315*/ 		}
/*315*/ 		Proto_i = 0;
/*316*/ 		while( (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 36, Proto_0err_entry_get, 41), Proto_i, Proto_0err_entry_get, 42) != Proto_old_m ){
/*317*/ 			m2_inc(&Proto_i, 1);
/*319*/ 		}
/*319*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 36, Proto_0err_entry_get, 43), 4, 1, Proto_i, Proto_0err_entry_get, 44) = Proto_m;
/*322*/ 	} else {
/*322*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 36, Proto_0err_entry_get, 45), 4, 1, Proto_0err_entry_get, 46) = Proto_m;
/*324*/ 	}
/*324*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 8, Proto_0err_entry_get, 47) = Scanner_s;
/*325*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 12, Proto_0err_entry_get, 48) = str_toupper(Scanner_s);
/*327*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 20, Proto_0err_entry_get, 49) = Scanner_here();
/*328*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 16, Proto_0err_entry_get, 50) = Proto_sign;
/*333*/ 	if( (Globals_php_ver == 4) ){
/*335*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 51), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") == 0 ){
/*336*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 52), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"': this name is reserved for PHP 5 constructors", 1));
/*339*/ 		}
/*339*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 53), (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 12, Proto_0err_entry_get, 54)) == 0 ){
/*340*/ 			Proto_is_constructor = TRUE;
/*341*/ 			if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Proto_0err_entry_get, 55) == NULL ){
/*342*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 40, Proto_0err_entry_get, 56) = Proto_m;
/*344*/ 			} else {
/*344*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 57), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"': constructor already declared as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Proto_0err_entry_get, 58), 8, Proto_0err_entry_get, 59), m2runtime_CHR(39), 1));
/*349*/ 			}
/*350*/ 		}
/*352*/ 	} else {
/*352*/ 		if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 60), (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 12, Proto_0err_entry_get, 61)) == 0) || (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 62), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") == 0)) ){
/*354*/ 			Proto_is_constructor = TRUE;
/*355*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 63), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") != 0 ){
/*356*/ 				Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"the constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 64), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' has the same name of the class. PHP 5 states", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)" it should be called `__construct()'", 1));
/*360*/ 			}
/*360*/ 			if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Proto_0err_entry_get, 65) == NULL ){
/*361*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 40, Proto_0err_entry_get, 66) = Proto_m;
/*363*/ 			} else {
/*363*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 67), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"': constructor already declared as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Proto_0err_entry_get, 68), 8, Proto_0err_entry_get, 69), m2runtime_CHR(39), 1));
/*368*/ 			}
/*370*/ 		}
/*374*/ 	}
/*374*/ 	Proto_is_destructor = (((Globals_php_ver == 5)) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 70), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__DESTRUCT") == 0));
/*375*/ 	if( Proto_is_destructor ){
/*376*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 44, Proto_0err_entry_get, 71) = Proto_m;
/*379*/ 	}
/*379*/ 	if( (!Accounting_report_unused || Proto_is_constructor || Proto_is_destructor || Proto_abstract) ){
/*380*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 60, Proto_0err_entry_get, 72) = 100;
/*383*/ 	}
/*383*/ 	Globals_curr_method = Proto_m;
/*384*/ 	m2_inc(&Globals_scope, 1);
/*385*/ 	Scanner_ReadSym();
/*391*/ 	Accounting_AccountVarLHS(m2runtime_CHR(42), FALSE);
/*392*/ 	Proto_this = Search_SearchVar(m2runtime_CHR(42), Globals_scope);
/*393*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_this, 52, 7, 8, Proto_0err_entry_get, 73) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"this";
/*394*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_this, 52, 7, 20, Proto_0err_entry_get, 74) = (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 24, Proto_0err_entry_get, 75);
/*399*/ 	Proto_ParseArgsListDecl(Proto_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"method");
/*401*/ 	if( !Proto_is_constructor ){
/*412*/ 	} else {
/*412*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Proto_m, 52, Proto_0err_entry_get, 76) ){
/*413*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 77), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"': a constructor cannot be `static'", 1));
/*415*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 52, Proto_0err_entry_get, 78) = FALSE;
/*417*/ 		}
/*417*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Proto_m, 56, Proto_0err_entry_get, 79) ){
/*418*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 80), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"': a constructor cannot be `final'", 1));
/*420*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 72, 8, 56, Proto_0err_entry_get, 81) = FALSE;
/*422*/ 		}
/*422*/ 		if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_sign, 8, Proto_0err_entry_get, 82) != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_sign, 8, Proto_0err_entry_get, 83) != Globals_void_type)) ){
/*423*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 84), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"': a constructor cannot", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)" return a value. It must be declared `void'.", 1));
/*426*/ 		}
/*426*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 8, Proto_0err_entry_get, 85) = Globals_void_type;
/*433*/ 	}
/*433*/ 	if( (Scanner_sym == 169) ){
/*434*/ 		Exceptions_ParseThrows();
/*437*/ 	}
/*437*/ 	Scanner_Expect(129, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"expected `;' at the end of the method prototype");
/*438*/ 	Scanner_ReadSym();
/*440*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_this, 52, 7, 48, Proto_0err_entry_get, 86) = 100;
/*445*/ 	Expressions_CleanCurrentScope();
/*446*/ 	m2_inc(&Globals_scope, -1);
/*447*/ 	Globals_curr_method = NULL;
/*451*/ }


/*457*/ void
/*457*/ Proto_ParseAttributes(int *Proto_visibility, int *Proto_abstract, int *Proto_final, int *Proto_static)
/*457*/ {
/*457*/ 	*Proto_visibility = 2;
/*458*/ 	*Proto_abstract = FALSE;
/*459*/ 	*Proto_final = FALSE;
/*460*/ 	*Proto_static = FALSE;
/*463*/ 	do{
/*463*/ 		if( (Scanner_sym == 163) ){
/*464*/ 			*Proto_visibility = 0;
/*465*/ 			Scanner_ReadSym();
/*467*/ 		} else if( (Scanner_sym == 162) ){
/*468*/ 			*Proto_visibility = 1;
/*469*/ 			Scanner_ReadSym();
/*471*/ 		} else if( (Scanner_sym == 161) ){
/*472*/ 			*Proto_visibility = 2;
/*473*/ 			Scanner_ReadSym();
/*475*/ 		} else if( (Scanner_sym == 164) ){
/*476*/ 			*Proto_abstract = TRUE;
/*477*/ 			Scanner_ReadSym();
/*479*/ 		} else if( (Scanner_sym == 166) ){
/*480*/ 			*Proto_final = TRUE;
/*481*/ 			Scanner_ReadSym();
/*483*/ 		} else if( (Scanner_sym == 165) ){
/*484*/ 			*Proto_static = TRUE;
/*485*/ 			Scanner_ReadSym();
/*489*/ 		} else {
/*490*/ 			goto m2runtime_loop_1;
/*491*/ 		}
/*492*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*494*/ }


/*496*/ void
/*496*/ Proto_ForwClassDecl(int Proto_private, int Proto_abstract, int Proto_final)
/*496*/ {
/*497*/ 	RECORD * Proto_c = NULL;
/*498*/ 	int Proto_visibility = 0;
/*499*/ 	int Proto_static = 0;
/*501*/ 	RECORD * Proto_t = NULL;
/*501*/ 	Scanner_ReadSym();
/*502*/ 	Scanner_Expect(145, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected class name");
/*503*/ 	Proto_c = Search_SearchClass(Scanner_s, TRUE);
/*504*/ 	if( Proto_c != NULL ){
/*505*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_c, 48, Proto_0err_entry_get, 87)), 1));
/*508*/ 	}
/*508*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 8, Proto_0err_entry_get, 88) = Scanner_s;
/*509*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 12, Proto_0err_entry_get, 89) = str_toupper(Scanner_s);
/*510*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 60, Proto_0err_entry_get, 90) = TRUE;
/*511*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 72, Proto_0err_entry_get, 91) = Proto_abstract;
/*512*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 68, Proto_0err_entry_get, 92) = Proto_final;
/*513*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 24, Proto_0err_entry_get, 93) = (
/*513*/ 		push((char*) alloc_RECORD(24, 2)),
/*513*/ 		*(int*) (tos()+16) = 9,
/*513*/ 		*(int*) (tos()+20) = 1,
/*513*/ 		push((char*) NULL),
/*513*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*513*/ 		push((char*) Proto_c),
/*514*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*514*/ 		(RECORD*) pop()
/*514*/ 	);
/*514*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 48, Proto_0err_entry_get, 94) = Scanner_here();
/*515*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 64, Proto_0err_entry_get, 95) = Proto_private;
/*516*/ 	*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_classes, 4, 1, Proto_0err_entry_get, 96) = Proto_c;
/*517*/ 	Scanner_ReadSym();
/*519*/ 	Scanner_Expect(153, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"expected `{' in class prototype");
/*520*/ 	Scanner_ReadSym();
/*522*/ 	Globals_curr_class = Proto_c;
/*523*/ 	while( (Scanner_sym != 154) ){
/*524*/ 		Proto_ParseAttributes(&Proto_visibility, &Proto_abstract, &Proto_final, &Proto_static);
/*525*/ 		Proto_t = Expressions_ParseType(FALSE);
/*526*/ 		Proto_ParseMethodProto(Proto_visibility, Proto_abstract, Proto_final, Proto_static, Proto_t);
/*528*/ 	}
/*528*/ 	Globals_curr_class = NULL;
/*530*/ 	Scanner_Expect(154, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"expected `}' in class prototype");
/*531*/ 	Scanner_ReadSym();
/*535*/ }


/*537*/ void
/*537*/ Proto_ParseForwardDecl(void)
/*537*/ {
/*538*/ 	int Proto_visibility = 0;
/*539*/ 	int Proto_static = 0;
/*539*/ 	int Proto_final = 0;
/*539*/ 	int Proto_abstract = 0;
/*541*/ 	RECORD * Proto_t = NULL;
/*541*/ 	if( (Globals_scope > 0) ){
/*542*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\61,\0,\0,\0)"forward declarations allowed only in global scope");
/*545*/ 	}
/*545*/ 	Scanner_ReadSym();
/*547*/ 	Proto_ParseAttributes(&Proto_visibility, &Proto_abstract, &Proto_final, &Proto_static);
/*548*/ 	Proto_t = Expressions_ParseType(FALSE);
/*550*/ 	if( ((Globals_curr_class == NULL) && ((Globals_scope == 0))) ){
/*553*/ 		if( (Scanner_sym == 134) ){
/*555*/ 			if( (((Proto_visibility == 1)) || Proto_static || Proto_final || Proto_abstract) ){
/*556*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"invalid attributes for function prototype");
/*558*/ 			}
/*558*/ 			Proto_ForwFuncDecl((Proto_visibility == 0), Proto_t);
/*560*/ 		} else if( (Scanner_sym == 135) ){
/*561*/ 			if( (((Proto_visibility == 1)) || Proto_static) ){
/*562*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"invalid attributes for class prototype");
/*564*/ 			}
/*564*/ 			if( Proto_t != NULL ){
/*565*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"invalid return type in class prototype");
/*567*/ 			}
/*567*/ 			Proto_ForwClassDecl((Proto_visibility == 0), Proto_abstract, Proto_final);
/*570*/ 		} else {
/*570*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"expected function or class prototype");
/*573*/ 		}
/*573*/ 	} else if( ((Globals_curr_class != NULL) && ((Globals_scope == 0))) ){
/*576*/ 		if( (Scanner_sym != 134) ){
/*577*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"expected function prototype");
/*580*/ 		}
/*580*/ 		Proto_ParseMethodProto(Proto_visibility, Proto_abstract, Proto_final, Proto_static, Proto_t);
/*583*/ 	} else {
/*583*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"forward declaration not allowed here");
/*588*/ 	}
/*590*/ }


char * Proto_0func[] = {
    "ParseArgsListDecl",
    "ForwFuncDecl",
    "ParseMethodProto",
    "ForwClassDecl"
};

int Proto_0err_entry[] = {
    0 /* ParseArgsListDecl */, 27,
    0 /* ParseArgsListDecl */, 36,
    0 /* ParseArgsListDecl */, 37,
    0 /* ParseArgsListDecl */, 39,
    0 /* ParseArgsListDecl */, 40,
    0 /* ParseArgsListDecl */, 48,
    0 /* ParseArgsListDecl */, 57,
    0 /* ParseArgsListDecl */, 64,
    0 /* ParseArgsListDecl */, 71,
    0 /* ParseArgsListDecl */, 77,
    0 /* ParseArgsListDecl */, 80,
    0 /* ParseArgsListDecl */, 80,
    0 /* ParseArgsListDecl */, 81,
    0 /* ParseArgsListDecl */, 82,
    0 /* ParseArgsListDecl */, 82,
    0 /* ParseArgsListDecl */, 84,
    0 /* ParseArgsListDecl */, 90,
    1 /* ForwFuncDecl */, 115,
    1 /* ForwFuncDecl */, 119,
    1 /* ForwFuncDecl */, 133,
    1 /* ForwFuncDecl */, 134,
    1 /* ForwFuncDecl */, 135,
    1 /* ForwFuncDecl */, 136,
    1 /* ForwFuncDecl */, 137,
    1 /* ForwFuncDecl */, 138,
    1 /* ForwFuncDecl */, 139,
    1 /* ForwFuncDecl */, 140,
    1 /* ForwFuncDecl */, 141,
    1 /* ForwFuncDecl */, 143,
    2 /* ParseMethodProto */, 233,
    2 /* ParseMethodProto */, 244,
    2 /* ParseMethodProto */, 277,
    2 /* ParseMethodProto */, 278,
    2 /* ParseMethodProto */, 279,
    2 /* ParseMethodProto */, 280,
    2 /* ParseMethodProto */, 281,
    2 /* ParseMethodProto */, 283,
    2 /* ParseMethodProto */, 287,
    2 /* ParseMethodProto */, 296,
    2 /* ParseMethodProto */, 309,
    2 /* ParseMethodProto */, 311,
    2 /* ParseMethodProto */, 316,
    2 /* ParseMethodProto */, 316,
    2 /* ParseMethodProto */, 319,
    2 /* ParseMethodProto */, 319,
    2 /* ParseMethodProto */, 322,
    2 /* ParseMethodProto */, 322,
    2 /* ParseMethodProto */, 324,
    2 /* ParseMethodProto */, 325,
    2 /* ParseMethodProto */, 327,
    2 /* ParseMethodProto */, 328,
    2 /* ParseMethodProto */, 335,
    2 /* ParseMethodProto */, 336,
    2 /* ParseMethodProto */, 339,
    2 /* ParseMethodProto */, 339,
    2 /* ParseMethodProto */, 341,
    2 /* ParseMethodProto */, 342,
    2 /* ParseMethodProto */, 344,
    2 /* ParseMethodProto */, 346,
    2 /* ParseMethodProto */, 346,
    2 /* ParseMethodProto */, 352,
    2 /* ParseMethodProto */, 352,
    2 /* ParseMethodProto */, 353,
    2 /* ParseMethodProto */, 355,
    2 /* ParseMethodProto */, 356,
    2 /* ParseMethodProto */, 360,
    2 /* ParseMethodProto */, 361,
    2 /* ParseMethodProto */, 363,
    2 /* ParseMethodProto */, 365,
    2 /* ParseMethodProto */, 365,
    2 /* ParseMethodProto */, 374,
    2 /* ParseMethodProto */, 376,
    2 /* ParseMethodProto */, 380,
    2 /* ParseMethodProto */, 393,
    2 /* ParseMethodProto */, 394,
    2 /* ParseMethodProto */, 394,
    2 /* ParseMethodProto */, 412,
    2 /* ParseMethodProto */, 413,
    2 /* ParseMethodProto */, 415,
    2 /* ParseMethodProto */, 417,
    2 /* ParseMethodProto */, 418,
    2 /* ParseMethodProto */, 420,
    2 /* ParseMethodProto */, 422,
    2 /* ParseMethodProto */, 422,
    2 /* ParseMethodProto */, 423,
    2 /* ParseMethodProto */, 426,
    2 /* ParseMethodProto */, 440,
    3 /* ForwClassDecl */, 506,
    3 /* ForwClassDecl */, 508,
    3 /* ForwClassDecl */, 509,
    3 /* ForwClassDecl */, 510,
    3 /* ForwClassDecl */, 511,
    3 /* ForwClassDecl */, 512,
    3 /* ForwClassDecl */, 513,
    3 /* ForwClassDecl */, 514,
    3 /* ForwClassDecl */, 515,
    3 /* ForwClassDecl */, 516
};

void Proto_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Proto";
    *f = Proto_0func[ Proto_0err_entry[2*i] ];
    *l = Proto_0err_entry[2*i + 1];
}
