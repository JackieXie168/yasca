/* IMPLEMENTATION MODULE Expressions */
#define M2_IMPORT_Expressions

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_Accounting
#    include "Accounting.c"
#endif

#ifndef M2_IMPORT_Classes
#    include "Classes.c"
#endif

#ifndef M2_IMPORT_Exceptions
#    include "Exceptions.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Operators
#    include "Operators.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

void Expressions_0err_entry_get(int i, char **m, char **f, int *l);
/* 20*/ int Expressions_handle_error = 0;

/* 25*/ void
/* 25*/ Expressions_CleanCurrentScope(void)
/* 25*/ {
/* 26*/ 	int Expressions_i = 0;
/* 28*/ 	RECORD * Expressions_v = NULL;
/* 28*/ 	Expressions_i = (Globals_vars_n - 1);
/* 29*/ 	while( (((Expressions_i >= 0)) && (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_vars, Expressions_i, Expressions_0err_entry_get, 0), 40, Expressions_0err_entry_get, 1) == Globals_scope))) ){
/* 30*/ 		Expressions_v = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_vars, Expressions_i, Expressions_0err_entry_get, 2);
/* 31*/ 		if( (! *(int *)m2runtime_dereference_rhs_RECORD(Expressions_v, 44, Expressions_0err_entry_get, 3) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 16, Expressions_0err_entry_get, 4) != NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_v, 48, Expressions_0err_entry_get, 5) == 0))) ){
/* 32*/ 			Scanner_Notice2((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 16, Expressions_0err_entry_get, 6), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_v, 8, Expressions_0err_entry_get, 7), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"' assigned but never used", 1));
/* 34*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_v, 44, Expressions_0err_entry_get, 8) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 16, Expressions_0err_entry_get, 9) == NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_v, 48, Expressions_0err_entry_get, 10) == 0))) ){
/* 35*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"in the last function, variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_v, 8, Expressions_0err_entry_get, 11), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"' declared global but not used", 1));
/* 38*/ 		}
/* 38*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Globals_vars, 4, 1, Expressions_i, Expressions_0err_entry_get, 12) = NULL;
/* 39*/ 		m2_inc(&Expressions_i, -1);
/* 41*/ 	}
/* 41*/ 	Globals_vars_n = (Expressions_i + 1);
/* 45*/ }


/* 47*/ void
/* 47*/ Expressions_InheritErrors(int *Expressions_curr, int Expressions_inherited)
/* 47*/ {
/* 47*/ 	*Expressions_curr = (*Expressions_curr | Expressions_inherited);
/* 56*/ }


/* 65*/ void
/* 65*/ Expressions_ResolveClassProperty(RECORD *Expressions_class, int Expressions_static, STRING *Expressions_id, RECORD **Expressions_P, RECORD **Expressions_p)
/* 65*/ {
/* 65*/ 	Search_SearchClassProperty(Expressions_class, Expressions_id, Expressions_P, Expressions_p);
/* 66*/ 	if( *Expressions_p == NULL ){
/* 67*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"property `", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_class, 8, Expressions_0err_entry_get, 13), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", Expressions_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"' does not exist or not visible", 1));
/* 70*/ 		return ;
/* 71*/ 	}
/* 71*/ 	Accounting_AccountClassProperty(*Expressions_P, *Expressions_p);
/* 74*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_p, 32, Expressions_0err_entry_get, 14)){

/* 76*/ 	case 2:
/* 79*/ 	break;

/* 79*/ 	case 1:
/* 80*/ 	if( ((Globals_curr_class == NULL) || !Classes_IsSubclassOf(Globals_curr_class, *Expressions_P)) ){
/* 81*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"access forbidden to protected property `", Classes_pc(Expressions_class, *Expressions_P), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(*Expressions_p, 8, Expressions_0err_entry_get, 15), m2runtime_CHR(39), 1));
/* 85*/ 	}
/* 85*/ 	break;

/* 85*/ 	case 0:
/* 88*/ 	if( Globals_curr_class != *Expressions_P ){
/* 89*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"access forbidden to private property `", Classes_pc(Expressions_class, *Expressions_P), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(*Expressions_p, 8, Expressions_0err_entry_get, 16), m2runtime_CHR(39), 1));
/* 94*/ 	}
/* 94*/ 	break;

/* 94*/ 	default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 17);
/* 96*/ 	}
/* 96*/ 	if( Expressions_static ){
/* 97*/ 		if( ! *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_p, 36, Expressions_0err_entry_get, 18) ){
/* 98*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"static access to non-static property `", Classes_pc(Expressions_class, *Expressions_P), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(*Expressions_p, 8, Expressions_0err_entry_get, 19), m2runtime_CHR(39), 1));
/*102*/ 		}
/*102*/ 	} else {
/*102*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_p, 36, Expressions_0err_entry_get, 20) ){
/*103*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"non-static access to static property `", Classes_pc(Expressions_class, *Expressions_P), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(*Expressions_p, 8, Expressions_0err_entry_get, 21), m2runtime_CHR(39), 1));
/*107*/ 		}
/*108*/ 	}
/*110*/ }

 RECORD * Expressions_ParseExpr();

/*114*/ void
/*114*/ Expressions_SkipFuncCall(void)
/*114*/ {
/*116*/ 	RECORD * Expressions_r = NULL;
/*116*/ 	Scanner_ReadSym();
/*117*/ 	if( (Scanner_sym == 13) ){
/*118*/ 		Scanner_ReadSym();
/*120*/ 		return ;
/*122*/ 	}
/*122*/ 	do{
/*122*/ 		Expressions_r = Expressions_ParseExpr();
/*123*/ 		if( (Scanner_sym == 16) ){
/*124*/ 			Scanner_ReadSym();
/*125*/ 		} else if( (Scanner_sym == 13) ){
/*126*/ 			Scanner_ReadSym();
/*128*/ 			return ;
/*130*/ 		}
/*131*/ 	}while(TRUE);
/*133*/ }


/*141*/ void
/*141*/ Expressions_DereferenceClassMethod(RECORD *Expressions_class, int Expressions_static, STRING *Expressions_id, RECORD **Expressions_res_class, RECORD **Expressions_res_method)
/*141*/ {
/*142*/ 	RECORD * Expressions_M = NULL;
/*144*/ 	RECORD * Expressions_m = NULL;
/*145*/ 	Classes_ResolveClassMethod(Expressions_class, Expressions_id, &Expressions_M, &Expressions_m);
/*146*/ 	*Expressions_res_class = Expressions_M;
/*147*/ 	*Expressions_res_method = Expressions_m;
/*148*/ 	if( Expressions_m == NULL ){
/*149*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the method ", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_class, 8, Expressions_0err_entry_get, 22), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Expressions_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"() does not exist", 1));
/*151*/ 		return ;
/*153*/ 	} else {
/*153*/ 		Accounting_AccountClassMethod(Expressions_M, Expressions_m);
/*155*/ 		if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_m, 68, Expressions_0err_entry_get, 23) != 0)) && ((Expressions_handle_error == 0))) ){
/*156*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the method ", Scanner_mn(Expressions_M, Expressions_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)" may raise error", 1));
/*157*/ 			if( Globals_curr_func != NULL ){
/*158*/ 				Expressions_InheritErrors((int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_func, 60, 9, 56, Expressions_0err_entry_get, 24),  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_m, 68, Expressions_0err_entry_get, 25));
/*159*/ 			} else if( Globals_curr_method != NULL ){
/*160*/ 				Expressions_InheritErrors((int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_method, 72, 8, 68, Expressions_0err_entry_get, 26),  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_m, 68, Expressions_0err_entry_get, 27));
/*167*/ 			}
/*168*/ 		}
/*168*/ 		Exceptions_ThrowExceptions((ARRAY *)m2runtime_dereference_rhs_RECORD(Expressions_m, 28, Expressions_0err_entry_get, 28));
/*173*/ 	}
/*173*/ 	if( ((Expressions_m == (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_M, 40, Expressions_0err_entry_get, 29)) && (((Globals_curr_class == NULL) || (Globals_curr_method != (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Expressions_0err_entry_get, 30)) || !Classes_IsSubclassOf(Globals_curr_class, Expressions_M)))) ){
/*179*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the method ", Scanner_mn(Expressions_class, Expressions_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" is a class ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\104,\0,\0,\0)"constructor, it can be called explicity only inside the constructor ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"of an extending class", 1));
/*185*/ 	}
/*185*/ 	if( ((Expressions_m == (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_M, 40, Expressions_0err_entry_get, 31)) && (Globals_curr_class != NULL) && (Globals_curr_method == (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Expressions_0err_entry_get, 32))) ){
/*189*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 80, Expressions_0err_entry_get, 33) = TRUE;
/*193*/ 	}
/*193*/ 	if( ((Expressions_m == (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_M, 44, Expressions_0err_entry_get, 34)) && (((Globals_curr_class == NULL) || (Globals_curr_method != (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 44, Expressions_0err_entry_get, 35)) || !Classes_IsSubclassOf(Globals_curr_class, Expressions_M)))) ){
/*199*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the method ", Scanner_mn(Expressions_class, Expressions_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" is a class ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\103,\0,\0,\0)"destructor, it can be called explicity only inside the constructor ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"of an extending class", 1));
/*205*/ 	}
/*205*/ 	if( ((Expressions_m == (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_M, 44, Expressions_0err_entry_get, 36)) && (Globals_curr_class != NULL) && (Globals_curr_method == (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 44, Expressions_0err_entry_get, 37))) ){
/*209*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 84, Expressions_0err_entry_get, 38) = TRUE;
/*213*/ 	}
/*213*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_m, 48, Expressions_0err_entry_get, 39)){

/*214*/ 	case 2:
/*215*/ 	break;

/*215*/ 	case 1:
/*216*/ 	if( ((Globals_curr_class == NULL) || !Classes_IsSubclassOf(Globals_curr_class, Expressions_M)) ){
/*217*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"access forbidden to protected method ", Classes_pc(Expressions_class, Expressions_M), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_m, 8, Expressions_0err_entry_get, 40), 1));
/*220*/ 	}
/*220*/ 	break;

/*220*/ 	case 0:
/*221*/ 	if( Globals_curr_class != Expressions_M ){
/*222*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"access forbidden to private method ", Classes_pc(Expressions_class, Expressions_M), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_m, 8, Expressions_0err_entry_get, 41), 1));
/*226*/ 	}
/*226*/ 	break;

/*226*/ 	default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 42);
/*228*/ 	}
/*228*/ 	if( Expressions_static ){
/*229*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_m, 52, Expressions_0err_entry_get, 43) ){
/*230*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_m, 44, Expressions_0err_entry_get, 44) ){
/*231*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"cannot call abstract static method ", Scanner_mn(Expressions_M, Expressions_m), 1));
/*234*/ 			}
/*234*/ 		} else {
/*234*/ 			if( ((Globals_curr_method != NULL) && ! *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 52, Expressions_0err_entry_get, 45) && Classes_IsSubclassOf(Globals_curr_class, Expressions_M)) ){
/*238*/ 			} else {
/*238*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"static access to non-static method ", Classes_pc(Expressions_class, Expressions_M), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_m, 8, Expressions_0err_entry_get, 46), 1));
/*242*/ 			}
/*243*/ 		}
/*243*/ 	} else {
/*243*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_m, 52, Expressions_0err_entry_get, 47) ){
/*244*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"non-static access to static method ", Classes_pc(Expressions_class, Expressions_M), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_m, 8, Expressions_0err_entry_get, 48), 1));
/*248*/ 		}
/*250*/ 	}
/*252*/ }


/*258*/ RECORD *
/*258*/ Expressions_ParseType(int Expressions_allow_type_hinting)
/*258*/ {

/*260*/ 	RECORD *
/*260*/ 	Expressions_ParseArrayType(void)
/*260*/ 	{
/*262*/ 		RECORD * Expressions_t = NULL;
/*262*/ 		Expressions_t = (
/*262*/ 			push((char*) alloc_RECORD(24, 2)),
/*262*/ 			*(int*) (tos()+16) = 6,
/*262*/ 			*(int*) (tos()+20) = 1,
/*262*/ 			push((char*) NULL),
/*262*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*262*/ 			push((char*) NULL),
/*263*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*263*/ 			(RECORD*) pop()
/*263*/ 		);
/*263*/ 		Scanner_ReadSym();
/*264*/ 		if( (Scanner_sym == 138) ){
/*265*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Expressions_t, 24, 2, 20, Expressions_0err_entry_get, 49) = 3;
/*266*/ 			Scanner_ReadSym();
/*267*/ 		} else if( (Scanner_sym == 140) ){
/*268*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Expressions_t, 24, 2, 20, Expressions_0err_entry_get, 50) = 5;
/*269*/ 			Scanner_ReadSym();
/*271*/ 		}
/*271*/ 		Scanner_Expect(152, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"expected `[]' or `[int]' or `[string]'");
/*272*/ 		Scanner_ReadSym();
/*273*/ 		if( (Scanner_sym == 151) ){
/*274*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_t, 24, 2, 8, Expressions_0err_entry_get, 51) = Expressions_ParseArrayType();
/*276*/ 		} else {
/*276*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_t, 24, 2, 8, Expressions_0err_entry_get, 52) = Expressions_ParseType(FALSE);
/*278*/ 		}
/*278*/ 		return Expressions_t;
/*281*/ 	}

/*283*/ 	RECORD * Expressions_class = NULL;
/*283*/ 	switch(Scanner_sym){

/*284*/ 	case 136:
/*284*/ 	Scanner_ReadSym();
/*284*/ 	return Globals_void_type;
/*285*/ 	break;

/*285*/ 	case 137:
/*285*/ 	Scanner_ReadSym();
/*285*/ 	return Globals_boolean_type;
/*286*/ 	break;

/*286*/ 	case 138:
/*286*/ 	Scanner_ReadSym();
/*286*/ 	return Globals_int_type;
/*287*/ 	break;

/*287*/ 	case 139:
/*287*/ 	Scanner_ReadSym();
/*287*/ 	return Globals_float_type;
/*288*/ 	break;

/*288*/ 	case 140:
/*288*/ 	Scanner_ReadSym();
/*288*/ 	return Globals_string_type;
/*289*/ 	break;

/*289*/ 	case 141:
/*289*/ 	case 70:
/*290*/ 	if( (((Scanner_sym == 70)) && !Expressions_allow_type_hinting) ){
/*291*/ 		return NULL;
/*293*/ 	}
/*293*/ 	Scanner_ReadSym();
/*294*/ 	if( (Scanner_sym == 151) ){
/*295*/ 		return Expressions_ParseArrayType();
/*297*/ 	} else {
/*297*/ 		return (
/*297*/ 			push((char*) alloc_RECORD(24, 2)),
/*297*/ 			*(int*) (tos()+16) = 6,
/*297*/ 			*(int*) (tos()+20) = 1,
/*297*/ 			push((char*) NULL),
/*297*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*297*/ 			push((char*) NULL),
/*298*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*299*/ 			(RECORD*) pop()
/*299*/ 		);
/*299*/ 	}
/*299*/ 	break;

/*299*/ 	case 142:
/*299*/ 	Scanner_ReadSym();
/*299*/ 	return Globals_mixed_type;
/*300*/ 	break;

/*300*/ 	case 143:
/*300*/ 	Scanner_ReadSym();
/*300*/ 	return Globals_resource_type;
/*301*/ 	break;

/*301*/ 	case 144:
/*301*/ 	Scanner_ReadSym();
/*301*/ 	return (
/*301*/ 		push((char*) alloc_RECORD(24, 2)),
/*301*/ 		*(int*) (tos()+16) = 9,
/*301*/ 		*(int*) (tos()+20) = 1,
/*301*/ 		push((char*) NULL),
/*301*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*301*/ 		push((char*) NULL),
/*302*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*302*/ 		(RECORD*) pop()
/*302*/ 	);
/*302*/ 	break;

/*302*/ 	case 71:
/*303*/ 	if( (Expressions_allow_type_hinting && ((Globals_php_ver == 4))) ){
/*304*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"type hinting not allowed (PHP 5)");
/*306*/ 	}
/*306*/ 	if( !Expressions_allow_type_hinting ){
/*307*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"invalid type `", Scanner_s, m2runtime_CHR(39), 1));
/*309*/ 	}
/*309*/ 	Scanner_ReadSym();
/*310*/ 	return (
/*310*/ 		push((char*) alloc_RECORD(24, 2)),
/*310*/ 		*(int*) (tos()+16) = 9,
/*310*/ 		*(int*) (tos()+20) = 1,
/*310*/ 		push((char*) NULL),
/*310*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*310*/ 		push((char*) NULL),
/*311*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*311*/ 		(RECORD*) pop()
/*311*/ 	);
/*311*/ 	break;

/*311*/ 	case 145:
/*312*/ 	Expressions_class = Search_SearchClass(Scanner_s, TRUE);
/*313*/ 	if( Expressions_class == NULL ){
/*315*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"undefined identifier `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' in PHPLint meta-code", 1));
/*316*/ 		Scanner_ReadSym();
/*317*/ 		return (
/*317*/ 			push((char*) alloc_RECORD(24, 2)),
/*317*/ 			*(int*) (tos()+16) = 9,
/*317*/ 			*(int*) (tos()+20) = 1,
/*317*/ 			push((char*) NULL),
/*317*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*317*/ 			push((char*) NULL),
/*318*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*319*/ 			(RECORD*) pop()
/*319*/ 		);
/*319*/ 	} else {
/*319*/ 		Accounting_AccountClass(Expressions_class);
/*320*/ 		Scanner_ReadSym();
/*321*/ 		return (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_class, 24, Expressions_0err_entry_get, 53);
/*323*/ 	}
/*323*/ 	break;

/*323*/ 	case 29:
/*324*/ 	if( Expressions_allow_type_hinting ){
/*325*/ 		if( (Globals_php_ver == 4) ){
/*326*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"type hinting not allowed (PHP 5)");
/*329*/ 		}
/*329*/ 	} else {
/*329*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"invalid type `", Scanner_s, m2runtime_CHR(39), 1));
/*331*/ 	}
/*331*/ 	Expressions_class = Search_SearchClass(Scanner_s, TRUE);
/*332*/ 	if( Expressions_class == NULL ){
/*334*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"undefined class `", Scanner_s, m2runtime_CHR(39), 1));
/*335*/ 		Scanner_ReadSym();
/*336*/ 		return (
/*336*/ 			push((char*) alloc_RECORD(24, 2)),
/*336*/ 			*(int*) (tos()+16) = 9,
/*336*/ 			*(int*) (tos()+20) = 1,
/*336*/ 			push((char*) NULL),
/*336*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*336*/ 			push((char*) NULL),
/*337*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*338*/ 			(RECORD*) pop()
/*338*/ 		);
/*338*/ 	} else {
/*338*/ 		Scanner_ReadSym();
/*339*/ 		return (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_class, 24, Expressions_0err_entry_get, 54);
/*341*/ 	}
/*341*/ 	break;

/*341*/ 	case 103:
/*341*/ 	case 167:
/*342*/ 	if( (((Scanner_sym == 103)) && ((((Globals_php_ver == 4)) || !Expressions_allow_type_hinting))) ){
/*344*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"`self': type hinting not allowed");
/*346*/ 	}
/*346*/ 	if( Globals_curr_class == NULL ){
/*347*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"`self': not inside a class");
/*348*/ 		return NULL;
/*350*/ 	}
/*350*/ 	Scanner_ReadSym();
/*351*/ 	return (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 24, Expressions_0err_entry_get, 55);
/*352*/ 	break;

/*352*/ 	case 104:
/*352*/ 	case 168:
/*353*/ 	if( (((Scanner_sym == 104)) && ((((Globals_php_ver == 4)) || !Expressions_allow_type_hinting))) ){
/*355*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"`parent': type hinting not allowed");
/*357*/ 	}
/*357*/ 	if( Globals_curr_class == NULL ){
/*358*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"`parent': not inside a class");
/*359*/ 		return NULL;
/*361*/ 	}
/*361*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 16, Expressions_0err_entry_get, 56) == NULL ){
/*362*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"`parent': no parent class");
/*363*/ 		return NULL;
/*365*/ 	}
/*365*/ 	Scanner_ReadSym();
/*366*/ 	return (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 16, Expressions_0err_entry_get, 57), 24, Expressions_0err_entry_get, 58);
/*368*/ 	break;

/*368*/ 	default:
/*368*/ 	return NULL;
/*371*/ 	}
/*371*/ 	m2runtime_missing_return(Expressions_0err_entry_get, 59);
/*371*/ 	return NULL;
/*374*/ }


/*379*/ int
/*379*/ Expressions_LhsMatchRhs(RECORD *Expressions_lhs, RECORD *Expressions_rhs)
/*379*/ {

/*381*/ 	int
/*381*/ 	Expressions_MatchArray(int Expressions_li, RECORD *Expressions_le, int Expressions_ri, RECORD *Expressions_re)
/*381*/ 	{
/*383*/ 		int Expressions_idx = 0;
/*384*/ 		Expressions_idx = 0;
/*385*/ 		switch(Expressions_li){

/*386*/ 		case 1:
/*387*/ 		break;

/*387*/ 		case 3:
/*388*/ 		switch(Expressions_ri){

/*389*/ 		case 1:
/*389*/ 		Expressions_idx = 1;
/*390*/ 		break;

/*390*/ 		case 3:
/*390*/ 		Expressions_idx = 0;
/*391*/ 		break;

/*391*/ 		case 5:
/*391*/ 		return 2;
/*392*/ 		break;

/*392*/ 		case 7:
/*392*/ 		return 2;
/*394*/ 		break;

/*394*/ 		default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 60);
/*394*/ 		}
/*394*/ 		break;

/*394*/ 		case 5:
/*395*/ 		switch(Expressions_ri){

/*396*/ 		case 1:
/*396*/ 		Expressions_idx = 1;
/*397*/ 		break;

/*397*/ 		case 3:
/*397*/ 		return 2;
/*398*/ 		break;

/*398*/ 		case 5:
/*398*/ 		Expressions_idx = 0;
/*399*/ 		break;

/*399*/ 		case 7:
/*399*/ 		return 2;
/*401*/ 		break;

/*401*/ 		default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 61);
/*401*/ 		}
/*401*/ 		break;

/*401*/ 		case 7:
/*402*/ 		Expressions_idx = 0;
/*404*/ 		break;

/*404*/ 		default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 62);
/*406*/ 		}
/*406*/ 		if( Expressions_le == NULL ){
/*407*/ 			return m2_max(Expressions_idx, 0);
/*408*/ 		} else if( Expressions_re == NULL ){
/*409*/ 			return m2_max(Expressions_idx, 1);
/*411*/ 		} else {
/*411*/ 			return m2_max(Expressions_idx, Expressions_LhsMatchRhs(Expressions_le, Expressions_re));
/*414*/ 		}
/*414*/ 		m2runtime_missing_return(Expressions_0err_entry_get, 63);
/*414*/ 		return 0;
/*416*/ 	}

/*416*/ 	if( Expressions_lhs == NULL ){
/*417*/ 		if( ((Expressions_rhs != NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 64) == 1))) ){
/*418*/ 			return 2;
/*420*/ 		} else {
/*420*/ 			return 1;
/*423*/ 		}
/*423*/ 	}
/*423*/ 	if( Expressions_rhs == NULL ){
/*424*/ 		if( ((Expressions_lhs != NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_lhs, 16, Expressions_0err_entry_get, 65) == 1))) ){
/*425*/ 			return 2;
/*427*/ 		} else {
/*427*/ 			return 1;
/*430*/ 		}
/*430*/ 	}
/*430*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_lhs, 16, Expressions_0err_entry_get, 66)){

/*431*/ 	case 0:
/*432*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 67)){

/*433*/ 	case 0:
/*433*/ 	return 0;
/*434*/ 	break;

/*434*/ 	case 5:
/*434*/ 	case 6:
/*434*/ 	case 7:
/*434*/ 	case 8:
/*434*/ 	case 9:
/*434*/ 	return 1;
/*435*/ 	break;

/*435*/ 	default:
/*435*/ 	return 2;
/*437*/ 	}
/*437*/ 	break;

/*437*/ 	case 1:
/*437*/ 	return 2;
/*438*/ 	break;

/*438*/ 	case 2:
/*439*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 68)){

/*440*/ 	case 2:
/*440*/ 	return 0;
/*441*/ 	break;

/*441*/ 	case 7:
/*441*/ 	return 1;
/*442*/ 	break;

/*442*/ 	default:
/*442*/ 	return 2;
/*444*/ 	}
/*444*/ 	break;

/*444*/ 	case 3:
/*445*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 69)){

/*446*/ 	case 3:
/*446*/ 	return 0;
/*447*/ 	break;

/*447*/ 	case 7:
/*447*/ 	return 1;
/*448*/ 	break;

/*448*/ 	default:
/*448*/ 	return 2;
/*450*/ 	}
/*450*/ 	break;

/*450*/ 	case 4:
/*451*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 70)){

/*452*/ 	case 3:
/*452*/ 	case 4:
/*452*/ 	return 0;
/*453*/ 	break;

/*453*/ 	case 7:
/*453*/ 	return 1;
/*454*/ 	break;

/*454*/ 	default:
/*454*/ 	return 2;
/*456*/ 	}
/*456*/ 	break;

/*456*/ 	case 5:
/*457*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 71)){

/*458*/ 	case 0:
/*458*/ 	case 5:
/*458*/ 	return 0;
/*459*/ 	break;

/*459*/ 	case 7:
/*459*/ 	return 1;
/*460*/ 	break;

/*460*/ 	default:
/*460*/ 	return 2;
/*462*/ 	}
/*462*/ 	break;

/*462*/ 	case 6:
/*463*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 72)){

/*464*/ 	case 0:
/*464*/ 	return 0;
/*465*/ 	break;

/*465*/ 	case 7:
/*465*/ 	return 1;
/*466*/ 	break;

/*466*/ 	case 6:
/*466*/ 	return Expressions_MatchArray( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_lhs, 20, Expressions_0err_entry_get, 73), (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_lhs, 8, Expressions_0err_entry_get, 74),  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 20, Expressions_0err_entry_get, 75), (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 8, Expressions_0err_entry_get, 76));
/*468*/ 	break;

/*468*/ 	default:
/*468*/ 	return 2;
/*470*/ 	}
/*470*/ 	break;

/*470*/ 	case 7:
/*471*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 77) == 1) ){
/*472*/ 		return 2;
/*474*/ 	} else {
/*474*/ 		return 0;
/*476*/ 	}
/*476*/ 	break;

/*476*/ 	case 8:
/*477*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 78)){

/*478*/ 	case 0:
/*478*/ 	case 8:
/*478*/ 	return 0;
/*479*/ 	break;

/*479*/ 	case 7:
/*479*/ 	return 1;
/*480*/ 	break;

/*480*/ 	default:
/*480*/ 	return 2;
/*482*/ 	}
/*482*/ 	break;

/*482*/ 	case 9:
/*483*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 16, Expressions_0err_entry_get, 79)){

/*484*/ 	case 0:
/*484*/ 	return 0;
/*485*/ 	break;

/*485*/ 	case 7:
/*485*/ 	return 1;
/*486*/ 	break;

/*486*/ 	case 9:
/*487*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_lhs, 12, Expressions_0err_entry_get, 80) == NULL ){
/*488*/ 		return 0;
/*489*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 12, Expressions_0err_entry_get, 81) == NULL ){
/*490*/ 		return 1;
/*491*/ 	} else if( Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_rhs, 12, Expressions_0err_entry_get, 82), (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_lhs, 12, Expressions_0err_entry_get, 83)) ){
/*492*/ 		return 0;
/*494*/ 	} else {
/*494*/ 		return 2;
/*496*/ 	}
/*496*/ 	break;

/*496*/ 	default:
/*496*/ 	return 2;
/*499*/ 	}
/*499*/ 	break;

/*499*/ 	default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 84);
/*499*/ 	}
/*499*/ 	return 0;
/*503*/ }

 RECORD *
 Expressions_ParseClassMethodCall(RECORD *, int, STRING *);

/*518*/ void
/*518*/ Expressions_DereferenceLHS(RECORD *Expressions_expect, RECORD **Expressions_found)
/*518*/ {
/*519*/ 	RECORD * Expressions_r = NULL;
/*520*/ 	RECORD * Expressions_unk = NULL;
/*520*/ 	RECORD * Expressions_t = NULL;
/*521*/ 	STRING * Expressions_id = NULL;
/*522*/ 	RECORD * Expressions_cl = NULL;
/*524*/ 	RECORD * Expressions_p = NULL;
/*526*/ 	if( (Scanner_sym == 14) ){
/*528*/ 		if( *Expressions_found == NULL ){
/*529*/ 			*Expressions_found = (
/*529*/ 				push((char*) alloc_RECORD(24, 2)),
/*529*/ 				*(int*) (tos()+16) = 6,
/*529*/ 				*(int*) (tos()+20) = 1,
/*529*/ 				push((char*) NULL),
/*529*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*529*/ 				push((char*) NULL),
/*530*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*530*/ 				(RECORD*) pop()
/*530*/ 			);
/*530*/ 			Scanner_ReadSym();
/*531*/ 			if( (Scanner_sym == 15) ){
/*532*/ 				*(int *)m2runtime_dereference_lhs_RECORD(Expressions_found, 24, 2, 20, Expressions_0err_entry_get, 85) = 3;
/*533*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(Expressions_found, 24, 2, 8, Expressions_0err_entry_get, 86) = Expressions_expect;
/*534*/ 				Scanner_ReadSym();
/*536*/ 				return ;
/*537*/ 			}
/*537*/ 			Expressions_r = Expressions_ParseExpr();
/*538*/ 			if( Expressions_r == NULL ){
/*540*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 87) == Globals_int_type ){
/*541*/ 				*(int *)m2runtime_dereference_lhs_RECORD(Expressions_found, 24, 2, 20, Expressions_0err_entry_get, 88) = 3;
/*542*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 89) == Globals_string_type ){
/*543*/ 				*(int *)m2runtime_dereference_lhs_RECORD(Expressions_found, 24, 2, 20, Expressions_0err_entry_get, 90) = 5;
/*545*/ 			} else {
/*545*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"invalid array index of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 91)), 1));
/*547*/ 			}
/*547*/ 			Scanner_Expect(15, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `]'");
/*548*/ 			Scanner_ReadSym();
/*549*/ 			Expressions_DereferenceLHS(Expressions_expect, (RECORD **)m2runtime_dereference_lhs_RECORD(Expressions_found, 24, 2, 8, Expressions_0err_entry_get, 92));
/*551*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 16, Expressions_0err_entry_get, 93) == 6) ){
/*552*/ 			Scanner_ReadSym();
/*553*/ 			if( (Scanner_sym == 15) ){
/*554*/ 				switch( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 20, Expressions_0err_entry_get, 94)){

/*555*/ 				case 1:
/*556*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)"`[]' operator applied to an array of undefined index type");
/*557*/ 				break;

/*557*/ 				case 3:
/*558*/ 				break;

/*558*/ 				case 5:
/*559*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"applying the `[]' operator to array ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"with index of type string", 1));
/*561*/ 				break;

/*561*/ 				case 7:
/*562*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"applying the `[]' operator to array ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"whose index can be either int and string", 1));
/*565*/ 				break;

/*565*/ 				default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 95);
/*565*/ 				}
/*565*/ 				Scanner_ReadSym();
/*566*/ 				*Expressions_found = (RECORD *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 8, Expressions_0err_entry_get, 96);
/*567*/ 				switch(Expressions_LhsMatchRhs(*Expressions_found, Expressions_expect)){

/*568*/ 				case 0:
/*569*/ 				break;

/*569*/ 				case 1:
/*570*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"found ", Types_TypeToString(*Expressions_found), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)", expected ", Types_TypeToString(Expressions_expect), 1));
/*572*/ 				break;

/*572*/ 				case 2:
/*573*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"found ", Types_TypeToString(*Expressions_found), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)", expected ", Types_TypeToString(Expressions_expect), 1));
/*576*/ 				break;

/*576*/ 				default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 97);
/*577*/ 				}
/*577*/ 				return ;
/*578*/ 			} else {
/*578*/ 				Expressions_r = Expressions_ParseExpr();
/*579*/ 				if( Expressions_r == NULL ){
/*581*/ 				} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 98) == Globals_int_type ){
/*582*/ 					if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 20, Expressions_0err_entry_get, 99) == 5) ){
/*583*/ 						Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"invalid index of type int, expected string");
/*585*/ 					}
/*585*/ 				} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 100) == Globals_string_type ){
/*586*/ 					if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 20, Expressions_0err_entry_get, 101) == 3) ){
/*587*/ 						Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"invalid index of type string, expected int");
/*590*/ 					}
/*590*/ 				} else {
/*590*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"invalid array index of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 102)), 1));
/*592*/ 				}
/*592*/ 				Scanner_Expect(15, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `]'");
/*593*/ 				Scanner_ReadSym();
/*594*/ 				Expressions_DereferenceLHS(Expressions_expect, (RECORD **)m2runtime_dereference_lhs_RECORD(Expressions_found, 24, 2, 8, Expressions_0err_entry_get, 103));
/*598*/ 			}
/*598*/ 		} else {
/*598*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"can't check usage of `[' applied to a value of type ", Types_TypeToString(*Expressions_found), 1));
/*601*/ 			Scanner_ReadSym();
/*602*/ 			if( (Scanner_sym == 15) ){
/*603*/ 				Scanner_ReadSym();
/*605*/ 				return ;
/*606*/ 			}
/*606*/ 			Expressions_r = Expressions_ParseExpr();
/*607*/ 			Scanner_Expect(15, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `]'");
/*608*/ 			Scanner_ReadSym();
/*609*/ 			Expressions_t = NULL;
/*610*/ 			Expressions_DereferenceLHS(Expressions_expect, &Expressions_t);
/*614*/ 		}
/*614*/ 	} else if( (Scanner_sym == 61) ){
/*615*/ 		if( *Expressions_found == NULL ){
/*616*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"`->' operator applied to a value of type unknown");
/*617*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 16, Expressions_0err_entry_get, 104) != 9) ){
/*618*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"`->' operator applied to a value of type ", Types_TypeToString(*Expressions_found), 1));
/*620*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 12, Expressions_0err_entry_get, 105) == NULL ){
/*621*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)"`->' operator applied to an object of unknown class");
/*623*/ 		}
/*623*/ 		if( ((*Expressions_found != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 12, Expressions_0err_entry_get, 106) != NULL)) ){
/*624*/ 			Scanner_ReadSym();
/*625*/ 			if( (Scanner_sym == 29) ){
/*627*/ 			} else if( (Scanner_sym == 20) ){
/*628*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\160,\0,\0,\0)"expected property name or method name after `->'. Variable-name properties/methods are not supported by PHPLint.");
/*629*/ 				Scanner_s = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"UNKNOWN_", Scanner_s, 1);
/*631*/ 			} else {
/*631*/ 				Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"expected property name or method name after `->'");
/*633*/ 			}
/*633*/ 			Expressions_id = Scanner_s;
/*634*/ 			Scanner_ReadSym();
/*635*/ 			if( (Scanner_sym == 12) ){
/*636*/ 				Expressions_cl = (RECORD *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 12, Expressions_0err_entry_get, 107);
				Expressions_t = Expressions_ParseClassMethodCall(Expressions_cl, FALSE, Expressions_id);
/*638*/ 				if( (((Globals_php_ver == 4)) && ((Scanner_sym == 61))) ){
/*639*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"cannot dereference object returned by method.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)" That's a limitation of PHP 4.", 1));
/*643*/ 				}
/*643*/ 			} else {
/*643*/ 				Expressions_ResolveClassProperty((RECORD *)m2runtime_dereference_rhs_RECORD(*Expressions_found, 12, Expressions_0err_entry_get, 108), FALSE, Expressions_id, &Expressions_cl, &Expressions_p);
/*644*/ 				if( Expressions_p == NULL ){
/*645*/ 					Expressions_t = NULL;
/*647*/ 				} else {
/*647*/ 					Expressions_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_p, 12, Expressions_0err_entry_get, 109);
/*650*/ 				}
/*650*/ 			}
/*650*/ 			Expressions_DereferenceLHS(Expressions_expect, &Expressions_t);
/*653*/ 		} else {
/*653*/ 			Scanner_ReadSym();
/*654*/ 			if( (Scanner_sym == 20) ){
/*655*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\160,\0,\0,\0)"expected property name or method name after `->'. Variable-name properties/methods are not supported by PHPLint.");
/*657*/ 			} else {
/*657*/ 				Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"expected property name or method name after `->'");
/*660*/ 			}
/*660*/ 			Scanner_ReadSym();
/*661*/ 			if( (Scanner_sym == 12) ){
/*662*/ 				Expressions_SkipFuncCall();
/*663*/ 				if( (((Globals_php_ver == 4)) && ((Scanner_sym == 61))) ){
/*664*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"cannot dereference object returned by method.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)" That's a limitation of the PHP 4.", 1));
/*668*/ 				}
/*668*/ 			}
/*668*/ 			Expressions_DereferenceLHS(Expressions_expect, &Expressions_unk);
/*671*/ 		}
/*671*/ 	} else if( *Expressions_found == NULL ){
/*672*/ 		*Expressions_found = Expressions_expect;
/*673*/ 	} else if( Expressions_expect == NULL ){
/*676*/ 	} else {
/*676*/ 		switch(Expressions_LhsMatchRhs(*Expressions_found, Expressions_expect)){

/*677*/ 		case 0:
/*678*/ 		break;

/*678*/ 		case 1:
/*679*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"invalid type ", Types_TypeToString(Expressions_expect), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" assigned to ", Types_TypeToString(*Expressions_found), 1));
/*681*/ 		break;

/*681*/ 		case 2:
/*682*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"invalid type ", Types_TypeToString(Expressions_expect), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" assigned to ", Types_TypeToString(*Expressions_found), 1));
/*685*/ 		break;

/*685*/ 		default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 110);
/*686*/ 		}
/*688*/ 	}
/*690*/ }


/*706*/ void
/*706*/ Expressions_ParseLHS(RECORD *Expressions_expect)
/*706*/ {
/*707*/ 	RECORD * Expressions_v = NULL;
/*708*/ 	RECORD * Expressions_res_cl = NULL;
/*708*/ 	RECORD * Expressions_cl = NULL;
/*709*/ 	RECORD * Expressions_res_p = NULL;
/*711*/ 	RECORD * Expressions_t = NULL;
/*712*/ 	if( (Scanner_sym == 20) ){
/*713*/ 		Expressions_v = Search_SearchVar(Scanner_s, Globals_scope);
/*714*/ 		Scanner_ReadSym();
/*715*/ 		if( (((Scanner_sym == 14)) || ((Scanner_sym == 61))) ){
/*716*/ 			if( Expressions_v == NULL ){
/*717*/ 				Accounting_AccountVarLHS(Scanner_s, FALSE);
/*718*/ 				Expressions_v = Search_SearchVar(Scanner_s, Globals_scope);
/*720*/ 			} else {
/*720*/ 				Accounting_AccountVarRHS2(Expressions_v);
/*724*/ 			}
/*724*/ 		} else {
/*724*/ 			if( Expressions_v == NULL ){
/*725*/ 				Accounting_AccountVarLHS(Scanner_s, FALSE);
/*726*/ 				Expressions_v = Search_SearchVar(Scanner_s, Globals_scope);
/*728*/ 			} else {
/*728*/ 				Accounting_AccountVarLHS2(Expressions_v);
/*731*/ 			}
/*731*/ 		}
/*731*/ 		Expressions_DereferenceLHS(Expressions_expect, (RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_v, 52, 7, 20, Expressions_0err_entry_get, 111));
/*734*/ 	} else if( (Scanner_sym == 29) ){
/*735*/ 		Expressions_cl = Search_SearchClass(Scanner_s, TRUE);
/*736*/ 		if( Expressions_cl == NULL ){
/*737*/ 			Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"invalid syntax in LHS. Undeclared class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"'?", 1));
/*739*/ 		}
/*739*/ 		Scanner_ReadSym();
/*740*/ 		Scanner_Expect(19, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"expected `::'");
/*741*/ 		Scanner_ReadSym();
/*742*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"expected property");
/*743*/ 		Expressions_ResolveClassProperty(Expressions_cl, TRUE, Scanner_s, &Expressions_res_cl, &Expressions_res_p);
/*744*/ 		if( Expressions_res_p == NULL ){
/*745*/ 			Scanner_ReadSym();
/*746*/ 			Expressions_DereferenceLHS(Expressions_expect, &Expressions_t);
/*748*/ 		} else {
/*748*/ 			Scanner_ReadSym();
/*749*/ 			Expressions_DereferenceLHS(Expressions_expect, (RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_res_p, 48, 6, 12, Expressions_0err_entry_get, 112));
/*753*/ 		}
/*753*/ 	} else if( (Scanner_sym == 103) ){
/*754*/ 		if( (Globals_php_ver == 4) ){
/*755*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"invalid `self::' (PHP 5)");
/*757*/ 		}
/*757*/ 		Expressions_cl = Globals_curr_class;
/*758*/ 		if( Expressions_cl == NULL ){
/*759*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"`self::': not inside a class");
/*761*/ 		}
/*761*/ 		Scanner_ReadSym();
/*762*/ 		Scanner_Expect(19, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"expected `::'");
/*763*/ 		Scanner_ReadSym();
/*764*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"expected property");
/*765*/ 		Expressions_ResolveClassProperty(Expressions_cl, TRUE, Scanner_s, &Expressions_res_cl, &Expressions_res_p);
/*766*/ 		if( Expressions_res_p == NULL ){
/*767*/ 			Scanner_ReadSym();
/*768*/ 			Expressions_DereferenceLHS(Expressions_expect, &Expressions_t);
/*770*/ 		} else {
/*770*/ 			Scanner_ReadSym();
/*771*/ 			Expressions_DereferenceLHS(Expressions_expect, (RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_res_p, 48, 6, 12, Expressions_0err_entry_get, 113));
/*775*/ 		}
/*775*/ 	} else if( (Scanner_sym == 104) ){
/*776*/ 		if( (Globals_php_ver == 4) ){
/*777*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"invalid `parent::' (PHP 5)");
/*779*/ 		}
/*779*/ 		Expressions_cl = Globals_curr_class;
/*780*/ 		if( Expressions_cl == NULL ){
/*781*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"`parent::': not inside a class");
/*783*/ 		}
/*783*/ 		Expressions_cl = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_cl, 16, Expressions_0err_entry_get, 114);
/*784*/ 		if( Expressions_cl == NULL ){
/*785*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"`parent::': no parent class");
/*787*/ 		}
/*787*/ 		Scanner_ReadSym();
/*788*/ 		Scanner_Expect(19, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"expected `::'");
/*789*/ 		Scanner_ReadSym();
/*790*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected class property");
/*791*/ 		Expressions_ResolveClassProperty(Expressions_cl, TRUE, Scanner_s, &Expressions_res_cl, &Expressions_res_p);
/*792*/ 		if( Expressions_res_p == NULL ){
/*793*/ 			Scanner_ReadSym();
/*794*/ 			Expressions_DereferenceLHS(Expressions_expect, &Expressions_t);
/*796*/ 		} else {
/*796*/ 			Scanner_ReadSym();
/*797*/ 			Expressions_DereferenceLHS(Expressions_expect, (RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_res_p, 48, 6, 12, Expressions_0err_entry_get, 115));
/*801*/ 		}
/*801*/ 	} else {
/*801*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"invalid syntax in LHS");
/*805*/ 	}
/*807*/ }


/*814*/ void
/*814*/ Expressions_ParseArgsListCall(int Expressions_guess, STRING *Expressions_n, RECORD *Expressions_sign, RECORD *Expressions_decl_in)
/*814*/ {

/*820*/ 	void
/*820*/ 	Expressions_CheckActualArgument(STRING *Expressions_n, int Expressions_i, RECORD *Expressions_a, RECORD *Expressions_r)
/*820*/ 	{

/*822*/ 		STRING *
/*822*/ 		Expressions_base(void)
/*822*/ 		{
/*822*/ 			return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"calling `", Expressions_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"()' declared in ", Scanner_reference(Expressions_decl_in), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)", argument no. ", m2runtime_itos(((Expressions_i + 1))), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", 1);
/*827*/ 		}

/*829*/ 		RECORD * Expressions_b = NULL;
/*829*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_a, 12, Expressions_0err_entry_get, 116) == NULL ){
/*832*/ 			return ;
/*834*/ 		}
/*834*/ 		if( Expressions_r == NULL ){
/*837*/ 			return ;
/*839*/ 		}
/*839*/ 		Expressions_b = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 117);
/*840*/ 		switch(Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_a, 12, Expressions_0err_entry_get, 118), Expressions_b)){

/*841*/ 		case 0:
/*842*/ 		break;

/*842*/ 		case 1:
/*843*/ 		Scanner_Warning(m2runtime_concat_STRING(0, Expressions_base(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"found type `", Types_TypeToString(Expressions_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"', required type `", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_a, 12, Expressions_0err_entry_get, 119)), m2runtime_CHR(39), 1));
/*845*/ 		break;

/*845*/ 		case 2:
/*846*/ 		Scanner_Error(m2runtime_concat_STRING(0, Expressions_base(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"found type `", Types_TypeToString(Expressions_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"', required type `", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_a, 12, Expressions_0err_entry_get, 120)), m2runtime_CHR(39), 1));
/*849*/ 		break;

/*849*/ 		default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 121);
/*850*/ 		}
/*852*/ 	}

/*853*/ 	int Expressions_i = 0;
/*854*/ 	RECORD * Expressions_r = NULL;
/*856*/ 	RECORD * Expressions_a = NULL;
/*856*/ 	Scanner_ReadSym();
/*858*/ 	if( (Scanner_sym == 13) ){
/*859*/ 		Scanner_ReadSym();
/*860*/ 		if( (!Expressions_guess && (( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_sign, 20, Expressions_0err_entry_get, 122) > 0))) ){
/*861*/ 			Scanner_Error(m2runtime_concat_STRING(0, m2runtime_CHR(96), Expressions_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"()' declared in ", Scanner_reference(Expressions_decl_in), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)" requires arguments", 1));
/*864*/ 		}
/*864*/ 		return ;
/*865*/ 	}
/*865*/ 	Expressions_i = 0;
/*867*/ 	do{
/*867*/ 		if( Expressions_guess ){
/*868*/ 			Expressions_r = Expressions_ParseExpr();
/*869*/ 			Expressions_a = NULL;
/*870*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Expressions_a, 24, 3, 8, Expressions_0err_entry_get, 123) = m2runtime_CHR(63);
/*871*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Expressions_a, 24, 3, 20, Expressions_0err_entry_get, 124) = FALSE;
/*872*/ 			if( Expressions_r == NULL ){
/*873*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_a, 24, 3, 12, Expressions_0err_entry_get, 125) = NULL;
/*875*/ 			} else {
/*875*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_a, 24, 3, 12, Expressions_0err_entry_get, 126) = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 127);
/*877*/ 			}
/*877*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Expressions_sign, 28, 2, 12, Expressions_0err_entry_get, 128), 4, 1, Expressions_0err_entry_get, 129) = Expressions_a;
/*878*/ 			m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Expressions_sign, 28, 2, 20, Expressions_0err_entry_get, 130), 1);
/*879*/ 		} else if( (Expressions_i < m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Expressions_sign, 12, Expressions_0err_entry_get, 131))) ){
/*880*/ 			Expressions_a = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Expressions_sign, 12, Expressions_0err_entry_get, 132), Expressions_i, Expressions_0err_entry_get, 133);
/*881*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_a, 20, Expressions_0err_entry_get, 134) ){
/*882*/ 				Expressions_ParseLHS((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_a, 12, Expressions_0err_entry_get, 135));
/*884*/ 			} else {
/*884*/ 				Expressions_r = Expressions_ParseExpr();
/*885*/ 				Expressions_CheckActualArgument(Expressions_n, Expressions_i, Expressions_a, Expressions_r);
/*888*/ 			}
/*888*/ 		} else {
/*888*/ 			if( (((Expressions_i == m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Expressions_sign, 12, Expressions_0err_entry_get, 136)))) && ! *(int *)m2runtime_dereference_rhs_RECORD(Expressions_sign, 24, Expressions_0err_entry_get, 137)) ){
/*889*/ 				Scanner_Error(m2runtime_concat_STRING(0, m2runtime_CHR(96), Expressions_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"()' declared in ", Scanner_reference(Expressions_decl_in), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)": too many arguments", 1));
/*891*/ 			}
/*891*/ 			Expressions_r = Expressions_ParseExpr();
/*893*/ 		}
/*893*/ 		if( (Scanner_sym == 16) ){
/*894*/ 			Scanner_ReadSym();
/*895*/ 			m2_inc(&Expressions_i, 1);
/*898*/ 		} else {
/*899*/ 			goto m2runtime_loop_1;
/*900*/ 		}
/*900*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*900*/ 	if( Expressions_guess ){
/*901*/ 		Scanner_Expect(13, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"expected ')'  or ',' in argument list of unknown `", Expressions_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"()'", 1));
/*903*/ 		Scanner_ReadSym();
/*905*/ 	} else {
/*905*/ 		if( (Scanner_sym == 13) ){
/*906*/ 			if( ((Expressions_i + 1) <  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_sign, 20, Expressions_0err_entry_get, 138)) ){
/*907*/ 				Scanner_Error(m2runtime_concat_STRING(0, m2runtime_CHR(96), Expressions_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"()' declared in ", Scanner_reference(Expressions_decl_in), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)" requires more arguments", 1));
/*909*/ 			}
/*909*/ 			Scanner_ReadSym();
/*911*/ 		} else {
/*911*/ 			Scanner_UnexpectedSymbol();
/*914*/ 		}
/*915*/ 	}
/*917*/ }


/*929*/ RECORD *
/*929*/ Expressions_ParseClassMethodCall(RECORD *Expressions_class, int Expressions_static, STRING *Expressions_name)
/*929*/ {
/*930*/ 	RECORD * Expressions_m = NULL;
/*931*/ 	RECORD * Expressions_sign = NULL;
/*933*/ 	RECORD * Expressions_c2 = NULL;
/*933*/ 	if( Expressions_class == NULL ){
/*934*/ 		Expressions_SkipFuncCall();
/*935*/ 		return NULL;
/*938*/ 	}
/*938*/ 	Expressions_DereferenceClassMethod(Expressions_class, Expressions_static, Expressions_name, &Expressions_c2, &Expressions_m);
/*940*/ 	if( Expressions_m == NULL ){
/*941*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_sign, 28, 2, 8, Expressions_0err_entry_get, 139) = NULL;
/*942*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Expressions_m, 72, 8, 8, Expressions_0err_entry_get, 140) = Expressions_name;
/*943*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Expressions_m, 72, 8, 12, Expressions_0err_entry_get, 141) = str_toupper(Expressions_name);
/*944*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Expressions_m, 72, 8, 48, Expressions_0err_entry_get, 142) = 2;
/*945*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Expressions_m, 72, 8, 52, Expressions_0err_entry_get, 143) = Expressions_static;
/*946*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_m, 72, 8, 16, Expressions_0err_entry_get, 144) = Expressions_sign;
/*947*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_m, 72, 8, 20, Expressions_0err_entry_get, 145) = NULL;
/*948*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_m, 72, 8, 24, Expressions_0err_entry_get, 146) = Scanner_here();
/*949*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Expressions_m, 72, 8, 60, Expressions_0err_entry_get, 147) = 1;
/*951*/ 		Expressions_ParseArgsListCall(TRUE, m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_class, 8, Expressions_0err_entry_get, 148), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Expressions_name, 1), Expressions_sign, (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_m, 20, Expressions_0err_entry_get, 149));
/*952*/ 		Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"guessed signature of the method `", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_class, 8, Expressions_0err_entry_get, 150), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Expressions_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"()' as ", Types_MethodSignatureToString(Expressions_m), 1));
/*955*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Expressions_class, 92, 13, 36, Expressions_0err_entry_get, 151), 4, 1, Expressions_0err_entry_get, 152) = Expressions_m;
/*958*/ 	} else {
/*958*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_m, 16, Expressions_0err_entry_get, 153) == NULL ){
/*960*/ 			Expressions_sign = (
/*961*/ 				push((char*) alloc_RECORD(28, 2)),
/*961*/ 				push((char*) NULL),
/*961*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*962*/ 				*(int*) (tos()+16) = FALSE,
/*963*/ 				*(int*) (tos()+20) = 0,
/*964*/ 				push((char*) NULL),
/*964*/ 				*(ARRAY**) (tosn(1)+12) = (ARRAY*) tos(), pop(),
/*965*/ 				*(int*) (tos()+24) = FALSE,
/*967*/ 				(RECORD*) pop()
/*967*/ 			);
/*967*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_m, 72, 8, 16, Expressions_0err_entry_get, 154) = Expressions_sign;
/*969*/ 		} else {
/*969*/ 			Expressions_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_m, 16, Expressions_0err_entry_get, 155);
/*972*/ 		}
/*972*/ 		Expressions_ParseArgsListCall(FALSE, m2runtime_concat_STRING(0, Classes_pc(Expressions_class, Expressions_c2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_m, 8, Expressions_0err_entry_get, 156), 1), Expressions_sign, (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_m, 20, Expressions_0err_entry_get, 157));
/*975*/ 	}
/*975*/ 	return (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_sign, 8, Expressions_0err_entry_get, 158);
/*979*/ }


/*981*/ int
/*981*/ Expressions_IsAssignOp(int Expressions_sym)
/*981*/ {
/*981*/ 	return (((Expressions_sym == 31)) || ((Expressions_sym == 76)) || ((Expressions_sym == 77)) || ((Expressions_sym == 78)) || ((Expressions_sym == 79)) || ((Expressions_sym == 75)) || ((Expressions_sym == 80)) || ((Expressions_sym == 81)) || ((Expressions_sym == 82)) || ((Expressions_sym == 83)) || ((Expressions_sym == 84)) || ((Expressions_sym == 85)));
/*990*/ }


/*1019*/ RECORD *
/*1019*/ Expressions_Dereference(RECORD **Expressions_t)
/*1019*/ {

/*1024*/ 	RECORD *
/*1024*/ 	Expressions_DereferenceArray(RECORD **Expressions_t)
/*1024*/ 	{
/*1026*/ 		RECORD * Expressions_r = NULL;
/*1026*/ 		if( *Expressions_t == NULL ){
/*1027*/ 			*Expressions_t = (
/*1027*/ 				push((char*) alloc_RECORD(24, 2)),
/*1027*/ 				*(int*) (tos()+16) = 6,
/*1027*/ 				*(int*) (tos()+20) = 1,
/*1027*/ 				push((char*) NULL),
/*1027*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1027*/ 				push((char*) NULL),
/*1028*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*1028*/ 				(RECORD*) pop()
/*1028*/ 			);
/*1028*/ 			Scanner_ReadSym();
/*1029*/ 			if( (Scanner_sym == 15) ){
/*1030*/ 				*(int *)m2runtime_dereference_lhs_RECORD(Expressions_t, 24, 2, 20, Expressions_0err_entry_get, 159) = 3;
/*1031*/ 				Scanner_ReadSym();
/*1032*/ 				Scanner_Expect(31, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"required `=' after the operator `[]'");
/*1033*/ 				return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(Expressions_t, 24, 2, 8, Expressions_0err_entry_get, 160));
/*1036*/ 			}
/*1036*/ 			Expressions_r = Expressions_ParseExpr();
/*1037*/ 			if( Expressions_r == NULL ){
/*1039*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 161) == Globals_int_type ){
/*1040*/ 				*(int *)m2runtime_dereference_lhs_RECORD(Expressions_t, 24, 2, 20, Expressions_0err_entry_get, 162) = 3;
/*1041*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 163) == Globals_string_type ){
/*1042*/ 				*(int *)m2runtime_dereference_lhs_RECORD(Expressions_t, 24, 2, 20, Expressions_0err_entry_get, 164) = 5;
/*1044*/ 			} else {
/*1044*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"invalid array index of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 165)), 1));
/*1046*/ 			}
/*1046*/ 			Scanner_Expect(15, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `]'");
/*1047*/ 			Scanner_ReadSym();
/*1048*/ 			return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(Expressions_t, 24, 2, 8, Expressions_0err_entry_get, 166));
/*1050*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 16, Expressions_0err_entry_get, 167) == 5) ){
/*1051*/ 			Scanner_ReadSym();
/*1052*/ 			if( (Scanner_sym == 15) ){
/*1053*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"undefined last element `[]' operator for a value of type string");
/*1054*/ 				Scanner_ReadSym();
/*1055*/ 				return Globals_string_type;
/*1057*/ 			}
/*1057*/ 			Expressions_r = Expressions_ParseExpr();
/*1058*/ 			if( Expressions_r == NULL ){
/*1060*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 168) == Globals_int_type ){
/*1062*/ 			} else {
/*1062*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"invalid array index of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 169)), 1));
/*1064*/ 			}
/*1064*/ 			Scanner_Expect(15, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `]'");
/*1065*/ 			Scanner_ReadSym();
/*1066*/ 			return Globals_string_type;
/*1068*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 16, Expressions_0err_entry_get, 170) == 6) ){
/*1069*/ 			Scanner_ReadSym();
/*1070*/ 			if( (Scanner_sym == 15) ){
/*1071*/ 				if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 20, Expressions_0err_entry_get, 171) == 1) ){
/*1072*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"applying the `[]' operator to array ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"of undefined index type", 1));
/*1074*/ 				} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 20, Expressions_0err_entry_get, 172) == 5) ){
/*1075*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"applying the `[]' operator to array ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"with index of type string", 1));
/*1078*/ 				}
/*1078*/ 				Scanner_ReadSym();
/*1079*/ 				Scanner_Expect(31, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"required `=' after the operator `[]'");
/*1080*/ 				return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(Expressions_t, 24, 2, 8, Expressions_0err_entry_get, 173));
/*1082*/ 			}
/*1082*/ 			Expressions_r = Expressions_ParseExpr();
/*1083*/ 			if( Expressions_r == NULL ){
/*1085*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 174) == Globals_int_type ){
/*1086*/ 				if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 20, Expressions_0err_entry_get, 175) == 5) ){
/*1087*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"invalid index of type int, expected string");
/*1089*/ 				}
/*1089*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 176) == Globals_string_type ){
/*1090*/ 				if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 20, Expressions_0err_entry_get, 177) == 3) ){
/*1091*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"invalid index of type string, expected int");
/*1094*/ 				}
/*1094*/ 			} else {
/*1094*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"invalid array index of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 178)), 1));
/*1096*/ 			}
/*1096*/ 			Scanner_Expect(15, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `]'");
/*1097*/ 			Scanner_ReadSym();
/*1098*/ 			return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(Expressions_t, 24, 2, 8, Expressions_0err_entry_get, 179));
/*1101*/ 		} else {
/*1101*/ 			if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 16, Expressions_0err_entry_get, 180) == 7) ){
/*1102*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)"can't check usage of `[' applied to a value of type mixed");
/*1104*/ 			} else {
/*1104*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"`[' operator not applicable to a value of type ", Types_TypeToString(*Expressions_t), 1));
/*1107*/ 			}
/*1107*/ 			Scanner_ReadSym();
/*1108*/ 			if( (Scanner_sym == 15) ){
/*1109*/ 				Scanner_ReadSym();
/*1110*/ 				Scanner_Expect(31, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"required `=' after the operator `[]'");
/*1111*/ 				*Expressions_t = (
/*1111*/ 					push((char*) alloc_RECORD(24, 2)),
/*1111*/ 					*(int*) (tos()+16) = 6,
/*1111*/ 					*(int*) (tos()+20) = 1,
/*1111*/ 					push((char*) NULL),
/*1111*/ 					*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1111*/ 					push((char*) NULL),
/*1112*/ 					*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*1112*/ 					(RECORD*) pop()
/*1112*/ 				);
/*1112*/ 				return Expressions_Dereference(Expressions_t);
/*1114*/ 			}
/*1114*/ 			Expressions_r = Expressions_ParseExpr();
/*1115*/ 			Scanner_Expect(15, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `]'");
/*1116*/ 			Scanner_ReadSym();
/*1117*/ 			return Expressions_Dereference(Expressions_t);
/*1121*/ 		}
/*1121*/ 		m2runtime_missing_return(Expressions_0err_entry_get, 181);
/*1121*/ 		return NULL;
/*1124*/ 	}

/*1125*/ 	STRING * Expressions_id = NULL;
/*1126*/ 	RECORD * Expressions_class = NULL;
/*1127*/ 	RECORD * Expressions_p = NULL;
/*1128*/ 	RECORD * Expressions_r = NULL;
/*1129*/ 	RECORD * Expressions_t2 = NULL;
/*1129*/ 	RECORD * Expressions_unk = NULL;
/*1130*/ 	int Expressions_op = 0;
/*1131*/ 	int Expressions_left_inval = 0;
/*1133*/ 	RECORD * Expressions_v = NULL;
/*1133*/ 	if( (Scanner_sym == 14) ){
/*1134*/ 		return Expressions_DereferenceArray(Expressions_t);
/*1136*/ 	} else if( (Scanner_sym == 10) ){
/*1137*/ 		if( ((*Expressions_t == NULL) || (( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 16, Expressions_0err_entry_get, 182) != 5))) ){
/*1138*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"`{' operator applied to a value of type ", Types_TypeToString(*Expressions_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)". Expected a string.", 1));
/*1141*/ 		} else {
/*1141*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\166,\0,\0,\0)"using deprecated character selector operator `{'. Support for this operator deprecated since PHP 5.1. Use `[' instead.");
/*1143*/ 		}
/*1143*/ 		Scanner_ReadSym();
/*1144*/ 		Expressions_r = Expressions_ParseExpr();
/*1145*/ 		if( Expressions_r == NULL ){
/*1148*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 183) != Globals_int_type ){
/*1149*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"invalid character selector {EXPR} of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 184)), 1));
/*1152*/ 		}
/*1152*/ 		Scanner_Expect(11, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"expected closing '}' in character selector");
/*1153*/ 		Scanner_ReadSym();
/*1154*/ 		return Globals_string_type;
/*1156*/ 	} else if( (Scanner_sym == 61) ){
/*1157*/ 		if( *Expressions_t == NULL ){
/*1158*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"`->' operator applied to a value of type unknown");
/*1159*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 16, Expressions_0err_entry_get, 185) != 9) ){
/*1160*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"`->' operator applied to a value of type ", Types_TypeToString(*Expressions_t), 1));
/*1162*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 12, Expressions_0err_entry_get, 186) == NULL ){
/*1163*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)"`->' operator applied to an object of unknown class");
/*1165*/ 		}
/*1165*/ 		if( ((*Expressions_t == NULL) || (( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 16, Expressions_0err_entry_get, 187) != 9)) || ((RECORD *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 12, Expressions_0err_entry_get, 188) == NULL)) ){
/*1166*/ 			Scanner_ReadSym();
/*1167*/ 			Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"expected property name or method name after `->'");
/*1169*/ 			Scanner_ReadSym();
/*1170*/ 			if( (Scanner_sym == 12) ){
/*1171*/ 				Expressions_SkipFuncCall();
/*1172*/ 				if( (((Globals_php_ver == 4)) && ((Scanner_sym == 61))) ){
/*1173*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"cannot dereference object returned by method.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)" That's a limitation of the PHP 4.", 1));
/*1177*/ 				}
/*1177*/ 			}
/*1177*/ 			return Expressions_Dereference(&Expressions_unk);
/*1179*/ 		} else {
/*1179*/ 			Scanner_ReadSym();
/*1180*/ 			if( (Scanner_sym == 29) ){
/*1182*/ 			} else if( (Scanner_sym == 20) ){
/*1183*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"expected property name or method name after `->'");
/*1184*/ 				Scanner_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"UNKNOWN";
/*1186*/ 			} else {
/*1186*/ 				Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"expected property name or method name after `->'");
/*1188*/ 			}
/*1188*/ 			Expressions_id = Scanner_s;
/*1189*/ 			Scanner_ReadSym();
/*1190*/ 			if( (Scanner_sym == 12) ){
/*1191*/ 				Expressions_t2 = Expressions_ParseClassMethodCall((RECORD *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 12, Expressions_0err_entry_get, 189), FALSE, Expressions_id);
/*1192*/ 				if( (((Globals_php_ver == 4)) && ((Scanner_sym == 61))) ){
/*1193*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"cannot dereference object returned by method.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)" That's a limitation of the PHP 4.", 1));
/*1197*/ 				}
/*1197*/ 			} else {
/*1197*/ 				Expressions_ResolveClassProperty((RECORD *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 12, Expressions_0err_entry_get, 190), FALSE, Expressions_id, &Expressions_class, &Expressions_p);
/*1198*/ 				if( Expressions_p == NULL ){
/*1199*/ 					Expressions_t2 = NULL;
/*1201*/ 				} else {
/*1201*/ 					Expressions_t2 = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_p, 12, Expressions_0err_entry_get, 191);
/*1204*/ 				}
/*1204*/ 			}
/*1204*/ 			return Expressions_Dereference(&Expressions_t2);
/*1207*/ 		}
/*1207*/ 	} else if( Expressions_IsAssignOp(Scanner_sym) ){
/*1208*/ 		Expressions_op = Scanner_sym;
/*1209*/ 		if( *Expressions_t != NULL ){
/*1214*/ 			switch(Expressions_op){

/*1215*/ 			case 76:
/*1215*/ 			case 77:
/*1215*/ 			case 78:
/*1216*/ 			if( ((*Expressions_t != Globals_int_type) && (*Expressions_t != Globals_float_type)) ){
/*1217*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid LHS type ", Types_TypeToString(*Expressions_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" for the operator", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)" += -= *=", 1));
/*1219*/ 				Expressions_left_inval = TRUE;
/*1221*/ 			}
/*1221*/ 			break;

/*1221*/ 			case 79:
/*1222*/ 			if( *Expressions_t != Globals_float_type ){
/*1223*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid LHS type ", Types_TypeToString(*Expressions_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" for the operator", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)" /=, required float", 1));
/*1225*/ 				Expressions_left_inval = TRUE;
/*1227*/ 			}
/*1227*/ 			break;

/*1227*/ 			case 75:
/*1228*/ 			if( *Expressions_t != Globals_string_type ){
/*1229*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid LHS type ", Types_TypeToString(*Expressions_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" for the operator", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)" .=, required string", 1));
/*1231*/ 				Expressions_left_inval = TRUE;
/*1233*/ 			}
/*1233*/ 			break;

/*1233*/ 			case 80:
/*1233*/ 			case 81:
/*1233*/ 			case 82:
/*1234*/ 			case 83:
/*1234*/ 			case 84:
/*1234*/ 			case 85:
/*1235*/ 			if( *Expressions_t != Globals_int_type ){
/*1236*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid LHS type ", Types_TypeToString(*Expressions_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)" for the operator %= &= |= ^= <<= >>=, required int", 1));
/*1238*/ 				Expressions_left_inval = TRUE;
/*1241*/ 			}
/*1241*/ 			break;
/*1243*/ 			}
/*1243*/ 		}
/*1243*/ 		Scanner_ReadSym();
/*1248*/ 		Expressions_r = Expressions_ParseExpr();
/*1249*/ 		if( Expressions_r == NULL ){
/*1251*/ 			return NULL;
/*1257*/ 		}
/*1257*/ 		Expressions_t2 = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 192);
/*1258*/ 		switch(Expressions_op){

/*1259*/ 		case 76:
/*1259*/ 		case 77:
/*1259*/ 		case 78:
/*1260*/ 		if( ((Expressions_t2 != Globals_int_type) && (Expressions_t2 != Globals_float_type)) ){
/*1261*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid RHS type ", Types_TypeToString(Expressions_t2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" for the operator", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)" += -= *=", 1));
/*1263*/ 			Expressions_left_inval = TRUE;
/*1265*/ 		}
/*1265*/ 		break;

/*1265*/ 		case 79:
/*1266*/ 		if( ((Expressions_t2 != Globals_int_type) && (Expressions_t2 != Globals_float_type)) ){
/*1267*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid RHS type ", Types_TypeToString(Expressions_t2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" for the operator", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)" /=, required float", 1));
/*1269*/ 			Expressions_left_inval = TRUE;
/*1271*/ 		}
/*1271*/ 		break;

/*1271*/ 		case 75:
/*1272*/ 		if( Expressions_t2 != Globals_string_type ){
/*1273*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid RHS type ", Types_TypeToString(Expressions_t2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" for the operator", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)" .=, required string", 1));
/*1275*/ 			Expressions_left_inval = TRUE;
/*1277*/ 		}
/*1277*/ 		break;

/*1277*/ 		case 80:
/*1277*/ 		case 81:
/*1277*/ 		case 82:
/*1278*/ 		case 83:
/*1278*/ 		case 84:
/*1278*/ 		case 85:
/*1279*/ 		if( Expressions_t2 != Globals_int_type ){
/*1280*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid RHS type ", Types_TypeToString(Expressions_t2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)" for the operator %= &= |= ^= <<= >>=, required int", 1));
/*1282*/ 			Expressions_left_inval = TRUE;
/*1285*/ 		}
/*1285*/ 		break;
/*1290*/ 		}
/*1290*/ 		if( *Expressions_t == NULL ){
/*1291*/ 			*Expressions_t = Expressions_t2;
/*1292*/ 			return Expressions_t2;
/*1295*/ 		}
/*1295*/ 		if( (Expressions_op == 31) ){
/*1296*/ 			switch(Expressions_LhsMatchRhs(*Expressions_t, Expressions_t2)){

/*1297*/ 			case 0:
/*1298*/ 			break;

/*1298*/ 			case 1:
/*1299*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"cannot assign a value of type ", Types_TypeToString(Expressions_t2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)" to a variable of type ", Types_TypeToString(*Expressions_t), 1));
/*1301*/ 			break;

/*1301*/ 			case 2:
/*1302*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"cannot assign a value of type ", Types_TypeToString(Expressions_t2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)" to a variable of type ", Types_TypeToString(*Expressions_t), 1));
/*1305*/ 			break;

/*1305*/ 			default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 193);
/*1305*/ 			}
/*1305*/ 			return *Expressions_t;
/*1308*/ 		}
/*1308*/ 		if( ((*Expressions_t == Globals_int_type) && (Expressions_t2 == Globals_float_type)) ){
/*1309*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"can't assign float to int in assignment operator");
/*1311*/ 		}
/*1311*/ 		return *Expressions_t;
/*1313*/ 	} else if( (Scanner_sym == 107) ){
/*1314*/ 		if( (Globals_php_ver == 4) ){
/*1315*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"invalid operator `instanceof' (PHP 5). Hint: use `is_a()'.");
/*1317*/ 		}
/*1317*/ 		if( ((*Expressions_t != NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 16, Expressions_0err_entry_get, 194) != 9)) && (( *(int *)m2runtime_dereference_rhs_RECORD(*Expressions_t, 16, Expressions_0err_entry_get, 195) != 7))) ){
/*1319*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"the left side of `instanceof' is of type ", Types_TypeToString(*Expressions_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)", expected object or mixed", 1));
/*1322*/ 		}
/*1322*/ 		Scanner_ReadSym();
/*1323*/ 		if( (Scanner_sym == 29) ){
/*1324*/ 			if( Search_SearchClass(Scanner_s, TRUE) == NULL ){
/*1325*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"' (still) undefined", 1));
/*1327*/ 			}
/*1327*/ 		} else if( (Scanner_sym == 103) ){
/*1328*/ 			if( Globals_curr_class == NULL ){
/*1329*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"`self' undefined outside class body");
/*1331*/ 			}
/*1331*/ 		} else if( (Scanner_sym == 104) ){
/*1332*/ 			if( Globals_curr_class == NULL ){
/*1333*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"`parent' undefined outside class body");
/*1334*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 16, Expressions_0err_entry_get, 196) == NULL ){
/*1335*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"current class has no parent");
/*1337*/ 			}
/*1337*/ 		} else if( (Scanner_sym == 20) ){
/*1338*/ 			Expressions_v = Search_SearchVar(Scanner_s, Globals_scope);
/*1339*/ 			if( (Expressions_v == NULL) ){
/*1340*/ 				Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"unknown variable `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"' after `instanceof'", 1));
/*1342*/ 			}
/*1342*/ 			if( ((( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 20, Expressions_0err_entry_get, 197), 16, Expressions_0err_entry_get, 198) != 5)) && (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 20, Expressions_0err_entry_get, 199), 16, Expressions_0err_entry_get, 200) != 9))) ){
/*1343*/ 				Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"variable after `instanceof' must be string or object, ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 20, Expressions_0err_entry_get, 201)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" found for `$", Scanner_s, m2runtime_CHR(39), 1));
/*1347*/ 			}
/*1347*/ 		} else {
/*1347*/ 			Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"expected class name or variable, found symbol ", Scanner_SymToName(Scanner_sym), 1));
/*1349*/ 		}
/*1349*/ 		Scanner_ReadSym();
/*1350*/ 		return Globals_boolean_type;
/*1352*/ 	} else if( (Scanner_sym == 52) ){
/*1353*/ 		if( ((*Expressions_t != NULL) && (*Expressions_t != Globals_int_type)) ){
/*1354*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"`++' applied to ", Types_TypeToString(*Expressions_t), 1));
/*1356*/ 		}
/*1356*/ 		Scanner_ReadSym();
/*1357*/ 		return Globals_int_type;
/*1359*/ 	} else if( (Scanner_sym == 53) ){
/*1360*/ 		if( ((*Expressions_t != NULL) && (*Expressions_t != Globals_int_type)) ){
/*1361*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"`--' applied to ", Types_TypeToString(*Expressions_t), 1));
/*1363*/ 		}
/*1363*/ 		Scanner_ReadSym();
/*1364*/ 		return Globals_int_type;
/*1367*/ 	} else {
/*1367*/ 		return *Expressions_t;
/*1370*/ 	}
/*1370*/ 	m2runtime_missing_return(Expressions_0err_entry_get, 202);
/*1370*/ 	return NULL;
/*1372*/ }


/*1385*/ RECORD *
/*1385*/ Expressions_ParseFuncCall(STRING *Expressions_func_name, int Expressions_inside_expr)
/*1385*/ {
/*1386*/ 	int Expressions_guess = 0;
/*1387*/ 	RECORD * Expressions_f = NULL;
/*1389*/ 	RECORD * Expressions_sign = NULL;
/*1389*/ 	Expressions_f = Accounting_AccountFuncCall(Expressions_func_name);
/*1391*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_f, 16, Expressions_0err_entry_get, 203) == NULL ){
/*1392*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_f, 28, Expressions_0err_entry_get, 204) == NULL ){
/*1393*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Expressions_func_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\74,\0,\0,\0)"()' (still) not declared. Guessing signature from its usage.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)" Hint: it's better to declare the functions before their usage.", 1));
/*1396*/ 			Expressions_guess = TRUE;
/*1397*/ 			if( Expressions_inside_expr ){
/*1398*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_sign, 28, 2, 8, Expressions_0err_entry_get, 205) = Globals_mixed_type;
/*1400*/ 			} else {
/*1400*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_sign, 28, 2, 8, Expressions_0err_entry_get, 206) = Globals_void_type;
/*1402*/ 			}
/*1402*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_f, 60, 9, 28, Expressions_0err_entry_get, 207) = Expressions_sign;
/*1403*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_f, 60, 9, 20, Expressions_0err_entry_get, 208) = Scanner_here();
/*1405*/ 		} else {
/*1405*/ 			Expressions_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_f, 28, Expressions_0err_entry_get, 209);
/*1408*/ 		}
/*1408*/ 	} else {
/*1408*/ 		Expressions_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_f, 28, Expressions_0err_entry_get, 210);
/*1411*/ 	}
/*1411*/ 	if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_f, 56, Expressions_0err_entry_get, 211) != 0)) && ((Expressions_handle_error == 0))) ){
/*1412*/ 		Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"the function `", Expressions_func_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"()' may raise error", 1));
/*1413*/ 		if( Globals_curr_func != NULL ){
/*1414*/ 			Expressions_InheritErrors((int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_func, 60, 9, 56, Expressions_0err_entry_get, 212),  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_f, 56, Expressions_0err_entry_get, 213));
/*1415*/ 		} else if( Globals_curr_method != NULL ){
/*1416*/ 			Expressions_InheritErrors((int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_method, 72, 8, 68, Expressions_0err_entry_get, 214),  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_f, 56, Expressions_0err_entry_get, 215));
/*1423*/ 		}
/*1424*/ 	}
/*1424*/ 	Exceptions_ThrowExceptions((ARRAY *)m2runtime_dereference_rhs_RECORD(Expressions_f, 32, Expressions_0err_entry_get, 216));
/*1426*/ 	Expressions_ParseArgsListCall(Expressions_guess, (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_f, 8, Expressions_0err_entry_get, 217), (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_f, 28, Expressions_0err_entry_get, 218), (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_f, 16, Expressions_0err_entry_get, 219));
/*1428*/ 	return (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_sign, 8, Expressions_0err_entry_get, 220);
/*1433*/ }

  RECORD * Expressions_ParseStaticExpr();

/*1440*/ RECORD *
/*1440*/ Expressions_ParseArray(int Expressions_static)
/*1440*/ {
/*1442*/ 	RECORD * Expressions_e = NULL;
/*1442*/ 	RECORD * Expressions_k = NULL;
/*1442*/ 	RECORD * Expressions_r = NULL;
/*1443*/ 	Expressions_r = (
/*1443*/ 		push((char*) alloc_RECORD(16, 2)),
/*1443*/ 		push((char*) (
/*1443*/ 			push((char*) alloc_RECORD(24, 2)),
/*1443*/ 			*(int*) (tos()+16) = 6,
/*1443*/ 			*(int*) (tos()+20) = 1,
/*1443*/ 			push((char*) NULL),
/*1443*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1443*/ 			push((char*) NULL),
/*1443*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*1443*/ 			(RECORD*) pop()
/*1443*/ 		)),
/*1443*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1443*/ 		push((char*) NULL),
/*1444*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1446*/ 		(RECORD*) pop()
/*1446*/ 	);
/*1446*/ 	Scanner_ReadSym();
/*1447*/ 	if( (Scanner_sym == 13) ){
/*1448*/ 		Scanner_ReadSym();
/*1449*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 12, Expressions_0err_entry_get, 221) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"array()";
/*1450*/ 		return Expressions_r;
/*1452*/ 	}
/*1452*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 12, Expressions_0err_entry_get, 222) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"array(...)";
/*1455*/ 	if( Expressions_static ){
/*1456*/ 		Expressions_k = Expressions_ParseStaticExpr();
/*1458*/ 	} else {
/*1458*/ 		Expressions_k = Expressions_ParseExpr();
/*1460*/ 	}
/*1460*/ 	if( (Scanner_sym == 32) ){
/*1461*/ 		if( Expressions_k == NULL ){
/*1463*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_k, 8, Expressions_0err_entry_get, 223) == Globals_int_type ){
/*1464*/ 			*(int *)m2runtime_dereference_lhs_RECORD((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 8, Expressions_0err_entry_get, 224), 24, 2, 20, Expressions_0err_entry_get, 225) = 3;
/*1465*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_k, 8, Expressions_0err_entry_get, 226) == Globals_string_type ){
/*1466*/ 			*(int *)m2runtime_dereference_lhs_RECORD((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 8, Expressions_0err_entry_get, 227), 24, 2, 20, Expressions_0err_entry_get, 228) = 5;
/*1468*/ 		} else {
/*1468*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"invalid key of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_k, 8, Expressions_0err_entry_get, 229)), 1));
/*1470*/ 		}
/*1470*/ 		Scanner_ReadSym();
/*1471*/ 		if( Expressions_static ){
/*1472*/ 			Expressions_e = Expressions_ParseStaticExpr();
/*1474*/ 		} else {
/*1474*/ 			Expressions_e = Expressions_ParseExpr();
/*1477*/ 		}
/*1477*/ 	} else {
/*1477*/ 		*(int *)m2runtime_dereference_lhs_RECORD((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 8, Expressions_0err_entry_get, 230), 24, 2, 20, Expressions_0err_entry_get, 231) = 3;
/*1478*/ 		Expressions_e = Expressions_k;
/*1480*/ 	}
/*1480*/ 	if( Expressions_e == NULL ){
/*1483*/ 	} else {
/*1483*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 8, Expressions_0err_entry_get, 232), 24, 2, 8, Expressions_0err_entry_get, 233) = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_e, 8, Expressions_0err_entry_get, 234);
/*1488*/ 	}
/*1488*/ 	while( (Scanner_sym == 16) ){
/*1489*/ 		Scanner_ReadSym();
/*1491*/ 		if( (Scanner_sym == 13) ){
/*1493*/ 			Scanner_ReadSym();
/*1494*/ 			return Expressions_r;
/*1497*/ 		}
/*1497*/ 		if( Expressions_static ){
/*1498*/ 			Expressions_k = Expressions_ParseStaticExpr();
/*1500*/ 		} else {
/*1500*/ 			Expressions_k = Expressions_ParseExpr();
/*1502*/ 		}
/*1502*/ 		if( (Scanner_sym == 32) ){
/*1503*/ 			if( Expressions_k == NULL ){
/*1505*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_k, 8, Expressions_0err_entry_get, 235) == Globals_int_type ){
/*1506*/ 				if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 236), 20, Expressions_0err_entry_get, 237) == 5) ){
/*1507*/ 					Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"mixing keys of different types in array");
/*1508*/ 					*(int *)m2runtime_dereference_lhs_RECORD((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 8, Expressions_0err_entry_get, 238), 24, 2, 20, Expressions_0err_entry_get, 239) = 7;
/*1510*/ 				}
/*1510*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_k, 8, Expressions_0err_entry_get, 240) == Globals_string_type ){
/*1511*/ 				if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 241), 20, Expressions_0err_entry_get, 242) == 3) ){
/*1512*/ 					Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"mixing keys of different types in array");
/*1513*/ 					*(int *)m2runtime_dereference_lhs_RECORD((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 8, Expressions_0err_entry_get, 243), 24, 2, 20, Expressions_0err_entry_get, 244) = 7;
/*1516*/ 				}
/*1516*/ 			} else {
/*1516*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"invalid array key of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_k, 8, Expressions_0err_entry_get, 245)), 1));
/*1518*/ 			}
/*1518*/ 			Scanner_ReadSym();
/*1519*/ 			if( Expressions_static ){
/*1520*/ 				Expressions_e = Expressions_ParseStaticExpr();
/*1522*/ 			} else {
/*1522*/ 				Expressions_e = Expressions_ParseExpr();
/*1525*/ 			}
/*1527*/ 		} else {
/*1527*/ 			if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 246), 20, Expressions_0err_entry_get, 247) == 5) ){
/*1528*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"mixing keys of different types in array");
/*1529*/ 				*(int *)m2runtime_dereference_lhs_RECORD((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 8, Expressions_0err_entry_get, 248), 24, 2, 20, Expressions_0err_entry_get, 249) = 7;
/*1531*/ 			}
/*1531*/ 			Expressions_e = Expressions_k;
/*1533*/ 		}
/*1533*/ 		if( Expressions_e == NULL ){
/*1535*/ 		} else if( (Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 250), 8, Expressions_0err_entry_get, 251), (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_e, 8, Expressions_0err_entry_get, 252)) != 0) ){
/*1536*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)"mixing elements of different types in array: found ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_e, 8, Expressions_0err_entry_get, 253)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)", expected ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 254), 8, Expressions_0err_entry_get, 255)), 1));
/*1539*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 8, Expressions_0err_entry_get, 256), 24, 2, 8, Expressions_0err_entry_get, 257) = Globals_mixed_type;
/*1542*/ 		}
/*1543*/ 	}
/*1543*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `)'");
/*1544*/ 	Scanner_ReadSym();
/*1545*/ 	return Expressions_r;
/*1549*/ }


/*1553*/ RECORD *
/*1553*/ Expressions_ParseDoubleQuotedStringWithEmbeddedVars(int Expressions_staticExpr)
/*1553*/ {
/*1553*/ 	RECORD * Expressions_r = NULL;
/*1555*/ 	int Expressions_err = 0;
/*1555*/ 	Expressions_r = (
/*1555*/ 		push((char*) alloc_RECORD(16, 2)),
/*1555*/ 		push((char*) Globals_string_type),
/*1555*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1555*/ 		push((char*) Scanner_s),
/*1556*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1556*/ 		(RECORD*) pop()
/*1556*/ 	);
/*1556*/ 	Scanner_ReadSym();
/*1557*/ 	while( (Scanner_sym == 35) ){
/*1558*/ 		if( (Expressions_staticExpr && !Expressions_err) ){
/*1559*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"variables forbidden in static expression");
/*1560*/ 			Expressions_err = TRUE;
/*1563*/ 		}
/*1563*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Expressions_r, 16, 2, 12, Expressions_0err_entry_get, 258) = NULL;
/*1564*/ 		Accounting_AccountVarRHS(Scanner_s);
/*1565*/ 		Scanner_ReadSym();
/*1566*/ 		if( (Scanner_sym == 36) ){
/*1567*/ 			Scanner_ReadSym();
/*1570*/ 		}
/*1570*/ 	}
/*1570*/ 	return Expressions_r;
/*1574*/ }


/*1576*/ RECORD *
/*1576*/ Expressions_ParseList(void)
/*1576*/ {
/*1577*/ 	RECORD * Expressions_r = NULL;
/*1579*/ 	RECORD * Expressions_t = NULL;
/*1579*/ 	Scanner_ReadSym();
/*1580*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"expected '(' after 'list'");
/*1582*/ 	do{
/*1582*/ 		Scanner_ReadSym();
/*1583*/ 		if( (Scanner_sym == 20) ){
/*1584*/ 			Expressions_t = NULL;
/*1585*/ 			Expressions_ParseLHS(Expressions_t);
/*1588*/ 		}
/*1588*/ 		if( (Scanner_sym == 16) ){
/*1590*/ 		} else if( (Scanner_sym == 13) ){
/*1591*/ 			Scanner_ReadSym();
/*1594*/ 			goto m2runtime_loop_1;
/*1594*/ 		} else {
/*1594*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)"expected variable name or closing ')' inside list()");
/*1597*/ 		}
/*1597*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1597*/ 	Scanner_Expect(31, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"expected '=' after list()");
/*1598*/ 	Scanner_ReadSym();
/*1599*/ 	Expressions_r = Expressions_ParseExpr();
/*1600*/ 	if( Expressions_r == NULL ){
/*1601*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"unknown type assigned to the list()");
/*1602*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 259), 16, Expressions_0err_entry_get, 260) != 6) ){
/*1603*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"invalid value assigned to list(): ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 261)), 1));
/*1605*/ 	}
/*1605*/ 	return (
/*1605*/ 		push((char*) alloc_RECORD(16, 2)),
/*1605*/ 		push((char*) (
/*1605*/ 			push((char*) alloc_RECORD(24, 2)),
/*1605*/ 			*(int*) (tos()+16) = 6,
/*1605*/ 			*(int*) (tos()+20) = 1,
/*1605*/ 			push((char*) NULL),
/*1605*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1605*/ 			push((char*) NULL),
/*1605*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*1605*/ 			(RECORD*) pop()
/*1605*/ 		)),
/*1605*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1605*/ 		push((char*) NULL),
/*1605*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1607*/ 		(RECORD*) pop()
/*1607*/ 	);
/*1609*/ }


/*1624*/ RECORD *
/*1624*/ Expressions_ParseClassStaticAccess(RECORD *Expressions_class)
/*1624*/ {
/*1625*/ 	STRING * Expressions_id = NULL;
/*1626*/ 	RECORD * Expressions_c = NULL;
/*1627*/ 	RECORD * Expressions_c2 = NULL;
/*1628*/ 	RECORD * Expressions_p = NULL;
/*1630*/ 	RECORD * Expressions_t = NULL;
/*1630*/ 	Scanner_ReadSym();
/*1632*/ 	if( (Scanner_sym == 20) ){
/*1633*/ 		if( Expressions_class != NULL ){
/*1634*/ 			Expressions_ResolveClassProperty(Expressions_class, TRUE, Scanner_s, &Expressions_c2, &Expressions_p);
/*1636*/ 		}
/*1636*/ 		Scanner_ReadSym();
/*1637*/ 		if( (((Scanner_sym == 14)) || ((Scanner_sym == 10)) || ((Scanner_sym == 61)) || ((Scanner_sym == 52)) || ((Scanner_sym == 53)) || ((Scanner_sym == 107)) || Expressions_IsAssignOp(Scanner_sym)) ){
/*1644*/ 			if( Expressions_p == NULL ){
/*1645*/ 				Expressions_t = Expressions_Dereference(&Expressions_t);
/*1647*/ 			} else {
/*1647*/ 				Expressions_t = Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_p, 48, 6, 12, Expressions_0err_entry_get, 262));
/*1649*/ 			}
/*1649*/ 		} else if( Expressions_p != NULL ){
/*1650*/ 			Expressions_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_p, 12, Expressions_0err_entry_get, 263);
/*1652*/ 		}
/*1652*/ 		if( Expressions_t == NULL ){
/*1653*/ 			return NULL;
/*1655*/ 		} else {
/*1655*/ 			return (
/*1655*/ 				push((char*) alloc_RECORD(16, 2)),
/*1655*/ 				push((char*) Expressions_t),
/*1655*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1655*/ 				push((char*) NULL),
/*1656*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1657*/ 				(RECORD*) pop()
/*1657*/ 			);
/*1658*/ 		}
/*1658*/ 	} else if( (Scanner_sym == 29) ){
/*1659*/ 		Expressions_id = Scanner_s;
/*1660*/ 		Scanner_ReadSym();
/*1661*/ 		if( (Scanner_sym == 12) ){
/*1662*/ 			if( Expressions_class == NULL ){
/*1663*/ 				Expressions_SkipFuncCall();
/*1664*/ 				Expressions_t = NULL;
/*1666*/ 			} else {
/*1666*/ 				Expressions_t = Expressions_ParseClassMethodCall(Expressions_class, TRUE, Expressions_id);
/*1668*/ 			}
/*1668*/ 			if( (Scanner_sym == 61) ){
/*1669*/ 				if( (Globals_php_ver == 4) ){
/*1670*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"cannot dereference object returned by method");
/*1672*/ 				}
/*1672*/ 				Expressions_t = Expressions_Dereference(&Expressions_t);
/*1674*/ 			}
/*1674*/ 			if( Expressions_t == NULL ){
/*1675*/ 				return NULL;
/*1677*/ 			} else {
/*1677*/ 				return (
/*1677*/ 					push((char*) alloc_RECORD(16, 2)),
/*1677*/ 					push((char*) Expressions_t),
/*1677*/ 					*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1677*/ 					push((char*) NULL),
/*1678*/ 					*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1679*/ 					(RECORD*) pop()
/*1679*/ 				);
/*1680*/ 			}
/*1681*/ 		} else {
/*1681*/ 			if( Expressions_class == NULL ){
/*1682*/ 				return NULL;
/*1684*/ 			} else {
/*1684*/ 				Search_ResolveClassConst(Expressions_class, Expressions_id, &Expressions_c2, &Expressions_c);
/*1685*/ 				if( Expressions_c == NULL ){
/*1686*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"constant `", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_class, 8, Expressions_0err_entry_get, 264), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Expressions_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"' does not exist", 1));
/*1688*/ 					return NULL;
/*1690*/ 				} else {
/*1690*/ 					Accounting_AccountClassConst(Expressions_c2, Expressions_c);
/*1691*/ 					if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_c, 28, Expressions_0err_entry_get, 265) == 0)) && (Globals_curr_class != Expressions_c2)) ){
/*1692*/ 						Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"access forbidden to private constant `", Classes_pc(Expressions_class, Expressions_c2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Expressions_id, m2runtime_CHR(39), 1));
/*1694*/ 					} else if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_c, 28, Expressions_0err_entry_get, 266) == 1)) && (!Classes_IsSubclassOf(Globals_curr_class, Expressions_c2))) ){
/*1695*/ 						Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"access forbidden to protected constant `", Classes_pc(Expressions_class, Expressions_c2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Expressions_id, m2runtime_CHR(39), 1));
/*1698*/ 					}
/*1698*/ 					return (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_c, 12, Expressions_0err_entry_get, 267);
/*1701*/ 				}
/*1702*/ 			}
/*1704*/ 		}
/*1704*/ 	} else {
/*1704*/ 		Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"expected class item after `::', found ", Scanner_SymToName(Scanner_sym), 1));
/*1707*/ 	}
/*1707*/ 	m2runtime_missing_return(Expressions_0err_entry_get, 268);
/*1707*/ 	return NULL;
/*1709*/ }


/*1711*/ RECORD *
/*1711*/ Expressions_ParseSelf(void)
/*1711*/ {
/*1711*/ 	Scanner_ReadSym();
/*1712*/ 	Scanner_Expect(19, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"expected `::' after `self'");
/*1713*/ 	if( (Globals_php_ver == 4) ){
/*1714*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"invalid `self::' (PHP 5)");
/*1716*/ 	}
/*1716*/ 	if( Globals_curr_class == NULL ){
/*1717*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"invalid `self::': not inside a class");
/*1719*/ 	} else {
/*1719*/ 		return Expressions_ParseClassStaticAccess(Globals_curr_class);
/*1722*/ 	}
/*1722*/ 	m2runtime_missing_return(Expressions_0err_entry_get, 269);
/*1722*/ 	return NULL;
/*1724*/ }


/*1726*/ RECORD *
/*1726*/ Expressions_ParseParent(void)
/*1726*/ {
/*1726*/ 	Scanner_ReadSym();
/*1727*/ 	Scanner_Expect(19, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"expected `::' after `parent'");
/*1728*/ 	if( Globals_curr_class == NULL ){
/*1729*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"invalid `parent::': not inside a class");
/*1730*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 16, Expressions_0err_entry_get, 270) == NULL ){
/*1731*/ 		Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"invalid `parent::': class `", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 8, Expressions_0err_entry_get, 271), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' do not has a parent", 1));
/*1734*/ 	} else {
/*1734*/ 		return Expressions_ParseClassStaticAccess((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 16, Expressions_0err_entry_get, 272));
/*1737*/ 	}
/*1737*/ 	m2runtime_missing_return(Expressions_0err_entry_get, 273);
/*1737*/ 	return NULL;
/*1739*/ }


/*1749*/ void
/*1749*/ Expressions_ParseExit(void)
/*1749*/ {
/*1751*/ 	RECORD * Expressions_r = NULL;
/*1751*/ 	Scanner_ReadSym();
/*1752*/ 	if( (Scanner_sym == 12) ){
/*1753*/ 		Scanner_ReadSym();
/*1754*/ 		if( (Scanner_sym != 13) ){
/*1755*/ 			Expressions_r = Expressions_ParseExpr();
/*1756*/ 			if( Expressions_r == NULL ){
/*1758*/ 			} else if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 274) != Globals_int_type) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 275) != Globals_string_type)) ){
/*1759*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"the exit status must be int or string");
/*1763*/ 			}
/*1763*/ 		}
/*1763*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `)'");
/*1764*/ 		Scanner_ReadSym();
/*1767*/ 	}
/*1769*/ }


/*1775*/ void
/*1775*/ Expressions_CheckBoolean(STRING *Expressions_where, RECORD *Expressions_r)
/*1775*/ {
/*1775*/ 	if( Expressions_r == NULL ){
/*1779*/ 		return ;
/*1780*/ 	}
/*1780*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 276), 16, Expressions_0err_entry_get, 277)){

/*1781*/ 	case 2:
/*1782*/ 	return ;
/*1782*/ 	break;

/*1782*/ 	case 3:
/*1783*/ 	Scanner_Error(m2runtime_concat_STRING(0, Expressions_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)": expected expression of the type boolean, but found ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"an integer value. Remember that 0 evaluates to FALSE, and ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"any other integer value evaluates to TRUE.", 1));
/*1786*/ 	break;

/*1786*/ 	case 4:
/*1787*/ 	Scanner_Error(m2runtime_concat_STRING(0, Expressions_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)": expected expression of the type boolean, but found ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\102,\0,\0,\0)"a float value. Remember that 0.0 evaluates to FALSE and any other ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"value evaluates to TRUE.", 1));
/*1790*/ 	break;

/*1790*/ 	case 5:
/*1791*/ 	Scanner_Error(m2runtime_concat_STRING(0, Expressions_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)": expected expression of the type boolean, but found ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)"a string value. Remember that the empty string \042\042, the string ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\74,\0,\0,\0)"\0420\042 and the NULL string all evaluate to FALSE and any other ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"string evaluates to TRUE.", 1));
/*1795*/ 	break;

/*1795*/ 	case 6:
/*1796*/ 	Scanner_Error(m2runtime_concat_STRING(0, Expressions_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)": expected expression of the type boolean, but found ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"an array value. Remember that an array with zero elements ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"evaluates to FALSE, and an array with one or more elements ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"evaluates to TRUE.", 1));
/*1800*/ 	break;

/*1800*/ 	case 7:
/*1801*/ 	Scanner_Error(m2runtime_concat_STRING(0, Expressions_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)": expected expression of the type boolean, but found ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"a mixed value", 1));
/*1803*/ 	break;

/*1803*/ 	case 8:
/*1804*/ 	Scanner_Error(m2runtime_concat_STRING(0, Expressions_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)": expected expression of the type boolean, but found ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\102,\0,\0,\0)"a resource. Remember that a resource evaluates always to TRUE, so ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\104,\0,\0,\0)"that this expression is unuseful. Remember too that some functions, ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\101,\0,\0,\0)"formally declared to return a resource, might return the boolean ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\107,\0,\0,\0)"value FALSE on error; if that is the case, rewrite as (EXPR) === FALSE.", 1));
/*1809*/ 	break;

/*1809*/ 	case 9:
/*1810*/ 	Scanner_Error(m2runtime_concat_STRING(0, Expressions_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)": expected expression of the type boolean, but found ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\103,\0,\0,\0)"an object. Remember that an object evaluates to FALSE if it do not ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\104,\0,\0,\0)"has properties, and evaluates to TRUE if it has at least a property.", 1));
/*1814*/ 	break;

/*1814*/ 	default:
/*1814*/ 	Scanner_Error(m2runtime_concat_STRING(0, Expressions_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)": invalid type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 278)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)", expected expression of type boolean", 1));
/*1818*/ 	}
/*1820*/ }


/*1832*/ RECORD *
/*1832*/ Expressions_ParseExpr(void)
/*1832*/ {

/*1837*/ 	RECORD *
/*1837*/ 	Expressions_ParseVarRHS(void)
/*1837*/ 	{

/*1838*/ 		STRING *
/*1838*/ 		Expressions_DereferenceGLOBALS(void)
/*1838*/ 		{
/*1838*/ 			RECORD * Expressions_r = NULL;
/*1840*/ 			STRING * Expressions_n = NULL;
/*1840*/ 			Scanner_ReadSym();
/*1841*/ 			Expressions_r = Expressions_ParseExpr();
/*1842*/ 			Scanner_Expect(15, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `]'");
/*1843*/ 			Scanner_ReadSym();
/*1844*/ 			if( Expressions_r == NULL ){
/*1845*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"can't parse the name of the global variable");
/*1846*/ 				return NULL;
/*1847*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 279) != Globals_string_type ){
/*1848*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"$GLOBALS[?]: required string, found ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 280)), 1));
/*1850*/ 				return NULL;
/*1852*/ 			}
/*1852*/ 			Expressions_n = (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_r, 12, Expressions_0err_entry_get, 281);
/*1853*/ 			if( Expressions_n == NULL ){
/*1854*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"$GLOBALS[?]: undetermined variable name");
/*1855*/ 				return NULL;
/*1856*/ 			} else if( (m2runtime_length(Expressions_n) == 0) ){
/*1857*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"$GLOBALS['']: invalid empty string");
/*1858*/ 				return NULL;
/*1859*/ 			} else if( !m2_match(Expressions_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"^[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*$") ){
/*1860*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"$GLOBALS['", Expressions_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"']: invalid name, can't be a variable!", 1));
/*1861*/ 				return NULL;
/*1863*/ 			}
/*1863*/ 			return Expressions_n;
/*1867*/ 		}

/*1868*/ 		STRING * Expressions_id = NULL;
/*1870*/ 		RECORD * Expressions_v = NULL;
/*1870*/ 		Expressions_id = Scanner_s;
/*1871*/ 		Scanner_ReadSym();
/*1874*/ 		if( ((m2runtime_strcmp(Expressions_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"GLOBALS") == 0) && ((Scanner_sym == 14))) ){
/*1875*/ 			Expressions_id = Expressions_DereferenceGLOBALS();
/*1876*/ 			if( Expressions_id == NULL ){
/*1877*/ 				Expressions_v = NULL;
/*1878*/ 				Expressions_id = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"UNDETERMINED_GLOBAL_VAR";
/*1880*/ 			} else {
/*1880*/ 				Expressions_v = Search_SearchVar(Expressions_id, 0);
/*1881*/ 				if( ((Expressions_v == NULL) && ((Globals_scope > 0))) ){
/*1882*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"$GLOBALS['", Expressions_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"']: undefined global variable", 1));
/*1883*/ 					Expressions_id = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"UNDEFINED_GLOBAL_VAR_", Expressions_id, 1);
/*1887*/ 				}
/*1888*/ 			}
/*1888*/ 		} else {
/*1888*/ 			Expressions_v = Search_SearchVar(Expressions_id, Globals_scope);
/*1896*/ 		}
/*1896*/ 		if( (Scanner_sym == 12) ){
/*1897*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"invalid variable-name function (PHPLint restriction)");
/*1898*/ 			Expressions_SkipFuncCall();
/*1899*/ 			return NULL;
/*1902*/ 		} else if( (Scanner_sym == 14) ){
/*1903*/ 			if( Expressions_v == NULL ){
/*1906*/ 				Accounting_AccountVarLHS(Expressions_id, FALSE);
/*1907*/ 				Expressions_v = Search_SearchVar(Expressions_id, Globals_scope);
/*1911*/ 			} else {
/*1911*/ 				Accounting_AccountVarRHS2(Expressions_v);
/*1913*/ 			}
/*1913*/ 			return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_v, 52, 7, 20, Expressions_0err_entry_get, 282));
/*1916*/ 		} else if( (((Scanner_sym == 10)) || ((Scanner_sym == 61))) ){
/*1917*/ 			if( Expressions_v == NULL ){
/*1918*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"using unassigned variable `$", Expressions_id, m2runtime_CHR(39), 1));
/*1919*/ 				Accounting_AccountVarLHS(Expressions_id, FALSE);
/*1920*/ 				Expressions_v = Search_SearchVar(Expressions_id, Globals_scope);
/*1922*/ 			} else {
/*1922*/ 				Accounting_AccountVarRHS2(Expressions_v);
/*1924*/ 			}
/*1924*/ 			return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_v, 52, 7, 20, Expressions_0err_entry_get, 283));
/*1927*/ 		} else if( (Scanner_sym == 31) ){
/*1928*/ 			if( Expressions_v == NULL ){
/*1929*/ 				Accounting_AccountVarLHS(Expressions_id, FALSE);
/*1930*/ 				Expressions_v = Search_SearchVar(Expressions_id, Globals_scope);
/*1932*/ 			} else {
/*1932*/ 				Accounting_AccountVarLHS2(Expressions_v);
/*1934*/ 			}
/*1934*/ 			return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_v, 52, 7, 20, Expressions_0err_entry_get, 284));
/*1937*/ 		} else if( Expressions_IsAssignOp(Scanner_sym) ){
/*1938*/ 			if( Expressions_v == NULL ){
/*1939*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"using unassigned variable `$", Expressions_id, m2runtime_CHR(39), 1));
/*1940*/ 				Accounting_AccountVarLHS(Expressions_id, FALSE);
/*1941*/ 				Expressions_v = Search_SearchVar(Expressions_id, Globals_scope);
/*1943*/ 			} else {
/*1943*/ 				Accounting_AccountVarRHS2(Expressions_v);
/*1945*/ 			}
/*1945*/ 			return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_v, 52, 7, 20, Expressions_0err_entry_get, 285));
/*1948*/ 		} else if( (((Scanner_sym == 52)) || ((Scanner_sym == 53))) ){
/*1949*/ 			if( Expressions_v == NULL ){
/*1950*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"using unassigned variable `$", Expressions_id, m2runtime_CHR(39), 1));
/*1951*/ 				Accounting_AccountVarLHS(Expressions_id, FALSE);
/*1952*/ 				Expressions_v = Search_SearchVar(Expressions_id, Globals_scope);
/*1953*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_v, 52, 7, 20, Expressions_0err_entry_get, 286) = Globals_int_type;
/*1955*/ 			} else {
/*1955*/ 				Accounting_AccountVarRHS2(Expressions_v);
/*1957*/ 			}
/*1957*/ 			return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_v, 52, 7, 20, Expressions_0err_entry_get, 287));
/*1960*/ 		} else if( (Scanner_sym == 107) ){
/*1961*/ 			if( Expressions_v == NULL ){
/*1962*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"using unassigned variable `$", Expressions_id, m2runtime_CHR(39), 1));
/*1963*/ 				Accounting_AccountVarLHS(Expressions_id, FALSE);
/*1964*/ 				Expressions_v = Search_SearchVar(Expressions_id, Globals_scope);
/*1966*/ 			} else {
/*1966*/ 				Accounting_AccountVarRHS2(Expressions_v);
/*1968*/ 			}
/*1968*/ 			return Expressions_Dereference((RECORD **)m2runtime_dereference_lhs_RECORD(&Expressions_v, 52, 7, 20, Expressions_0err_entry_get, 288));
/*1971*/ 		} else if( Expressions_v != NULL ){
/*1972*/ 			Accounting_AccountVarRHS2(Expressions_v);
/*1973*/ 			return (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 20, Expressions_0err_entry_get, 289);
/*1977*/ 		} else {
/*1977*/ 			Accounting_AccountVarRHS(Expressions_id);
/*1978*/ 			Expressions_v = Search_SearchVar(Expressions_id, Globals_scope);
/*1979*/ 			return (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 20, Expressions_0err_entry_get, 290);
/*1984*/ 		}
/*1984*/ 		m2runtime_missing_return(Expressions_0err_entry_get, 291);
/*1984*/ 		return NULL;
/*1986*/ 	}


/*1988*/ 	RECORD *
/*1988*/ 	Expressions_ParseTerm(void)
/*1988*/ 	{

/*1990*/ 		void
/*1990*/ 		Expressions_ParseIsset(void)
/*1990*/ 		{
/*1990*/ 			Scanner_ReadSym();
/*1991*/ 			Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"expected `(' after `isset'");
/*1993*/ 			do{
/*1993*/ 				Scanner_ReadSym();
/*1994*/ 				Expressions_ParseLHS(NULL);
/*1995*/ 				if( (Scanner_sym == 16) ){
/*1997*/ 				} else if( (Scanner_sym == 13) ){
/*1998*/ 					Scanner_ReadSym();
/*2000*/ 					return ;
/*2001*/ 				} else {
/*2001*/ 					Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\100,\0,\0,\0)"expected variable name or closing ')' after isset() args, found ", Scanner_SymToName(Scanner_sym), 1));
/*2004*/ 				}
/*2005*/ 			}while(TRUE);
/*2007*/ 		}


/*2009*/ 		RECORD *
/*2009*/ 		Expressions_ParseNew(void)
/*2009*/ 		{
/*2010*/ 			RECORD * Expressions_class = NULL;
/*2011*/ 			RECORD * Expressions_C = NULL;
/*2012*/ 			RECORD * Expressions_c = NULL;
/*2013*/ 			RECORD * Expressions_r = NULL;
/*2015*/ 			RECORD * Expressions_v = NULL;
/*2015*/ 			Scanner_ReadSym();
/*2017*/ 			if( (Scanner_sym == 29) ){
/*2018*/ 				Expressions_class = Search_SearchClass(Scanner_s, TRUE);
/*2019*/ 				if( Expressions_class == NULL ){
/*2020*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"unknown class `", Scanner_s, m2runtime_CHR(39), 1));
/*2021*/ 					Scanner_ReadSym();
/*2022*/ 					if( (Scanner_sym == 12) ){
/*2023*/ 						Expressions_SkipFuncCall();
/*2025*/ 					}
/*2025*/ 					return NULL;
/*2028*/ 				}
/*2028*/ 			} else if( (Scanner_sym == 103) ){
/*2029*/ 				Expressions_class = Globals_curr_class;
/*2030*/ 				if( Expressions_class == NULL ){
/*2031*/ 					Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"`self': not inside a class");
/*2034*/ 				}
/*2034*/ 			} else if( (Scanner_sym == 104) ){
/*2035*/ 				if( Globals_curr_class == NULL ){
/*2036*/ 					Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"`parent': we are not inside a class");
/*2038*/ 				}
/*2038*/ 				Expressions_class = (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 16, Expressions_0err_entry_get, 292);
/*2039*/ 				if( Expressions_class == NULL ){
/*2040*/ 					Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"`parent': no parent class");
/*2044*/ 				}
/*2044*/ 			} else if( (Scanner_sym == 20) ){
/*2045*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"expected static class name after `new'");
/*2046*/ 				Expressions_v = Search_SearchVar(Scanner_s, Globals_scope);
/*2047*/ 				if( (Expressions_v == NULL) ){
/*2048*/ 					Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"unknown variable `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"' after `new'", 1));
/*2050*/ 				}
/*2050*/ 				if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 20, Expressions_0err_entry_get, 293), 16, Expressions_0err_entry_get, 294) != 5) ){
/*2051*/ 					Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"variable after `new' must be string, ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_v, 20, Expressions_0err_entry_get, 295)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" found for `$", Scanner_s, m2runtime_CHR(39), 1));
/*2054*/ 				}
/*2054*/ 				Scanner_ReadSym();
/*2055*/ 				if( (Scanner_sym == 12) ){
/*2056*/ 					Expressions_SkipFuncCall();
/*2058*/ 				}
/*2058*/ 				return NULL;
/*2060*/ 			} else {
/*2060*/ 				Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)"expected class name or `self' or `parent' after `new'");
/*2063*/ 			}
/*2063*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_class, 72, Expressions_0err_entry_get, 296) ){
/*2064*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"cannot instantiate abstract class `", Scanner_s, m2runtime_CHR(39), 1));
/*2067*/ 			}
/*2067*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_class, 76, Expressions_0err_entry_get, 297) ){
/*2068*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"cannot instantiate interface class `", Scanner_s, m2runtime_CHR(39), 1));
/*2071*/ 			}
/*2071*/ 			Accounting_AccountClass(Expressions_class);
/*2073*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Expressions_class, 56, Expressions_0err_entry_get, 298), EMPTY_STRING) > 0 ){
/*2074*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"instantiating object from deprecated class `", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_class, 8, Expressions_0err_entry_get, 299), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_class, 56, Expressions_0err_entry_get, 300), 1));
/*2079*/ 			}
/*2079*/ 			Expressions_C = Expressions_class;
/*2080*/ 			while( ((Expressions_C != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_C, 40, Expressions_0err_entry_get, 301) == NULL)) ){
/*2081*/ 				Expressions_C = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_C, 16, Expressions_0err_entry_get, 302);
/*2084*/ 			}
/*2084*/ 			if( Expressions_C == NULL ){
/*2085*/ 				Accounting_AccountClass(Expressions_class);
/*2086*/ 				Scanner_ReadSym();
/*2087*/ 				if( (Scanner_sym == 12) ){
/*2088*/ 					Scanner_ReadSym();
/*2089*/ 					if( (Scanner_sym != 13) ){
/*2090*/ 						Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"Expected `)', found ", Scanner_SymToName(Scanner_sym), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)". The class `", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_class, 8, Expressions_0err_entry_get, 303), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"' do not has a constructor, so no arguments are", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)" required", 1));
/*2096*/ 						do{
/*2096*/ 							Expressions_r = Expressions_ParseExpr();
/*2097*/ 							if( (Scanner_sym == 16) ){
/*2098*/ 								Scanner_ReadSym();
/*2101*/ 							} else {
/*2102*/ 								goto m2runtime_loop_1;
/*2103*/ 							}
/*2104*/ 						}while(TRUE);
m2runtime_loop_1: ;
/*2104*/ 					}
/*2104*/ 					Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `)'");
/*2105*/ 					Scanner_ReadSym();
/*2108*/ 				}
/*2109*/ 			} else {
/*2109*/ 				Expressions_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_C, 40, Expressions_0err_entry_get, 304);
/*2110*/ 				if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_c, 48, Expressions_0err_entry_get, 305) == 0)) && (Globals_curr_class != Expressions_C)) ){
/*2111*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"the constructor of the class `", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_C, 8, Expressions_0err_entry_get, 306), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"' is private", 1));
/*2114*/ 				}
/*2114*/ 				if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_c, 48, Expressions_0err_entry_get, 307) == 1)) && !Classes_IsSubclassOf(Globals_curr_class, Expressions_C)) ){
/*2116*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"the constructor of the class `", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_C, 8, Expressions_0err_entry_get, 308), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"' is protected", 1));
/*2119*/ 				}
/*2119*/ 				Scanner_ReadSym();
/*2120*/ 				if( (Scanner_sym == 12) ){
/*2121*/ 					Expressions_ParseArgsListCall(FALSE, m2runtime_concat_STRING(0, Classes_pc(Expressions_class, Expressions_C), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_c, 8, Expressions_0err_entry_get, 309), 1), (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_c, 16, Expressions_0err_entry_get, 310), (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_c, 20, Expressions_0err_entry_get, 311));
/*2123*/ 				} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_c, 16, Expressions_0err_entry_get, 312), 20, Expressions_0err_entry_get, 313) > 0) ){
/*2124*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"missing required arguments for constructor ", Classes_pc(Expressions_class, Expressions_C), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_c, 8, Expressions_0err_entry_get, 314), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_c, 20, Expressions_0err_entry_get, 315)), 1));
/*2128*/ 				} else {
/*2128*/ 					Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"missing parentheses after class name. Although ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"the constructor ", Classes_pc(Expressions_class, Expressions_C), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Expressions_c, 8, Expressions_0err_entry_get, 316), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)" has no mandatory arguments, it's a good habit", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)" to provide these parentheses.", 1));
/*2133*/ 				}
/*2133*/ 				if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Expressions_c, 68, Expressions_0err_entry_get, 317) != 0)) && ((Expressions_handle_error == 0))) ){
/*2134*/ 					Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the method ", Scanner_mn(Expressions_C, Expressions_c), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)" may raise error", 1));
/*2135*/ 					if( Globals_curr_func != NULL ){
/*2136*/ 						Expressions_InheritErrors((int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_func, 60, 9, 56, Expressions_0err_entry_get, 318),  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_c, 68, Expressions_0err_entry_get, 319));
/*2137*/ 					} else if( Globals_curr_method != NULL ){
/*2138*/ 						Expressions_InheritErrors((int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_method, 72, 8, 68, Expressions_0err_entry_get, 320),  *(int *)m2runtime_dereference_rhs_RECORD(Expressions_c, 68, Expressions_0err_entry_get, 321));
/*2145*/ 					}
/*2146*/ 				}
/*2146*/ 				Exceptions_ThrowExceptions((ARRAY *)m2runtime_dereference_rhs_RECORD(Expressions_c, 28, Expressions_0err_entry_get, 322));
/*2149*/ 			}
/*2149*/ 			return (
/*2149*/ 				push((char*) alloc_RECORD(16, 2)),
/*2149*/ 				push((char*) (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_class, 24, Expressions_0err_entry_get, 323)),
/*2149*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2149*/ 				push((char*) NULL),
/*2150*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2151*/ 				(RECORD*) pop()
/*2151*/ 			);
/*2153*/ 		}


/*2155*/ 		RECORD *
/*2155*/ 		Expressions_ParseClone(void)
/*2155*/ 		{
/*2156*/ 			RECORD * Expressions_r = NULL;
/*2157*/ 			RECORD * Expressions_C = NULL;
/*2159*/ 			RECORD * Expressions_m = NULL;
/*2159*/ 			Scanner_ReadSym();
/*2160*/ 			Expressions_r = Expressions_ParseTerm();
/*2161*/ 			if( Expressions_r == NULL ){
/*2163*/ 			} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 324), 16, Expressions_0err_entry_get, 325) == 9) ){
/*2165*/ 				Expressions_C = (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 326), 12, Expressions_0err_entry_get, 327);
/*2166*/ 				if( Expressions_C != NULL ){
/*2167*/ 					Classes_ResolveClassMethod(Expressions_C, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__clone", &Expressions_C, &Expressions_m);
/*2168*/ 					if( Expressions_m != NULL ){
/*2169*/ 						Accounting_AccountClassMethod(Expressions_C, Expressions_m);
/*2172*/ 					}
/*2174*/ 				}
/*2174*/ 			} else {
/*2174*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"invalid type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 328)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" for `clone'", 1));
/*2175*/ 				Expressions_r = NULL;
/*2178*/ 			}
/*2178*/ 			return Expressions_r;
/*2183*/ 		}

/*2184*/ 		STRING * Expressions_id = NULL;
/*2185*/ 		RECORD * Expressions_r = NULL;
/*2186*/ 		RECORD * Expressions_c = NULL;
/*2187*/ 		RECORD * Expressions_t = NULL;
/*2189*/ 		RECORD * Expressions_class = NULL;
/*2189*/ 		switch(Scanner_sym){

/*2191*/ 		case 63:
/*2192*/ 		Expressions_r = (
/*2192*/ 			push((char*) alloc_RECORD(16, 2)),
/*2192*/ 			push((char*) Globals_null_type),
/*2192*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2192*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL"),
/*2193*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2193*/ 			(RECORD*) pop()
/*2193*/ 		);
/*2193*/ 		Scanner_ReadSym();
/*2195*/ 		break;

/*2195*/ 		case 65:
/*2196*/ 		Expressions_r = (
/*2196*/ 			push((char*) alloc_RECORD(16, 2)),
/*2196*/ 			push((char*) Globals_boolean_type),
/*2196*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2196*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE"),
/*2197*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2197*/ 			(RECORD*) pop()
/*2197*/ 		);
/*2197*/ 		Scanner_ReadSym();
/*2199*/ 		break;

/*2199*/ 		case 66:
/*2200*/ 		Expressions_r = (
/*2200*/ 			push((char*) alloc_RECORD(16, 2)),
/*2200*/ 			push((char*) Globals_boolean_type),
/*2200*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2200*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE"),
/*2201*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2201*/ 			(RECORD*) pop()
/*2201*/ 		);
/*2201*/ 		Scanner_ReadSym();
/*2203*/ 		break;

/*2203*/ 		case 38:
/*2204*/ 		Expressions_r = (
/*2204*/ 			push((char*) alloc_RECORD(16, 2)),
/*2204*/ 			push((char*) Globals_int_type),
/*2204*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2204*/ 			push((char*) Scanner_s),
/*2205*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2205*/ 			(RECORD*) pop()
/*2205*/ 		);
/*2205*/ 		Scanner_ReadSym();
/*2207*/ 		break;

/*2207*/ 		case 39:
/*2208*/ 		Expressions_r = (
/*2208*/ 			push((char*) alloc_RECORD(16, 2)),
/*2208*/ 			push((char*) Globals_float_type),
/*2208*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2208*/ 			push((char*) Scanner_s),
/*2209*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2209*/ 			(RECORD*) pop()
/*2209*/ 		);
/*2209*/ 		Scanner_ReadSym();
/*2211*/ 		break;

/*2211*/ 		case 33:
/*2212*/ 		Expressions_r = (
/*2212*/ 			push((char*) alloc_RECORD(16, 2)),
/*2212*/ 			push((char*) Globals_string_type),
/*2212*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2212*/ 			push((char*) Scanner_s),
/*2213*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2213*/ 			(RECORD*) pop()
/*2213*/ 		);
/*2213*/ 		Scanner_ReadSym();
/*2215*/ 		break;

/*2215*/ 		case 34:
/*2216*/ 		Expressions_r = Expressions_ParseDoubleQuotedStringWithEmbeddedVars(FALSE);
/*2218*/ 		break;

/*2218*/ 		case 37:
/*2219*/ 		Expressions_r = Expressions_ParseDoubleQuotedStringWithEmbeddedVars(FALSE);
/*2221*/ 		break;

/*2221*/ 		case 73:
/*2222*/ 		Scanner_ReadSym();
/*2223*/ 		Expressions_r = Expressions_ParseTerm();
/*2225*/ 		break;

/*2225*/ 		case 20:
/*2226*/ 		Expressions_t = Expressions_ParseVarRHS();
/*2227*/ 		if( Expressions_t == NULL ){
/*2228*/ 			Expressions_r = NULL;
/*2230*/ 		} else {
/*2230*/ 			Expressions_r = (
/*2230*/ 				push((char*) alloc_RECORD(16, 2)),
/*2230*/ 				push((char*) Expressions_t),
/*2230*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2230*/ 				push((char*) NULL),
/*2231*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2232*/ 				(RECORD*) pop()
/*2232*/ 			);
/*2233*/ 		}
/*2233*/ 		break;

/*2233*/ 		case 29:
/*2234*/ 		Expressions_id = Scanner_s;
/*2235*/ 		Scanner_ReadSym();
/*2236*/ 		if( (Scanner_sym == 12) ){
/*2237*/ 			Expressions_t = Expressions_ParseFuncCall(Expressions_id, TRUE);
/*2238*/ 			if( (Scanner_sym == 61) ){
/*2239*/ 				if( (Globals_php_ver == 4) ){
/*2240*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"cannot dereference object returned by function");
/*2242*/ 				}
/*2242*/ 				Expressions_t = Expressions_Dereference(&Expressions_t);
/*2244*/ 			}
/*2244*/ 			if( Expressions_t == NULL ){
/*2245*/ 				Expressions_r = NULL;
/*2247*/ 			} else {
/*2247*/ 				Expressions_r = (
/*2247*/ 					push((char*) alloc_RECORD(16, 2)),
/*2247*/ 					push((char*) Expressions_t),
/*2247*/ 					*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2247*/ 					push((char*) NULL),
/*2248*/ 					*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2249*/ 					(RECORD*) pop()
/*2249*/ 				);
/*2250*/ 			}
/*2250*/ 		} else if( (Scanner_sym == 19) ){
/*2251*/ 			Expressions_class = Search_SearchClass(Expressions_id, TRUE);
/*2252*/ 			if( Expressions_class == NULL ){
/*2253*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"unknown class `", Expressions_id, m2runtime_CHR(39), 1));
/*2255*/ 			}
/*2255*/ 			return Expressions_ParseClassStaticAccess(Expressions_class);
/*2258*/ 		} else {
/*2258*/ 			Expressions_c = Accounting_AccountConstRHS(Expressions_id);
/*2259*/ 			Expressions_r = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_c, 20, Expressions_0err_entry_get, 329);
/*2262*/ 		}
/*2262*/ 		break;

/*2262*/ 		case 113:
/*2263*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\233,\0,\0,\0)"`exit()' (aka `die()') isn't a function, it is a statement. Trying to continue anyway, but probably the result of the expression will be of the wrong type.");
/*2264*/ 		Expressions_ParseExit();
/*2265*/ 		Expressions_r = NULL;
/*2267*/ 		break;

/*2267*/ 		case 103:
/*2268*/ 		Expressions_r = Expressions_ParseSelf();
/*2270*/ 		break;

/*2270*/ 		case 104:
/*2271*/ 		Expressions_r = Expressions_ParseParent();
/*2273*/ 		break;

/*2273*/ 		case 105:
/*2274*/ 		Expressions_r = Expressions_ParseNew();
/*2276*/ 		break;

/*2276*/ 		case 106:
/*2277*/ 		Expressions_r = Expressions_ParseClone();
/*2279*/ 		break;

/*2279*/ 		case 122:
/*2280*/ 		Expressions_ParseIsset();
/*2281*/ 		Expressions_r = (
/*2281*/ 			push((char*) alloc_RECORD(16, 2)),
/*2281*/ 			push((char*) Globals_boolean_type),
/*2281*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2281*/ 			push((char*) NULL),
/*2282*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2283*/ 			(RECORD*) pop()
/*2283*/ 		);
/*2283*/ 		break;

/*2283*/ 		case 70:
/*2284*/ 		Scanner_ReadSym();
/*2285*/ 		Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"expected `(' after `array'");
/*2286*/ 		Expressions_r = Expressions_ParseArray(FALSE);
/*2288*/ 		break;

/*2288*/ 		case 108:
/*2289*/ 		Expressions_r = Expressions_ParseList();
/*2291*/ 		break;

/*2291*/ 		case 12:
/*2293*/ 		Scanner_ReadSym();
/*2294*/ 		switch(Scanner_sym){

/*2296*/ 		case 64:
/*2297*/ 		Scanner_ReadSym();
/*2298*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"expected closing `)' in typecast");
/*2299*/ 		Scanner_ReadSym();
/*2300*/ 		Expressions_r = Expressions_ParseTerm();
/*2301*/ 		Expressions_r = Operators_EvalValueConversion(Expressions_r, Globals_boolean_type);
/*2303*/ 		break;

/*2303*/ 		case 67:
/*2304*/ 		Scanner_ReadSym();
/*2305*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"expected closing `)' in typecast");
/*2306*/ 		Scanner_ReadSym();
/*2307*/ 		Expressions_r = Expressions_ParseTerm();
/*2308*/ 		Expressions_r = Operators_EvalValueConversion(Expressions_r, Globals_int_type);
/*2310*/ 		break;

/*2310*/ 		case 68:
/*2311*/ 		Scanner_ReadSym();
/*2312*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"expected closing `)' in typecast");
/*2313*/ 		Scanner_ReadSym();
/*2314*/ 		Expressions_r = Expressions_ParseTerm();
/*2315*/ 		Expressions_r = Operators_EvalValueConversion(Expressions_r, Globals_float_type);
/*2317*/ 		break;

/*2317*/ 		case 69:
/*2318*/ 		Scanner_ReadSym();
/*2319*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"expected closing `)' in typecast");
/*2320*/ 		Scanner_ReadSym();
/*2321*/ 		Expressions_r = Expressions_ParseTerm();
/*2322*/ 		Expressions_r = Operators_EvalValueConversion(Expressions_r, Globals_string_type);
/*2324*/ 		break;

/*2324*/ 		case 70:
/*2326*/ 		Scanner_ReadSym();
/*2327*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"expected closing `)' in typecast");
/*2328*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\150,\0,\0,\0)"forbidden `(array)' typecast. Hint: maybe you should use the formal typecast `/*. array... .*/' instead.");
/*2329*/ 		Scanner_ReadSym();
/*2330*/ 		Expressions_r = Expressions_ParseTerm();
/*2331*/ 		Expressions_r = (
/*2331*/ 			push((char*) alloc_RECORD(16, 2)),
/*2331*/ 			push((char*) (
/*2331*/ 				push((char*) alloc_RECORD(24, 2)),
/*2331*/ 				*(int*) (tos()+16) = 6,
/*2331*/ 				*(int*) (tos()+20) = 1,
/*2331*/ 				push((char*) NULL),
/*2331*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2331*/ 				push((char*) NULL),
/*2331*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2331*/ 				(RECORD*) pop()
/*2331*/ 			)),
/*2331*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2331*/ 			push((char*) NULL),
/*2332*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2333*/ 			(RECORD*) pop()
/*2333*/ 		);
/*2333*/ 		break;

/*2333*/ 		case 71:
/*2334*/ 		Scanner_ReadSym();
/*2335*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"expected `)' after typecast");
/*2336*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\136,\0,\0,\0)"forbidden `(object)' typecast. Hint: maybe you should use the formal `/*. CLASS .*/' typecast.");
/*2337*/ 		Scanner_ReadSym();
/*2338*/ 		Expressions_r = Expressions_ParseTerm();
/*2339*/ 		Expressions_r = (
/*2339*/ 			push((char*) alloc_RECORD(16, 2)),
/*2339*/ 			push((char*) (
/*2339*/ 				push((char*) alloc_RECORD(24, 2)),
/*2339*/ 				*(int*) (tos()+16) = 9,
/*2339*/ 				*(int*) (tos()+20) = 1,
/*2339*/ 				push((char*) NULL),
/*2339*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2339*/ 				push((char*) NULL),
/*2339*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2339*/ 				(RECORD*) pop()
/*2339*/ 			)),
/*2339*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2339*/ 			push((char*) NULL),
/*2340*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2341*/ 			(RECORD*) pop()
/*2341*/ 		);
/*2341*/ 		break;

/*2342*/ 		default:
/*2342*/ 		Expressions_r = Expressions_ParseExpr();
/*2343*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"missing `)'");
/*2344*/ 		Scanner_ReadSym();
/*2347*/ 		}
/*2347*/ 		break;

/*2347*/ 		case 149:
/*2349*/ 		Scanner_ReadSym();
/*2350*/ 		Expressions_t = Expressions_ParseType(FALSE);
/*2351*/ 		Scanner_Expect(150, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"expected closing `)' in formal typecast");
/*2352*/ 		Scanner_ReadSym();
/*2353*/ 		Expressions_r = Expressions_ParseTerm();
/*2354*/ 		Expressions_r = Operators_EvalTypeConversion(Expressions_r, Expressions_t);
/*2357*/ 		break;

/*2357*/ 		default:
/*2357*/ 		Scanner_UnexpectedSymbol();
/*2361*/ 		}
/*2361*/ 		return Expressions_r;
/*2366*/ 	}


/*2368*/ 	RECORD *
/*2368*/ 	Expressions_e18(void)
/*2368*/ 	{
/*2370*/ 		RECORD * Expressions_r = NULL;
/*2370*/ 		if( (((Scanner_sym == 52)) || ((Scanner_sym == 53))) ){
/*2371*/ 			Scanner_ReadSym();
/*2372*/ 			Expressions_ParseLHS(Globals_int_type);
/*2373*/ 			Expressions_r = (
/*2373*/ 				push((char*) alloc_RECORD(16, 2)),
/*2373*/ 				push((char*) Globals_int_type),
/*2373*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2373*/ 				push((char*) NULL),
/*2374*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2375*/ 				(RECORD*) pop()
/*2375*/ 			);
/*2375*/ 		} else {
/*2375*/ 			Expressions_r = Expressions_ParseTerm();
/*2377*/ 		}
/*2377*/ 		return Expressions_r;
/*2381*/ 	}


/*2383*/ 	RECORD *
/*2383*/ 	Expressions_e17(void)
/*2383*/ 	{
/*2385*/ 		RECORD * Expressions_r = NULL;
/*2385*/ 		if( (Scanner_sym == 54) ){
/*2386*/ 			Scanner_ReadSym();
/*2387*/ 			Expressions_r = Operators_EvalNot(Expressions_e17());
/*2388*/ 		} else if( (Scanner_sym == 40) ){
/*2389*/ 			Scanner_ReadSym();
/*2390*/ 			Expressions_r = Operators_EvalUnaryPlusMinus(FALSE, Expressions_e17());
/*2391*/ 		} else if( (Scanner_sym == 41) ){
/*2392*/ 			Scanner_ReadSym();
/*2393*/ 			Expressions_r = Operators_EvalUnaryPlusMinus(TRUE, Expressions_e17());
/*2394*/ 		} else if( (Scanner_sym == 90) ){
/*2395*/ 			Scanner_ReadSym();
/*2396*/ 			Expressions_r = Operators_EvalBitNot(Expressions_e17());
/*2397*/ 		} else if( (Scanner_sym == 59) ){
/*2399*/ 			Scanner_ReadSym();
/*2400*/ 			m2_inc(&Expressions_handle_error, 1);
/*2401*/ 			Expressions_r = Expressions_e17();
/*2402*/ 			m2_inc(&Expressions_handle_error, -1);
/*2404*/ 		} else {
/*2404*/ 			Expressions_r = Expressions_e18();
/*2406*/ 		}
/*2406*/ 		return Expressions_r;
/*2410*/ 	}


/*2411*/ 	RECORD *
/*2411*/ 	Expressions_e16(void)
/*2411*/ 	{
/*2411*/ 		RECORD * Expressions_t = NULL;
/*2411*/ 		RECORD * Expressions_r = NULL;
/*2413*/ 		int Expressions_op = 0;
/*2413*/ 		Expressions_r = Expressions_e17();
/*2414*/ 		while( (((Scanner_sym == 42)) || ((Scanner_sym == 43)) || ((Scanner_sym == 74))) ){
/*2415*/ 			Expressions_op = Scanner_sym;
/*2416*/ 			Scanner_ReadSym();
/*2417*/ 			Expressions_t = Expressions_e17();
/*2418*/ 			switch(Expressions_op){

/*2419*/ 			case 42:
/*2419*/ 			Expressions_r = Operators_EvalMult(Expressions_r, Expressions_t);
/*2420*/ 			break;

/*2420*/ 			case 43:
/*2420*/ 			Expressions_r = Operators_EvalDiv(Expressions_r, Expressions_t);
/*2421*/ 			break;

/*2421*/ 			case 74:
/*2421*/ 			Expressions_r = Operators_EvalMod(Expressions_r, Expressions_t);
/*2423*/ 			break;

/*2423*/ 			default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 330);
/*2424*/ 			}
/*2424*/ 		}
/*2424*/ 		return Expressions_r;
/*2428*/ 	}


/*2429*/ 	RECORD *
/*2429*/ 	Expressions_e15(void)
/*2429*/ 	{
/*2429*/ 		RECORD * Expressions_q = NULL;
/*2429*/ 		RECORD * Expressions_r = NULL;
/*2431*/ 		int Expressions_op = 0;
/*2431*/ 		Expressions_r = Expressions_e16();
/*2432*/ 		while( (((Scanner_sym == 40)) || ((Scanner_sym == 41)) || ((Scanner_sym == 60))) ){
/*2433*/ 			Expressions_op = Scanner_sym;
/*2434*/ 			Scanner_ReadSym();
/*2435*/ 			Expressions_q = Expressions_e16();
/*2436*/ 			switch(Expressions_op){

/*2437*/ 			case 40:
/*2437*/ 			Expressions_r = Operators_EvalPlus(Expressions_r, Expressions_q);
/*2438*/ 			break;

/*2438*/ 			case 41:
/*2438*/ 			Expressions_r = Operators_EvalMinus(Expressions_r, Expressions_q);
/*2439*/ 			break;

/*2439*/ 			case 60:
/*2439*/ 			Expressions_r = Operators_EvalPeriod(Expressions_r, Expressions_q);
/*2441*/ 			break;

/*2441*/ 			default: m2runtime_missing_case_in_switch(Expressions_0err_entry_get, 331);
/*2442*/ 			}
/*2442*/ 		}
/*2442*/ 		return Expressions_r;
/*2446*/ 	}


/*2447*/ 	RECORD *
/*2447*/ 	Expressions_e14(void)
/*2447*/ 	{
/*2447*/ 		RECORD * Expressions_t = NULL;
/*2447*/ 		RECORD * Expressions_r = NULL;
/*2449*/ 		int Expressions_op = 0;
/*2449*/ 		Expressions_r = Expressions_e15();
/*2450*/ 		while( (((Scanner_sym == 86)) || ((Scanner_sym == 87))) ){
/*2451*/ 			Expressions_op = Scanner_sym;
/*2452*/ 			Scanner_ReadSym();
/*2453*/ 			Expressions_t = Expressions_e15();
/*2454*/ 			if( (Expressions_op == 86) ){
/*2455*/ 				Expressions_r = Operators_EvalLShift(Expressions_r, Expressions_t);
/*2457*/ 			} else {
/*2457*/ 				Expressions_r = Operators_EvalRShift(Expressions_r, Expressions_t);
/*2460*/ 			}
/*2460*/ 		}
/*2460*/ 		return Expressions_r;
/*2464*/ 	}


/*2465*/ 	RECORD *
/*2465*/ 	Expressions_e13(void)
/*2465*/ 	{
/*2465*/ 		RECORD * Expressions_r = NULL;
/*2467*/ 		STRING * Expressions_n = NULL;
/*2467*/ 		Expressions_r = Expressions_e14();
/*2468*/ 		switch(Scanner_sym){

/*2469*/ 		case 50:
/*2469*/ 		Expressions_n = m2runtime_CHR(60);
/*2470*/ 		break;

/*2470*/ 		case 51:
/*2470*/ 		Expressions_n = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"<=";
/*2471*/ 		break;

/*2471*/ 		case 48:
/*2471*/ 		Expressions_n = m2runtime_CHR(62);
/*2472*/ 		break;

/*2472*/ 		case 49:
/*2472*/ 		Expressions_n = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">=";
/*2473*/ 		break;

/*2473*/ 		default:
/*2473*/ 		return Expressions_r;
/*2475*/ 		}
/*2475*/ 		Scanner_ReadSym();
/*2476*/ 		return Operators_EvalCmp(Expressions_n, Expressions_r, Expressions_e14());
/*2480*/ 	}


/*2481*/ 	RECORD *
/*2481*/ 	Expressions_e12(void)
/*2481*/ 	{
/*2483*/ 		RECORD * Expressions_r = NULL;
/*2483*/ 		Expressions_r = Expressions_e13();
/*2484*/ 		switch(Scanner_sym){

/*2486*/ 		case 44:
/*2487*/ 		Scanner_ReadSym();
/*2488*/ 		return Operators_EvalEq((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==", Expressions_r, Expressions_e13());
/*2490*/ 		break;

/*2490*/ 		case 46:
/*2491*/ 		Scanner_ReadSym();
/*2492*/ 		return Operators_EvalEq((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=", Expressions_r, Expressions_e13());
/*2494*/ 		break;

/*2494*/ 		case 45:
/*2494*/ 		case 47:
/*2495*/ 		if( Expressions_r == NULL ){
/*2497*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 332) == Globals_void_type ){
/*2498*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"invalid operand of the type void");
/*2500*/ 		}
/*2500*/ 		Scanner_ReadSym();
/*2501*/ 		if( Expressions_r == NULL ){
/*2503*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 333) == Globals_void_type ){
/*2504*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"invalid operand of the type void");
/*2506*/ 		}
/*2506*/ 		Expressions_r = Expressions_e13();
/*2507*/ 		return (
/*2507*/ 			push((char*) alloc_RECORD(16, 2)),
/*2507*/ 			push((char*) Globals_boolean_type),
/*2507*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2507*/ 			push((char*) NULL),
/*2508*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2510*/ 			(RECORD*) pop()
/*2510*/ 		);
/*2510*/ 		break;

/*2510*/ 		default:
/*2510*/ 		return Expressions_r;
/*2513*/ 		}
/*2513*/ 		m2runtime_missing_return(Expressions_0err_entry_get, 334);
/*2513*/ 		return NULL;
/*2515*/ 	}


/*2516*/ 	RECORD *
/*2516*/ 	Expressions_e11(void)
/*2516*/ 	{
/*2518*/ 		RECORD * Expressions_r = NULL;
/*2518*/ 		Expressions_r = Expressions_e12();
/*2519*/ 		while( (Scanner_sym == 73) ){
/*2520*/ 			Scanner_ReadSym();
/*2521*/ 			Expressions_r = Operators_EvalBitAnd(Expressions_r, Expressions_e12());
/*2523*/ 		}
/*2523*/ 		return Expressions_r;
/*2527*/ 	}


/*2528*/ 	RECORD *
/*2528*/ 	Expressions_e10(void)
/*2528*/ 	{
/*2530*/ 		RECORD * Expressions_r = NULL;
/*2530*/ 		Expressions_r = Expressions_e11();
/*2531*/ 		while( (Scanner_sym == 88) ){
/*2532*/ 			Scanner_ReadSym();
/*2533*/ 			Expressions_r = Operators_EvalBitXor(Expressions_r, Expressions_e11());
/*2535*/ 		}
/*2535*/ 		return Expressions_r;
/*2539*/ 	}


/*2540*/ 	RECORD *
/*2540*/ 	Expressions_e9(void)
/*2540*/ 	{
/*2542*/ 		RECORD * Expressions_r = NULL;
/*2542*/ 		Expressions_r = Expressions_e10();
/*2543*/ 		while( (Scanner_sym == 72) ){
/*2544*/ 			Scanner_ReadSym();
/*2545*/ 			Expressions_r = Operators_EvalBitOr(Expressions_r, Expressions_e10());
/*2547*/ 		}
/*2547*/ 		return Expressions_r;
/*2551*/ 	}


/*2552*/ 	RECORD *
/*2552*/ 	Expressions_e8(void)
/*2552*/ 	{
/*2554*/ 		RECORD * Expressions_r = NULL;
/*2554*/ 		Expressions_r = Expressions_e9();
/*2555*/ 		while( (Scanner_sym == 57) ){
/*2556*/ 			Scanner_ReadSym();
/*2557*/ 			Expressions_r = Operators_EvalAnd((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"&&", Expressions_r, Expressions_e9());
/*2559*/ 		}
/*2559*/ 		return Expressions_r;
/*2563*/ 	}


/*2564*/ 	RECORD *
/*2564*/ 	Expressions_e7(void)
/*2564*/ 	{
/*2566*/ 		RECORD * Expressions_r = NULL;
/*2566*/ 		Expressions_r = Expressions_e8();
/*2567*/ 		while( (Scanner_sym == 55) ){
/*2568*/ 			Scanner_ReadSym();
/*2569*/ 			Expressions_r = Operators_EvalOr((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"||", Expressions_r, Expressions_e8());
/*2571*/ 		}
/*2571*/ 		return Expressions_r;
/*2575*/ 	}


/*2576*/ 	RECORD *
/*2576*/ 	Expressions_e6(void)
/*2576*/ 	{
/*2578*/ 		RECORD * Expressions_b = NULL;
/*2578*/ 		RECORD * Expressions_a = NULL;
/*2578*/ 		RECORD * Expressions_r = NULL;
/*2579*/ 		if( (Scanner_sym == 115) ){
/*2580*/ 			Scanner_ReadSym();
/*2581*/ 			Expressions_r = Expressions_e6();
/*2582*/ 			if( Expressions_r == NULL ){
/*2584*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 335) != Globals_string_type ){
/*2585*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"expected a string for the `print' operator");
/*2587*/ 			}
/*2587*/ 			return (
/*2587*/ 				push((char*) alloc_RECORD(16, 2)),
/*2587*/ 				push((char*) Globals_int_type),
/*2587*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2587*/ 				push((char*) m2runtime_CHR(49)),
/*2588*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2589*/ 				(RECORD*) pop()
/*2589*/ 			);
/*2590*/ 		}
/*2590*/ 		Expressions_r = Expressions_e7();
/*2591*/ 		while( (Scanner_sym == 30) ){
/*2592*/ 			Expressions_CheckBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"EXPR ? ...:...", Expressions_r);
/*2593*/ 			Scanner_ReadSym();
/*2594*/ 			Expressions_a = Expressions_ParseExpr();
/*2595*/ 			Scanner_Expect(18, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `:'");
/*2596*/ 			Scanner_ReadSym();
/*2597*/ 			Expressions_b = Expressions_ParseExpr();
/*2598*/ 			if( ((Expressions_a != NULL) && (Expressions_b != NULL) && !Types_SameType((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_a, 8, Expressions_0err_entry_get, 336), (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_b, 8, Expressions_0err_entry_get, 337))) ){
/*2599*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"`...? EXPR1 : EXPR2': type mismatch: EXPR1 is ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_a, 8, Expressions_0err_entry_get, 338)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)", EXPR2 is ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_b, 8, Expressions_0err_entry_get, 339)), 1));
/*2603*/ 			}
/*2603*/ 			Expressions_r = Expressions_a;
/*2605*/ 		}
/*2605*/ 		return Expressions_r;
/*2609*/ 	}


/*2610*/ 	RECORD *
/*2610*/ 	Expressions_e5(void)
/*2610*/ 	{
/*2612*/ 		RECORD * Expressions_r = NULL;
/*2612*/ 		Expressions_r = Expressions_e6();
/*2613*/ 		if( Expressions_IsAssignOp(Scanner_sym) ){
/*2614*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\151,\0,\0,\0)"invalid left hand side in assignment. Hint: you might want to use the comparison operators `==' or `==='.");
/*2615*/ 			Scanner_ReadSym();
/*2616*/ 			Expressions_r = Expressions_e6();
/*2618*/ 		}
/*2618*/ 		return Expressions_r;
/*2622*/ 	}


/*2623*/ 	RECORD *
/*2623*/ 	Expressions_e4(void)
/*2623*/ 	{
/*2625*/ 		RECORD * Expressions_r = NULL;
/*2625*/ 		Expressions_r = Expressions_e5();
/*2626*/ 		while( (Scanner_sym == 58) ){
/*2627*/ 			Scanner_ReadSym();
/*2628*/ 			Expressions_r = Operators_EvalAnd((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"and", Expressions_r, Expressions_e5());
/*2630*/ 		}
/*2630*/ 		return Expressions_r;
/*2634*/ 	}


/*2635*/ 	RECORD *
/*2635*/ 	Expressions_e3(void)
/*2635*/ 	{
/*2637*/ 		RECORD * Expressions_r = NULL;
/*2637*/ 		Expressions_r = Expressions_e4();
/*2638*/ 		while( (Scanner_sym == 89) ){
/*2639*/ 			Scanner_ReadSym();
/*2640*/ 			Expressions_r = Operators_EvalXor(Expressions_r, Expressions_e4());
/*2642*/ 		}
/*2642*/ 		return Expressions_r;
/*2646*/ 	}

/*2648*/ 	RECORD * Expressions_r = NULL;
/*2648*/ 	Expressions_r = Expressions_e3();
/*2649*/ 	while( (Scanner_sym == 56) ){
/*2650*/ 		Scanner_ReadSym();
/*2651*/ 		Expressions_r = Operators_EvalOr((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"or", Expressions_r, Expressions_e3());
/*2653*/ 	}
/*2653*/ 	return Expressions_r;
/*2657*/ }


/*2658*/ RECORD *
/*2658*/ Expressions_ParseExprList(void)
/*2658*/ {
/*2660*/ 	RECORD * Expressions_r = NULL;
/*2661*/ 	do{
/*2661*/ 		Expressions_r = Expressions_ParseExpr();
/*2662*/ 		if( (Scanner_sym != 16) ){
/*2663*/ 			return Expressions_r;
/*2665*/ 		}
/*2665*/ 		Scanner_ReadSym();
/*2668*/ 	}while(TRUE);
/*2668*/ 	m2runtime_missing_return(Expressions_0err_entry_get, 340);
/*2668*/ 	return NULL;
/*2670*/ }


/*2672*/ RECORD *
/*2672*/ Expressions_ParseStaticExpr(void)
/*2672*/ {

/*2674*/ 	RECORD *
/*2674*/ 	Expressions_ParseStaticExpr_ClassConst(RECORD *Expressions_cl)
/*2674*/ 	{
/*2676*/ 		return Expressions_ParseClassStaticAccess(Expressions_cl);
/*2680*/ 	}

/*2681*/ 	int Expressions_sign = 0;
/*2682*/ 	RECORD * Expressions_r = NULL;
/*2683*/ 	STRING * Expressions_id = NULL;
/*2684*/ 	RECORD * Expressions_class = NULL;
/*2685*/ 	RECORD * Expressions_c = NULL;
/*2687*/ 	RECORD * Expressions_t = NULL;
/*2687*/ 	if( (Scanner_sym == 63) ){
/*2688*/ 		Expressions_r = (
/*2688*/ 			push((char*) alloc_RECORD(16, 2)),
/*2688*/ 			push((char*) Globals_null_type),
/*2688*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2688*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL"),
/*2689*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2690*/ 			(RECORD*) pop()
/*2690*/ 		);
/*2690*/ 		Scanner_ReadSym();
/*2692*/ 	} else if( (Scanner_sym == 65) ){
/*2693*/ 		Expressions_r = (
/*2693*/ 			push((char*) alloc_RECORD(16, 2)),
/*2693*/ 			push((char*) Globals_boolean_type),
/*2693*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2693*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE"),
/*2694*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2694*/ 			(RECORD*) pop()
/*2694*/ 		);
/*2694*/ 		Scanner_ReadSym();
/*2696*/ 	} else if( (Scanner_sym == 66) ){
/*2697*/ 		Expressions_r = (
/*2697*/ 			push((char*) alloc_RECORD(16, 2)),
/*2697*/ 			push((char*) Globals_boolean_type),
/*2697*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2697*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE"),
/*2698*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2698*/ 			(RECORD*) pop()
/*2698*/ 		);
/*2698*/ 		Scanner_ReadSym();
/*2700*/ 	} else if( (((Scanner_sym == 40)) || ((Scanner_sym == 41))) ){
/*2701*/ 		if( (Scanner_sym == 41) ){
/*2702*/ 			Expressions_sign = TRUE;
/*2703*/ 			Scanner_ReadSym();
/*2705*/ 		}
/*2705*/ 		Expressions_r = Expressions_ParseStaticExpr();
/*2706*/ 		if( Expressions_r != NULL ){
/*2707*/ 			if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 341) == Globals_int_type ){
/*2708*/ 				if( Expressions_sign ){
/*2709*/ 					Expressions_r = (
/*2709*/ 						push((char*) alloc_RECORD(16, 2)),
/*2709*/ 						push((char*) Globals_int_type),
/*2709*/ 						*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2709*/ 						push((char*) m2runtime_itos(-m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Expressions_r, 12, Expressions_0err_entry_get, 342)))),
/*2710*/ 						*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2711*/ 						(RECORD*) pop()
/*2711*/ 					);
/*2711*/ 				}
/*2711*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 343) == Globals_float_type ){
/*2712*/ 				if( Expressions_sign ){
/*2713*/ 					Expressions_r = (
/*2713*/ 						push((char*) alloc_RECORD(16, 2)),
/*2713*/ 						push((char*) Globals_float_type),
/*2713*/ 						*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2713*/ 						push((char*) m2runtime_rtos(-m2_stor((STRING *)m2runtime_dereference_rhs_RECORD(Expressions_r, 12, Expressions_0err_entry_get, 344)))),
/*2714*/ 						*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2715*/ 						(RECORD*) pop()
/*2715*/ 					);
/*2716*/ 				}
/*2716*/ 			} else {
/*2716*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"unary minus on non numeric value");
/*2719*/ 			}
/*2720*/ 		}
/*2720*/ 	} else if( (Scanner_sym == 38) ){
/*2721*/ 		Expressions_r = (
/*2721*/ 			push((char*) alloc_RECORD(16, 2)),
/*2721*/ 			push((char*) Globals_int_type),
/*2721*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2721*/ 			push((char*) Scanner_s),
/*2722*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2722*/ 			(RECORD*) pop()
/*2722*/ 		);
/*2722*/ 		Scanner_ReadSym();
/*2724*/ 	} else if( (Scanner_sym == 39) ){
/*2725*/ 		Expressions_r = (
/*2725*/ 			push((char*) alloc_RECORD(16, 2)),
/*2725*/ 			push((char*) Globals_float_type),
/*2725*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2725*/ 			push((char*) Scanner_s),
/*2726*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2726*/ 			(RECORD*) pop()
/*2726*/ 		);
/*2726*/ 		Scanner_ReadSym();
/*2728*/ 	} else if( (Scanner_sym == 33) ){
/*2729*/ 		Expressions_r = (
/*2729*/ 			push((char*) alloc_RECORD(16, 2)),
/*2729*/ 			push((char*) Globals_string_type),
/*2729*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2729*/ 			push((char*) Scanner_s),
/*2730*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*2730*/ 			(RECORD*) pop()
/*2730*/ 		);
/*2730*/ 		Scanner_ReadSym();
/*2732*/ 	} else if( (Scanner_sym == 34) ){
/*2733*/ 		Expressions_r = Expressions_ParseDoubleQuotedStringWithEmbeddedVars(TRUE);
/*2735*/ 	} else if( (Scanner_sym == 37) ){
/*2736*/ 		Expressions_r = Expressions_ParseDoubleQuotedStringWithEmbeddedVars(TRUE);
/*2738*/ 	} else if( (Scanner_sym == 29) ){
/*2739*/ 		Expressions_id = Scanner_s;
/*2740*/ 		Scanner_ReadSym();
/*2741*/ 		if( (Scanner_sym == 19) ){
/*2742*/ 			Expressions_class = Search_SearchClass(Expressions_id, TRUE);
/*2743*/ 			if( Expressions_class == NULL ){
/*2744*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"unknown class `", Expressions_id, m2runtime_CHR(39), 1));
/*2746*/ 			}
/*2746*/ 			Expressions_r = Expressions_ParseStaticExpr_ClassConst(Expressions_class);
/*2749*/ 		} else {
/*2749*/ 			Expressions_c = Accounting_AccountConstRHS(Expressions_id);
/*2750*/ 			Expressions_r = (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_c, 20, Expressions_0err_entry_get, 345);
/*2754*/ 		}
/*2754*/ 	} else if( (Scanner_sym == 103) ){
/*2755*/ 		if( (Globals_php_ver == 4) ){
/*2756*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"invalid `self::' (PHP 5)");
/*2758*/ 		}
/*2758*/ 		if( Globals_curr_class == NULL ){
/*2759*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"`self::': not inside a class");
/*2761*/ 		}
/*2761*/ 		Scanner_ReadSym();
/*2762*/ 		Scanner_Expect(19, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"expected `::'");
/*2763*/ 		Expressions_r = Expressions_ParseStaticExpr_ClassConst(Globals_curr_class);
/*2765*/ 	} else if( (Scanner_sym == 104) ){
/*2766*/ 		if( (Globals_php_ver == 4) ){
/*2767*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"invalid `parent::' (PHP 5)");
/*2769*/ 		}
/*2769*/ 		if( Globals_curr_class == NULL ){
/*2770*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"`parent::': not inside a class");
/*2772*/ 		}
/*2772*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 16, Expressions_0err_entry_get, 346) == NULL ){
/*2773*/ 			Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"invalid `parent::': class `", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 8, Expressions_0err_entry_get, 347), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' do not has a parent", 1));
/*2776*/ 		}
/*2776*/ 		Scanner_ReadSym();
/*2777*/ 		Scanner_Expect(19, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"expected `::'");
/*2778*/ 		Expressions_r = Expressions_ParseStaticExpr_ClassConst((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 16, Expressions_0err_entry_get, 348));
/*2780*/ 	} else if( (Scanner_sym == 70) ){
/*2781*/ 		Scanner_ReadSym();
/*2782*/ 		if( (Scanner_sym != 12) ){
/*2783*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"expected `(' after `array'");
/*2785*/ 		}
/*2785*/ 		Expressions_r = Expressions_ParseArray(TRUE);
/*2787*/ 	} else if( (Scanner_sym == 149) ){
/*2789*/ 		Scanner_ReadSym();
/*2790*/ 		Expressions_t = Expressions_ParseType(FALSE);
/*2791*/ 		Scanner_Expect(150, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"expected closing `)' in formal typecast");
/*2794*/ 		Scanner_ReadSym();
/*2795*/ 		Expressions_r = Expressions_ParseStaticExpr();
/*2796*/ 		Expressions_r = Operators_EvalTypeConversion(Expressions_r, Expressions_t);
/*2799*/ 	} else {
/*2799*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\106,\0,\0,\0)"invalid static expression -- expected string, constant or static array");
/*2803*/ 	}
/*2803*/ 	return Expressions_r;
/*2807*/ }


/*2808*/ RECORD *
/*2808*/ Expressions_ParseExprOfType(RECORD *Expressions_t)
/*2808*/ {
/*2810*/ 	RECORD * Expressions_r = NULL;
/*2810*/ 	Expressions_r = Expressions_ParseExpr();
/*2811*/ 	if( Expressions_r == NULL ){
/*2812*/ 		return NULL;
/*2813*/ 	} else if( Types_SameType(Expressions_t, (RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 349)) ){
/*2814*/ 		return Expressions_r;
/*2816*/ 	} else {
/*2816*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"found expression of the type `", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Expressions_r, 8, Expressions_0err_entry_get, 350)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"', expected type `", Types_TypeToString(Expressions_t), m2runtime_CHR(39), 1));
/*2818*/ 		return NULL;
/*2821*/ 	}
/*2821*/ 	m2runtime_missing_return(Expressions_0err_entry_get, 351);
/*2821*/ 	return NULL;
/*2823*/ }


char * Expressions_0func[] = {
    "CleanCurrentScope",
    "ResolveClassProperty",
    "DereferenceClassMethod",
    "ParseArrayType",
    "ParseType",
    "MatchArray",
    "LhsMatchRhs",
    "DereferenceLHS",
    "ParseLHS",
    "CheckActualArgument",
    "ParseArgsListCall",
    "ParseClassMethodCall",
    "DereferenceArray",
    "Dereference",
    "ParseFuncCall",
    "ParseArray",
    "ParseDoubleQuotedStringWithEmbeddedVars",
    "ParseList",
    "ParseClassStaticAccess",
    "ParseSelf",
    "ParseParent",
    "ParseExit",
    "CheckBoolean",
    "DereferenceGLOBALS",
    "ParseVarRHS",
    "ParseNew",
    "ParseClone",
    "ParseTerm",
    "e16",
    "e15",
    "e12",
    "e6",
    "ParseExprList",
    "ParseStaticExpr",
    "ParseExprOfType"
};

int Expressions_0err_entry[] = {
    0 /* CleanCurrentScope */, 29,
    0 /* CleanCurrentScope */, 29,
    0 /* CleanCurrentScope */, 31,
    0 /* CleanCurrentScope */, 31,
    0 /* CleanCurrentScope */, 31,
    0 /* CleanCurrentScope */, 31,
    0 /* CleanCurrentScope */, 32,
    0 /* CleanCurrentScope */, 32,
    0 /* CleanCurrentScope */, 34,
    0 /* CleanCurrentScope */, 34,
    0 /* CleanCurrentScope */, 34,
    0 /* CleanCurrentScope */, 35,
    0 /* CleanCurrentScope */, 38,
    1 /* ResolveClassProperty */, 67,
    1 /* ResolveClassProperty */, 74,
    1 /* ResolveClassProperty */, 82,
    1 /* ResolveClassProperty */, 90,
    1 /* ResolveClassProperty */, 93,
    1 /* ResolveClassProperty */, 97,
    1 /* ResolveClassProperty */, 99,
    1 /* ResolveClassProperty */, 102,
    1 /* ResolveClassProperty */, 104,
    2 /* DereferenceClassMethod */, 149,
    2 /* DereferenceClassMethod */, 155,
    2 /* DereferenceClassMethod */, 158,
    2 /* DereferenceClassMethod */, 158,
    2 /* DereferenceClassMethod */, 160,
    2 /* DereferenceClassMethod */, 160,
    2 /* DereferenceClassMethod */, 168,
    2 /* DereferenceClassMethod */, 173,
    2 /* DereferenceClassMethod */, 176,
    2 /* DereferenceClassMethod */, 185,
    2 /* DereferenceClassMethod */, 187,
    2 /* DereferenceClassMethod */, 189,
    2 /* DereferenceClassMethod */, 193,
    2 /* DereferenceClassMethod */, 196,
    2 /* DereferenceClassMethod */, 205,
    2 /* DereferenceClassMethod */, 207,
    2 /* DereferenceClassMethod */, 209,
    2 /* DereferenceClassMethod */, 213,
    2 /* DereferenceClassMethod */, 218,
    2 /* DereferenceClassMethod */, 223,
    2 /* DereferenceClassMethod */, 225,
    2 /* DereferenceClassMethod */, 229,
    2 /* DereferenceClassMethod */, 230,
    2 /* DereferenceClassMethod */, 234,
    2 /* DereferenceClassMethod */, 239,
    2 /* DereferenceClassMethod */, 243,
    2 /* DereferenceClassMethod */, 245,
    3 /* ParseArrayType */, 265,
    3 /* ParseArrayType */, 268,
    3 /* ParseArrayType */, 274,
    3 /* ParseArrayType */, 276,
    4 /* ParseType */, 321,
    4 /* ParseType */, 339,
    4 /* ParseType */, 351,
    4 /* ParseType */, 361,
    4 /* ParseType */, 366,
    4 /* ParseType */, 366,
    4 /* ParseType */, 370,
    5 /* MatchArray */, 393,
    5 /* MatchArray */, 400,
    5 /* MatchArray */, 403,
    5 /* MatchArray */, 413,
    6 /* LhsMatchRhs */, 417,
    6 /* LhsMatchRhs */, 424,
    6 /* LhsMatchRhs */, 430,
    6 /* LhsMatchRhs */, 432,
    6 /* LhsMatchRhs */, 439,
    6 /* LhsMatchRhs */, 445,
    6 /* LhsMatchRhs */, 451,
    6 /* LhsMatchRhs */, 457,
    6 /* LhsMatchRhs */, 463,
    6 /* LhsMatchRhs */, 466,
    6 /* LhsMatchRhs */, 466,
    6 /* LhsMatchRhs */, 467,
    6 /* LhsMatchRhs */, 467,
    6 /* LhsMatchRhs */, 471,
    6 /* LhsMatchRhs */, 477,
    6 /* LhsMatchRhs */, 483,
    6 /* LhsMatchRhs */, 487,
    6 /* LhsMatchRhs */, 489,
    6 /* LhsMatchRhs */, 491,
    6 /* LhsMatchRhs */, 491,
    6 /* LhsMatchRhs */, 498,
    7 /* DereferenceLHS */, 532,
    7 /* DereferenceLHS */, 533,
    7 /* DereferenceLHS */, 540,
    7 /* DereferenceLHS */, 541,
    7 /* DereferenceLHS */, 542,
    7 /* DereferenceLHS */, 543,
    7 /* DereferenceLHS */, 545,
    7 /* DereferenceLHS */, 550,
    7 /* DereferenceLHS */, 551,
    7 /* DereferenceLHS */, 554,
    7 /* DereferenceLHS */, 564,
    7 /* DereferenceLHS */, 566,
    7 /* DereferenceLHS */, 575,
    7 /* DereferenceLHS */, 581,
    7 /* DereferenceLHS */, 582,
    7 /* DereferenceLHS */, 585,
    7 /* DereferenceLHS */, 586,
    7 /* DereferenceLHS */, 590,
    7 /* DereferenceLHS */, 595,
    7 /* DereferenceLHS */, 617,
    7 /* DereferenceLHS */, 620,
    7 /* DereferenceLHS */, 623,
    7 /* DereferenceLHS */, 636,
    7 /* DereferenceLHS */, 643,
    7 /* DereferenceLHS */, 647,
    7 /* DereferenceLHS */, 684,
    8 /* ParseLHS */, 732,
    8 /* ParseLHS */, 750,
    8 /* ParseLHS */, 772,
    8 /* ParseLHS */, 783,
    8 /* ParseLHS */, 798,
    9 /* CheckActualArgument */, 829,
    9 /* CheckActualArgument */, 839,
    9 /* CheckActualArgument */, 840,
    9 /* CheckActualArgument */, 844,
    9 /* CheckActualArgument */, 847,
    9 /* CheckActualArgument */, 848,
    10 /* ParseArgsListCall */, 860,
    10 /* ParseArgsListCall */, 870,
    10 /* ParseArgsListCall */, 871,
    10 /* ParseArgsListCall */, 873,
    10 /* ParseArgsListCall */, 875,
    10 /* ParseArgsListCall */, 875,
    10 /* ParseArgsListCall */, 877,
    10 /* ParseArgsListCall */, 877,
    10 /* ParseArgsListCall */, 878,
    10 /* ParseArgsListCall */, 879,
    10 /* ParseArgsListCall */, 880,
    10 /* ParseArgsListCall */, 881,
    10 /* ParseArgsListCall */, 881,
    10 /* ParseArgsListCall */, 882,
    10 /* ParseArgsListCall */, 888,
    10 /* ParseArgsListCall */, 888,
    10 /* ParseArgsListCall */, 906,
    11 /* ParseClassMethodCall */, 941,
    11 /* ParseClassMethodCall */, 942,
    11 /* ParseClassMethodCall */, 943,
    11 /* ParseClassMethodCall */, 944,
    11 /* ParseClassMethodCall */, 945,
    11 /* ParseClassMethodCall */, 946,
    11 /* ParseClassMethodCall */, 947,
    11 /* ParseClassMethodCall */, 948,
    11 /* ParseClassMethodCall */, 949,
    11 /* ParseClassMethodCall */, 951,
    11 /* ParseClassMethodCall */, 951,
    11 /* ParseClassMethodCall */, 952,
    11 /* ParseClassMethodCall */, 955,
    11 /* ParseClassMethodCall */, 955,
    11 /* ParseClassMethodCall */, 958,
    11 /* ParseClassMethodCall */, 967,
    11 /* ParseClassMethodCall */, 969,
    11 /* ParseClassMethodCall */, 972,
    11 /* ParseClassMethodCall */, 972,
    11 /* ParseClassMethodCall */, 975,
    12 /* DereferenceArray */, 1030,
    12 /* DereferenceArray */, 1034,
    12 /* DereferenceArray */, 1039,
    12 /* DereferenceArray */, 1040,
    12 /* DereferenceArray */, 1041,
    12 /* DereferenceArray */, 1042,
    12 /* DereferenceArray */, 1044,
    12 /* DereferenceArray */, 1049,
    12 /* DereferenceArray */, 1050,
    12 /* DereferenceArray */, 1060,
    12 /* DereferenceArray */, 1062,
    12 /* DereferenceArray */, 1068,
    12 /* DereferenceArray */, 1071,
    12 /* DereferenceArray */, 1074,
    12 /* DereferenceArray */, 1081,
    12 /* DereferenceArray */, 1085,
    12 /* DereferenceArray */, 1086,
    12 /* DereferenceArray */, 1089,
    12 /* DereferenceArray */, 1090,
    12 /* DereferenceArray */, 1094,
    12 /* DereferenceArray */, 1099,
    12 /* DereferenceArray */, 1101,
    12 /* DereferenceArray */, 1120,
    13 /* Dereference */, 1137,
    13 /* Dereference */, 1148,
    13 /* Dereference */, 1150,
    13 /* Dereference */, 1159,
    13 /* Dereference */, 1162,
    13 /* Dereference */, 1165,
    13 /* Dereference */, 1165,
    13 /* Dereference */, 1191,
    13 /* Dereference */, 1197,
    13 /* Dereference */, 1201,
    13 /* Dereference */, 1257,
    13 /* Dereference */, 1304,
    13 /* Dereference */, 1317,
    13 /* Dereference */, 1318,
    13 /* Dereference */, 1334,
    13 /* Dereference */, 1342,
    13 /* Dereference */, 1342,
    13 /* Dereference */, 1342,
    13 /* Dereference */, 1342,
    13 /* Dereference */, 1344,
    13 /* Dereference */, 1369,
    14 /* ParseFuncCall */, 1391,
    14 /* ParseFuncCall */, 1392,
    14 /* ParseFuncCall */, 1398,
    14 /* ParseFuncCall */, 1400,
    14 /* ParseFuncCall */, 1402,
    14 /* ParseFuncCall */, 1403,
    14 /* ParseFuncCall */, 1405,
    14 /* ParseFuncCall */, 1408,
    14 /* ParseFuncCall */, 1411,
    14 /* ParseFuncCall */, 1414,
    14 /* ParseFuncCall */, 1414,
    14 /* ParseFuncCall */, 1416,
    14 /* ParseFuncCall */, 1416,
    14 /* ParseFuncCall */, 1424,
    14 /* ParseFuncCall */, 1426,
    14 /* ParseFuncCall */, 1426,
    14 /* ParseFuncCall */, 1426,
    14 /* ParseFuncCall */, 1428,
    15 /* ParseArray */, 1449,
    15 /* ParseArray */, 1452,
    15 /* ParseArray */, 1463,
    15 /* ParseArray */, 1464,
    15 /* ParseArray */, 1464,
    15 /* ParseArray */, 1465,
    15 /* ParseArray */, 1466,
    15 /* ParseArray */, 1466,
    15 /* ParseArray */, 1468,
    15 /* ParseArray */, 1477,
    15 /* ParseArray */, 1477,
    15 /* ParseArray */, 1483,
    15 /* ParseArray */, 1483,
    15 /* ParseArray */, 1483,
    15 /* ParseArray */, 1505,
    15 /* ParseArray */, 1506,
    15 /* ParseArray */, 1506,
    15 /* ParseArray */, 1508,
    15 /* ParseArray */, 1508,
    15 /* ParseArray */, 1510,
    15 /* ParseArray */, 1511,
    15 /* ParseArray */, 1511,
    15 /* ParseArray */, 1513,
    15 /* ParseArray */, 1513,
    15 /* ParseArray */, 1516,
    15 /* ParseArray */, 1527,
    15 /* ParseArray */, 1527,
    15 /* ParseArray */, 1529,
    15 /* ParseArray */, 1529,
    15 /* ParseArray */, 1535,
    15 /* ParseArray */, 1535,
    15 /* ParseArray */, 1535,
    15 /* ParseArray */, 1537,
    15 /* ParseArray */, 1538,
    15 /* ParseArray */, 1538,
    15 /* ParseArray */, 1539,
    15 /* ParseArray */, 1539,
    16 /* ParseDoubleQuotedStringWithEmbeddedVars */, 1563,
    17 /* ParseList */, 1602,
    17 /* ParseList */, 1602,
    17 /* ParseList */, 1603,
    18 /* ParseClassStaticAccess */, 1648,
    18 /* ParseClassStaticAccess */, 1650,
    18 /* ParseClassStaticAccess */, 1686,
    18 /* ParseClassStaticAccess */, 1691,
    18 /* ParseClassStaticAccess */, 1694,
    18 /* ParseClassStaticAccess */, 1698,
    18 /* ParseClassStaticAccess */, 1706,
    19 /* ParseSelf */, 1721,
    20 /* ParseParent */, 1730,
    20 /* ParseParent */, 1731,
    20 /* ParseParent */, 1734,
    20 /* ParseParent */, 1736,
    21 /* ParseExit */, 1758,
    21 /* ParseExit */, 1758,
    22 /* CheckBoolean */, 1780,
    22 /* CheckBoolean */, 1780,
    22 /* CheckBoolean */, 1814,
    23 /* DereferenceGLOBALS */, 1847,
    23 /* DereferenceGLOBALS */, 1849,
    23 /* DereferenceGLOBALS */, 1852,
    24 /* ParseVarRHS */, 1914,
    24 /* ParseVarRHS */, 1925,
    24 /* ParseVarRHS */, 1935,
    24 /* ParseVarRHS */, 1946,
    24 /* ParseVarRHS */, 1953,
    24 /* ParseVarRHS */, 1958,
    24 /* ParseVarRHS */, 1969,
    24 /* ParseVarRHS */, 1973,
    24 /* ParseVarRHS */, 1979,
    24 /* ParseVarRHS */, 1983,
    25 /* ParseNew */, 2038,
    25 /* ParseNew */, 2050,
    25 /* ParseNew */, 2050,
    25 /* ParseNew */, 2052,
    25 /* ParseNew */, 2063,
    25 /* ParseNew */, 2067,
    25 /* ParseNew */, 2073,
    25 /* ParseNew */, 2075,
    25 /* ParseNew */, 2075,
    25 /* ParseNew */, 2080,
    25 /* ParseNew */, 2081,
    25 /* ParseNew */, 2091,
    25 /* ParseNew */, 2109,
    25 /* ParseNew */, 2110,
    25 /* ParseNew */, 2111,
    25 /* ParseNew */, 2114,
    25 /* ParseNew */, 2116,
    25 /* ParseNew */, 2121,
    25 /* ParseNew */, 2122,
    25 /* ParseNew */, 2122,
    25 /* ParseNew */, 2123,
    25 /* ParseNew */, 2123,
    25 /* ParseNew */, 2125,
    25 /* ParseNew */, 2126,
    25 /* ParseNew */, 2129,
    25 /* ParseNew */, 2133,
    25 /* ParseNew */, 2136,
    25 /* ParseNew */, 2136,
    25 /* ParseNew */, 2138,
    25 /* ParseNew */, 2138,
    25 /* ParseNew */, 2146,
    25 /* ParseNew */, 2149,
    26 /* ParseClone */, 2163,
    26 /* ParseClone */, 2163,
    26 /* ParseClone */, 2165,
    26 /* ParseClone */, 2165,
    26 /* ParseClone */, 2174,
    27 /* ParseTerm */, 2259,
    28 /* e16 */, 2422,
    29 /* e15 */, 2440,
    30 /* e12 */, 2497,
    30 /* e12 */, 2503,
    30 /* e12 */, 2512,
    31 /* e6 */, 2584,
    31 /* e6 */, 2598,
    31 /* e6 */, 2598,
    31 /* e6 */, 2600,
    31 /* e6 */, 2601,
    32 /* ParseExprList */, 2667,
    33 /* ParseStaticExpr */, 2707,
    33 /* ParseStaticExpr */, 2709,
    33 /* ParseStaticExpr */, 2711,
    33 /* ParseStaticExpr */, 2713,
    33 /* ParseStaticExpr */, 2750,
    33 /* ParseStaticExpr */, 2772,
    33 /* ParseStaticExpr */, 2773,
    33 /* ParseStaticExpr */, 2778,
    34 /* ParseExprOfType */, 2813,
    34 /* ParseExprOfType */, 2816,
    34 /* ParseExprOfType */, 2820
};

void Expressions_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Expressions";
    *f = Expressions_0func[ Expressions_0err_entry[2*i] ];
    *l = Expressions_0err_entry[2*i + 1];
}
