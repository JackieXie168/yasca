/* IMPLEMENTATION MODULE Classes */
#define M2_IMPORT_Classes

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

void Classes_0err_entry_get(int i, char **m, char **f, int *l);

/* 11*/ int
/* 11*/ Classes_IsSubclassOf(RECORD *Classes_child, RECORD *Classes_parent)
/* 11*/ {
/* 12*/ 	int Classes_i = 0;
/* 14*/ 	ARRAY * Classes_c = NULL;
/* 14*/ 	if( ((Classes_child == NULL) || (Classes_parent == NULL)) ){
/* 15*/ 		return FALSE;
/* 17*/ 	}
/* 17*/ 	if( Classes_child == Classes_parent ){
/* 18*/ 		return TRUE;
/* 20*/ 	}
/* 20*/ 	if( Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_child, 16, Classes_0err_entry_get, 0), Classes_parent) ){
/* 21*/ 		return TRUE;
/* 23*/ 	}
/* 23*/ 	Classes_c = (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_child, 20, Classes_0err_entry_get, 1);
/* 24*/ 	{
/* 24*/ 		int m2runtime_for_limit_1;
/* 24*/ 		Classes_i = 0;
/* 24*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_c) - 1);
/* 25*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/* 25*/ 			if( Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_c, Classes_i, Classes_0err_entry_get, 2), Classes_parent) ){
/* 26*/ 				return TRUE;
/* 29*/ 			}
/* 29*/ 		}
/* 29*/ 	}
/* 29*/ 	return FALSE;
/* 33*/ }


/* 34*/ int
/* 34*/ Classes_IsSubclassOfSet(RECORD *Classes_c, ARRAY *Classes_set)
/* 34*/ {
/* 36*/ 	int Classes_i = 0;
/* 36*/ 	{
/* 36*/ 		int m2runtime_for_limit_1;
/* 36*/ 		Classes_i = 0;
/* 36*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_set) - 1);
/* 37*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/* 37*/ 			if( Classes_IsSubclassOf(Classes_c, (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_set, Classes_i, Classes_0err_entry_get, 3)) ){
/* 38*/ 				return TRUE;
/* 41*/ 			}
/* 41*/ 		}
/* 41*/ 	}
/* 41*/ 	return FALSE;
/* 45*/ }


/* 48*/ ARRAY *
/* 48*/ Classes_OrphanClasses(ARRAY *Classes_parents, ARRAY *Classes_children)
/* 48*/ {
/* 49*/ 	int Classes_i = 0;
/* 51*/ 	ARRAY * Classes_orphans = NULL;
/* 51*/ 	{
/* 51*/ 		int m2runtime_for_limit_1;
/* 51*/ 		Classes_i = 0;
/* 51*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_children) - 1);
/* 52*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/* 52*/ 			if( !Classes_IsSubclassOfSet((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_children, Classes_i, Classes_0err_entry_get, 4), Classes_parents) ){
/* 53*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_orphans, 4, 1, Classes_0err_entry_get, 5) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_children, Classes_i, Classes_0err_entry_get, 6);
/* 56*/ 			}
/* 56*/ 		}
/* 56*/ 	}
/* 56*/ 	return Classes_orphans;
/* 60*/ }


/* 62*/ STRING *
/* 62*/ Classes_ClassesList(ARRAY *Classes_set)
/* 62*/ {
/* 63*/ 	STRING * Classes_s = NULL;
/* 65*/ 	int Classes_i = 0;
/* 65*/ 	{
/* 65*/ 		int m2runtime_for_limit_1;
/* 65*/ 		Classes_i = 0;
/* 65*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_set) - 1);
/* 66*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/* 66*/ 			if( (Classes_i > 0) ){
/* 67*/ 				Classes_s = m2runtime_concat_STRING(0, Classes_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ", 1);
/* 69*/ 			}
/* 69*/ 			Classes_s = m2runtime_concat_STRING(0, Classes_s, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_set, Classes_i, Classes_0err_entry_get, 7), 8, Classes_0err_entry_get, 8), 1);
/* 71*/ 		}
/* 71*/ 	}
/* 71*/ 	return Classes_s;
/* 75*/ }


/* 77*/ ARRAY *
/* 77*/ Classes_CloneSet(ARRAY *Classes_set)
/* 77*/ {
/* 78*/ 	ARRAY * Classes_copy = NULL;
/* 80*/ 	int Classes_i = 0;
/* 80*/ 	{
/* 80*/ 		int m2runtime_for_limit_1;
/* 80*/ 		Classes_i = (m2runtime_count(Classes_set) - 1);
/* 80*/ 		m2runtime_for_limit_1 = 0;
/* 81*/ 		for( ; Classes_i >= m2runtime_for_limit_1; Classes_i -= 1 ){
/* 81*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Classes_copy, 4, 1, Classes_i, Classes_0err_entry_get, 9) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_set, Classes_i, Classes_0err_entry_get, 10);
/* 83*/ 		}
/* 83*/ 	}
/* 83*/ 	return Classes_copy;
/* 87*/ }


/* 89*/ ARRAY *
/* 89*/ Classes_Sort(ARRAY *Classes_set)
/* 89*/ {

/* 91*/ 	int
/* 91*/ 	Classes_cmp(RECORD *Classes_a, RECORD *Classes_b)
/* 91*/ 	{
/* 91*/ 		if( Classes_IsSubclassOf(Classes_a, Classes_b) ){
/* 92*/ 			return -1;
/* 93*/ 		} else if( Classes_IsSubclassOf(Classes_b, Classes_a) ){
/* 94*/ 			return 1;
/* 96*/ 		} else {
/* 96*/ 			return m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Classes_a, 8, Classes_0err_entry_get, 11), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_b, 8, Classes_0err_entry_get, 12));
/* 99*/ 		}
/* 99*/ 		m2runtime_missing_return(Classes_0err_entry_get, 13);
/* 99*/ 		return 0;
/*101*/ 	}

/*102*/ 	int Classes_j = 0;
/*102*/ 	int Classes_i = 0;
/*103*/ 	RECORD * Classes_t = NULL;
/*105*/ 	ARRAY * Classes_new = NULL;
/*105*/ 	Classes_new = Classes_CloneSet(Classes_set);
/*106*/ 	{
/*106*/ 		int m2runtime_for_limit_1;
/*106*/ 		Classes_i = 0;
/*106*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_new) - 2);
/*107*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*107*/ 			{
/*107*/ 				int m2runtime_for_limit_2;
/*107*/ 				Classes_j = (Classes_i + 1);
/*107*/ 				m2runtime_for_limit_2 = (m2runtime_count(Classes_new) - 1);
/*108*/ 				for( ; Classes_j <= m2runtime_for_limit_2; Classes_j += 1 ){
/*108*/ 					if( (Classes_cmp((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_new, Classes_j, Classes_0err_entry_get, 14), (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_new, Classes_i, Classes_0err_entry_get, 15)) < 0) ){
/*109*/ 						Classes_t = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_new, Classes_i, Classes_0err_entry_get, 16);
/*110*/ 						*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Classes_new, 4, 1, Classes_i, Classes_0err_entry_get, 17) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_new, Classes_j, Classes_0err_entry_get, 18);
/*111*/ 						*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Classes_new, 4, 1, Classes_j, Classes_0err_entry_get, 19) = Classes_t;
/*114*/ 					}
/*115*/ 				}
/*115*/ 			}
/*115*/ 		}
/*115*/ 	}
/*115*/ 	return Classes_new;
/*119*/ }


/*124*/ STRING *
/*124*/ Classes_pc(RECORD *Classes_c1, RECORD *Classes_c2)
/*124*/ {
/*125*/ 	STRING * Classes_s = NULL;
/*127*/ 	int Classes_i = 0;
/*127*/ 	if( ((Classes_c1 == NULL) || (Classes_c2 == NULL)) ){
/*128*/ 		return NULL;
/*130*/ 	}
/*130*/ 	if( Classes_c1 == Classes_c2 ){
/*131*/ 		return (STRING *)m2runtime_dereference_rhs_RECORD(Classes_c1, 8, Classes_0err_entry_get, 20);
/*135*/ 	}
/*135*/ 	Classes_s = Classes_pc((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_c1, 16, Classes_0err_entry_get, 21), Classes_c2);
/*136*/ 	if( Classes_s != NULL ){
/*137*/ 		return m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_c1, 8, Classes_0err_entry_get, 22), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Classes_s, 1);
/*141*/ 	}
/*141*/ 	{
/*141*/ 		int m2runtime_for_limit_1;
/*141*/ 		Classes_i = 0;
/*141*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c1, 20, Classes_0err_entry_get, 23)) - 1);
/*142*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*142*/ 			Classes_s = Classes_pc((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c1, 20, Classes_0err_entry_get, 24), Classes_i, Classes_0err_entry_get, 25), Classes_c2);
/*143*/ 			if( Classes_s != NULL ){
/*144*/ 				return m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_c1, 8, Classes_0err_entry_get, 26), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Classes_s, 1);
/*147*/ 			}
/*148*/ 		}
/*148*/ 	}
/*148*/ 	m2runtime_HALT(Classes_0err_entry_get, 27, m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_c1, 8, Classes_0err_entry_get, 28), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)" does not extends nor implements ", (STRING *)m2runtime_dereference_rhs_RECORD(Classes_c2, 8, Classes_0err_entry_get, 29), 1));
/*150*/ 	m2runtime_missing_return(Classes_0err_entry_get, 30);
/*150*/ 	return NULL;
/*152*/ }


/*166*/ RECORD *
/*166*/ Classes_SearchMethod(RECORD *Classes_c, STRING *Classes_name, STRING *Classes_name_upper, int Classes_warn)
/*166*/ {
/*167*/ 	ARRAY * Classes_methods = NULL;
/*168*/ 	int Classes_i = 0;
/*169*/ 	RECORD * Classes_m = NULL;
/*171*/ 	STRING * Classes_action = NULL;
/*171*/ 	if( Classes_c == NULL ){
/*172*/ 		return NULL;
/*174*/ 	}
/*174*/ 	Classes_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c, 36, Classes_0err_entry_get, 31);
/*175*/ 	{
/*175*/ 		int m2runtime_for_limit_1;
/*175*/ 		Classes_i = 0;
/*175*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_methods) - 1);
/*176*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*176*/ 			Classes_m = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_methods, Classes_i, Classes_0err_entry_get, 32);
/*177*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 12, Classes_0err_entry_get, 33), Classes_name_upper) == 0 ){
/*178*/ 				if( (Classes_warn && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 8, Classes_0err_entry_get, 34), Classes_name) != 0)) ){
/*179*/ 					if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_m, 44, Classes_0err_entry_get, 35) ){
/*180*/ 						Classes_action = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"implemented";
/*182*/ 					} else {
/*182*/ 						Classes_action = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"overridden";
/*184*/ 					}
/*184*/ 					Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"the name of the method `", Classes_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"()' differs from the name of the ", Classes_action, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)" method ", Scanner_mn(Classes_c, Classes_m), 1));
/*188*/ 				}
/*188*/ 				return Classes_m;
/*191*/ 			}
/*191*/ 		}
/*191*/ 	}
/*191*/ 	return NULL;
/*202*/ }


/*209*/ ARRAY *
/*209*/ Classes_MergeIConstArrays(ARRAY *Classes_a, ARRAY *Classes_b, int Classes_errorOnCollision)
/*209*/ {
/*210*/ 	ARRAY * Classes_c = NULL;
/*212*/ 	int Classes_j = 0;
/*212*/ 	int Classes_i = 0;
/*212*/ 	if( Classes_a == NULL ){
/*213*/ 		return Classes_b;
/*215*/ 	}
/*215*/ 	if( Classes_b == NULL ){
/*216*/ 		return Classes_a;
/*220*/ 	}
/*220*/ 	{
/*220*/ 		int m2runtime_for_limit_1;
/*220*/ 		Classes_i = (m2runtime_count(Classes_a) - 1);
/*220*/ 		m2runtime_for_limit_1 = 0;
/*221*/ 		for( ; Classes_i >= m2runtime_for_limit_1; Classes_i -= 1 ){
/*221*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 36) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_i, Classes_0err_entry_get, 37);
/*225*/ 		}
/*225*/ 	}
/*225*/ 	{
/*225*/ 		int m2runtime_for_limit_1;
/*225*/ 		Classes_i = 0;
/*225*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_b) - 1);
/*226*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*227*/ 			Classes_j = (m2runtime_count(Classes_a) - 1);
/*229*/ 			do{
/*229*/ 				if( (((Classes_j < 0)) || ((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 38), 8, Classes_0err_entry_get, 39) == (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 40), 8, Classes_0err_entry_get, 41))) ){
/*231*/ 					*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 42) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 43);
/*234*/ 					goto m2runtime_loop_1;
/*234*/ 				} else if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 44), 12, Classes_0err_entry_get, 45), 8, Classes_0err_entry_get, 46), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 47), 12, Classes_0err_entry_get, 48), 8, Classes_0err_entry_get, 49)) == 0 ){
/*236*/ 					if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 50), 8, Classes_0err_entry_get, 51), 76, Classes_0err_entry_get, 52) ||  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 53), 8, Classes_0err_entry_get, 54), 76, Classes_0err_entry_get, 55)) ){
/*240*/ 						if( Classes_errorOnCollision ){
/*241*/ 							Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"colliding inherited constants ", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 56), 8, Classes_0err_entry_get, 57), 8, Classes_0err_entry_get, 58), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 59), 12, Classes_0err_entry_get, 60), 8, Classes_0err_entry_get, 61), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 62), 12, Classes_0err_entry_get, 63), 16, Classes_0err_entry_get, 64)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" and ", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 65), 8, Classes_0err_entry_get, 66), 8, Classes_0err_entry_get, 67), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 68), 12, Classes_0err_entry_get, 69), 8, Classes_0err_entry_get, 70), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 71), 12, Classes_0err_entry_get, 72), 16, Classes_0err_entry_get, 73)), 1));
/*254*/ 						}
/*255*/ 					}
/*257*/ 					goto m2runtime_loop_1;
/*257*/ 				}
/*257*/ 				m2_inc(&Classes_j, -1);
/*260*/ 			}while(TRUE);
m2runtime_loop_1: ;
/*261*/ 		}
/*261*/ 	}
/*261*/ 	return Classes_c;
/*265*/ }


/*268*/ ARRAY *
/*268*/ Classes_CollectConsts(RECORD *Classes_cl, int Classes_errorOnCollision)
/*268*/ {
/*269*/ 	ARRAY * Classes_b = NULL;
/*269*/ 	ARRAY * Classes_a = NULL;
/*270*/ 	RECORD * Classes_c = NULL;
/*272*/ 	int Classes_i = 0;
/*272*/ 	if( Classes_cl == NULL ){
/*273*/ 		return NULL;
/*279*/ 	}
/*279*/ 	Classes_a = Classes_CollectConsts((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_cl, 16, Classes_0err_entry_get, 74), FALSE);
/*284*/ 	{
/*284*/ 		int m2runtime_for_limit_1;
/*284*/ 		Classes_i = 0;
/*284*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 20, Classes_0err_entry_get, 75)) - 1);
/*285*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*285*/ 			Classes_b = Classes_CollectConsts((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 20, Classes_0err_entry_get, 76), Classes_i, Classes_0err_entry_get, 77), FALSE);
/*286*/ 			Classes_a = Classes_MergeIConstArrays(Classes_a, Classes_b, Classes_errorOnCollision);
/*292*/ 		}
/*292*/ 	}
/*292*/ 	Classes_b = NULL;
/*293*/ 	{
/*293*/ 		int m2runtime_for_limit_1;
/*293*/ 		Classes_i = 0;
/*293*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 28, Classes_0err_entry_get, 78)) - 1);
/*294*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*294*/ 			Classes_c = NULL;
/*295*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_c, 16, 2, 8, Classes_0err_entry_get, 79) = Classes_cl;
/*296*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_c, 16, 2, 12, Classes_0err_entry_get, 80) = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 28, Classes_0err_entry_get, 81), Classes_i, Classes_0err_entry_get, 82);
/*297*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_b, 4, 1, Classes_0err_entry_get, 83) = Classes_c;
/*299*/ 		}
/*299*/ 	}
/*299*/ 	Classes_a = Classes_MergeIConstArrays(Classes_b, Classes_a, Classes_errorOnCollision);
/*301*/ 	return Classes_a;
/*312*/ }


/*318*/ ARRAY *
/*318*/ Classes_MergeIPropArrays(ARRAY *Classes_a, ARRAY *Classes_b, int Classes_errorOnCollision)
/*318*/ {
/*319*/ 	ARRAY * Classes_c = NULL;
/*320*/ 	int Classes_j = 0;
/*320*/ 	int Classes_i = 0;
/*322*/ 	STRING * Classes_hint = NULL;
/*322*/ 	if( Classes_a == NULL ){
/*323*/ 		return Classes_b;
/*325*/ 	}
/*325*/ 	if( Classes_b == NULL ){
/*326*/ 		return Classes_a;
/*330*/ 	}
/*330*/ 	{
/*330*/ 		int m2runtime_for_limit_1;
/*330*/ 		Classes_i = (m2runtime_count(Classes_a) - 1);
/*330*/ 		m2runtime_for_limit_1 = 0;
/*331*/ 		for( ; Classes_i >= m2runtime_for_limit_1; Classes_i -= 1 ){
/*331*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 84) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_i, Classes_0err_entry_get, 85);
/*335*/ 		}
/*335*/ 	}
/*335*/ 	{
/*335*/ 		int m2runtime_for_limit_1;
/*335*/ 		Classes_i = 0;
/*335*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_b) - 1);
/*336*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*337*/ 			Classes_j = (m2runtime_count(Classes_a) - 1);
/*339*/ 			do{
/*339*/ 				if( (((Classes_j < 0)) || ((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 86), 8, Classes_0err_entry_get, 87) == (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 88), 8, Classes_0err_entry_get, 89))) ){
/*341*/ 					*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 90) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 91);
/*344*/ 					goto m2runtime_loop_1;
/*344*/ 				} else if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 92), 12, Classes_0err_entry_get, 93), 8, Classes_0err_entry_get, 94), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 95), 12, Classes_0err_entry_get, 96), 8, Classes_0err_entry_get, 97)) == 0) && ((((Globals_php_ver == 4)) || (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 98), 12, Classes_0err_entry_get, 99), 32, Classes_0err_entry_get, 100) != 0)) || (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 101), 12, Classes_0err_entry_get, 102), 32, Classes_0err_entry_get, 103) != 0))))) ){
/*351*/ 					if( Classes_errorOnCollision ){
/*352*/ 						if( (Globals_php_ver == 4) ){
/*353*/ 							Classes_hint = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\161,\0,\0,\0)". Private properties cannot be re-defined nor public|protected properties can be overriden (PHPLint restriction).";
/*355*/ 						} else {
/*355*/ 							Classes_hint = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\110,\0,\0,\0)". Public|protected properties cannot be overriden (PHPLint restriction).";
/*357*/ 						}
/*357*/ 						Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"colliding inherited properties ", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 104), 8, Classes_0err_entry_get, 105), 8, Classes_0err_entry_get, 106), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 107), 12, Classes_0err_entry_get, 108), 8, Classes_0err_entry_get, 109), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 110), 12, Classes_0err_entry_get, 111), 20, Classes_0err_entry_get, 112)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" and ", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 113), 8, Classes_0err_entry_get, 114), 8, Classes_0err_entry_get, 115), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 116), 12, Classes_0err_entry_get, 117), 8, Classes_0err_entry_get, 118), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 119), 12, Classes_0err_entry_get, 120), 20, Classes_0err_entry_get, 121)), Classes_hint, 1));
/*367*/ 					}
/*369*/ 					goto m2runtime_loop_1;
/*369*/ 				}
/*369*/ 				m2_inc(&Classes_j, -1);
/*372*/ 			}while(TRUE);
m2runtime_loop_1: ;
/*373*/ 		}
/*373*/ 	}
/*373*/ 	return Classes_c;
/*377*/ }


/*380*/ ARRAY *
/*380*/ Classes_CollectProps(RECORD *Classes_cl, int Classes_errorOnCollision)
/*380*/ {
/*381*/ 	ARRAY * Classes_b = NULL;
/*381*/ 	ARRAY * Classes_a = NULL;
/*382*/ 	RECORD * Classes_p = NULL;
/*384*/ 	int Classes_i = 0;
/*384*/ 	if( Classes_cl == NULL ){
/*385*/ 		return NULL;
/*391*/ 	}
/*391*/ 	Classes_a = Classes_CollectProps((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_cl, 16, Classes_0err_entry_get, 122), FALSE);
/*408*/ 	Classes_b = NULL;
/*409*/ 	{
/*409*/ 		int m2runtime_for_limit_1;
/*409*/ 		Classes_i = 0;
/*409*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 32, Classes_0err_entry_get, 123)) - 1);
/*410*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*410*/ 			Classes_p = NULL;
/*411*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_p, 16, 2, 8, Classes_0err_entry_get, 124) = Classes_cl;
/*412*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_p, 16, 2, 12, Classes_0err_entry_get, 125) = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 32, Classes_0err_entry_get, 126), Classes_i, Classes_0err_entry_get, 127);
/*413*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_b, 4, 1, Classes_0err_entry_get, 128) = Classes_p;
/*415*/ 		}
/*415*/ 	}
/*415*/ 	Classes_a = Classes_MergeIPropArrays(Classes_b, Classes_a, Classes_errorOnCollision);
/*417*/ 	return Classes_a;
/*429*/ }


/*435*/ ARRAY *
/*435*/ Classes_MergeIMethodArrays(ARRAY *Classes_a, ARRAY *Classes_b, int Classes_errorOnCollision)
/*435*/ {
/*436*/ 	ARRAY * Classes_c = NULL;
/*437*/ 	int Classes_j = 0;
/*437*/ 	int Classes_i = 0;
/*439*/ 	RECORD * Classes_bm = NULL;
/*439*/ 	RECORD * Classes_am = NULL;
/*439*/ 	if( Classes_a == NULL ){
/*440*/ 		return Classes_b;
/*442*/ 	}
/*442*/ 	if( Classes_b == NULL ){
/*443*/ 		return Classes_a;
/*447*/ 	}
/*447*/ 	{
/*447*/ 		int m2runtime_for_limit_1;
/*447*/ 		Classes_i = (m2runtime_count(Classes_a) - 1);
/*447*/ 		m2runtime_for_limit_1 = 0;
/*448*/ 		for( ; Classes_i >= m2runtime_for_limit_1; Classes_i -= 1 ){
/*448*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 129) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_i, Classes_0err_entry_get, 130);
/*452*/ 		}
/*452*/ 	}
/*452*/ 	{
/*452*/ 		int m2runtime_for_limit_1;
/*452*/ 		Classes_i = 0;
/*452*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_b) - 1);
/*453*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*454*/ 			Classes_j = (m2runtime_count(Classes_a) - 1);
/*456*/ 			do{
/*456*/ 				if( (((Classes_j < 0)) || ((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 131), 8, Classes_0err_entry_get, 132) == (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 133), 8, Classes_0err_entry_get, 134))) ){
/*458*/ 					*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 135) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 136);
/*461*/ 					goto m2runtime_loop_1;
/*462*/ 				}
/*462*/ 				Classes_am = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 137);
/*463*/ 				Classes_bm = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 138);
/*465*/ 				if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 139), 12, Classes_0err_entry_get, 140), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_bm, 12, Classes_0err_entry_get, 141), 12, Classes_0err_entry_get, 142)) == 0) && ((((Globals_php_ver == 4)) || (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 143), 48, Classes_0err_entry_get, 144) != 0)) || (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 145), 48, Classes_0err_entry_get, 146) != 0))))) ){
/*472*/ 					if( Classes_errorOnCollision ){
/*473*/ 						Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"colliding inherited methods ", Scanner_mn((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 8, Classes_0err_entry_get, 147), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 148)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 149), 20, Classes_0err_entry_get, 150)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" and ", Scanner_mn((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_bm, 8, Classes_0err_entry_get, 151), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_bm, 12, Classes_0err_entry_get, 152)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_bm, 12, Classes_0err_entry_get, 153), 20, Classes_0err_entry_get, 154)), 1));
/*482*/ 					}
/*484*/ 					goto m2runtime_loop_1;
/*484*/ 				}
/*484*/ 				m2_inc(&Classes_j, -1);
/*487*/ 			}while(TRUE);
m2runtime_loop_1: ;
/*488*/ 		}
/*488*/ 	}
/*488*/ 	return Classes_c;
/*492*/ }


/*495*/ ARRAY *
/*495*/ Classes_CollectMethods(RECORD *Classes_cl, int Classes_errorOnCollision)
/*495*/ {
/*496*/ 	ARRAY * Classes_b = NULL;
/*496*/ 	ARRAY * Classes_a = NULL;
/*497*/ 	RECORD * Classes_m = NULL;
/*499*/ 	int Classes_i = 0;
/*499*/ 	if( Classes_cl == NULL ){
/*500*/ 		return NULL;
/*511*/ 	}
/*511*/ 	{
/*511*/ 		int m2runtime_for_limit_1;
/*511*/ 		Classes_i = 0;
/*511*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 20, Classes_0err_entry_get, 155)) - 1);
/*512*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*512*/ 			Classes_b = Classes_CollectMethods((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 20, Classes_0err_entry_get, 156), Classes_i, Classes_0err_entry_get, 157), FALSE);
/*513*/ 			Classes_a = Classes_MergeIMethodArrays(Classes_a, Classes_b, Classes_errorOnCollision);
/*519*/ 		}
/*519*/ 	}
/*519*/ 	Classes_b = NULL;
/*520*/ 	{
/*520*/ 		int m2runtime_for_limit_1;
/*520*/ 		Classes_i = 0;
/*520*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 36, Classes_0err_entry_get, 158)) - 1);
/*521*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*521*/ 			Classes_m = NULL;
/*522*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_m, 16, 2, 8, Classes_0err_entry_get, 159) = Classes_cl;
/*523*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_m, 16, 2, 12, Classes_0err_entry_get, 160) = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 36, Classes_0err_entry_get, 161), Classes_i, Classes_0err_entry_get, 162);
/*524*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_b, 4, 1, Classes_0err_entry_get, 163) = Classes_m;
/*526*/ 		}
/*526*/ 	}
/*526*/ 	Classes_a = Classes_MergeIMethodArrays(Classes_b, Classes_a, Classes_errorOnCollision);
/*528*/ 	return Classes_a;
/*533*/ }


/*535*/ void
/*535*/ Classes_CheckCollisionsBetweenExtendedAndImplementedClasses(RECORD *Classes_cl)
/*535*/ {
/*536*/ 	ARRAY * Classes_ic = NULL;
/*537*/ 	ARRAY * Classes_ip = NULL;
/*539*/ 	ARRAY * Classes_im = NULL;
/*544*/ 	Classes_ic = Classes_CollectConsts(Classes_cl, TRUE);
/*557*/ 	Classes_ip = Classes_CollectProps(Classes_cl, TRUE);
/*562*/ 	Classes_im = Classes_CollectMethods(Classes_cl, TRUE);
/*567*/ }


/*569*/ void
/*569*/ Classes_CheckImplementedMethods(RECORD *Classes_child)
/*569*/ {
/*570*/ 	RECORD * Classes_parent = NULL;
/*571*/ 	ARRAY * Classes_parent_methods = NULL;
/*572*/ 	int Classes_j = 0;
/*572*/ 	int Classes_i = 0;
/*574*/ 	RECORD * Classes_c_m = NULL;
/*574*/ 	RECORD * Classes_p_m = NULL;
/*577*/ 	Classes_parent = (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_child, 16, Classes_0err_entry_get, 164);
/*578*/ 	if( ((Classes_parent != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Classes_parent, 72, Classes_0err_entry_get, 165)) ){
/*579*/ 		Classes_parent_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_parent, 36, Classes_0err_entry_get, 166);
/*580*/ 		{
/*580*/ 			int m2runtime_for_limit_1;
/*580*/ 			Classes_i = 0;
/*580*/ 			m2runtime_for_limit_1 = (m2runtime_count(Classes_parent_methods) - 1);
/*581*/ 			for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*581*/ 				Classes_p_m = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_parent_methods, Classes_i, Classes_0err_entry_get, 167);
/*582*/ 				if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 44, Classes_0err_entry_get, 168) ){
/*583*/ 					Classes_c_m = Classes_SearchMethod(Classes_child, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 8, Classes_0err_entry_get, 169), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 12, Classes_0err_entry_get, 170), TRUE);
/*584*/ 					if( Classes_c_m == NULL ){
/*585*/ 						Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_child, 48, Classes_0err_entry_get, 171), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"in class `", (STRING *)m2runtime_dereference_rhs_RECORD(Classes_child, 8, Classes_0err_entry_get, 172), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\61,\0,\0,\0)"': missing implementation of the abstract method ", Scanner_mn(Classes_parent, Classes_p_m), 1));
/*590*/ 					}
/*591*/ 				}
/*592*/ 			}
/*592*/ 		}
/*595*/ 	}
/*595*/ 	{
/*595*/ 		int m2runtime_for_limit_1;
/*595*/ 		Classes_i = 0;
/*595*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_child, 20, Classes_0err_entry_get, 173)) - 1);
/*596*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*596*/ 			Classes_parent = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_child, 20, Classes_0err_entry_get, 174), Classes_i, Classes_0err_entry_get, 175);
/*597*/ 			Classes_parent_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_parent, 36, Classes_0err_entry_get, 176);
/*598*/ 			{
/*598*/ 				int m2runtime_for_limit_2;
/*598*/ 				Classes_j = 0;
/*598*/ 				m2runtime_for_limit_2 = (m2runtime_count(Classes_parent_methods) - 1);
/*599*/ 				for( ; Classes_j <= m2runtime_for_limit_2; Classes_j += 1 ){
/*599*/ 					Classes_p_m = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_parent_methods, Classes_j, Classes_0err_entry_get, 177);
/*600*/ 					Classes_c_m = Classes_SearchMethod(Classes_child, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 8, Classes_0err_entry_get, 178), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 12, Classes_0err_entry_get, 179), TRUE);
/*601*/ 					if( Classes_c_m == NULL ){
/*602*/ 						Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_child, 48, Classes_0err_entry_get, 180), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"in class `", (STRING *)m2runtime_dereference_rhs_RECORD(Classes_child, 8, Classes_0err_entry_get, 181), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\61,\0,\0,\0)"': missing implementation of the abstract method ", Scanner_mn(Classes_parent, Classes_p_m), 1));
/*607*/ 					}
/*608*/ 				}
/*608*/ 			}
/*609*/ 		}
/*609*/ 	}
/*611*/ }


/*634*/ int
/*634*/ Classes_IsOverridingType(RECORD *Classes_a, RECORD *Classes_b)
/*634*/ {
/*634*/ 	if( Types_SameType(Classes_a, Classes_b) ){
/*635*/ 		return TRUE;
/*638*/ 	}
/*638*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 16, Classes_0err_entry_get, 182)){

/*640*/ 	case 7:
/*642*/ 	return ((( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 183) == 5)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 184) == 6)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 185) == 7)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 186) == 8)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 187) == 9)));
/*648*/ 	break;

/*648*/ 	case 9:
/*649*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 188) == NULL ){
/*651*/ 		return ((( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 189) == 5)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 190) == 6)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 191) == 7)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 192) == 8)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 193) == 9)));
/*658*/ 	} else {
/*658*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 194) == 9) ){
/*659*/ 			return Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 12, Classes_0err_entry_get, 195), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 196));
/*661*/ 		} else {
/*661*/ 			return FALSE;
/*665*/ 		}
/*667*/ 	}
/*667*/ 	break;

/*667*/ 	default:
/*667*/ 	return FALSE;
/*671*/ 	}
/*671*/ 	m2runtime_missing_return(Classes_0err_entry_get, 197);
/*671*/ 	return 0;
/*673*/ }


/*680*/ void
/*680*/ Classes_CheckOverridesImplements(RECORD *Classes_ac, RECORD *Classes_a, RECORD *Classes_bc, RECORD *Classes_b)
/*680*/ {

/*687*/ 	STRING *
/*687*/ 	Classes_CheckSign(RECORD *Classes_a, RECORD *Classes_b)
/*687*/ 	{
/*688*/ 		int Classes_b_n = 0;
/*688*/ 		int Classes_b_m = 0;
/*688*/ 		int Classes_a_n = 0;
/*688*/ 		int Classes_a_m = 0;
/*688*/ 		int Classes_i = 0;
/*690*/ 		RECORD * Classes_b_arg = NULL;
/*690*/ 		RECORD * Classes_a_arg = NULL;
/*694*/ 		if( !Classes_IsOverridingType((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 8, Classes_0err_entry_get, 198), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 8, Classes_0err_entry_get, 199)) ){
/*695*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"incompatible return types";
/*701*/ 		}
/*701*/ 		Classes_a_m =  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 200);
/*701*/ 		Classes_a_n = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 201)) - Classes_a_m);
/*702*/ 		Classes_b_m =  *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 202);
/*702*/ 		Classes_b_n = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_b, 12, Classes_0err_entry_get, 203)) - Classes_b_m);
/*704*/ 		if( (Classes_a_m != Classes_b_m) ){
/*705*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"different number of mandatory arguments";
/*708*/ 		}
/*708*/ 		if( (Classes_b_n < Classes_a_n) ){
/*709*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"too few default arguments";
/*712*/ 		}
/*712*/ 		{
/*712*/ 			int m2runtime_for_limit_1;
/*712*/ 			Classes_i = 0;
/*712*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 204)) - 1);
/*713*/ 			for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*714*/ 				Classes_a_arg = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 205), Classes_i, Classes_0err_entry_get, 206);
/*715*/ 				Classes_b_arg = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_b, 12, Classes_0err_entry_get, 207), Classes_i, Classes_0err_entry_get, 208);
/*720*/ 				if( ((! *(int *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 20, Classes_0err_entry_get, 209) &&  *(int *)m2runtime_dereference_rhs_RECORD(Classes_b_arg, 20, Classes_0err_entry_get, 210)) || ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 20, Classes_0err_entry_get, 211) && ! *(int *)m2runtime_dereference_rhs_RECORD(Classes_b_arg, 20, Classes_0err_entry_get, 212))) ){
/*722*/ 					return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"invalid & in argument no. ", m2runtime_itos(((Classes_i + 1))), 1);
/*730*/ 				}
/*730*/ 				if( (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 20, Classes_0err_entry_get, 213) && !Types_SameType((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b_arg, 12, Classes_0err_entry_get, 214), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 12, Classes_0err_entry_get, 215))) || (! *(int *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 20, Classes_0err_entry_get, 216) && !Classes_IsOverridingType((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b_arg, 12, Classes_0err_entry_get, 217), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 12, Classes_0err_entry_get, 218)))) ){
/*732*/ 					return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"incompatible type in overriding argument no. ", m2runtime_itos(((Classes_i + 1))), 1);
/*735*/ 				}
/*739*/ 			}
/*739*/ 		}
/*739*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 24, Classes_0err_entry_get, 219) && ! *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 24, Classes_0err_entry_get, 220)) ){
/*740*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"required variable number of arguments /*.args.*/";
/*743*/ 		}
/*743*/ 		return NULL;
/*747*/ 	}

/*748*/ 	STRING * Classes_t = NULL;
/*750*/ 	STRING * Classes_err = NULL;
/*750*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 44, Classes_0err_entry_get, 221) ){
/*751*/ 		Classes_t = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"implemented";
/*753*/ 	} else {
/*753*/ 		Classes_t = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"overridden";
/*757*/ 	}
/*757*/ 	if( (! *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 44, Classes_0err_entry_get, 222) &&  *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 44, Classes_0err_entry_get, 223)) ){
/*758*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 224), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)": cannot make abstract the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)" non-abstract method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 225)), 1));
/*764*/ 	}
/*764*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 52, Classes_0err_entry_get, 226) && ! *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 52, Classes_0err_entry_get, 227)) ){
/*765*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 228), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)": cannot make static the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)" non-static method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 229)), 1));
/*768*/ 	} else if( (! *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 52, Classes_0err_entry_get, 230) &&  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 52, Classes_0err_entry_get, 231)) ){
/*769*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 232), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)": cannot make non-static the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)" static method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 233)), 1));
/*775*/ 	}
/*775*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 56, Classes_0err_entry_get, 234) ){
/*776*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 235), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)": cannot override final method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 236)), 1));
/*781*/ 	}
/*781*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 48, Classes_0err_entry_get, 237) <  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 48, Classes_0err_entry_get, 238)) ){
/*782*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 239), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)": cannot lower the visibility of the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)" method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 240)), 1));
/*787*/ 	}
/*787*/ 	Classes_err = Classes_CheckSign((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 16, Classes_0err_entry_get, 241), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 242));
/*788*/ 	if( Classes_err != NULL ){
/*789*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 243), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)": the signature `", Types_FunctionSignatureToString((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 244)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' does not match the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)" method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 245)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" with signature `", Types_FunctionSignatureToString((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 16, Classes_0err_entry_get, 246)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", Classes_err, 1));
/*797*/ 	}
/*797*/ 	Classes_err = Classes_ClassesList(Classes_Sort(Classes_OrphanClasses((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_a, 28, Classes_0err_entry_get, 247), (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_b, 28, Classes_0err_entry_get, 248))));
/*798*/ 	if( Classes_err != NULL ){
/*799*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 249), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)": more exceptions thrown than declared in ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)" method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 250)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", Classes_err, 1));
/*804*/ 	}
/*806*/ }


/*814*/ void
/*814*/ Classes_ResolveClassMethod(RECORD *Classes_class, STRING *Classes_id, RECORD **Classes_res_class, RECORD **Classes_res_method)
/*814*/ {
/*815*/ 	int Classes_i = 0;
/*817*/ 	RECORD * Classes_m = NULL;
/*817*/ 	if( Classes_class == NULL ){
/*818*/ 		*Classes_res_class = NULL;
/*819*/ 		*Classes_res_method = NULL;
/*821*/ 		return ;
/*824*/ 	}
/*824*/ 	Classes_m = Search_SearchClassMethod(Classes_class, Classes_id, TRUE);
/*825*/ 	if( Classes_m != NULL ){
/*827*/ 		*Classes_res_class = Classes_class;
/*828*/ 		*Classes_res_method = Classes_m;
/*830*/ 		return ;
/*833*/ 	}
/*833*/ 	Classes_ResolveClassMethod((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_class, 16, Classes_0err_entry_get, 251), Classes_id, Classes_res_class, Classes_res_method);
/*834*/ 	if( *Classes_res_method != NULL ){
/*836*/ 		return ;
/*839*/ 	}
/*839*/ 	{
/*839*/ 		int m2runtime_for_limit_1;
/*839*/ 		Classes_i = 0;
/*839*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_class, 20, Classes_0err_entry_get, 252)) - 1);
/*840*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*840*/ 			Classes_ResolveClassMethod((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_class, 20, Classes_0err_entry_get, 253), Classes_i, Classes_0err_entry_get, 254), Classes_id, Classes_res_class, Classes_res_method);
/*841*/ 			if( *Classes_res_method != NULL ){
/*843*/ 				return ;
/*845*/ 			}
/*847*/ 		}
/*847*/ 	}
/*847*/ 	*Classes_res_class = NULL;
/*848*/ 	*Classes_res_method = NULL;
/*852*/ }


/*859*/ void
/*859*/ Classes_InheritExceptions(ARRAY **Classes_new, ARRAY *Classes_old)
/*859*/ {

/*861*/ 	int
/*861*/ 	Classes_Contains(RECORD *Classes_c)
/*861*/ 	{
/*863*/ 		int Classes_i = 0;
/*863*/ 		{
/*863*/ 			int m2runtime_for_limit_1;
/*863*/ 			Classes_i = 0;
/*863*/ 			m2runtime_for_limit_1 = (m2runtime_count(*Classes_new) - 1);
/*864*/ 			for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*864*/ 				if( (RECORD *)m2runtime_dereference_rhs_ARRAY(*Classes_new, Classes_i, Classes_0err_entry_get, 255) == Classes_c ){
/*865*/ 					return TRUE;
/*868*/ 				}
/*868*/ 			}
/*868*/ 		}
/*868*/ 		return FALSE;
/*872*/ 	}

/*874*/ 	int Classes_i = 0;
/*874*/ 	{
/*874*/ 		int m2runtime_for_limit_1;
/*874*/ 		Classes_i = 0;
/*874*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_old) - 1);
/*875*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*875*/ 			if( !Classes_Contains((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_old, Classes_i, Classes_0err_entry_get, 256)) ){
/*876*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(Classes_new, 4, 1, Classes_0err_entry_get, 257) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_old, Classes_i, Classes_0err_entry_get, 258);
/*879*/ 			}
/*880*/ 		}
/*880*/ 	}
/*882*/ }


/*888*/ void
/*888*/ Classes_CheckOverriddenMethod(RECORD *Classes_c, RECORD *Classes_m)
/*888*/ {
/*889*/ 	RECORD * Classes_o_c = NULL;
/*890*/ 	RECORD * Classes_o_m = NULL;
/*893*/ 	int Classes_i = 0;

/*898*/ 	void
/*898*/ 	Classes_CheckImplementation(RECORD *Classes_c, RECORD *Classes_m, RECORD *Classes_if)
/*898*/ 	{
/*899*/ 		RECORD * Classes_i_m = NULL;
/*901*/ 		int Classes_i = 0;
/*901*/ 		if( Classes_if == NULL ){
/*903*/ 			return ;
/*904*/ 		}
/*904*/ 		Classes_i_m = Classes_SearchMethod(Classes_if, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 8, Classes_0err_entry_get, 259), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 12, Classes_0err_entry_get, 260), TRUE);
/*905*/ 		if( Classes_i_m != NULL ){
/*906*/ 			Classes_CheckOverridesImplements(Classes_if, Classes_i_m, Classes_c, Classes_m);
/*907*/ 			Classes_InheritExceptions((ARRAY **)m2runtime_dereference_lhs_RECORD(&Classes_m, 72, 8, 28, Classes_0err_entry_get, 261), (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_i_m, 28, Classes_0err_entry_get, 262));
/*909*/ 		}
/*909*/ 		{
/*909*/ 			int m2runtime_for_limit_1;
/*909*/ 			Classes_i = 0;
/*909*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_if, 20, Classes_0err_entry_get, 263)) - 1);
/*910*/ 			for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*910*/ 				Classes_CheckImplementation(Classes_c, Classes_m, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_if, 20, Classes_0err_entry_get, 264), Classes_i, Classes_0err_entry_get, 265));
/*913*/ 			}
/*913*/ 		}
/*915*/ 	}

/*919*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_c, 16, Classes_0err_entry_get, 266) != NULL ){
/*920*/ 		Classes_ResolveClassMethod((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_c, 16, Classes_0err_entry_get, 267), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 8, Classes_0err_entry_get, 268), &Classes_o_c, &Classes_o_m);
/*921*/ 		if( Classes_o_m == NULL ){
/*923*/ 		} else if( ((Classes_o_m == (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_o_c, 40, Classes_0err_entry_get, 269)) && ! *(int *)m2runtime_dereference_rhs_RECORD(Classes_o_m, 44, Classes_0err_entry_get, 270)) ){
/*925*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_o_m, 56, Classes_0err_entry_get, 271) ){
/*926*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the method ", Scanner_mn(Classes_c, Classes_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)" cannot override the final method ", Scanner_mn(Classes_o_c, Classes_o_m), 1));
/*928*/ 		} else if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Classes_o_m, 48, Classes_0err_entry_get, 272) == 0)) && ((Globals_php_ver == 4))) ){
/*929*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the method ", Scanner_mn(Classes_c, Classes_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)" cannot redefine the private method ", Scanner_mn(Classes_o_c, Classes_o_m), 1));
/*932*/ 		} else {
/*932*/ 			Classes_CheckOverridesImplements(Classes_o_c, Classes_o_m, Classes_c, Classes_m);
/*933*/ 			Classes_InheritExceptions((ARRAY **)m2runtime_dereference_lhs_RECORD(&Classes_m, 72, 8, 28, Classes_0err_entry_get, 273), (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_o_m, 28, Classes_0err_entry_get, 274));
/*936*/ 		}
/*937*/ 	}
/*937*/ 	{
/*937*/ 		int m2runtime_for_limit_1;
/*937*/ 		Classes_i = 0;
/*937*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c, 20, Classes_0err_entry_get, 275)) - 1);
/*938*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*938*/ 			Classes_CheckImplementation(Classes_c, Classes_m, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c, 20, Classes_0err_entry_get, 276), Classes_i, Classes_0err_entry_get, 277));
/*941*/ 		}
/*941*/ 	}
/*944*/ }


char * Classes_0func[] = {
    "IsSubclassOf",
    "IsSubclassOfSet",
    "OrphanClasses",
    "ClassesList",
    "CloneSet",
    "cmp",
    "Sort",
    "pc",
    "SearchMethod",
    "MergeIConstArrays",
    "CollectConsts",
    "MergeIPropArrays",
    "CollectProps",
    "MergeIMethodArrays",
    "CollectMethods",
    "CheckImplementedMethods",
    "IsOverridingType",
    "CheckSign",
    "CheckOverridesImplements",
    "ResolveClassMethod",
    "Contains",
    "InheritExceptions",
    "CheckImplementation",
    "CheckOverriddenMethod"
};

int Classes_0err_entry[] = {
    0 /* IsSubclassOf */, 20,
    0 /* IsSubclassOf */, 23,
    0 /* IsSubclassOf */, 25,
    1 /* IsSubclassOfSet */, 37,
    2 /* OrphanClasses */, 52,
    2 /* OrphanClasses */, 53,
    2 /* OrphanClasses */, 54,
    3 /* ClassesList */, 69,
    3 /* ClassesList */, 69,
    4 /* CloneSet */, 81,
    4 /* CloneSet */, 82,
    5 /* cmp */, 96,
    5 /* cmp */, 96,
    5 /* cmp */, 98,
    6 /* Sort */, 108,
    6 /* Sort */, 108,
    6 /* Sort */, 110,
    6 /* Sort */, 110,
    6 /* Sort */, 111,
    6 /* Sort */, 111,
    7 /* pc */, 131,
    7 /* pc */, 135,
    7 /* pc */, 137,
    7 /* pc */, 141,
    7 /* pc */, 142,
    7 /* pc */, 142,
    7 /* pc */, 144,
    7 /* pc */, 148,
    7 /* pc */, 148,
    7 /* pc */, 148,
    7 /* pc */, 149,
    8 /* SearchMethod */, 174,
    8 /* SearchMethod */, 177,
    8 /* SearchMethod */, 177,
    8 /* SearchMethod */, 178,
    8 /* SearchMethod */, 179,
    9 /* MergeIConstArrays */, 221,
    9 /* MergeIConstArrays */, 222,
    9 /* MergeIConstArrays */, 229,
    9 /* MergeIConstArrays */, 229,
    9 /* MergeIConstArrays */, 229,
    9 /* MergeIConstArrays */, 229,
    9 /* MergeIConstArrays */, 231,
    9 /* MergeIConstArrays */, 232,
    9 /* MergeIConstArrays */, 234,
    9 /* MergeIConstArrays */, 234,
    9 /* MergeIConstArrays */, 234,
    9 /* MergeIConstArrays */, 234,
    9 /* MergeIConstArrays */, 234,
    9 /* MergeIConstArrays */, 234,
    9 /* MergeIConstArrays */, 236,
    9 /* MergeIConstArrays */, 236,
    9 /* MergeIConstArrays */, 236,
    9 /* MergeIConstArrays */, 236,
    9 /* MergeIConstArrays */, 236,
    9 /* MergeIConstArrays */, 236,
    9 /* MergeIConstArrays */, 242,
    9 /* MergeIConstArrays */, 242,
    9 /* MergeIConstArrays */, 242,
    9 /* MergeIConstArrays */, 242,
    9 /* MergeIConstArrays */, 242,
    9 /* MergeIConstArrays */, 242,
    9 /* MergeIConstArrays */, 243,
    9 /* MergeIConstArrays */, 243,
    9 /* MergeIConstArrays */, 243,
    9 /* MergeIConstArrays */, 245,
    9 /* MergeIConstArrays */, 245,
    9 /* MergeIConstArrays */, 245,
    9 /* MergeIConstArrays */, 245,
    9 /* MergeIConstArrays */, 245,
    9 /* MergeIConstArrays */, 245,
    9 /* MergeIConstArrays */, 246,
    9 /* MergeIConstArrays */, 246,
    9 /* MergeIConstArrays */, 246,
    10 /* CollectConsts */, 279,
    10 /* CollectConsts */, 284,
    10 /* CollectConsts */, 285,
    10 /* CollectConsts */, 285,
    10 /* CollectConsts */, 293,
    10 /* CollectConsts */, 295,
    10 /* CollectConsts */, 296,
    10 /* CollectConsts */, 296,
    10 /* CollectConsts */, 297,
    10 /* CollectConsts */, 297,
    11 /* MergeIPropArrays */, 331,
    11 /* MergeIPropArrays */, 332,
    11 /* MergeIPropArrays */, 339,
    11 /* MergeIPropArrays */, 339,
    11 /* MergeIPropArrays */, 339,
    11 /* MergeIPropArrays */, 339,
    11 /* MergeIPropArrays */, 341,
    11 /* MergeIPropArrays */, 342,
    11 /* MergeIPropArrays */, 344,
    11 /* MergeIPropArrays */, 344,
    11 /* MergeIPropArrays */, 344,
    11 /* MergeIPropArrays */, 344,
    11 /* MergeIPropArrays */, 344,
    11 /* MergeIPropArrays */, 344,
    11 /* MergeIPropArrays */, 347,
    11 /* MergeIPropArrays */, 347,
    11 /* MergeIPropArrays */, 347,
    11 /* MergeIPropArrays */, 348,
    11 /* MergeIPropArrays */, 348,
    11 /* MergeIPropArrays */, 348,
    11 /* MergeIPropArrays */, 358,
    11 /* MergeIPropArrays */, 358,
    11 /* MergeIPropArrays */, 358,
    11 /* MergeIPropArrays */, 358,
    11 /* MergeIPropArrays */, 358,
    11 /* MergeIPropArrays */, 358,
    11 /* MergeIPropArrays */, 359,
    11 /* MergeIPropArrays */, 359,
    11 /* MergeIPropArrays */, 359,
    11 /* MergeIPropArrays */, 361,
    11 /* MergeIPropArrays */, 361,
    11 /* MergeIPropArrays */, 361,
    11 /* MergeIPropArrays */, 361,
    11 /* MergeIPropArrays */, 361,
    11 /* MergeIPropArrays */, 361,
    11 /* MergeIPropArrays */, 362,
    11 /* MergeIPropArrays */, 362,
    11 /* MergeIPropArrays */, 362,
    12 /* CollectProps */, 391,
    12 /* CollectProps */, 409,
    12 /* CollectProps */, 411,
    12 /* CollectProps */, 412,
    12 /* CollectProps */, 412,
    12 /* CollectProps */, 413,
    12 /* CollectProps */, 413,
    13 /* MergeIMethodArrays */, 448,
    13 /* MergeIMethodArrays */, 449,
    13 /* MergeIMethodArrays */, 456,
    13 /* MergeIMethodArrays */, 456,
    13 /* MergeIMethodArrays */, 456,
    13 /* MergeIMethodArrays */, 456,
    13 /* MergeIMethodArrays */, 458,
    13 /* MergeIMethodArrays */, 459,
    13 /* MergeIMethodArrays */, 463,
    13 /* MergeIMethodArrays */, 465,
    13 /* MergeIMethodArrays */, 465,
    13 /* MergeIMethodArrays */, 465,
    13 /* MergeIMethodArrays */, 465,
    13 /* MergeIMethodArrays */, 465,
    13 /* MergeIMethodArrays */, 468,
    13 /* MergeIMethodArrays */, 468,
    13 /* MergeIMethodArrays */, 469,
    13 /* MergeIMethodArrays */, 469,
    13 /* MergeIMethodArrays */, 474,
    13 /* MergeIMethodArrays */, 474,
    13 /* MergeIMethodArrays */, 475,
    13 /* MergeIMethodArrays */, 475,
    13 /* MergeIMethodArrays */, 477,
    13 /* MergeIMethodArrays */, 477,
    13 /* MergeIMethodArrays */, 478,
    13 /* MergeIMethodArrays */, 478,
    14 /* CollectMethods */, 511,
    14 /* CollectMethods */, 512,
    14 /* CollectMethods */, 512,
    14 /* CollectMethods */, 520,
    14 /* CollectMethods */, 522,
    14 /* CollectMethods */, 523,
    14 /* CollectMethods */, 523,
    14 /* CollectMethods */, 524,
    14 /* CollectMethods */, 524,
    15 /* CheckImplementedMethods */, 577,
    15 /* CheckImplementedMethods */, 578,
    15 /* CheckImplementedMethods */, 579,
    15 /* CheckImplementedMethods */, 582,
    15 /* CheckImplementedMethods */, 582,
    15 /* CheckImplementedMethods */, 583,
    15 /* CheckImplementedMethods */, 583,
    15 /* CheckImplementedMethods */, 585,
    15 /* CheckImplementedMethods */, 585,
    15 /* CheckImplementedMethods */, 595,
    15 /* CheckImplementedMethods */, 596,
    15 /* CheckImplementedMethods */, 597,
    15 /* CheckImplementedMethods */, 597,
    15 /* CheckImplementedMethods */, 600,
    15 /* CheckImplementedMethods */, 600,
    15 /* CheckImplementedMethods */, 600,
    15 /* CheckImplementedMethods */, 602,
    15 /* CheckImplementedMethods */, 602,
    16 /* IsOverridingType */, 638,
    16 /* IsOverridingType */, 642,
    16 /* IsOverridingType */, 643,
    16 /* IsOverridingType */, 644,
    16 /* IsOverridingType */, 645,
    16 /* IsOverridingType */, 646,
    16 /* IsOverridingType */, 649,
    16 /* IsOverridingType */, 651,
    16 /* IsOverridingType */, 652,
    16 /* IsOverridingType */, 653,
    16 /* IsOverridingType */, 654,
    16 /* IsOverridingType */, 655,
    16 /* IsOverridingType */, 658,
    16 /* IsOverridingType */, 659,
    16 /* IsOverridingType */, 659,
    16 /* IsOverridingType */, 670,
    17 /* CheckSign */, 694,
    17 /* CheckSign */, 694,
    17 /* CheckSign */, 701,
    17 /* CheckSign */, 701,
    17 /* CheckSign */, 702,
    17 /* CheckSign */, 702,
    17 /* CheckSign */, 712,
    17 /* CheckSign */, 714,
    17 /* CheckSign */, 715,
    17 /* CheckSign */, 715,
    17 /* CheckSign */, 720,
    17 /* CheckSign */, 720,
    17 /* CheckSign */, 720,
    17 /* CheckSign */, 721,
    17 /* CheckSign */, 721,
    17 /* CheckSign */, 730,
    17 /* CheckSign */, 730,
    17 /* CheckSign */, 730,
    17 /* CheckSign */, 731,
    17 /* CheckSign */, 731,
    17 /* CheckSign */, 731,
    17 /* CheckSign */, 739,
    17 /* CheckSign */, 739,
    18 /* CheckOverridesImplements */, 750,
    18 /* CheckOverridesImplements */, 757,
    18 /* CheckOverridesImplements */, 757,
    18 /* CheckOverridesImplements */, 758,
    18 /* CheckOverridesImplements */, 760,
    18 /* CheckOverridesImplements */, 764,
    18 /* CheckOverridesImplements */, 764,
    18 /* CheckOverridesImplements */, 765,
    18 /* CheckOverridesImplements */, 767,
    18 /* CheckOverridesImplements */, 768,
    18 /* CheckOverridesImplements */, 768,
    18 /* CheckOverridesImplements */, 769,
    18 /* CheckOverridesImplements */, 771,
    18 /* CheckOverridesImplements */, 775,
    18 /* CheckOverridesImplements */, 776,
    18 /* CheckOverridesImplements */, 777,
    18 /* CheckOverridesImplements */, 781,
    18 /* CheckOverridesImplements */, 781,
    18 /* CheckOverridesImplements */, 782,
    18 /* CheckOverridesImplements */, 783,
    18 /* CheckOverridesImplements */, 787,
    18 /* CheckOverridesImplements */, 787,
    18 /* CheckOverridesImplements */, 789,
    18 /* CheckOverridesImplements */, 790,
    18 /* CheckOverridesImplements */, 791,
    18 /* CheckOverridesImplements */, 792,
    18 /* CheckOverridesImplements */, 797,
    18 /* CheckOverridesImplements */, 797,
    18 /* CheckOverridesImplements */, 799,
    18 /* CheckOverridesImplements */, 801,
    19 /* ResolveClassMethod */, 833,
    19 /* ResolveClassMethod */, 839,
    19 /* ResolveClassMethod */, 840,
    19 /* ResolveClassMethod */, 840,
    20 /* Contains */, 864,
    21 /* InheritExceptions */, 875,
    21 /* InheritExceptions */, 876,
    21 /* InheritExceptions */, 877,
    22 /* CheckImplementation */, 904,
    22 /* CheckImplementation */, 904,
    22 /* CheckImplementation */, 907,
    22 /* CheckImplementation */, 907,
    22 /* CheckImplementation */, 909,
    22 /* CheckImplementation */, 910,
    22 /* CheckImplementation */, 910,
    23 /* CheckOverriddenMethod */, 919,
    23 /* CheckOverriddenMethod */, 920,
    23 /* CheckOverriddenMethod */, 920,
    23 /* CheckOverriddenMethod */, 923,
    23 /* CheckOverriddenMethod */, 923,
    23 /* CheckOverriddenMethod */, 925,
    23 /* CheckOverriddenMethod */, 928,
    23 /* CheckOverriddenMethod */, 933,
    23 /* CheckOverriddenMethod */, 933,
    23 /* CheckOverriddenMethod */, 937,
    23 /* CheckOverriddenMethod */, 938,
    23 /* CheckOverriddenMethod */, 938
};

void Classes_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Classes";
    *f = Classes_0func[ Classes_0err_entry[2*i] ];
    *l = Classes_0err_entry[2*i + 1];
}
