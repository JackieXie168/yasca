/* IMPLEMENTATION MODULE ParseDocBlock */
#define M2_IMPORT_ParseDocBlock

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif
/* 46*/ int ParseDocBlock_parse_phpdoc = 0;

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_buffer
#    include "buffer.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

void ParseDocBlock_0err_entry_get(int i, char **m, char **f, int *l);
/*  9*/ RECORD * ParseDocBlock_pdb = NULL;
/* 10*/ STRING * ParseDocBlock_in = NULL;
/* 11*/ int ParseDocBlock_pos = 0;
/* 12*/ int ParseDocBlock_line_n = 0;
/* 13*/ int ParseDocBlock_len = 0;
/* 15*/ STRING * ParseDocBlock_c = NULL;
/* 16*/ STRING * ParseDocBlock_return_descr = NULL;
/* 18*/ void * ParseDocBlock_descr = NULL;
/* 23*/ ARRAY * ParseDocBlock_types = NULL;

/* 25*/ int
/* 25*/ ParseDocBlock_isLWSP(STRING *ParseDocBlock_c)
/* 25*/ {
/* 25*/ 	return ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(9)) == 0));
/* 29*/ }


/* 39*/ void
/* 39*/ ParseDocBlock_readCh(void)
/* 39*/ {

/* 47*/ 	void
/* 47*/ 	ParseDocBlock_lowLevelReadCh(void)
/* 47*/ 	{
/* 47*/ 		if( ParseDocBlock_c == NULL ){
/* 48*/ 			m2runtime_HALT(ParseDocBlock_0err_entry_get, 0, NULL);
/* 50*/ 		}
/* 50*/ 		if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0 ){
/* 51*/ 			m2_inc(&ParseDocBlock_line_n, 1);
/* 53*/ 		}
/* 53*/ 		if( (ParseDocBlock_pos >= ParseDocBlock_len) ){
/* 54*/ 			ParseDocBlock_c = NULL;
/* 56*/ 			return ;
/* 57*/ 		}
/* 57*/ 		ParseDocBlock_c = m2runtime_substr(ParseDocBlock_in, ParseDocBlock_pos, 0, 0, ParseDocBlock_0err_entry_get, 1);
/* 58*/ 		m2_inc(&ParseDocBlock_pos, 1);
/* 59*/ 		if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(13)) == 0 ){
/* 61*/ 			if( (((ParseDocBlock_pos < ParseDocBlock_len)) && (m2runtime_strcmp(m2runtime_substr(ParseDocBlock_in, ParseDocBlock_pos, 0, 0, ParseDocBlock_0err_entry_get, 2), m2runtime_CHR(10)) == 0)) ){
/* 62*/ 				m2_inc(&ParseDocBlock_pos, 1);
/* 64*/ 			}
/* 64*/ 			ParseDocBlock_c = m2runtime_CHR(10);
/* 67*/ 		}
/* 70*/ 	}

/* 70*/ 	if( ParseDocBlock_c == NULL ){
/* 72*/ 		return ;
/* 73*/ 	}
/* 73*/ 	if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0 ){
/* 75*/ 		do{
/* 75*/ 			ParseDocBlock_lowLevelReadCh();
/* 76*/ 			while( ParseDocBlock_isLWSP(ParseDocBlock_c) ){
/* 77*/ 				ParseDocBlock_lowLevelReadCh();
/* 79*/ 			}
/* 79*/ 			if( ParseDocBlock_c == NULL ){
/* 82*/ 				goto m2runtime_loop_1;
/* 82*/ 			}
/* 82*/ 			if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(42)) == 0 ){
/* 83*/ 				ParseDocBlock_lowLevelReadCh();
/* 84*/ 				while( ParseDocBlock_isLWSP(ParseDocBlock_c) ){
/* 85*/ 					ParseDocBlock_lowLevelReadCh();
/* 88*/ 				}
/* 89*/ 				goto m2runtime_loop_1;
/* 89*/ 			}
/* 89*/ 			Scanner_Notice2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)"missing `*' at the beginning of the line -- ignoring line");
/* 90*/ 			while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) != 0)) ){
/* 91*/ 				ParseDocBlock_lowLevelReadCh();
/* 93*/ 			}
/* 93*/ 			if( ParseDocBlock_c == NULL ){
/* 96*/ 				goto m2runtime_loop_1;
/* 97*/ 			}
/* 98*/ 		}while(TRUE);
m2runtime_loop_1: ;
/* 98*/ 	} else {
/* 98*/ 		ParseDocBlock_lowLevelReadCh();
/*101*/ 	}
/*103*/ }

/*106*/ void * ParseDocBlock_b = NULL;

/*108*/ STRING *
/*108*/ ParseDocBlock_textToHtml(STRING *ParseDocBlock_s)
/*108*/ {
/*109*/ 	int ParseDocBlock_i = 0;
/*110*/ 	STRING * ParseDocBlock_c = NULL;
/*112*/ 	void * ParseDocBlock_b = NULL;
/*112*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*113*/ 	{
/*113*/ 		int m2runtime_for_limit_1;
/*113*/ 		ParseDocBlock_i = 0;
/*113*/ 		m2runtime_for_limit_1 = (m2runtime_length(ParseDocBlock_s) - 1);
/*114*/ 		for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*114*/ 			ParseDocBlock_c = m2runtime_substr(ParseDocBlock_s, ParseDocBlock_i, 0, 0, ParseDocBlock_0err_entry_get, 3);
/*115*/ 			if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(60)) == 0 ){
/*116*/ 				buffer_AddString((void *)&ParseDocBlock_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&lt;");
/*117*/ 			} else if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(62)) == 0 ){
/*118*/ 				buffer_AddString((void *)&ParseDocBlock_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&gt;");
/*119*/ 			} else if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(38)) == 0 ){
/*120*/ 				buffer_AddString((void *)&ParseDocBlock_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"&amp;");
/*122*/ 			} else {
/*122*/ 				buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_c);
/*125*/ 			}
/*125*/ 		}
/*125*/ 	}
/*125*/ 	return buffer_ToString(ParseDocBlock_b);
/*135*/ }

/*136*/ ARRAY * ParseDocBlock_tags = NULL;
/*138*/ void * ParseDocBlock_eb = NULL;

/*151*/ STRING *
/*151*/ ParseDocBlock_filterValidHtmlEntities(STRING *ParseDocBlock_s)
/*151*/ {
/*153*/ 	ARRAY * ParseDocBlock_a = NULL;
/*154*/ 	int ParseDocBlock_i = 0;
/*155*/ 	STRING * ParseDocBlock_l = NULL;
/*157*/ 	STRING * ParseDocBlock_t = NULL;

/*165*/ 	void
/*165*/ 	ParseDocBlock_nextTag(void)
/*165*/ 	{

/*166*/ 		STRING *
/*166*/ 		ParseDocBlock_detectTag(STRING *ParseDocBlock_s)
/*166*/ 		{
/*166*/ 			int ParseDocBlock_i = 0;
/*168*/ 			STRING * ParseDocBlock_t = NULL;
/*168*/ 			{
/*168*/ 				int m2runtime_for_limit_1;
/*168*/ 				ParseDocBlock_i = 0;
/*168*/ 				m2runtime_for_limit_1 = (m2runtime_count(ParseDocBlock_tags) - 1);
/*169*/ 				for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*169*/ 					ParseDocBlock_t = (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_tags, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 4);
/*170*/ 					if( (((m2runtime_length(ParseDocBlock_s) >= m2runtime_length(ParseDocBlock_t))) && (m2runtime_strcmp(m2runtime_substr(ParseDocBlock_s, 0, m2runtime_length(ParseDocBlock_t), 1, ParseDocBlock_0err_entry_get, 5), ParseDocBlock_t) == 0)) ){
/*172*/ 						return ParseDocBlock_t;
/*175*/ 					}
/*175*/ 				}
/*175*/ 			}
/*175*/ 			return NULL;
/*179*/ 		}

/*179*/ 		if( (ParseDocBlock_i >= m2runtime_count(ParseDocBlock_a)) ){
/*180*/ 			ParseDocBlock_t = NULL;
/*181*/ 			ParseDocBlock_l = NULL;
/*183*/ 			return ;
/*184*/ 		}
/*184*/ 		ParseDocBlock_l = (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_a, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 6);
/*185*/ 		ParseDocBlock_t = ParseDocBlock_detectTag(ParseDocBlock_l);
/*186*/ 		m2_inc(&ParseDocBlock_i, 1);
/*190*/ 	}


/*191*/ 	STRING *
/*191*/ 	ParseDocBlock_short(STRING *ParseDocBlock_s)
/*191*/ 	{
/*193*/ 		int ParseDocBlock_l = 0;
/*193*/ 		ParseDocBlock_l = m2runtime_length(ParseDocBlock_s);
/*194*/ 		if( (ParseDocBlock_l > 30) ){
/*196*/ 			ParseDocBlock_s = m2runtime_concat_STRING(0, m2runtime_substr(ParseDocBlock_s, 0, 25, 1, ParseDocBlock_0err_entry_get, 7), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"...", 1);
/*198*/ 		}
/*198*/ 		return str_substitute(str_substitute(ParseDocBlock_s, m2runtime_CHR(10), m2runtime_CHR(32)), m2runtime_CHR(13), m2runtime_CHR(32));
/*202*/ 	}


/*208*/ 	void
/*208*/ 	ParseDocBlock_addTag(void)
/*208*/ 	{
/*208*/ 		buffer_AddString((void *)&ParseDocBlock_eb, m2runtime_CHR(60));
/*209*/ 		buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_t);
/*210*/ 		buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_textToHtml(m2runtime_substr(ParseDocBlock_l, m2runtime_length(ParseDocBlock_t), m2runtime_length(ParseDocBlock_l), 1, ParseDocBlock_0err_entry_get, 8)));
/*211*/ 		ParseDocBlock_nextTag();
/*214*/ 	}


/*216*/ 	void
/*216*/ 	ParseDocBlock_addBareText(void)
/*216*/ 	{
/*216*/ 		buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&lt;");
/*217*/ 		buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_textToHtml(ParseDocBlock_l));
/*218*/ 		ParseDocBlock_nextTag();
/*221*/ 	}


/*223*/ 	void
/*223*/ 	ParseDocBlock_parseHtml(void)
/*223*/ 	{

/*225*/ 		int
/*225*/ 		ParseDocBlock_isSimpleTag(void)
/*225*/ 		{
/*225*/ 			return ((m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"b>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"i>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"code>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"samp>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"var>") == 0));
/*229*/ 		}


/*230*/ 		void
/*230*/ 		ParseDocBlock_parseSimpleTag(void)
/*230*/ 		{
/*232*/ 			STRING * ParseDocBlock_q_end = NULL;
/*232*/ 			STRING * ParseDocBlock_q = NULL;
/*232*/ 			ParseDocBlock_q = ParseDocBlock_t;
/*233*/ 			ParseDocBlock_q_end = m2runtime_concat_STRING(0, m2runtime_CHR(47), ParseDocBlock_q, 1);
/*234*/ 			ParseDocBlock_addTag();
/*236*/ 			do{
/*236*/ 				if( ParseDocBlock_t == NULL ){
/*237*/ 					if( ParseDocBlock_l == NULL ){
/*238*/ 						Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"missing closing tag `<", ParseDocBlock_q_end, m2runtime_CHR(39), 1));
/*239*/ 						buffer_AddString((void *)&ParseDocBlock_eb, m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_q_end, 1));
/*241*/ 						return ;
/*242*/ 					} else {
/*242*/ 						ParseDocBlock_addBareText();
/*244*/ 					}
/*244*/ 				} else if( m2runtime_strcmp(ParseDocBlock_t, ParseDocBlock_q_end) == 0 ){
/*245*/ 					ParseDocBlock_addTag();
/*247*/ 					return ;
/*247*/ 				} else if( ParseDocBlock_isSimpleTag() ){
/*248*/ 					ParseDocBlock_parseSimpleTag();
/*250*/ 				} else {
/*250*/ 					Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected closing tag `<", ParseDocBlock_q_end, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"' near the line `<", ParseDocBlock_short(ParseDocBlock_l), m2runtime_CHR(39), 1));
/*251*/ 					buffer_AddString((void *)&ParseDocBlock_eb, m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_q_end, 1));
/*253*/ 					return ;
/*255*/ 				}
/*257*/ 			}while(TRUE);
/*258*/ 		}


/*265*/ 		void
/*265*/ 		ParseDocBlock_checkEmptyAfterTag(void)
/*265*/ 		{
/*265*/ 			if( !m2_match(ParseDocBlock_l, m2runtime_concat_STRING(0, ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"[ \011]*$", 1)) ){
/*266*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"trailing chars after tag `<", ParseDocBlock_short(ParseDocBlock_l), m2runtime_CHR(39), 1));
/*268*/ 			}
/*268*/ 			buffer_AddString((void *)&ParseDocBlock_eb, m2runtime_CHR(60));
/*269*/ 			buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_t);
/*270*/ 			ParseDocBlock_nextTag();
/*273*/ 		}


/*275*/ 		void
/*275*/ 		ParseDocBlock_parseLi(void)
/*275*/ 		{
/*275*/ 			ParseDocBlock_addTag();
/*276*/ 			ParseDocBlock_parseHtml();
/*277*/ 			if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"/li>") == 0 ){
/*278*/ 				ParseDocBlock_checkEmptyAfterTag();
/*280*/ 			} else {
/*280*/ 				buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</li>\012");
/*284*/ 			}
/*286*/ 		}

/*287*/ 		do{
/*287*/ 			if( ParseDocBlock_t == NULL ){
/*288*/ 				if( ParseDocBlock_l == NULL ){
/*290*/ 					return ;
/*291*/ 				} else {
/*291*/ 					ParseDocBlock_addBareText();
/*294*/ 				}
/*294*/ 			} else if( ((m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"br>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"/br>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"p>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"/p>") == 0)) ){
/*297*/ 				ParseDocBlock_addTag();
/*299*/ 			} else if( ParseDocBlock_isSimpleTag() ){
/*300*/ 				ParseDocBlock_parseSimpleTag();
/*302*/ 			} else if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"pre>") == 0 ){
/*303*/ 				ParseDocBlock_addTag();
/*304*/ 				while( ((m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"/pre>") != 0) && (ParseDocBlock_l != NULL)) ){
/*305*/ 					ParseDocBlock_addBareText();
/*307*/ 				}
/*307*/ 				if( ParseDocBlock_l == NULL ){
/*308*/ 					Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"unclosed <pre> entity");
/*309*/ 					buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</pre>\012");
/*311*/ 					return ;
/*312*/ 				}
/*312*/ 				ParseDocBlock_addTag();
/*314*/ 			} else if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"ul>") == 0 ){
/*315*/ 				ParseDocBlock_checkEmptyAfterTag();
/*316*/ 				while( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"li>") == 0 ){
/*317*/ 					ParseDocBlock_parseLi();
/*319*/ 				}
/*319*/ 				if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"/ul>") == 0 ){
/*320*/ 					ParseDocBlock_addTag();
/*322*/ 				} else {
/*322*/ 					Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"expected `</ul>' near or at `<", ParseDocBlock_short(ParseDocBlock_l), m2runtime_CHR(39), 1));
/*323*/ 					buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</ul>\012");
/*326*/ 				}
/*326*/ 			} else if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"ol>") == 0 ){
/*327*/ 				ParseDocBlock_checkEmptyAfterTag();
/*328*/ 				while( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"li>") == 0 ){
/*329*/ 					ParseDocBlock_parseLi();
/*331*/ 				}
/*331*/ 				if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"/ol>") == 0 ){
/*332*/ 					ParseDocBlock_addTag();
/*334*/ 				} else {
/*334*/ 					Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"expected `</ol>' near or at `<", ParseDocBlock_short(ParseDocBlock_l), m2runtime_CHR(39), 1));
/*335*/ 					buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</ol>\012");
/*339*/ 				}
/*341*/ 			} else {
/*341*/ 				return ;
/*344*/ 			}
/*345*/ 		}while(TRUE);
/*347*/ 	}

/*348*/ 	if( m2runtime_strcmp(ParseDocBlock_s, EMPTY_STRING) <= 0 ){
/*349*/ 		return ParseDocBlock_s;
/*352*/ 	}
/*352*/ 	if( ParseDocBlock_tags == NULL ){
/*353*/ 		ParseDocBlock_tags = str_split(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)"b> /b> i> /i> code> /code> br> p> /p> pre> /pre> /br>", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)" ul> /ul> ol> /ol> li> /li> samp> /samp> var> /var>", 1), m2runtime_CHR(32));
/*358*/ 	}
/*358*/ 	ParseDocBlock_a = str_split(ParseDocBlock_s, m2runtime_CHR(60));
/*359*/ 	ParseDocBlock_i = 0;
/*360*/ 	ParseDocBlock_nextTag();
/*362*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_eb);
/*365*/ 	buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_textToHtml(ParseDocBlock_l));
/*366*/ 	ParseDocBlock_nextTag();
/*368*/ 	while( ParseDocBlock_l != NULL ){
/*369*/ 		ParseDocBlock_parseHtml();
/*370*/ 		if( ParseDocBlock_l != NULL ){
/*371*/ 			ParseDocBlock_addBareText();
/*374*/ 		}
/*375*/ 	}
/*375*/ 	return buffer_ToString(ParseDocBlock_eb);
/*379*/ }


/*381*/ void
/*381*/ ParseDocBlock_skipLWSP(void)
/*381*/ {
/*381*/ 	while( ParseDocBlock_isLWSP(ParseDocBlock_c) ){
/*382*/ 		ParseDocBlock_readCh();
/*385*/ 	}
/*387*/ }


/*393*/ STRING *
/*393*/ ParseDocBlock_upToEndOfLine(void)
/*393*/ {
/*393*/ 	ParseDocBlock_skipLWSP();
/*394*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*395*/ 	while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) != 0)) ){
/*396*/ 		buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_c);
/*397*/ 		ParseDocBlock_readCh();
/*399*/ 	}
/*399*/ 	if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0 ){
/*400*/ 		ParseDocBlock_readCh();
/*402*/ 	}
/*402*/ 	return buffer_ToString(ParseDocBlock_b);
/*406*/ }


/*430*/ RECORD *
/*430*/ ParseDocBlock_parseType(STRING *ParseDocBlock_w)
/*430*/ {
/*431*/ 	int ParseDocBlock_i = 0;
/*432*/ 	STRING * ParseDocBlock_c = NULL;
/*434*/ 	STRING * ParseDocBlock_sym_lc = NULL;
/*434*/ 	STRING * ParseDocBlock_sym = NULL;

/*436*/ 	void
/*436*/ 	ParseDocBlock_next_char(void)
/*436*/ 	{
/*436*/ 		if( (ParseDocBlock_i >= m2runtime_length(ParseDocBlock_w)) ){
/*437*/ 			ParseDocBlock_c = NULL;
/*439*/ 		} else {
/*439*/ 			ParseDocBlock_c = m2runtime_substr(ParseDocBlock_w, ParseDocBlock_i, 0, 0, ParseDocBlock_0err_entry_get, 9);
/*441*/ 		}
/*441*/ 		m2_inc(&ParseDocBlock_i, 1);
/*444*/ 	}


/*446*/ 	int
/*446*/ 	ParseDocBlock_isDigit(STRING *ParseDocBlock_c)
/*446*/ 	{
/*446*/ 		return ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(57)) <= 0));
/*449*/ 	}


/*451*/ 	int
/*451*/ 	ParseDocBlock_is_id_char(STRING *ParseDocBlock_c)
/*451*/ 	{
/*451*/ 		return (((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(57)) <= 0)) || ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(97)) >= 0) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(122)) <= 0)) || ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(65)) >= 0) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(90)) <= 0)) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(95)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(128)) > 0));
/*458*/ 	}


/*459*/ 	void
/*459*/ 	ParseDocBlock_next_sym(void)
/*459*/ 	{
/*461*/ 		int ParseDocBlock_j = 0;
/*461*/ 		if( ParseDocBlock_c == NULL ){
/*462*/ 			ParseDocBlock_sym = NULL;
/*463*/ 		} else if( ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(124)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(91)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(93)) == 0)) ){
/*464*/ 			ParseDocBlock_sym = ParseDocBlock_c;
/*465*/ 			ParseDocBlock_next_char();
/*466*/ 		} else if( (ParseDocBlock_is_id_char(ParseDocBlock_c) && !ParseDocBlock_isDigit(ParseDocBlock_c)) ){
/*467*/ 			ParseDocBlock_j = ParseDocBlock_i;
/*469*/ 			do {
/*469*/ 				ParseDocBlock_next_char();
/*470*/ 			} while( !( !ParseDocBlock_is_id_char(ParseDocBlock_c) ));
/*471*/ 			ParseDocBlock_sym = m2runtime_substr(ParseDocBlock_w, (ParseDocBlock_j - 1), (ParseDocBlock_i - 1), 1, ParseDocBlock_0err_entry_get, 10);
/*472*/ 			ParseDocBlock_sym_lc = str_tolower(ParseDocBlock_sym);
/*474*/ 		} else {
/*474*/ 			ParseDocBlock_sym = ParseDocBlock_c;
/*475*/ 			ParseDocBlock_next_char();
/*478*/ 		}
/*479*/ 	}


/*481*/ 	void
/*481*/ 	ParseDocBlock_checkMispelled(STRING *ParseDocBlock_expect, STRING *ParseDocBlock_found)
/*481*/ 	{
/*481*/ 		if( m2runtime_strcmp(ParseDocBlock_expect, ParseDocBlock_found) == 0 ){
/*483*/ 			return ;
/*484*/ 		}
/*484*/ 		Scanner_Notice2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"mispelled type identifier `", ParseDocBlock_found, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"', expected `", ParseDocBlock_expect, m2runtime_CHR(39), 1));
/*488*/ 	}


/*490*/ 	RECORD *
/*490*/ 	ParseDocBlock_next_type(void)
/*490*/ 	{

/*491*/ 		RECORD *
/*491*/ 		ParseDocBlock_parse_array(void)
/*491*/ 		{
/*493*/ 			RECORD * ParseDocBlock_t = NULL;
/*493*/ 			ParseDocBlock_t = (
/*493*/ 				push((char*) alloc_RECORD(24, 2)),
/*493*/ 				*(int*) (tos()+16) = 6,
/*493*/ 				*(int*) (tos()+20) = 1,
/*493*/ 				push((char*) NULL),
/*493*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*493*/ 				push((char*) NULL),
/*494*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*494*/ 				(RECORD*) pop()
/*494*/ 			);
/*494*/ 			ParseDocBlock_next_sym();
/*495*/ 			if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int") == 0 ){
/*496*/ 				ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int", ParseDocBlock_sym);
/*497*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_t, 24, 2, 20, ParseDocBlock_0err_entry_get, 11) = 3;
/*498*/ 				ParseDocBlock_next_sym();
/*499*/ 			} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string") == 0 ){
/*500*/ 				ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string", ParseDocBlock_sym);
/*501*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_t, 24, 2, 20, ParseDocBlock_0err_entry_get, 12) = 5;
/*502*/ 				ParseDocBlock_next_sym();
/*504*/ 			}
/*504*/ 			if( m2runtime_strcmp(ParseDocBlock_sym, m2runtime_CHR(93)) != 0 ){
/*505*/ 				Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"in type declaration, expected `[]' or `[int]' or `[string]'");
/*506*/ 				return ParseDocBlock_t;
/*508*/ 			}
/*508*/ 			ParseDocBlock_next_sym();
/*509*/ 			if( m2runtime_strcmp(ParseDocBlock_sym, m2runtime_CHR(91)) == 0 ){
/*510*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_t, 24, 2, 8, ParseDocBlock_0err_entry_get, 13) = ParseDocBlock_parse_array();
/*512*/ 			} else {
/*512*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_t, 24, 2, 8, ParseDocBlock_0err_entry_get, 14) = ParseDocBlock_next_type();
/*514*/ 			}
/*514*/ 			return ParseDocBlock_t;
/*517*/ 		}

/*519*/ 		RECORD * ParseDocBlock_cl = NULL;
/*519*/ 		if( ParseDocBlock_sym == NULL ){
/*520*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"invalid or missing type");
/*521*/ 			ParseDocBlock_next_sym();
/*522*/ 			return NULL;
/*523*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"void") == 0 ){
/*524*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"void", ParseDocBlock_sym);
/*525*/ 			ParseDocBlock_next_sym();
/*526*/ 			return Globals_void_type;
/*527*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"bool") == 0 ){
/*528*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"bool", ParseDocBlock_sym);
/*529*/ 			ParseDocBlock_next_sym();
/*530*/ 			return Globals_boolean_type;
/*531*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean") == 0 ){
/*532*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean", ParseDocBlock_sym);
/*533*/ 			ParseDocBlock_next_sym();
/*534*/ 			return Globals_boolean_type;
/*535*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"false") == 0 ){
/*536*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE", ParseDocBlock_sym);
/*537*/ 			ParseDocBlock_next_sym();
/*538*/ 			return Globals_boolean_type;
/*539*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int") == 0 ){
/*540*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int", ParseDocBlock_sym);
/*541*/ 			ParseDocBlock_next_sym();
/*542*/ 			return Globals_int_type;
/*543*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"integer") == 0 ){
/*544*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"integer", ParseDocBlock_sym);
/*545*/ 			ParseDocBlock_next_sym();
/*546*/ 			return Globals_int_type;
/*547*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float") == 0 ){
/*548*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float", ParseDocBlock_sym);
/*549*/ 			ParseDocBlock_next_sym();
/*550*/ 			return Globals_float_type;
/*551*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"double") == 0 ){
/*552*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"double", ParseDocBlock_sym);
/*553*/ 			ParseDocBlock_next_sym();
/*554*/ 			return Globals_float_type;
/*555*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"real") == 0 ){
/*556*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"real", ParseDocBlock_sym);
/*557*/ 			ParseDocBlock_next_sym();
/*558*/ 			return Globals_float_type;
/*559*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"number") == 0 ){
/*560*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)"unsupported type `number', assuming `float' instead");
/*561*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"number", ParseDocBlock_sym);
/*562*/ 			ParseDocBlock_next_sym();
/*563*/ 			return Globals_float_type;
/*564*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string") == 0 ){
/*565*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string", ParseDocBlock_sym);
/*566*/ 			ParseDocBlock_next_sym();
/*567*/ 			return Globals_string_type;
/*568*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array") == 0 ){
/*569*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array", ParseDocBlock_sym);
/*570*/ 			ParseDocBlock_next_sym();
/*571*/ 			if( m2runtime_strcmp(ParseDocBlock_sym, m2runtime_CHR(91)) == 0 ){
/*572*/ 				return ParseDocBlock_parse_array();
/*574*/ 			} else {
/*574*/ 				return (
/*574*/ 					push((char*) alloc_RECORD(24, 2)),
/*574*/ 					*(int*) (tos()+16) = 6,
/*574*/ 					*(int*) (tos()+20) = 1,
/*574*/ 					push((char*) NULL),
/*574*/ 					*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*574*/ 					push((char*) NULL),
/*575*/ 					*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*576*/ 					(RECORD*) pop()
/*576*/ 				);
/*576*/ 			}
/*576*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"resource") == 0 ){
/*577*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"resource", ParseDocBlock_sym);
/*578*/ 			ParseDocBlock_next_sym();
/*579*/ 			return Globals_resource_type;
/*580*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"mixed") == 0 ){
/*581*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"mixed", ParseDocBlock_sym);
/*582*/ 			ParseDocBlock_next_sym();
/*583*/ 			return Globals_mixed_type;
/*584*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object") == 0 ){
/*585*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object", ParseDocBlock_sym);
/*586*/ 			ParseDocBlock_next_sym();
/*587*/ 			return (
/*587*/ 				push((char*) alloc_RECORD(24, 2)),
/*587*/ 				*(int*) (tos()+16) = 9,
/*587*/ 				*(int*) (tos()+20) = 1,
/*587*/ 				push((char*) NULL),
/*587*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*587*/ 				push((char*) NULL),
/*588*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*588*/ 				(RECORD*) pop()
/*588*/ 			);
/*588*/ 		} else if( m2_match(ParseDocBlock_sym, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"^[_a-zA-Z\200-\377][_0-9a-zA-Z\200-\377]*$") ){
/*589*/ 			ParseDocBlock_cl = Search_SearchClass(ParseDocBlock_sym, TRUE);
/*590*/ 			if( ParseDocBlock_cl == NULL ){
/*591*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"unknown type/class `", ParseDocBlock_sym, m2runtime_CHR(39), 1));
/*592*/ 				ParseDocBlock_next_sym();
/*593*/ 				return (
/*593*/ 					push((char*) alloc_RECORD(24, 2)),
/*593*/ 					*(int*) (tos()+16) = 9,
/*593*/ 					*(int*) (tos()+20) = 1,
/*593*/ 					push((char*) NULL),
/*593*/ 					*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*593*/ 					push((char*) NULL),
/*594*/ 					*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*595*/ 					(RECORD*) pop()
/*595*/ 				);
/*595*/ 			} else {
/*595*/ 				ParseDocBlock_next_sym();
/*596*/ 				return (RECORD *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_cl, 24, ParseDocBlock_0err_entry_get, 15);
/*599*/ 			}
/*599*/ 		} else {
/*599*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"invalid type `", ParseDocBlock_sym, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"', presuming mixed and trying to continue anyway", 1));
/*600*/ 			ParseDocBlock_next_sym();
/*601*/ 			return Globals_mixed_type;
/*604*/ 		}
/*604*/ 		m2runtime_missing_return(ParseDocBlock_0err_entry_get, 16);
/*604*/ 		return NULL;
/*605*/ 	}

/*607*/ 	RECORD * ParseDocBlock_ignore = NULL;
/*607*/ 	RECORD * ParseDocBlock_res = NULL;
/*607*/ 	ParseDocBlock_i = 0;
/*608*/ 	ParseDocBlock_next_char();
/*609*/ 	ParseDocBlock_next_sym();
/*610*/ 	ParseDocBlock_res = ParseDocBlock_next_type();
/*611*/ 	while( m2runtime_strcmp(ParseDocBlock_sym, m2runtime_CHR(124)) == 0 ){
/*612*/ 		ParseDocBlock_next_sym();
/*613*/ 		ParseDocBlock_ignore = ParseDocBlock_next_type();
/*615*/ 	}
/*615*/ 	if( ParseDocBlock_sym != NULL ){
/*616*/ 		Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"unknown/unexpected symbol `", ParseDocBlock_sym, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"' in type", 1));
/*618*/ 	}
/*618*/ 	return ParseDocBlock_res;
/*622*/ }


/*627*/ void
/*627*/ ParseDocBlock_parseLineTag(void)
/*627*/ {

/*628*/ 	void
/*628*/ 	ParseDocBlock_check_eol(STRING *ParseDocBlock_tag_name)
/*628*/ 	{
/*630*/ 		STRING * ParseDocBlock_s = NULL;
/*630*/ 		ParseDocBlock_skipLWSP();
/*631*/ 		if( ParseDocBlock_c == NULL ){
/*633*/ 			return ;
/*633*/ 		} else if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0 ){
/*636*/ 			do {
/*636*/ 				ParseDocBlock_readCh();
/*637*/ 				ParseDocBlock_skipLWSP();
/*638*/ 			} while( !( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) != 0 ));
/*639*/ 			if( ((ParseDocBlock_c == NULL) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) == 0)) ){
/*641*/ 				return ;
/*642*/ 			}
/*642*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"unexpected continuation lines for `", ParseDocBlock_tag_name, m2runtime_CHR(39), 1));
/*643*/ 			while( ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) != 0) && (ParseDocBlock_c != NULL)) ){
/*644*/ 				ParseDocBlock_s = ParseDocBlock_upToEndOfLine();
/*647*/ 			}
/*647*/ 		} else {
/*647*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"unexpected trailing words inside `", ParseDocBlock_tag_name, m2runtime_CHR(39), 1));
/*648*/ 			ParseDocBlock_s = ParseDocBlock_upToEndOfLine();
/*651*/ 		}
/*653*/ 	}


/*662*/ 	STRING *
/*662*/ 	ParseDocBlock_getWord(void)
/*662*/ 	{
/*662*/ 		ParseDocBlock_skipLWSP();
/*663*/ 		buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*664*/ 		while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) != 0) && !ParseDocBlock_isLWSP(ParseDocBlock_c)) ){
/*665*/ 			buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_c);
/*666*/ 			ParseDocBlock_readCh();
/*668*/ 		}
/*668*/ 		return ParseDocBlock_textToHtml(buffer_ToString(ParseDocBlock_b));
/*672*/ 	}


/*673*/ 	STRING *
/*673*/ 	ParseDocBlock_getDescr(void)
/*673*/ 	{
/*675*/ 		STRING * ParseDocBlock_l = NULL;
/*675*/ 		STRING * ParseDocBlock_s = NULL;
/*675*/ 		while( (ParseDocBlock_isLWSP(ParseDocBlock_c) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0)) ){
/*676*/ 			ParseDocBlock_readCh();
/*678*/ 		}
/*678*/ 		if( ((ParseDocBlock_c == NULL) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) == 0)) ){
/*679*/ 			return NULL;
/*682*/ 		}
/*682*/ 		ParseDocBlock_s = ParseDocBlock_filterValidHtmlEntities(ParseDocBlock_upToEndOfLine());
/*685*/ 		while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) != 0)) ){
/*686*/ 			ParseDocBlock_l = ParseDocBlock_filterValidHtmlEntities(ParseDocBlock_upToEndOfLine());
/*687*/ 			if( m2runtime_strcmp(ParseDocBlock_l, EMPTY_STRING) <= 0 ){
/*688*/ 				ParseDocBlock_s = m2runtime_concat_STRING(0, ParseDocBlock_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<p>", 1);
/*690*/ 			} else {
/*690*/ 				ParseDocBlock_s = m2runtime_concat_STRING(0, ParseDocBlock_s, m2runtime_CHR(10), ParseDocBlock_l, 1);
/*693*/ 			}
/*693*/ 		}
/*693*/ 		return ParseDocBlock_s;
/*697*/ 	}


/*698*/ 	STRING *
/*698*/ 	ParseDocBlock_getText(void)
/*698*/ 	{
/*700*/ 		STRING * ParseDocBlock_l = NULL;
/*700*/ 		STRING * ParseDocBlock_s = NULL;
/*700*/ 		ParseDocBlock_s = ParseDocBlock_textToHtml(ParseDocBlock_upToEndOfLine());
/*702*/ 		while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) != 0)) ){
/*703*/ 			ParseDocBlock_l = ParseDocBlock_textToHtml(ParseDocBlock_upToEndOfLine());
/*704*/ 			if( m2runtime_strcmp(ParseDocBlock_l, EMPTY_STRING) <= 0 ){
/*705*/ 				ParseDocBlock_s = m2runtime_concat_STRING(0, ParseDocBlock_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<p>", 1);
/*707*/ 			} else {
/*707*/ 				ParseDocBlock_s = m2runtime_concat_STRING(0, ParseDocBlock_s, m2runtime_CHR(10), ParseDocBlock_l, 1);
/*710*/ 			}
/*710*/ 		}
/*710*/ 		return ParseDocBlock_s;
/*714*/ 	}


/*716*/ 	void
/*716*/ 	ParseDocBlock_parseGlobal(void)
/*716*/ 	{
/*719*/ 		RECORD * ParseDocBlock_t = NULL;
/*721*/ 		STRING * ParseDocBlock_n = NULL;
/*724*/ 		ParseDocBlock_n = ParseDocBlock_getWord();
/*725*/ 		if( m2runtime_strcmp(ParseDocBlock_n, EMPTY_STRING) <= 0 ){
/*726*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"missing type in @global");
/*727*/ 			ParseDocBlock_n = ParseDocBlock_getText();
/*729*/ 			return ;
/*730*/ 		}
/*730*/ 		ParseDocBlock_t = ParseDocBlock_parseType(ParseDocBlock_n);
/*731*/ 		if( ParseDocBlock_t == NULL ){
/*733*/ 			ParseDocBlock_n = ParseDocBlock_getText();
/*735*/ 			return ;
/*740*/ 		}
/*740*/ 		ParseDocBlock_n = ParseDocBlock_getWord();
/*741*/ 		if( m2runtime_strcmp(ParseDocBlock_n, EMPTY_STRING) <= 0 ){
/*742*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"missing variable name in @global");
/*743*/ 			ParseDocBlock_n = ParseDocBlock_getText();
/*745*/ 			return ;
/*746*/ 		}
/*746*/ 		if( (m2_match(ParseDocBlock_n, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"^\134$GLOBALS\134[\042", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"\042\134]$", 1)) || m2_match(ParseDocBlock_n, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"^\134$GLOBALS\134['", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"'\134]$", 1))) ){
/*748*/ 			ParseDocBlock_n = m2runtime_substr(ParseDocBlock_n, 10, (m2runtime_length(ParseDocBlock_n) - 2), 1, ParseDocBlock_0err_entry_get, 17);
/*749*/ 		} else if( m2_match(ParseDocBlock_n, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"^\134$", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*", m2runtime_CHR(36), 1)) ){
/*750*/ 			ParseDocBlock_n = m2runtime_substr(ParseDocBlock_n, 1, m2runtime_length(ParseDocBlock_n), 1, ParseDocBlock_0err_entry_get, 18);
/*752*/ 		} else {
/*752*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"invalid variable name `", ParseDocBlock_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"' in @global", 1));
/*753*/ 			ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@global");
/*755*/ 			return ;
/*756*/ 		}
/*756*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@global");
/*757*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 12, ParseDocBlock_0err_entry_get, 19) = ParseDocBlock_t;
/*758*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 16, ParseDocBlock_0err_entry_get, 20) = ParseDocBlock_n;
/*762*/ 	}


/*763*/ 	RECORD *
/*763*/ 	ParseDocBlock_parseParam(int ParseDocBlock_position)
/*763*/ 	{
/*764*/ 		RECORD * ParseDocBlock_p = NULL;
/*766*/ 		STRING * ParseDocBlock_w = NULL;
/*769*/ 		ParseDocBlock_w = ParseDocBlock_getWord();
/*770*/ 		if( ((m2runtime_strcmp(ParseDocBlock_w, EMPTY_STRING) > 0) && (m2runtime_strcmp(m2runtime_substr(ParseDocBlock_w, 0, 0, 0, ParseDocBlock_0err_entry_get, 21), m2runtime_CHR(36)) == 0)) ){
/*771*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)"invalid @param declaration: expected @param TYPE $var");
/*772*/ 			ParseDocBlock_w = ParseDocBlock_getDescr();
/*773*/ 			return NULL;
/*775*/ 		} else {
/*775*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 12, ParseDocBlock_0err_entry_get, 22) = ParseDocBlock_parseType(ParseDocBlock_w);
/*776*/ 			if( (RECORD *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_p, 12, ParseDocBlock_0err_entry_get, 23) == Globals_void_type ){
/*777*/ 				Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"@param cannot be `void'");
/*778*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 12, ParseDocBlock_0err_entry_get, 24) = NULL;
/*781*/ 			}
/*785*/ 		}
/*785*/ 		ParseDocBlock_skipLWSP();
/*786*/ 		if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(38)) == 0 ){
/*787*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 20, ParseDocBlock_0err_entry_get, 25) = TRUE;
/*788*/ 			ParseDocBlock_readCh();
/*794*/ 		}
/*794*/ 		ParseDocBlock_w = ParseDocBlock_getWord();
/*795*/ 		if( m2runtime_strcmp(ParseDocBlock_w, EMPTY_STRING) <= 0 ){
/*796*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"missing parameter name for @param no. ", m2runtime_itos(((ParseDocBlock_position + 1))), 1));
/*797*/ 		} else if( !m2_match(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"^\134$[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*$") ){
/*798*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"invalid parameter name `", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"', expected variable name `$varname'", 1));
/*801*/ 		} else {
/*801*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 8, ParseDocBlock_0err_entry_get, 26) = m2runtime_substr(ParseDocBlock_w, 1, m2runtime_length(ParseDocBlock_w), 1, ParseDocBlock_0err_entry_get, 27);
/*808*/ 		}
/*808*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 16, ParseDocBlock_0err_entry_get, 28) = ParseDocBlock_getDescr();
/*810*/ 		return ParseDocBlock_p;
/*815*/ 	}

/*816*/ 	RECORD * ParseDocBlock_p = NULL;
/*817*/ 	int ParseDocBlock_position = 0;
/*819*/ 	STRING * ParseDocBlock_url = NULL;
/*819*/ 	STRING * ParseDocBlock_w = NULL;
/*819*/ 	ParseDocBlock_w = ParseDocBlock_getWord();
/*829*/ 	if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@abstract") == 0 ){
/*830*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 36, ParseDocBlock_0err_entry_get, 29) = TRUE;
/*831*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@abstract");
/*834*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@access") == 0 ){
/*835*/ 		ParseDocBlock_w = ParseDocBlock_getWord();
/*836*/ 		if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"private") == 0 ){
/*837*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 40, ParseDocBlock_0err_entry_get, 30) = TRUE;
/*838*/ 		} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"protected") == 0 ){
/*839*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 44, ParseDocBlock_0err_entry_get, 31) = TRUE;
/*840*/ 		} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"public") == 0 ){
/*841*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 48, ParseDocBlock_0err_entry_get, 32) = TRUE;
/*843*/ 		} else {
/*843*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"expected public|protected|private after @access");
/*845*/ 		}
/*845*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@access");
/*848*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@author") == 0 ){
/*849*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"<@author ", ParseDocBlock_getText(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*852*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"@copyright") == 0 ){
/*853*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"<@copyright ", ParseDocBlock_getDescr(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*856*/ 	} else if( ((m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"@deprecated") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@deprec") == 0)) ){
/*857*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"\012<@deprecated ", ParseDocBlock_getDescr(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*860*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@final") == 0 ){
/*861*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 52, ParseDocBlock_0err_entry_get, 33) = TRUE;
/*862*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@final");
/*865*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@global") == 0 ){
/*866*/ 		ParseDocBlock_parseGlobal();
/*869*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@license") == 0 ){
/*870*/ 		ParseDocBlock_url = ParseDocBlock_getWord();
/*871*/ 		ParseDocBlock_w = ParseDocBlock_getText();
/*872*/ 		if( (m2runtime_length(ParseDocBlock_w) == 0) ){
/*873*/ 			ParseDocBlock_w = ParseDocBlock_url;
/*875*/ 		}
/*875*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"\012<@license <a href=\042", ParseDocBlock_url, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\042>", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</a>>\012", 1));
/*878*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"@link") == 0 ){
/*879*/ 		ParseDocBlock_url = ParseDocBlock_getWord();
/*880*/ 		ParseDocBlock_w = ParseDocBlock_getText();
/*881*/ 		if( (m2runtime_length(ParseDocBlock_w) == 0) ){
/*882*/ 			ParseDocBlock_w = ParseDocBlock_url;
/*884*/ 		}
/*884*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"\012<p><b>Link:</b> <a href=\042", ParseDocBlock_url, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\042>", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"</a></p>\012", 1));
/*887*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@package") == 0 ){
/*888*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 32, ParseDocBlock_0err_entry_get, 34) = TRUE;
/*889*/ 		ParseDocBlock_w = ParseDocBlock_getWord();
/*890*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"<@package ", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*891*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@package");
/*894*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@param") == 0 ){
/*895*/ 		if( ParseDocBlock_pdb == NULL ){
/*896*/ 			ParseDocBlock_position = 0;
/*898*/ 		} else {
/*898*/ 			ParseDocBlock_position = m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 35));
/*900*/ 		}
/*900*/ 		ParseDocBlock_p = ParseDocBlock_parseParam(ParseDocBlock_position);
/*901*/ 		if( ParseDocBlock_p != NULL ){
/*902*/ 			if( ParseDocBlock_pdb == NULL ){
/*903*/ 				*(ARRAY **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 28, ParseDocBlock_0err_entry_get, 36) = NULL;
/*905*/ 			}
/*905*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 28, ParseDocBlock_0err_entry_get, 37), 4, 1, ParseDocBlock_0err_entry_get, 38) = ParseDocBlock_p;
/*909*/ 		}
/*909*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@return") == 0 ){
/*910*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 24, ParseDocBlock_0err_entry_get, 39) = ParseDocBlock_parseType(ParseDocBlock_getWord());
/*911*/ 		ParseDocBlock_return_descr = ParseDocBlock_getDescr();
/*916*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"@see") == 0 ){
/*917*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<@see ", ParseDocBlock_getWord(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*918*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"@see");
/*921*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@since") == 0 ){
/*922*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"\012<@since ", ParseDocBlock_getDescr(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*925*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@static") == 0 ){
/*926*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 56, ParseDocBlock_0err_entry_get, 40) = TRUE;
/*927*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@static");
/*930*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"@todo") == 0 ){
/*931*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"\012<p>\012<b>To-do:</b>\012", ParseDocBlock_getDescr(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"\012</p>\012", 1));
/*935*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"@var") == 0 ){
/*936*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 20, ParseDocBlock_0err_entry_get, 41) = ParseDocBlock_parseType(ParseDocBlock_getWord());
/*937*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 20, ParseDocBlock_0err_entry_get, 42) == Globals_void_type ){
/*938*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"@var cannot be `void'");
/*939*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 20, ParseDocBlock_0err_entry_get, 43) = NULL;
/*941*/ 		}
/*941*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, ParseDocBlock_getDescr(), m2runtime_CHR(10), 1));
/*944*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@version") == 0 ){
/*945*/ 		ParseDocBlock_w = ParseDocBlock_getDescr();
/*946*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"<@version ", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*949*/ 	} else if( ((m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@example") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@category") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@example") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"@exception") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"@filesource") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@ignore") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@internal") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"@name") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"@staticvar") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"@subpackage") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@tutorial") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"@uses") == 0)) ){
/*962*/ 		Scanner_Notice2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"unsupported line tag `", ParseDocBlock_w, m2runtime_CHR(39), 1));
/*963*/ 		ParseDocBlock_w = ParseDocBlock_getText();
/*966*/ 	} else {
/*966*/ 		Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"unknown line tag `", ParseDocBlock_w, m2runtime_CHR(39), 1));
/*967*/ 		ParseDocBlock_w = ParseDocBlock_getText();
/*971*/ 	}
/*973*/ }


/*975*/ void
/*975*/ ParseDocBlock_parseShortAndLongDescr(STRING **ParseDocBlock_short, STRING **ParseDocBlock_long)
/*975*/ {

/*980*/ 	int
/*980*/ 	ParseDocBlock_findPeriod(STRING *ParseDocBlock_s)
/*980*/ 	{
/*982*/ 		int ParseDocBlock_j = 0;
/*982*/ 		int ParseDocBlock_i = 0;
/*982*/ 		ParseDocBlock_i = str_find(ParseDocBlock_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)". ");
/*983*/ 		ParseDocBlock_j = str_find(ParseDocBlock_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)".\011");
/*984*/ 		if( (ParseDocBlock_i == -1) ){
/*985*/ 			ParseDocBlock_i = ParseDocBlock_j;
/*986*/ 		} else if( (ParseDocBlock_j == -1) ){
/*989*/ 		} else {
/*989*/ 			ParseDocBlock_i = m2_min(ParseDocBlock_i, ParseDocBlock_j);
/*992*/ 		}
/*992*/ 		if( (ParseDocBlock_i >= 0) ){
/*993*/ 			return ParseDocBlock_i;
/*995*/ 		} else {
/*995*/ 			if( m2runtime_strcmp(m2runtime_substr(ParseDocBlock_s, (m2runtime_length(ParseDocBlock_s) - 1), 0, 0, ParseDocBlock_0err_entry_get, 44), m2runtime_CHR(46)) == 0 ){
/*996*/ 				return (m2runtime_length(ParseDocBlock_s) - 1);
/*998*/ 			} else {
/*998*/ 				return -1;
/*1001*/ 			}
/*1002*/ 		}
/*1002*/ 		m2runtime_missing_return(ParseDocBlock_0err_entry_get, 45);
/*1002*/ 		return 0;
/*1004*/ 	}

/*1005*/ 	int ParseDocBlock_x = 0;
/*1005*/ 	int ParseDocBlock_i = 0;
/*1005*/ 	int ParseDocBlock_n = 0;
/*1006*/ 	void * ParseDocBlock_b = NULL;
/*1007*/ 	STRING * ParseDocBlock_s = NULL;
/*1010*/ 	ARRAY * ParseDocBlock_a = NULL;
/*1010*/ 	*ParseDocBlock_short = NULL;
/*1011*/ 	*ParseDocBlock_long = NULL;
/*1013*/ 	while( (ParseDocBlock_isLWSP(ParseDocBlock_c) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0)) ){
/*1014*/ 		ParseDocBlock_readCh();
/*1017*/ 	}
/*1017*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*1020*/ 	do{
/*1020*/ 		if( ((ParseDocBlock_c == NULL) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) == 0)) ){
/*1021*/ 			*ParseDocBlock_short = str_join(ParseDocBlock_a, m2runtime_CHR(32));
/*1024*/ 			goto m2runtime_loop_1;
/*1025*/ 		}
/*1025*/ 		ParseDocBlock_s = ParseDocBlock_upToEndOfLine();
/*1027*/ 		if( m2runtime_strcmp(ParseDocBlock_s, EMPTY_STRING) <= 0 ){
/*1028*/ 			*ParseDocBlock_short = str_join(ParseDocBlock_a, m2runtime_CHR(32));
/*1031*/ 			goto m2runtime_loop_1;
/*1032*/ 		}
/*1032*/ 		if( (ParseDocBlock_n >= 3) ){
/*1033*/ 			*ParseDocBlock_short = (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_a, 0, ParseDocBlock_0err_entry_get, 46);
/*1034*/ 			{
/*1034*/ 				int m2runtime_for_limit_1;
/*1034*/ 				ParseDocBlock_i = 1;
/*1034*/ 				m2runtime_for_limit_1 = (m2runtime_count(ParseDocBlock_a) - 1);
/*1035*/ 				for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*1035*/ 					buffer_AddString((void *)&ParseDocBlock_b, (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_a, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 47));
/*1036*/ 					buffer_AddString((void *)&ParseDocBlock_b, m2runtime_CHR(10));
/*1039*/ 				}
/*1039*/ 			}
/*1040*/ 			goto m2runtime_loop_1;
/*1041*/ 		}
/*1041*/ 		ParseDocBlock_x = ParseDocBlock_findPeriod(ParseDocBlock_s);
/*1043*/ 		if( (ParseDocBlock_x > 0) ){
/*1044*/ 			*ParseDocBlock_short = m2runtime_concat_STRING(0, str_join(ParseDocBlock_a, m2runtime_CHR(32)), m2runtime_CHR(32), m2runtime_substr(ParseDocBlock_s, 0, ParseDocBlock_x, 1, ParseDocBlock_0err_entry_get, 48), 1);
/*1045*/ 			buffer_AddString((void *)&ParseDocBlock_b, m2runtime_substr(ParseDocBlock_s, (ParseDocBlock_x + 1), m2runtime_length(ParseDocBlock_s), 1, ParseDocBlock_0err_entry_get, 49));
/*1046*/ 			buffer_AddString((void *)&ParseDocBlock_b, m2runtime_CHR(10));
/*1049*/ 			goto m2runtime_loop_1;
/*1050*/ 		}
/*1050*/ 		*(STRING **)m2runtime_dereference_lhs_ARRAY(&ParseDocBlock_a, 4, 1, ParseDocBlock_n, ParseDocBlock_0err_entry_get, 50) = ParseDocBlock_s;
/*1051*/ 		m2_inc(&ParseDocBlock_n, 1);
/*1054*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1054*/ 	while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) != 0)) ){
/*1055*/ 		ParseDocBlock_s = ParseDocBlock_upToEndOfLine();
/*1056*/ 		if( m2runtime_strcmp(ParseDocBlock_s, EMPTY_STRING) <= 0 ){
/*1057*/ 			buffer_AddString((void *)&ParseDocBlock_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<p>\012");
/*1059*/ 		} else {
/*1059*/ 			buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_s);
/*1060*/ 			buffer_AddString((void *)&ParseDocBlock_b, m2runtime_CHR(10));
/*1063*/ 		}
/*1064*/ 	}
/*1064*/ 	*ParseDocBlock_short = ParseDocBlock_textToHtml(*ParseDocBlock_short);
/*1065*/ 	*ParseDocBlock_long = ParseDocBlock_filterValidHtmlEntities(buffer_ToString(ParseDocBlock_b));
/*1070*/ }

/*1074*/ RECORD * ParseDocBlock_template = NULL;
/*1078*/ RECORD * ParseDocBlock_template_where = NULL;

/*1082*/ RECORD *
/*1082*/ ParseDocBlock_ParseDocBlock(STRING *ParseDocBlock_doc)
/*1082*/ {
/*1083*/ 	RECORD * ParseDocBlock_p = NULL;
/*1085*/ 	int ParseDocBlock_i = 0;
/*1089*/ 	int ParseDocBlock_is_template = 0;
/*1092*/ 	STRING * ParseDocBlock_long = NULL;
/*1092*/ 	STRING * ParseDocBlock_short = NULL;
/*1092*/ 	if( !ParseDocBlock_parse_phpdoc ){
/*1093*/ 		return NULL;
/*1099*/ 	}
/*1099*/ 	if( (((m2runtime_length(ParseDocBlock_doc) >= 8)) && (m2runtime_strcmp(m2runtime_substr(ParseDocBlock_doc, 0, 6, 1, ParseDocBlock_0err_entry_get, 51), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"/**#@+") == 0)) ){
/*1100*/ 		if( ParseDocBlock_template != NULL ){
/*1101*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"missing closing /**#@-*/ for template opened in ", Scanner_reference(ParseDocBlock_template_where), 1));
/*1104*/ 		}
/*1104*/ 		ParseDocBlock_is_template = TRUE;
/*1105*/ 		ParseDocBlock_template = NULL;
/*1106*/ 		ParseDocBlock_template_where = Scanner_here();
/*1112*/ 	}
/*1112*/ 	if( m2runtime_strcmp(ParseDocBlock_doc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"/**#@-*/") == 0 ){
/*1113*/ 		if( ParseDocBlock_template == NULL ){
/*1114*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"no previous template opened");
/*1116*/ 		}
/*1116*/ 		ParseDocBlock_template = NULL;
/*1119*/ 	}
/*1119*/ 	if( ParseDocBlock_types == NULL ){
/*1120*/ 		ParseDocBlock_types = (
/*1121*/ 			push((char*) alloc_ARRAY(4, 1)),
/*1121*/ 			push((char*) (
/*1121*/ 				push((char*) alloc_RECORD(16, 2)),
/*1121*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int"),
/*1121*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1121*/ 				push((char*) Globals_int_type),
/*1121*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*1122*/ 				(RECORD*) pop()
/*1122*/ 			)),
/*1122*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*1122*/ 			push((char*) (
/*1122*/ 				push((char*) alloc_RECORD(16, 2)),
/*1122*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string"),
/*1122*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1122*/ 				push((char*) Globals_string_type),
/*1123*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*1124*/ 				(RECORD*) pop()
/*1124*/ 			)),
/*1124*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*1125*/ 			(ARRAY*) pop()
/*1125*/ 		);
/*1127*/ 	}
/*1127*/ 	ParseDocBlock_in = ParseDocBlock_doc;
/*1128*/ 	if( ParseDocBlock_is_template ){
/*1130*/ 		ParseDocBlock_pos = 6;
/*1132*/ 	} else {
/*1132*/ 		ParseDocBlock_pos = 3;
/*1134*/ 	}
/*1134*/ 	ParseDocBlock_line_n = 1;
/*1135*/ 	ParseDocBlock_len = m2runtime_length(ParseDocBlock_doc);
/*1136*/ 	if( (ParseDocBlock_len <= 5) ){
/*1137*/ 		return NULL;
/*1139*/ 	}
/*1139*/ 	ParseDocBlock_len = (ParseDocBlock_len - 2);
/*1140*/ 	ParseDocBlock_c = m2runtime_CHR(32);
/*1141*/ 	ParseDocBlock_readCh();
/*1144*/ 	ParseDocBlock_pdb = NULL;
/*1145*/ 	ParseDocBlock_return_descr = NULL;
/*1146*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_descr);
/*1148*/ 	ParseDocBlock_parseShortAndLongDescr(&ParseDocBlock_short, &ParseDocBlock_long);
/*1149*/ 	if( ((m2runtime_strcmp(ParseDocBlock_short, EMPTY_STRING) > 0) || (m2runtime_strcmp(ParseDocBlock_long, EMPTY_STRING) > 0)) ){
/*1150*/ 		buffer_AddString((void *)&ParseDocBlock_descr, ParseDocBlock_short);
/*1151*/ 		buffer_AddString((void *)&ParseDocBlock_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\012\012");
/*1152*/ 		buffer_AddString((void *)&ParseDocBlock_descr, ParseDocBlock_long);
/*1159*/ 	}
/*1159*/ 	while( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) == 0 ){
/*1160*/ 		ParseDocBlock_parseLineTag();
/*1163*/ 	}
/*1163*/ 	if( ParseDocBlock_c != NULL ){
/*1164*/ 		m2runtime_HALT(ParseDocBlock_0err_entry_get, 52, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"expected @ in DocBlock, found ", ParseDocBlock_c, 1));
/*1171*/ 	}
/*1171*/ 	if( ((ParseDocBlock_pdb != NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 53) != NULL)) ){
/*1172*/ 		buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*1173*/ 		{
/*1173*/ 			int m2runtime_for_limit_1;
/*1173*/ 			ParseDocBlock_i = 0;
/*1173*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 54)) - 1);
/*1174*/ 			for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*1174*/ 				ParseDocBlock_p = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 55), ParseDocBlock_i, ParseDocBlock_0err_entry_get, 56);
/*1175*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_p, 16, ParseDocBlock_0err_entry_get, 57), EMPTY_STRING) > 0 ){
/*1176*/ 					buffer_AddString((void *)&ParseDocBlock_b, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"<tr><td valign=top><b><code>$", (STRING *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_p, 8, ParseDocBlock_0err_entry_get, 58), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"</code></b></td> <td valign=top>", (STRING *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_p, 16, ParseDocBlock_0err_entry_get, 59), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"</td></tr>\012", 1));
/*1181*/ 				}
/*1181*/ 			}
/*1181*/ 		}
/*1181*/ 		if( (buffer_Length(ParseDocBlock_b) > 0) ){
/*1182*/ 			buffer_AddString((void *)&ParseDocBlock_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"\012<p><b>Parameters:</b>\012<table>\012");
/*1183*/ 			buffer_AddString((void *)&ParseDocBlock_descr, buffer_ToString(ParseDocBlock_b));
/*1184*/ 			buffer_AddString((void *)&ParseDocBlock_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"</table>\012</p>\012");
/*1187*/ 		}
/*1191*/ 	}
/*1191*/ 	if( m2runtime_strcmp(ParseDocBlock_return_descr, EMPTY_STRING) > 0 ){
/*1192*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"\012<p><b>Return:</b> ", ParseDocBlock_return_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</a>\012", 1));
/*1195*/ 	}
/*1195*/ 	if( (buffer_Length(ParseDocBlock_descr) > 0) ){
/*1196*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 60, 6, 8, ParseDocBlock_0err_entry_get, 60) = buffer_ToString(ParseDocBlock_descr);
/*1199*/ 	}
/*1199*/ 	if( ParseDocBlock_pdb == NULL ){
/*1200*/ 		if( ParseDocBlock_is_template ){
/*1201*/ 			Scanner_Notice2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"unuseful empty template");
/*1203*/ 		}
/*1203*/ 		return NULL;
/*1209*/ 	}
/*1209*/ 	if( (( *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 40, ParseDocBlock_0err_entry_get, 61) && (( *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 44, ParseDocBlock_0err_entry_get, 62) ||  *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 48, ParseDocBlock_0err_entry_get, 63)))) || ( *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 44, ParseDocBlock_0err_entry_get, 64) &&  *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 48, ParseDocBlock_0err_entry_get, 65))) ){
/*1211*/ 		Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"multiple @access declarations");
/*1214*/ 	}
/*1214*/ 	if( ParseDocBlock_is_template ){
/*1215*/ 		ParseDocBlock_template = ParseDocBlock_pdb;
/*1218*/ 	}
/*1218*/ 	return ParseDocBlock_pdb;
/*1222*/ }


/*1224*/ RECORD *
/*1224*/ ParseDocBlock_SearchParam(RECORD *ParseDocBlock_pdb, STRING *ParseDocBlock_name)
/*1224*/ {
/*1225*/ 	ARRAY * ParseDocBlock_params = NULL;
/*1227*/ 	int ParseDocBlock_i = 0;
/*1227*/ 	if( ParseDocBlock_pdb == NULL ){
/*1228*/ 		return NULL;
/*1230*/ 	}
/*1230*/ 	ParseDocBlock_params = (ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 66);
/*1231*/ 	{
/*1231*/ 		int m2runtime_for_limit_1;
/*1231*/ 		ParseDocBlock_i = 0;
/*1231*/ 		m2runtime_for_limit_1 = (m2runtime_count(ParseDocBlock_params) - 1);
/*1232*/ 		for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*1232*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_params, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 67), 8, ParseDocBlock_0err_entry_get, 68), ParseDocBlock_name) == 0 ){
/*1233*/ 				return (RECORD *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_params, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 69);
/*1236*/ 			}
/*1237*/ 		}
/*1237*/ 	}
/*1237*/ 	return NULL;
/*1242*/ }


char * ParseDocBlock_0func[] = {
    "lowLevelReadCh",
    "textToHtml",
    "detectTag",
    "nextTag",
    "short",
    "addTag",
    "next_char",
    "next_sym",
    "parse_array",
    "next_type",
    "parseGlobal",
    "parseParam",
    "parseLineTag",
    "findPeriod",
    "parseShortAndLongDescr",
    "ParseDocBlock",
    "SearchParam"
};

int ParseDocBlock_0err_entry[] = {
    0 /* lowLevelReadCh */, 48,
    0 /* lowLevelReadCh */, 57,
    0 /* lowLevelReadCh */, 61,
    1 /* textToHtml */, 114,
    2 /* detectTag */, 170,
    2 /* detectTag */, 170,
    3 /* nextTag */, 185,
    4 /* short */, 196,
    5 /* addTag */, 210,
    6 /* next_char */, 439,
    7 /* next_sym */, 471,
    8 /* parse_array */, 497,
    8 /* parse_array */, 501,
    8 /* parse_array */, 510,
    8 /* parse_array */, 512,
    9 /* next_type */, 596,
    9 /* next_type */, 603,
    10 /* parseGlobal */, 748,
    10 /* parseGlobal */, 750,
    10 /* parseGlobal */, 757,
    10 /* parseGlobal */, 758,
    11 /* parseParam */, 770,
    11 /* parseParam */, 775,
    11 /* parseParam */, 776,
    11 /* parseParam */, 778,
    11 /* parseParam */, 787,
    11 /* parseParam */, 801,
    11 /* parseParam */, 801,
    11 /* parseParam */, 808,
    12 /* parseLineTag */, 830,
    12 /* parseLineTag */, 837,
    12 /* parseLineTag */, 839,
    12 /* parseLineTag */, 841,
    12 /* parseLineTag */, 861,
    12 /* parseLineTag */, 888,
    12 /* parseLineTag */, 898,
    12 /* parseLineTag */, 903,
    12 /* parseLineTag */, 905,
    12 /* parseLineTag */, 905,
    12 /* parseLineTag */, 910,
    12 /* parseLineTag */, 926,
    12 /* parseLineTag */, 936,
    12 /* parseLineTag */, 937,
    12 /* parseLineTag */, 939,
    13 /* findPeriod */, 995,
    13 /* findPeriod */, 1001,
    14 /* parseShortAndLongDescr */, 1034,
    14 /* parseShortAndLongDescr */, 1035,
    14 /* parseShortAndLongDescr */, 1044,
    14 /* parseShortAndLongDescr */, 1045,
    14 /* parseShortAndLongDescr */, 1050,
    15 /* ParseDocBlock */, 1099,
    15 /* ParseDocBlock */, 1164,
    15 /* ParseDocBlock */, 1171,
    15 /* ParseDocBlock */, 1173,
    15 /* ParseDocBlock */, 1174,
    15 /* ParseDocBlock */, 1175,
    15 /* ParseDocBlock */, 1175,
    15 /* ParseDocBlock */, 1177,
    15 /* ParseDocBlock */, 1178,
    15 /* ParseDocBlock */, 1196,
    15 /* ParseDocBlock */, 1209,
    15 /* ParseDocBlock */, 1209,
    15 /* ParseDocBlock */, 1209,
    15 /* ParseDocBlock */, 1210,
    15 /* ParseDocBlock */, 1210,
    16 /* SearchParam */, 1230,
    16 /* SearchParam */, 1232,
    16 /* SearchParam */, 1232,
    16 /* SearchParam */, 1234
};

void ParseDocBlock_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "ParseDocBlock";
    *f = ParseDocBlock_0func[ ParseDocBlock_0err_entry[2*i] ];
    *l = ParseDocBlock_0err_entry[2*i + 1];
}
