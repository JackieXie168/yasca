/* IMPLEMENTATION MODULE Statements */
#define M2_IMPORT_Statements

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_ParseDocBlock
#    include "ParseDocBlock.c"
#endif
/* 11*/ int Statements_recursive_parsing = 0;
/* 14*/ RECORD * Statements_pdb = NULL;
/* 19*/ ARRAY * Statements_include_path = NULL;
/* 22*/ ARRAY * Statements_modules_abs_path = NULL;
/* 25*/ ARRAY * Statements_packages_abs_path = NULL;
/* 28*/ RECORD * Statements_curr_package = NULL;
/* 33*/ int Statements_loop_level = 0;

#ifndef M2_IMPORT_Accounting
#    include "Accounting.c"
#endif

#ifndef M2_IMPORT_Classes
#    include "Classes.c"
#endif

#ifndef M2_IMPORT_Documentator
#    include "Documentator.c"
#endif

#ifndef M2_IMPORT_Exceptions
#    include "Exceptions.c"
#endif

#ifndef M2_IMPORT_Expressions
#    include "Expressions.c"
#endif

#ifndef M2_IMPORT_FileName
#    include "FileName.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Proto
#    include "Proto.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_io
#    include "io.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

void Statements_0err_entry_get(int i, char **m, char **f, int *l);

/* 19*/ void
/* 19*/ Statements_ParseEcho(void)
/* 19*/ {
/* 20*/ 	RECORD * Statements_r = NULL;
/* 22*/ 	RECORD * Statements_t = NULL;
/* 22*/ 	Scanner_ReadSym();
/* 24*/ 	do{
/* 24*/ 		Statements_r = Expressions_ParseExpr();
/* 25*/ 		if( Statements_r == NULL ){
/* 28*/ 		} else {
/* 28*/ 			Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 0);
/* 29*/ 			if( ((Statements_t == Globals_int_type) || (Statements_t == Globals_float_type) || (Statements_t == Globals_string_type)) ){
/* 32*/ 			} else if( Statements_t == Globals_boolean_type ){
/* 33*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\151,\0,\0,\0)"found boolean value: remember that FALSE gets rendered as empty string \042\042 while TRUE gets rendered as \0421\042");
/* 34*/ 			} else if( (((Globals_php_ver == 5)) && (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_t, 16, Statements_0err_entry_get, 1) == 9)) && (Search_SearchClassMethod((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__toString", FALSE) != NULL)) ){
/* 38*/ 			} else {
/* 38*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"found argument of the type ", Types_TypeToString(Statements_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)". The arguments of the `echo' statement must be of", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)" type int, float, string.", 1));
/* 43*/ 			}
/* 43*/ 		}
/* 43*/ 		if( (Scanner_sym != 16) ){
/* 46*/ 			goto m2runtime_loop_1;
/* 46*/ 		}
/* 46*/ 		Scanner_ReadSym();
/* 49*/ 	}while(TRUE);
m2runtime_loop_1: ;
/* 51*/ }


/* 53*/ void
/* 53*/ Statements_ParseReturn(void)
/* 53*/ {
/* 54*/ 	RECORD * Statements_r = NULL;
/* 55*/ 	RECORD * Statements_found = NULL;
/* 55*/ 	RECORD * Statements_expected = NULL;
/* 56*/ 	STRING * Statements_n = NULL;
/* 57*/ 	RECORD * Statements_sign = NULL;
/* 59*/ 	int Statements_no_expr = 0;
/* 59*/ 	Scanner_ReadSym();
/* 60*/ 	if( Globals_curr_func != NULL ){
/* 61*/ 		Statements_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_func, 28, Statements_0err_entry_get, 3);
/* 62*/ 		Statements_expected = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 4);
/* 63*/ 		Statements_n = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_func, 8, Statements_0err_entry_get, 5), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"()'", 1);
/* 64*/ 	} else if( Globals_curr_method != NULL ){
/* 65*/ 		Statements_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 16, Statements_0err_entry_get, 6);
/* 66*/ 		Statements_expected = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 7);
/* 67*/ 		Statements_n = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"method ", Scanner_mn(Globals_curr_class, Globals_curr_method), 1);
/* 69*/ 	} else {
/* 69*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"`return' in global scope");
/* 71*/ 		if( (Scanner_sym != 17) ){
/* 72*/ 			Statements_r = Expressions_ParseExpr();
/* 75*/ 		}
/* 76*/ 	}
/* 76*/ 	if( (Scanner_sym == 17) ){
/* 77*/ 		Statements_found = NULL;
/* 78*/ 		Statements_no_expr = TRUE;
/* 80*/ 	} else {
/* 80*/ 		Statements_r = Expressions_ParseExpr();
/* 81*/ 		if( Statements_r == NULL ){
/* 82*/ 			Statements_found = NULL;
/* 83*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 8) == Globals_void_type ){
/* 84*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"the expression do not returns a value");
/* 85*/ 			Statements_found = NULL;
/* 87*/ 		} else {
/* 87*/ 			Statements_found = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 9);
/* 89*/ 		}
/* 89*/ 		Statements_no_expr = FALSE;
/* 92*/ 	}
/* 92*/ 	if( Statements_expected == NULL ){
/* 93*/ 		if( Statements_no_expr ){
/* 94*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"from this `return;' we guess the ", Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)" is of type void", 1));
/* 96*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 10) = Globals_void_type;
/* 97*/ 		} else if( Statements_found == NULL ){
/* 98*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"cannot determinate the type of the returned ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\74,\0,\0,\0)"expression. Presuming `mixed' and trying to continue anyway.", 1));
/*100*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 11) = Globals_mixed_type;
/*102*/ 		} else {
/*102*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"from this `return' we guess the ", Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)" returns a value of type ", Types_TypeToString(Statements_found), 1));
/*104*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 12) = Statements_found;
/*107*/ 		}
/*107*/ 	} else {
/*107*/ 		if( Statements_no_expr ){
/*108*/ 			if( Statements_expected != Globals_void_type ){
/*109*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"missing returned value for ", Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)" declared of type ", Types_TypeToString(Statements_expected), 1));
/*112*/ 			}
/*112*/ 		} else if( Statements_found == NULL ){
/*113*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"cannot determinate the type of the returned ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"expression. The type of the value returned by the ", Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)" should be ", Types_TypeToString(Statements_expected), 1));
/*117*/ 		} else {
/*117*/ 			switch(Expressions_LhsMatchRhs(Statements_expected, Statements_found)){

/*118*/ 			case 0:
/*119*/ 			break;

/*119*/ 			case 1:
/*120*/ 			Scanner_Warning(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)": expected return type ", Types_TypeToString(Statements_expected), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)", found expression of type ", Types_TypeToString(Statements_found), 1));
/*124*/ 			break;

/*124*/ 			case 2:
/*125*/ 			Scanner_Error(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)": expected return type ", Types_TypeToString(Statements_expected), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)", found expression of type ", Types_TypeToString(Statements_found), 1));
/*130*/ 			break;

/*130*/ 			default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 13);
/*131*/ 			}
/*132*/ 		}
/*133*/ 	}
/*135*/ }


/*137*/ void
/*137*/ Statements_ParseTriggerError(void)
/*137*/ {
/*142*/ 	RECORD * Statements_r = NULL;
/*144*/ 	int Statements_err = 0;
/*144*/ 	Scanner_ReadSym();
/*145*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `('");
/*146*/ 	Scanner_ReadSym();
/*151*/ 	Statements_r = Expressions_ParseExprOfType(Globals_string_type);
/*152*/ 	if( (Scanner_sym == 13) ){
/*153*/ 		Scanner_ReadSym();
/*155*/ 		return ;
/*160*/ 	}
/*160*/ 	Scanner_Expect(16, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected `,' or `)'");
/*161*/ 	Scanner_ReadSym();
/*162*/ 	Statements_r = Expressions_ParseExprOfType(Globals_int_type);
/*163*/ 	Statements_err = 0;
/*164*/ 	if( Statements_r == NULL ){
/*166*/ 	} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 14) == NULL ){
/*169*/ 	} else {
/*169*/ 		Statements_err = m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 15));
/*182*/ 	}
/*182*/ 	if( (Statements_err == 1024) ){
/*183*/ 		Statements_err = 0;
/*186*/ 	}
/*186*/ 	if( Globals_curr_func != NULL ){
/*187*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_func, 60, 9, 56, Statements_0err_entry_get, 16) = ( *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_func, 56, Statements_0err_entry_get, 17) | Statements_err);
/*188*/ 	} else if( Globals_curr_method != NULL ){
/*189*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_method, 72, 8, 68, Statements_0err_entry_get, 18) = ( *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 68, Statements_0err_entry_get, 19) | Statements_err);
/*196*/ 	}
/*196*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `)'");
/*197*/ 	Scanner_ReadSym();
/*202*/ }


/*219*/ void
/*219*/ Statements_DocBlockCheckAllowedLineTags(int Statements_allow, STRING *Statements_documenting_what)
/*219*/ {

/*221*/ 	void
/*221*/ 	Statements_err(STRING *Statements_tag)
/*221*/ 	{
/*221*/ 		Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"invalid DocBlock line tag `", Statements_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"': not allowed for ", Statements_documenting_what, 1));
/*226*/ 	}

/*226*/ 	if( Statements_pdb == NULL ){
/*228*/ 		return ;
/*230*/ 	}
/*230*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 20) != NULL) && (((Statements_allow & 2) == 0))) ){
/*231*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"@var");
/*233*/ 	}
/*233*/ 	if( (((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 28, Statements_0err_entry_get, 21) != NULL) && (((Statements_allow & 4) == 0))) ){
/*234*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@param");
/*236*/ 	}
/*236*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 22) != NULL) && (((Statements_allow & 8) == 0))) ){
/*237*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@return");
/*239*/ 	}
/*239*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 36, Statements_0err_entry_get, 23) && (((Statements_allow & 16) == 0))) ){
/*240*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@abstract");
/*242*/ 	}
/*242*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 56, Statements_0err_entry_get, 24) && (((Statements_allow & 32) == 0))) ){
/*243*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@static");
/*245*/ 	}
/*245*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 52, Statements_0err_entry_get, 25) && (((Statements_allow & 64) == 0))) ){
/*246*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@final");
/*248*/ 	}
/*248*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 40, Statements_0err_entry_get, 26) && (((Statements_allow & 128) == 0))) ){
/*249*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"@access private");
/*251*/ 	}
/*251*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 44, Statements_0err_entry_get, 27) && (((Statements_allow & 256) == 0))) ){
/*252*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"@access protected");
/*254*/ 	}
/*254*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 28) && (((Statements_allow & 512) == 0))) ){
/*255*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"@access public");
/*257*/ 	}
/*257*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 32, Statements_0err_entry_get, 29) && (((Statements_allow & 1) == 0))) ){
/*258*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@package");
/*260*/ 	}
/*260*/ 	if( (((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 16, Statements_0err_entry_get, 30) != NULL) && (((Statements_allow & 1024) == 0))) ){
/*261*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@global");
/*264*/ 	}
/*266*/ }


/*268*/ void
/*268*/ Statements_FatalUnsupportedOldStyleSyntax(void)
/*268*/ {
/*268*/ 	Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\67,\0,\0,\0)"unsupported old-style syntax. Please use {...} instead.");
/*271*/ }

   static int Statements_ParseSimpleStatement(void);
 static RECORD * Statements_ParsePackage(STRING *s, int module);

/*277*/ void
/*277*/ Statements_ParseStatement(void)
/*277*/ {
/*279*/ 	int Statements_check_semicolon = 0;
	Statements_check_semicolon = Statements_ParseSimpleStatement();
/*280*/ 	if( Statements_check_semicolon ){
/*281*/ 		if( (Scanner_sym == 17) ){
/*282*/ 			Scanner_ReadSym();
/*283*/ 		} else if( (Scanner_sym == 6) ){
/*284*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"missing `;'");
/*286*/ 		} else {
/*286*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"missing `;'");
/*289*/ 		}
/*290*/ 	}
/*292*/ }


/*295*/ void
/*295*/ Statements_ParseBlock(void)
/*295*/ {
/*295*/ 	if( (Scanner_sym == 18) ){
/*296*/ 		Statements_FatalUnsupportedOldStyleSyntax();
/*297*/ 	} else if( (Scanner_sym == 10) ){
/*298*/ 		Scanner_ReadSym();
/*299*/ 		while( (Scanner_sym != 11) ){
/*300*/ 			Statements_ParseStatement();
/*302*/ 		}
/*302*/ 		Scanner_ReadSym();
/*304*/ 	} else {
/*304*/ 		Statements_ParseStatement();
/*307*/ 	}
/*309*/ }


/*316*/ int
/*316*/ Statements_ParseArgsListDecl(RECORD *Statements_sign, STRING *Statements_function_or_module)
/*316*/ {
/*317*/ 	RECORD * Statements_a = NULL;
/*318*/ 	RECORD * Statements_r = NULL;
/*319*/ 	RECORD * Statements_v = NULL;
/*320*/ 	int Statements_guess = 0;
/*321*/ 	int Statements_opt_arg = 0;
/*323*/ 	RECORD * Statements_p = NULL;
/*323*/ 	Scanner_Expect(12, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"expected '(' in ", Statements_function_or_module, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/*324*/ 	Scanner_ReadSym();
/*327*/ 	do{
/*327*/ 		if( (Scanner_sym == 13) ){
/*330*/ 			goto m2runtime_loop_1;
/*331*/ 		}
/*331*/ 		if( (Scanner_sym == 148) ){
/*332*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 24, Statements_0err_entry_get, 31) = TRUE;
/*333*/ 			Scanner_ReadSym();
/*336*/ 			goto m2runtime_loop_1;
/*340*/ 		}
/*340*/ 		Statements_a = NULL;
/*341*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 12, Statements_0err_entry_get, 32) = Expressions_ParseType(TRUE);
/*342*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 33) == Globals_void_type ){
/*343*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"argument of type `void' not allowed");
/*349*/ 		}
/*349*/ 		if( (Scanner_sym == 73) ){
/*350*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 20, Statements_0err_entry_get, 34) = TRUE;
/*351*/ 			Scanner_ReadSym();
/*357*/ 		}
/*357*/ 		Scanner_Expect(20, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"expected name of the formal argument in ", Statements_function_or_module, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/*359*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 8, Statements_0err_entry_get, 35) = Scanner_s;
/*365*/ 		if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 36) == NULL) && (Statements_pdb != NULL)) ){
/*366*/ 			Statements_p = ParseDocBlock_SearchParam(Statements_pdb, Scanner_s);
/*367*/ 			if( Statements_p == NULL ){
/*368*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"missing `@param TYPE $", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"' in DocBlock above", 1));
/*370*/ 			} else {
/*370*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 12, Statements_0err_entry_get, 37) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 38);
/*371*/ 				if( (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_p, 20, Statements_0err_entry_get, 39) && ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 20, Statements_0err_entry_get, 40)) || (! *(int *)m2runtime_dereference_rhs_RECORD(Statements_p, 20, Statements_0err_entry_get, 41) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 20, Statements_0err_entry_get, 42))) ){
/*374*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\106,\0,\0,\0)"conflicting passing method between DocBlock @param and actual PHP code");
/*377*/ 				}
/*378*/ 			}
/*382*/ 		}
/*382*/ 		Accounting_AccountVarLHS(Scanner_s, FALSE);
/*383*/ 		Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*384*/ 		if( ((Globals_curr_method != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 44, Statements_0err_entry_get, 43)) ){
/*385*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 48, Statements_0err_entry_get, 44) = 100;
/*387*/ 		}
/*387*/ 		Scanner_ReadSym();
/*392*/ 		if( (Scanner_sym == 31) ){
/*393*/ 			if( (((Globals_php_ver == 4)) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 20, Statements_0err_entry_get, 45)) ){
/*394*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\111,\0,\0,\0)"can't assign default value to formal argument passed by reference (PHP 5)");
/*396*/ 			}
/*396*/ 			Statements_opt_arg = TRUE;
/*397*/ 			Scanner_ReadSym();
/*398*/ 			Statements_r = Expressions_ParseStaticExpr();
/*399*/ 			if( Statements_r == NULL ){
/*401*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 46) == NULL ){
/*402*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 12, Statements_0err_entry_get, 47) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 48);
/*403*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 16, Statements_0err_entry_get, 49) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 50);
/*405*/ 			} else {
/*405*/ 				switch(Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 51), (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 52))){

/*406*/ 				case 1:
/*407*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"type mismatch: formal argument of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 53)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)", default expression of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 54)), 1));
/*410*/ 				break;

/*410*/ 				case 2:
/*411*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"type mismatch: formal argument of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 55)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)", default expression of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 56)), 1));
/*415*/ 				break;
/*416*/ 				}
/*416*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 16, Statements_0err_entry_get, 57) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 58);
/*418*/ 			}
/*418*/ 		} else if( Statements_opt_arg ){
/*419*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"missing default value for argument `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 59), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"'. Hint: mandatory arguments can't follow the default ones.", 1));
/*422*/ 		}
/*422*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 60) == NULL ){
/*423*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 12, Statements_0err_entry_get, 61) = Globals_mixed_type;
/*424*/ 			Statements_guess = TRUE;
/*425*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"undefined type for argument `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 62), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\154,\0,\0,\0)"', presuming `mixed' and trying to continue anyway. Hint: either use an explicit type (example: `/*.int.*/ $", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 63), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"')", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)" or assign a default value (example: `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 64), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"=123').", 1));
/*430*/ 		}
/*430*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 65) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 66);
/*431*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 24, Statements_0err_entry_get, 67) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 16, Statements_0err_entry_get, 68);
/*432*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 12, Statements_0err_entry_get, 69), 4, 1, Statements_0err_entry_get, 70) = Statements_a;
/*433*/ 		if( !Statements_opt_arg ){
/*434*/ 			m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 20, Statements_0err_entry_get, 71), 1);
/*437*/ 		}
/*437*/ 		if( (Scanner_sym == 16) ){
/*438*/ 			Scanner_ReadSym();
/*440*/ 		} else if( (Scanner_sym == 131) ){
/*441*/ 			Scanner_ReadSym();
/*442*/ 			Scanner_Expect(148, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"expected `args'");
/*443*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 24, Statements_0err_entry_get, 72) = TRUE;
/*444*/ 			Scanner_ReadSym();
/*448*/ 			goto m2runtime_loop_1;
/*449*/ 		} else {
/*451*/ 			goto m2runtime_loop_1;
/*452*/ 		}
/*452*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*452*/ 	Scanner_Expect(13, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected ')' or ',' in ", Statements_function_or_module, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/*454*/ 	Scanner_ReadSym();
/*455*/ 	return Statements_guess;
/*459*/ }


/*464*/ int
/*464*/ Statements_eqbool(int Statements_a, int Statements_b)
/*464*/ {
/*464*/ 	return ((Statements_a && Statements_b) || (!Statements_a && !Statements_b));
/*468*/ }


/*469*/ int
/*469*/ Statements_SameSign(RECORD *Statements_a, RECORD *Statements_b)
/*469*/ {
/*471*/ 	int Statements_i = 0;
/*471*/ 	if( (!Types_SameType((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 73), (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_b, 8, Statements_0err_entry_get, 74)) || !Statements_eqbool( *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 16, Statements_0err_entry_get, 75),  *(int *)m2runtime_dereference_rhs_RECORD(Statements_b, 16, Statements_0err_entry_get, 76))) ){
/*474*/ 		return FALSE;
/*476*/ 	}
/*476*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 20, Statements_0err_entry_get, 77) !=  *(int *)m2runtime_dereference_rhs_RECORD(Statements_b, 20, Statements_0err_entry_get, 78)) ){
/*477*/ 		return FALSE;
/*479*/ 	}
/*479*/ 	if( (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 79)) != m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_b, 12, Statements_0err_entry_get, 80))) ){
/*480*/ 		return FALSE;
/*482*/ 	}
/*482*/ 	{
/*482*/ 		int m2runtime_for_limit_1;
/*482*/ 		Statements_i = 0;
/*482*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 81)) - 1);
/*483*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*483*/ 			if( (!Types_SameType((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 82), Statements_i, Statements_0err_entry_get, 83), 12, Statements_0err_entry_get, 84), (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_b, 12, Statements_0err_entry_get, 85), Statements_i, Statements_0err_entry_get, 86), 12, Statements_0err_entry_get, 87)) || !Statements_eqbool( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 88), Statements_i, Statements_0err_entry_get, 89), 20, Statements_0err_entry_get, 90),  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_b, 12, Statements_0err_entry_get, 91), Statements_i, Statements_0err_entry_get, 92), 20, Statements_0err_entry_get, 93))) ){
/*486*/ 				return FALSE;
/*489*/ 			}
/*489*/ 		}
/*489*/ 	}
/*489*/ 	return TRUE;
/*493*/ }


/*499*/ void
/*499*/ Statements_ParseFuncDecl(int Statements_private, RECORD *Statements_t)
/*499*/ {

/*500*/ 	void
/*500*/ 	Statements_AccountFuncDecl(STRING *Statements_name, int Statements_private)
/*500*/ 	{
/*500*/ 		RECORD * Statements_f = NULL;
/*502*/ 		STRING * Statements_name_upper = NULL;
/*502*/ 		if( (Globals_scope > 0) ){
/*503*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"' nested inside another function.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)" The scope of this function is global but it will exist only if", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)" the parent function will be called. If the parent function is", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)" called once more, this will give a fatal error.", 1));
/*509*/ 		}
/*509*/ 		Statements_name_upper = str_toupper(Statements_name);
/*510*/ 		if( (((m2runtime_length(Statements_name) >= 2)) && (m2runtime_strcmp(m2runtime_substr(Statements_name, 0, 2, 1, Statements_0err_entry_get, 94), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"__") == 0)) ){
/*511*/ 			if( m2runtime_strcmp(Statements_name_upper, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__AUTOLOAD") == 0 ){
/*512*/ 				if( (Globals_php_ver == 4) ){
/*513*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"function name `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"' is reserved for special use in PHP 5", 1));
/*516*/ 				}
/*516*/ 			} else {
/*516*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\146,\0,\0,\0)"': names beginning with two underscores are reserved for future extensions of the language, do not use", 1));
/*519*/ 			}
/*520*/ 		}
/*520*/ 		Statements_f = Search_SearchFunc(Statements_name, TRUE);
/*521*/ 		if( Statements_f == NULL ){
/*522*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 8, Statements_0err_entry_get, 95) = Statements_name;
/*523*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 12, Statements_0err_entry_get, 96) = Statements_name_upper;
/*524*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 48, Statements_0err_entry_get, 97) = Statements_private;
/*525*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 16, Statements_0err_entry_get, 98) = Scanner_here();
/*526*/ 			if( !Accounting_report_unused ){
/*527*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 52, Statements_0err_entry_get, 99) = 100;
/*529*/ 			}
/*529*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 24, Statements_0err_entry_get, 100) = NULL;
/*530*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 28, Statements_0err_entry_get, 101) = NULL;
/*531*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_funcs, 4, 1, Statements_0err_entry_get, 102) = Statements_f;
/*532*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 103) == NULL ){
/*533*/ 			if( (Statements_private && (m2runtime_strcmp(Scanner_fn, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 104), 8, Statements_0err_entry_get, 105)) != 0)) ){
/*534*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"private function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"' declared after being used in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 24, Statements_0err_entry_get, 106)), 1));
/*538*/ 			} else {
/*538*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"' declared after being used in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 24, Statements_0err_entry_get, 107)), 1));
/*544*/ 			}
/*544*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 8, Statements_0err_entry_get, 108) = Statements_name;
/*545*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 16, Statements_0err_entry_get, 109) = Scanner_here();
/*547*/ 		} else {
/*547*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 110)), 1));
/*551*/ 		}
/*554*/ 	}

/*555*/ 	RECORD * Statements_f = NULL;
/*556*/ 	RECORD * Statements_parent_func = NULL;
/*557*/ 	RECORD * Statements_old_sign = NULL;
/*557*/ 	RECORD * Statements_sign = NULL;
/*558*/ 	int Statements_guess = 0;
/*559*/ 	RECORD * Statements_proto_in = NULL;
/*560*/ 	ARRAY * Statements_proto_exceptions = NULL;
/*562*/ 	STRING * Statements_err = NULL;
/*563*/ 	Statements_DocBlockCheckAllowedLineTags(((4 | 8) | 128), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function");
/*566*/ 	if( (!Statements_private && (Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 40, Statements_0err_entry_get, 111)) ){
/*567*/ 		Statements_private = TRUE;
/*570*/ 	}
/*570*/ 	if( ((Statements_t == NULL) && (Statements_pdb != NULL)) ){
/*571*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 112) == NULL ){
/*572*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"missing `@return TYPE' declaration in DocBlock above");
/*574*/ 		} else {
/*574*/ 			Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 113);
/*577*/ 		}
/*577*/ 	}
/*577*/ 	if( Statements_t == NULL ){
/*578*/ 		Statements_guess = TRUE;
/*580*/ 	}
/*580*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 114) = Statements_t;
/*582*/ 	Scanner_ReadSym();
/*584*/ 	if( (Scanner_sym == 73) ){
/*585*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 16, Statements_0err_entry_get, 115) = TRUE;
/*586*/ 		if( (Globals_php_ver == 5) ){
/*587*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"obsolete syntax `function &func()', don't use in PHP 5");
/*589*/ 		}
/*589*/ 		Scanner_ReadSym();
/*596*/ 	}
/*596*/ 	Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"expected function name after `function'");
/*597*/ 	Statements_f = Search_SearchFunc(Scanner_s, FALSE);
/*598*/ 	if( Statements_f == NULL ){
/*599*/ 		Statements_AccountFuncDecl(Scanner_s, Statements_private);
/*600*/ 		Statements_f = Search_SearchFunc(Scanner_s, FALSE);
/*601*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 44, Statements_0err_entry_get, 116) ){
/*602*/ 		Statements_old_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 28, Statements_0err_entry_get, 117);
/*603*/ 		Statements_proto_in = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 118);
/*604*/ 		Statements_proto_exceptions = Classes_CloneSet((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_f, 32, Statements_0err_entry_get, 119));
/*605*/ 		if( (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 48, Statements_0err_entry_get, 120) && !Statements_private) || (! *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 48, Statements_0err_entry_get, 121) && Statements_private)) ){
/*607*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\70,\0,\0,\0)"mismatch on the `private' attribute, check prototype in ", Scanner_reference(Statements_proto_in), 1));
/*609*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 48, Statements_0err_entry_get, 122) = Statements_private;
/*611*/ 		}
/*612*/ 	} else {
/*612*/ 		Statements_old_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 28, Statements_0err_entry_get, 123);
/*613*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 48, Statements_0err_entry_get, 124) = Statements_private;
/*615*/ 	}
/*615*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 28, Statements_0err_entry_get, 125) = Statements_sign;
/*616*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 16, Statements_0err_entry_get, 126) = Scanner_here();
/*617*/ 	Statements_parent_func = Globals_curr_func;
/*618*/ 	Globals_curr_func = Statements_f;
/*619*/ 	m2_inc(&Globals_scope, 1);
/*620*/ 	Scanner_ReadSym();
/*625*/ 	if( Statements_ParseArgsListDecl(Statements_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function") ){
/*626*/ 		Statements_guess = TRUE;
/*633*/ 	}
/*633*/ 	if( (Scanner_sym == 169) ){
/*634*/ 		Exceptions_ParseThrows();
/*640*/ 	}
/*640*/ 	if( (Scanner_sym == 170) ){
/*641*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 36, Statements_0err_entry_get, 127) = Scanner_s;
/*642*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 40, Statements_0err_entry_get, 128) = Documentator_ExtractDeprecated(Scanner_s);
/*643*/ 		Scanner_ReadSym();
/*644*/ 	} else if( Statements_pdb != NULL ){
/*645*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 36, Statements_0err_entry_get, 129) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 130);
/*646*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 40, Statements_0err_entry_get, 131) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 132));
/*647*/ 		Statements_pdb = NULL;
/*653*/ 	}
/*653*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"expected '{' in function body declaration");
/*654*/ 	Statements_ParseBlock();
/*655*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 133) == NULL ){
/*657*/ 		Statements_guess = TRUE;
/*658*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 134) = Globals_void_type;
/*661*/ 	}
/*661*/ 	Expressions_CleanCurrentScope();
/*662*/ 	m2_inc(&Globals_scope, -1);
/*663*/ 	Globals_curr_func = Statements_parent_func;
/*665*/ 	if( Statements_guess ){
/*666*/ 		Scanner_Notice2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 135), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"guessed signature of the function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 136), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"()' as ", Types_FunctionSignatureToString(Statements_sign), 1));
/*670*/ 	}
/*670*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 44, Statements_0err_entry_get, 137) ){
/*671*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 52, Statements_0err_entry_get, 138) == 0) ){
/*672*/ 			Scanner_Notice2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 139), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 140), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"()' declared forward in ", Scanner_reference(Statements_proto_in), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)" but not used before implementation", 1));
/*675*/ 		}
/*675*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 60, 9, 44, Statements_0err_entry_get, 141) = FALSE;
/*676*/ 		if( !Statements_SameSign(Statements_old_sign, Statements_sign) ){
/*677*/ 			Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 142), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 143), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"()': the actual signature ", Types_FunctionSignatureToString(Statements_sign), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)" does not match the prototype ", Types_FunctionSignatureToString(Statements_old_sign), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)" as declared in ", Scanner_reference(Statements_proto_in), 1));
/*683*/ 		}
/*683*/ 		Statements_err = Classes_ClassesList(Classes_Sort(Classes_OrphanClasses(Statements_proto_exceptions, (ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_f, 32, Statements_0err_entry_get, 144))));
/*684*/ 		if( m2runtime_strcmp(Statements_err, NULL) > 0 ){
/*685*/ 			Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 145), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 146), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\112,\0,\0,\0)"()' throws more exceptions than those listed in the prototype declared in ", Scanner_reference(Statements_proto_in), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", Statements_err, 1));
/*689*/ 		}
/*689*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 20, Statements_0err_entry_get, 147) != NULL ){
/*690*/ 		if( !Statements_SameSign(Statements_old_sign, Statements_sign) ){
/*691*/ 			Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 148), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 149), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"()': declared signature ", Types_FunctionSignatureToString(Statements_sign), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)" differs from signature ", Types_FunctionSignatureToString(Statements_old_sign), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)" as guessed in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 20, Statements_0err_entry_get, 150)), 1));
/*697*/ 		}
/*697*/ 		if( (ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_f, 32, Statements_0err_entry_get, 151) != NULL ){
/*698*/ 			Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 152), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 153), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"()' as guessed in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 20, Statements_0err_entry_get, 154)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)" throws unexpected exceptions: ", Classes_ClassesList((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_f, 32, Statements_0err_entry_get, 155)), 1));
/*704*/ 		}
/*706*/ 	}
/*708*/ }


/*709*/ void
/*709*/ Statements_ParseBreak(void)
/*709*/ {
/*711*/ 	RECORD * Statements_r = NULL;
/*711*/ 	if( (Statements_loop_level == 0) ){
/*712*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"`break' MUST be inside a loop or a switch");
/*714*/ 	}
/*714*/ 	Scanner_ReadSym();
/*715*/ 	if( (Scanner_sym != 17) ){
/*716*/ 		Statements_r = Expressions_ParseExprOfType(Globals_int_type);
/*717*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"`break EXPR'", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)": unadvised programming practice; can't check", 1));
/*721*/ 	}
/*723*/ }


/*724*/ void
/*724*/ Statements_ParseContinue(void)
/*724*/ {
/*726*/ 	RECORD * Statements_r = NULL;
/*726*/ 	if( (Statements_loop_level == 0) ){
/*727*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"`continue' MUST be inside a loop or a switch");
/*729*/ 	}
/*729*/ 	Scanner_ReadSym();
/*730*/ 	if( (Scanner_sym != 17) ){
/*731*/ 		Statements_r = Expressions_ParseExprOfType(Globals_int_type);
/*732*/ 		Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"'continue EXPR'", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)": unadvised programming practice", 1));
/*736*/ 	}
/*738*/ }


/*742*/ void
/*742*/ Statements_ParseFor(void)
/*742*/ {
/*744*/ 	RECORD * Statements_r = NULL;
/*744*/ 	Scanner_ReadSym();
/*745*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected '('");
/*746*/ 	Scanner_ReadSym();
/*749*/ 	if( (Scanner_sym != 17) ){
/*750*/ 		Statements_r = Expressions_ParseExprList();
/*752*/ 	}
/*752*/ 	Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `;'");
/*753*/ 	Scanner_ReadSym();
/*756*/ 	if( (Scanner_sym != 17) ){
/*757*/ 		Statements_r = Expressions_ParseExprList();
/*758*/ 		Expressions_CheckBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"`for(...; EXPR; ...)'", Statements_r);
/*760*/ 	}
/*760*/ 	Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `;'");
/*761*/ 	Scanner_ReadSym();
/*764*/ 	if( (Scanner_sym != 13) ){
/*765*/ 		Statements_r = Expressions_ParseExprList();
/*767*/ 	}
/*767*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"expected closing `)' of the `for' statement");
/*768*/ 	Scanner_ReadSym();
/*770*/ 	m2_inc(&Statements_loop_level, 1);
/*771*/ 	Statements_ParseBlock();
/*772*/ 	m2_inc(&Statements_loop_level, -1);
/*776*/ }


/*783*/ void
/*783*/ Statements_ParseForeach(void)
/*783*/ {
/*784*/ 	RECORD * Statements_r = NULL;
/*785*/ 	RECORD * Statements_elem_type = NULL;
/*785*/ 	RECORD * Statements_index_type = NULL;
/*786*/ 	RECORD * Statements_v = NULL;
/*786*/ 	RECORD * Statements_k = NULL;
/*788*/ 	int Statements_by_addr = 0;
/*788*/ 	Scanner_ReadSym();
/*789*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"required `(' after `foreach'");
/*790*/ 	Scanner_ReadSym();
/*793*/ 	Statements_r = Expressions_ParseExpr();
/*794*/ 	Statements_index_type = Globals_mixed_type;
/*795*/ 	Statements_elem_type = Globals_mixed_type;
/*796*/ 	if( Statements_r == NULL ){
/*798*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 156), 16, Statements_0err_entry_get, 157) == 6) ){
/*799*/ 		switch( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 158), 20, Statements_0err_entry_get, 159)){

/*800*/ 		case 1:
/*800*/ 		Statements_index_type = Globals_mixed_type;
/*801*/ 		break;

/*801*/ 		case 3:
/*801*/ 		Statements_index_type = Globals_int_type;
/*802*/ 		break;

/*802*/ 		case 5:
/*802*/ 		Statements_index_type = Globals_string_type;
/*803*/ 		break;

/*803*/ 		case 7:
/*803*/ 		Statements_index_type = Globals_mixed_type;
/*805*/ 		break;

/*805*/ 		default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 160);
/*805*/ 		}
/*805*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 161), 8, Statements_0err_entry_get, 162) != NULL ){
/*806*/ 			Statements_elem_type = (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 163), 8, Statements_0err_entry_get, 164);
/*808*/ 		}
/*808*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 165), 16, Statements_0err_entry_get, 166) == 9) ){
/*811*/ 	} else {
/*811*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)"`foreach(EXPR' requires an array or an object, found ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 167)), 1));
/*816*/ 	}
/*816*/ 	Scanner_Expect(23, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\75,\0,\0,\0)"expected `as'. Hint: check `foreach( ARRAY_EXPRESSION as ...'");
/*817*/ 	Scanner_ReadSym();
/*820*/ 	if( (Scanner_sym == 73) ){
/*821*/ 		if( (Globals_php_ver == 4) ){
/*822*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"can't use `&' in `foreach' (PHP 5)");
/*824*/ 		}
/*824*/ 		Statements_by_addr = TRUE;
/*825*/ 		Scanner_ReadSym();
/*829*/ 	}
/*829*/ 	Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"`foreach': expected variable name");
/*830*/ 	Accounting_AccountVarLHS(Scanner_s, FALSE);
/*831*/ 	Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*832*/ 	Scanner_ReadSym();
/*835*/ 	if( (Scanner_sym == 32) ){
/*836*/ 		if( Statements_by_addr ){
/*837*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"the key cannot be passed by reference");
/*838*/ 			Statements_by_addr = FALSE;
/*840*/ 		}
/*840*/ 		Statements_k = Statements_v;
/*841*/ 		Scanner_ReadSym();
/*842*/ 		if( (Scanner_sym == 73) ){
/*843*/ 			Statements_by_addr = TRUE;
/*844*/ 			Scanner_ReadSym();
/*846*/ 		}
/*846*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"`foreach': expected variable name after `=>'");
/*847*/ 		Accounting_AccountVarLHS(Scanner_s, FALSE);
/*848*/ 		Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*849*/ 		Scanner_ReadSym();
/*852*/ 	}
/*852*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"expected closing `)' of the `foreach' statement");
/*853*/ 	Scanner_ReadSym();
/*858*/ 	if( Statements_k == NULL ){
/*860*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_k, 20, Statements_0err_entry_get, 168) == NULL ){
/*862*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_k, 52, 7, 20, Statements_0err_entry_get, 169) = Statements_index_type;
/*865*/ 	} else {
/*865*/ 		switch(Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_k, 20, Statements_0err_entry_get, 170), Statements_index_type)){

/*866*/ 		case 0:
/*867*/ 		break;

/*867*/ 		case 1:
/*868*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"foreach(): the type of the variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_k, 8, Statements_0err_entry_get, 171), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_k, 20, Statements_0err_entry_get, 172)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)" does not match the index of ", Types_TypeToString(Statements_index_type), 1));
/*871*/ 		break;

/*871*/ 		case 2:
/*872*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"foreach(): the type of the variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_k, 8, Statements_0err_entry_get, 173), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_k, 20, Statements_0err_entry_get, 174)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)" does not match the index of ", Types_TypeToString(Statements_index_type), 1));
/*876*/ 		break;

/*876*/ 		default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 175);
/*877*/ 		}
/*888*/ 	}
/*888*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_v, 20, Statements_0err_entry_get, 176) == NULL ){
/*889*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 177) = Statements_elem_type;
/*891*/ 	} else {
/*891*/ 		switch(Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_v, 20, Statements_0err_entry_get, 178), Statements_elem_type)){

/*892*/ 		case 0:
/*893*/ 		break;

/*893*/ 		case 1:
/*894*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"foreach(): the type of the variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_v, 8, Statements_0err_entry_get, 179), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_v, 20, Statements_0err_entry_get, 180)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)" does not match the elements of the array ", Types_TypeToString(Statements_elem_type), 1));
/*898*/ 		break;

/*898*/ 		case 2:
/*899*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"foreach(): the type of the variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_v, 8, Statements_0err_entry_get, 181), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_v, 20, Statements_0err_entry_get, 182)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)" does not match the elements of the array ", Types_TypeToString(Statements_elem_type), 1));
/*904*/ 		break;

/*904*/ 		default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 183);
/*905*/ 		}
/*906*/ 	}
/*906*/ 	m2_inc(&Statements_loop_level, 1);
/*907*/ 	Statements_ParseBlock();
/*908*/ 	m2_inc(&Statements_loop_level, -1);
/*912*/ }


/*913*/ void
/*913*/ Statements_ParseSwitch(void)
/*913*/ {
/*913*/ 	RECORD * Statements_r = NULL;
/*913*/ 	RECORD * Statements_t = NULL;
/*915*/ 	int Statements_found_return = 0;
/*915*/ 	int Statements_found_statements = 0;
/*915*/ 	Scanner_ReadSym();
/*916*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `('");
/*917*/ 	Scanner_ReadSym();
/*918*/ 	Statements_r = Expressions_ParseExpr();
/*919*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `)'");
/*920*/ 	if( Statements_r == NULL ){
/*924*/ 	} else {
/*924*/ 		Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 184);
/*925*/ 		if( ((Statements_t != Globals_int_type) && (Statements_t != Globals_string_type)) ){
/*926*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"switch(EXPR): invalid expression of type ", Types_TypeToString(Statements_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)". Expected int or string.", 1));
/*928*/ 			Statements_t = NULL;
/*931*/ 		}
/*931*/ 	}
/*931*/ 	Scanner_ReadSym();
/*932*/ 	if( (Scanner_sym == 18) ){
/*933*/ 		Statements_FatalUnsupportedOldStyleSyntax();
/*935*/ 	}
/*935*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `{'");
/*936*/ 	Scanner_ReadSym();
/*937*/ 	m2_inc(&Statements_loop_level, 1);
/*939*/ 	do{
/*939*/ 		if( (Scanner_sym == 110) ){
/*940*/ 			Scanner_ReadSym();
/*941*/ 			Statements_r = Expressions_ParseStaticExpr();
/*942*/ 			Scanner_Expect(18, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"expected `:' after `case' expression");
/*943*/ 			if( Statements_t != NULL ){
/*944*/ 				if( Statements_r == NULL ){
/*947*/ 				} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 185) != Statements_t ){
/*948*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"invalid type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 186)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)" for the `case' branch. Expected ", Types_TypeToString(Statements_t), 1));
/*953*/ 				}
/*953*/ 			}
/*953*/ 			Scanner_ReadSym();
/*954*/ 			Statements_found_statements = FALSE;
/*955*/ 			while( (((Scanner_sym != 111)) && ((Scanner_sym != 110)) && ((Scanner_sym != 112)) && ((Scanner_sym != 11)) && ((Scanner_sym != 159)) && ((Scanner_sym != 160))) ){
/*959*/ 				Statements_found_statements = TRUE;
/*960*/ 				Statements_found_return = (Scanner_sym == 28);
/*961*/ 				Statements_ParseStatement();
/*963*/ 			}
/*963*/ 			if( (Scanner_sym == 111) ){
/*964*/ 				Statements_ParseBreak();
/*965*/ 				Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `;'");
/*966*/ 				Scanner_ReadSym();
/*967*/ 			} else if( (Scanner_sym == 159) ){
/*968*/ 				Scanner_ReadSym();
/*969*/ 				if( (Scanner_sym == 129) ){
/*970*/ 					Scanner_ReadSym();
/*972*/ 				} else {
/*972*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"expected `;' in meta-code");
/*974*/ 				}
/*974*/ 			} else if( (Statements_found_statements && !Statements_found_return) ){
/*975*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"missing `break;' in `case' branch");
/*977*/ 			}
/*977*/ 		} else if( (Scanner_sym == 160) ){
/*978*/ 			Scanner_ReadSym();
/*979*/ 			if( (Scanner_sym == 130) ){
/*980*/ 				Scanner_ReadSym();
/*982*/ 			} else {
/*982*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"expected `:' in meta-code");
/*984*/ 			}
/*984*/ 			Scanner_Expect(11, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `}'");
/*985*/ 			Scanner_ReadSym();
/*987*/ 			goto m2runtime_loop_1;
/*987*/ 		} else if( (Scanner_sym == 112) ){
/*988*/ 			Scanner_ReadSym();
/*989*/ 			Scanner_Expect(18, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"expected `:' after `default'");
/*990*/ 			Scanner_ReadSym();
/*991*/ 			while( (Scanner_sym != 11) ){
/*992*/ 				Statements_ParseStatement();
/*994*/ 			}
/*994*/ 			Scanner_ReadSym();
/*996*/ 			goto m2runtime_loop_1;
/*996*/ 		} else if( (Scanner_sym == 11) ){
/*997*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"missing `default:' branch in `switch'");
/*998*/ 			Scanner_ReadSym();
/*1001*/ 			goto m2runtime_loop_1;
/*1001*/ 		} else {
/*1001*/ 			Scanner_UnexpectedSymbol();
/*1004*/ 		}
/*1004*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1004*/ 	m2_inc(&Statements_loop_level, -1);
/*1008*/ }


/*1010*/ void
/*1010*/ Statements_ParseClassConstDecl(int Statements_visibility)
/*1010*/ {
/*1011*/ 	RECORD * Statements_cl = NULL;
/*1012*/ 	RECORD * Statements_c = NULL;
/*1014*/ 	RECORD * Statements_r = NULL;
/*1014*/ 	Scanner_ReadSym();
/*1017*/ 	do{
/*1017*/ 		Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"expected constant name");
/*1022*/ 		Search_ResolveClassConst(Globals_curr_class, Scanner_s, &Statements_cl, &Statements_c);
/*1023*/ 		if( Statements_c != NULL ){
/*1024*/ 			if( Statements_cl == Globals_curr_class ){
/*1025*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"class constant `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' already defined in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 187)), 1));
/*1027*/ 			} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_cl, 72, Statements_0err_entry_get, 188) ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_cl, 76, Statements_0err_entry_get, 189)) ){
/*1028*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"cannot re-define the constant `", Classes_pc(Globals_curr_class, Statements_cl), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"' inherited from interface or abstract class", 1));
/*1033*/ 			}
/*1034*/ 		}
/*1034*/ 		Statements_c = NULL;
/*1035*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 5, 8, Statements_0err_entry_get, 190) = Scanner_s;
/*1036*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 5, 28, Statements_0err_entry_get, 191) = Statements_visibility;
/*1037*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 5, 16, Statements_0err_entry_get, 192) = Scanner_here();
/*1038*/ 		if( !Accounting_report_unused ){
/*1039*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 5, 32, Statements_0err_entry_get, 193) = 100;
/*1041*/ 		}
/*1041*/ 		Scanner_ReadSym();
/*1042*/ 		Scanner_Expect(31, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"expected `=' after constant name");
/*1043*/ 		Scanner_ReadSym();
/*1044*/ 		Statements_r = Expressions_ParseStaticExpr();
/*1045*/ 		if( Statements_r == NULL ){
/*1048*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 194), 16, Statements_0err_entry_get, 195) == 6) ){
/*1049*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"arrays are not allowed in class constants");
/*1051*/ 		}
/*1051*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 5, 12, Statements_0err_entry_get, 196) = Statements_r;
/*1052*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 28, Statements_0err_entry_get, 197), 4, 1, Statements_0err_entry_get, 198) = Statements_c;
/*1054*/ 		if( (Scanner_sym == 16) ){
/*1055*/ 			Scanner_ReadSym();
/*1058*/ 		} else {
/*1059*/ 			goto m2runtime_loop_1;
/*1060*/ 		}
/*1061*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1061*/ 	Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"missing `;'");
/*1062*/ 	Scanner_ReadSym();
/*1064*/ 	if( (Scanner_sym == 170) ){
/*1065*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 5, 20, Statements_0err_entry_get, 199) = Scanner_s;
/*1066*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 5, 24, Statements_0err_entry_get, 200) = Documentator_ExtractDeprecated(Scanner_s);
/*1067*/ 		Scanner_ReadSym();
/*1068*/ 	} else if( Statements_pdb != NULL ){
/*1069*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 5, 20, Statements_0err_entry_get, 201) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 202);
/*1070*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 5, 24, Statements_0err_entry_get, 203) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 204));
/*1071*/ 		Statements_pdb = NULL;
/*1075*/ 	}
/*1077*/ }


/*1079*/ void
/*1079*/ Statements_ParseClassPropertyDecl(int Statements_visibility, int Statements_static, RECORD *Statements_t)
/*1079*/ {
/*1080*/ 	RECORD * Statements_P = NULL;
/*1081*/ 	RECORD * Statements_p = NULL;
/*1083*/ 	RECORD * Statements_r = NULL;
/*1086*/ 	do{
/*1086*/ 		if( (Scanner_sym != 20) ){
/*1087*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"expected property name $NAME");
/*1091*/ 		}
/*1091*/ 		Search_SearchClassProperty(Globals_curr_class, Scanner_s, &Statements_P, &Statements_p);
/*1092*/ 		if( Statements_p != NULL ){
/*1093*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"property `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' already defined in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 20, Statements_0err_entry_get, 205)), 1));
/*1098*/ 		}
/*1098*/ 		Statements_p = NULL;
/*1099*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 8, Statements_0err_entry_get, 206) = Scanner_s;
/*1101*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 32, Statements_0err_entry_get, 207) = Statements_visibility;
/*1104*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 36, Statements_0err_entry_get, 208) = Statements_static;
/*1106*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 12, Statements_0err_entry_get, 209) = Statements_t;
/*1108*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 20, Statements_0err_entry_get, 210) = Scanner_here();
/*1109*/ 		if( !Accounting_report_unused ){
/*1110*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 40, Statements_0err_entry_get, 211) = 100;
/*1112*/ 		}
/*1112*/ 		Scanner_ReadSym();
/*1115*/ 		if( (Scanner_sym == 31) ){
/*1116*/ 			Scanner_ReadSym();
/*1117*/ 			Statements_r = Expressions_ParseStaticExpr();
/*1118*/ 			if( Statements_r == NULL ){
/*1120*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 212) == NULL ){
/*1121*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 12, Statements_0err_entry_get, 213) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 214);
/*1122*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 16, Statements_0err_entry_get, 215) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 216);
/*1124*/ 			} else {
/*1124*/ 				switch(Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 217), (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 218))){

/*1125*/ 				case 0:
/*1126*/ 				break;

/*1126*/ 				case 1:
/*1127*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"property `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 219), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"' of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 220)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)", expression of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 221)), 1));
/*1130*/ 				break;

/*1130*/ 				case 2:
/*1131*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"property `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 222), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"' of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 223)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)", expression of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 224)), 1));
/*1135*/ 				break;

/*1135*/ 				default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 225);
/*1135*/ 				}
/*1135*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 16, Statements_0err_entry_get, 226) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 227);
/*1137*/ 			}
/*1137*/ 		} else if( Statements_t == NULL ){
/*1138*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"undefined type for property `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 228), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"'. Undefined properties take the initial value NULL.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)" Hint: either specify a type (example: /*.int.*/ $", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 229), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)") or an initial value (example: $", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 230), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"=123).", 1));
/*1144*/ 		}
/*1144*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 32, Statements_0err_entry_get, 231), 4, 1, Statements_0err_entry_get, 232) = Statements_p;
/*1147*/ 		if( (Scanner_sym == 16) ){
/*1148*/ 			Scanner_ReadSym();
/*1151*/ 		} else {
/*1152*/ 			goto m2runtime_loop_1;
/*1154*/ 		}
/*1155*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1155*/ 	Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected ';'");
/*1156*/ 	Scanner_ReadSym();
/*1158*/ 	if( (Scanner_sym == 170) ){
/*1159*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 24, Statements_0err_entry_get, 233) = Scanner_s;
/*1160*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 28, Statements_0err_entry_get, 234) = Documentator_ExtractDeprecated(Scanner_s);
/*1161*/ 		Scanner_ReadSym();
/*1162*/ 	} else if( Statements_pdb != NULL ){
/*1163*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 24, Statements_0err_entry_get, 235) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 236);
/*1164*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 28, Statements_0err_entry_get, 237) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 238));
/*1165*/ 		Statements_pdb = NULL;
/*1169*/ 	}
/*1172*/ }

/*1178*/ ARRAY * Statements_specialMethods = NULL;

/*1179*/ void
/*1179*/ Statements_CheckSpecialMethodSignature(RECORD *Statements_m)
/*1179*/ {
/*1179*/ 	int Statements_i = 0;
/*1181*/ 	STRING * Statements_sign = NULL;
/*1181*/ 	if( (((m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 239)) <= 2)) || (m2runtime_strcmp(m2runtime_substr((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 240), 0, 2, 1, Statements_0err_entry_get, 241), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"__") != 0)) ){
/*1183*/ 		return ;
/*1185*/ 	}
/*1185*/ 	if( Statements_specialMethods == NULL ){
/*1186*/ 		Statements_specialMethods = (
/*1189*/ 			push((char*) alloc_ARRAY(4, 1)),
/*1189*/ 			push((char*) (
/*1189*/ 				push((char*) alloc_RECORD(28, 3)),
/*1189*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__destruct"),
/*1189*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1189*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__DESTRUCT"),
/*1189*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1189*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"public void()"),
/*1189*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1189*/ 				*(int*) (tos()+20) = FALSE,
/*1189*/ 				*(int*) (tos()+24) = FALSE,
/*1190*/ 				(RECORD*) pop()
/*1190*/ 			)),
/*1190*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*1192*/ 			push((char*) (
/*1192*/ 				push((char*) alloc_RECORD(28, 3)),
/*1192*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__clone"),
/*1192*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1192*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__CLONE"),
/*1192*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1192*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"public void()"),
/*1192*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1192*/ 				*(int*) (tos()+20) = FALSE,
/*1192*/ 				*(int*) (tos()+24) = FALSE,
/*1193*/ 				(RECORD*) pop()
/*1193*/ 			)),
/*1193*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*1194*/ 			push((char*) (
/*1194*/ 				push((char*) alloc_RECORD(28, 3)),
/*1194*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"__set_static"),
/*1194*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1194*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"__SET_STATIC"),
/*1194*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1194*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"public static void(array[string]mixed)"),
/*1194*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1194*/ 				*(int*) (tos()+20) = FALSE,
/*1194*/ 				*(int*) (tos()+24) = FALSE,
/*1195*/ 				(RECORD*) pop()
/*1195*/ 			)),
/*1195*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),2) = (RECORD*) tos(), pop(),
/*1197*/ 			push((char*) (
/*1197*/ 				push((char*) alloc_RECORD(28, 3)),
/*1197*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__sleep"),
/*1197*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1197*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__SLEEP"),
/*1197*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1197*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"public array[int]string()"),
/*1197*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1197*/ 				*(int*) (tos()+20) = TRUE,
/*1197*/ 				*(int*) (tos()+24) = FALSE,
/*1198*/ 				(RECORD*) pop()
/*1198*/ 			)),
/*1198*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),3) = (RECORD*) tos(), pop(),
/*1198*/ 			push((char*) (
/*1198*/ 				push((char*) alloc_RECORD(28, 3)),
/*1198*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"__wakeup"),
/*1198*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1198*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"__WAKEUP"),
/*1198*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1198*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"public void()"),
/*1198*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1198*/ 				*(int*) (tos()+20) = TRUE,
/*1198*/ 				*(int*) (tos()+24) = FALSE,
/*1199*/ 				(RECORD*) pop()
/*1199*/ 			)),
/*1199*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),4) = (RECORD*) tos(), pop(),
/*1200*/ 			push((char*) (
/*1200*/ 				push((char*) alloc_RECORD(28, 3)),
/*1200*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__toString"),
/*1200*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1200*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__TOSTRING"),
/*1200*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1200*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"public string()"),
/*1200*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1200*/ 				*(int*) (tos()+20) = FALSE,
/*1200*/ 				*(int*) (tos()+24) = FALSE,
/*1201*/ 				(RECORD*) pop()
/*1201*/ 			)),
/*1201*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),5) = (RECORD*) tos(), pop(),
/*1203*/ 			push((char*) (
/*1203*/ 				push((char*) alloc_RECORD(28, 3)),
/*1203*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"__set"),
/*1203*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1203*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"__SET"),
/*1203*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1203*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"public void(string, mixed)"),
/*1203*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1203*/ 				*(int*) (tos()+20) = FALSE,
/*1203*/ 				*(int*) (tos()+24) = TRUE,
/*1204*/ 				(RECORD*) pop()
/*1204*/ 			)),
/*1204*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),6) = (RECORD*) tos(), pop(),
/*1204*/ 			push((char*) (
/*1204*/ 				push((char*) alloc_RECORD(28, 3)),
/*1204*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"__get"),
/*1204*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1204*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"__GET"),
/*1204*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1204*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"public mixed(string)"),
/*1204*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1204*/ 				*(int*) (tos()+20) = FALSE,
/*1204*/ 				*(int*) (tos()+24) = TRUE,
/*1205*/ 				(RECORD*) pop()
/*1205*/ 			)),
/*1205*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),7) = (RECORD*) tos(), pop(),
/*1205*/ 			push((char*) (
/*1205*/ 				push((char*) alloc_RECORD(28, 3)),
/*1205*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__isset"),
/*1205*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1205*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__ISSET"),
/*1205*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1205*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"public boolean(string)"),
/*1205*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1205*/ 				*(int*) (tos()+20) = FALSE,
/*1205*/ 				*(int*) (tos()+24) = TRUE,
/*1206*/ 				(RECORD*) pop()
/*1206*/ 			)),
/*1206*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),8) = (RECORD*) tos(), pop(),
/*1206*/ 			push((char*) (
/*1206*/ 				push((char*) alloc_RECORD(28, 3)),
/*1206*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__unset"),
/*1206*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1206*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__UNSET"),
/*1206*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1206*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"public void(string)"),
/*1206*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1206*/ 				*(int*) (tos()+20) = FALSE,
/*1206*/ 				*(int*) (tos()+24) = TRUE,
/*1207*/ 				(RECORD*) pop()
/*1207*/ 			)),
/*1207*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),9) = (RECORD*) tos(), pop(),
/*1207*/ 			push((char*) (
/*1207*/ 				push((char*) alloc_RECORD(28, 3)),
/*1207*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"__call"),
/*1207*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1207*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"__CALL"),
/*1207*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1207*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"public mixed(string, array[]mixed)"),
/*1207*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1207*/ 				*(int*) (tos()+20) = FALSE,
/*1207*/ 				*(int*) (tos()+24) = TRUE,
/*1210*/ 				(RECORD*) pop()
/*1210*/ 			)),
/*1210*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),10) = (RECORD*) tos(), pop(),
/*1211*/ 			(ARRAY*) pop()
/*1211*/ 		);
/*1213*/ 	}
/*1213*/ 	Statements_i = (m2runtime_count(Statements_specialMethods) - 1);
/*1215*/ 	do{
/*1215*/ 		if( (Statements_i < 0) ){
/*1218*/ 			goto m2runtime_loop_1;
/*1218*/ 		}
/*1218*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 242), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 243), 12, Statements_0err_entry_get, 244)) == 0 ){
/*1219*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 245), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 246), 8, Statements_0err_entry_get, 247)) != 0 ){
/*1220*/ 				Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"the special method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 248), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"' should be written as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 249), 8, Statements_0err_entry_get, 250), m2runtime_CHR(39), 1));
/*1224*/ 			}
/*1225*/ 			goto m2runtime_loop_1;
/*1225*/ 		}
/*1225*/ 		m2_inc(&Statements_i, -1);
/*1228*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1228*/ 	if( (Statements_i < 0) ){
/*1229*/ 		if( (((m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 251)) >= 2)) && (m2runtime_strcmp(m2runtime_substr((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 252), 0, 2, 1, Statements_0err_entry_get, 253), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"__") == 0)) ){
/*1230*/ 			Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 254), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"unknown special method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 255), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\121,\0,\0,\0)"'. Methods whose name begin with `__' are reserved for future use by the language", 1));
/*1234*/ 		}
/*1234*/ 		return ;
/*1238*/ 	}
/*1238*/ 	if( (((Globals_php_ver == 4)) && ! *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 256), 20, Statements_0err_entry_get, 257)) ){
/*1239*/ 		Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 258), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"the name `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 259), 8, Statements_0err_entry_get, 260), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\107,\0,\0,\0)"' is reserved for a special method in PHP5, use another name under PHP4", 1));
/*1241*/ 		return ;
/*1241*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 261), 24, Statements_0err_entry_get, 262) ){
/*1242*/ 		Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 263), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"special method `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 264), 8, Statements_0err_entry_get, 265), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"' not supported by PHPLint", 1));
/*1246*/ 	}
/*1246*/ 	Statements_sign = Types_MethodSignatureToString(Statements_m);
/*1247*/ 	if( m2runtime_strcmp(Statements_sign, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 266), 16, Statements_0err_entry_get, 267)) != 0 ){
/*1248*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 268), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"special method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 269), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"': invalid signature `", Statements_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"', expected `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 270), 16, Statements_0err_entry_get, 271), m2runtime_CHR(39), 1));
/*1253*/ 	}
/*1255*/ }


/*1257*/ int
/*1257*/ Statements_SameMethodSignature(RECORD *Statements_m1, RECORD *Statements_m2)
/*1257*/ {
/*1257*/ 	return (Statements_eqbool( *(int *)m2runtime_dereference_rhs_RECORD(Statements_m1, 56, Statements_0err_entry_get, 272),  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m2, 56, Statements_0err_entry_get, 273)) && Statements_eqbool( *(int *)m2runtime_dereference_rhs_RECORD(Statements_m1, 52, Statements_0err_entry_get, 274),  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m2, 52, Statements_0err_entry_get, 275)) && (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_m1, 48, Statements_0err_entry_get, 276) ==  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m2, 48, Statements_0err_entry_get, 277))) && Statements_SameSign((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m1, 16, Statements_0err_entry_get, 278), (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m2, 16, Statements_0err_entry_get, 279)));
/*1264*/ }


/*1267*/ void
/*1267*/ Statements_ParseClassMethodDecl(int Statements_abstract, int Statements_visibility, int Statements_static, int Statements_final, RECORD *Statements_t)
/*1267*/ {
/*1268*/ 	RECORD * Statements_old_m = NULL;
/*1268*/ 	RECORD * Statements_m = NULL;
/*1269*/ 	int Statements_i = 0;
/*1270*/ 	RECORD * Statements_sign = NULL;
/*1271*/ 	RECORD * Statements_this = NULL;
/*1272*/ 	int Statements_guess = 0;
/*1273*/ 	int Statements_is_destructor = 0;
/*1273*/ 	int Statements_is_constructor = 0;
/*1275*/ 	STRING * Statements_err = NULL;

/*1281*/ 	RECORD *
/*1281*/ 	Statements_ParentConstructor(RECORD *Statements_c)
/*1281*/ 	{
/*1281*/ 		Statements_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 280);
/*1282*/ 		while( ((Statements_c != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 40, Statements_0err_entry_get, 281) == NULL)) ){
/*1283*/ 			Statements_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 282);
/*1285*/ 		}
/*1285*/ 		return Statements_c;
/*1288*/ 	}


/*1294*/ 	RECORD *
/*1294*/ 	Statements_ParentDestructor(RECORD *Statements_c)
/*1294*/ 	{
/*1294*/ 		Statements_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 283);
/*1295*/ 		while( ((Statements_c != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 44, Statements_0err_entry_get, 284) == NULL)) ){
/*1296*/ 			Statements_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 285);
/*1298*/ 		}
/*1298*/ 		return Statements_c;
/*1302*/ 	}

/*1305*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 76, Statements_0err_entry_get, 286) ){
/*1306*/ 		Statements_abstract = TRUE;
/*1307*/ 		if( (Statements_visibility != 2) ){
/*1308*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"interface methods must be `public'");
/*1309*/ 			Statements_visibility = 2;
/*1311*/ 		}
/*1311*/ 		if( Statements_final ){
/*1312*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"interface methods cannot be `final'");
/*1313*/ 			Statements_final = FALSE;
/*1316*/ 		}
/*1316*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 72, Statements_0err_entry_get, 287) ){
/*1317*/ 		if( Statements_abstract ){
/*1318*/ 			if( (Statements_visibility == 0) ){
/*1319*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"abstract methods cannot be `private'");
/*1320*/ 				Statements_visibility = 1;
/*1322*/ 			}
/*1322*/ 			if( Statements_static ){
/*1323*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"abstract methods cannot be static");
/*1324*/ 				Statements_static = FALSE;
/*1326*/ 			}
/*1326*/ 			if( Statements_final ){
/*1327*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"abstract methods cannot be `final'");
/*1328*/ 				Statements_final = FALSE;
/*1331*/ 			}
/*1331*/ 		} else {
/*1331*/ 			if( (Statements_final && ((Statements_visibility == 0))) ){
/*1332*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"a private method is implicitly `final'");
/*1333*/ 				Statements_final = FALSE;
/*1336*/ 			}
/*1337*/ 		}
/*1338*/ 	} else {
/*1338*/ 		if( Statements_abstract ){
/*1339*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"abstract method in non-abstract class");
/*1340*/ 			Statements_abstract = FALSE;
/*1342*/ 		}
/*1342*/ 		if( (Statements_final && ((Statements_visibility == 0))) ){
/*1343*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"a private method is implicitly `final'");
/*1344*/ 			Statements_final = FALSE;
/*1348*/ 		}
/*1349*/ 	}
/*1349*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 44, Statements_0err_entry_get, 288) = Statements_abstract;
/*1350*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 48, Statements_0err_entry_get, 289) = Statements_visibility;
/*1351*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 52, Statements_0err_entry_get, 290) = Statements_static;
/*1352*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 56, Statements_0err_entry_get, 291) = Statements_final;
/*1354*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 292) = Statements_t;
/*1355*/ 	if( Statements_t == NULL ){
/*1356*/ 		Statements_guess = TRUE;
/*1359*/ 	}
/*1359*/ 	Scanner_ReadSym();
/*1364*/ 	if( (Scanner_sym == 73) ){
/*1365*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 16, Statements_0err_entry_get, 293) = TRUE;
/*1366*/ 		if( (Globals_php_ver == 5) ){
/*1367*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"obsolete syntax `function &func()', don't use in PHP 5");
/*1369*/ 		}
/*1369*/ 		Scanner_ReadSym();
/*1375*/ 	}
/*1375*/ 	Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"expected method name");
/*1376*/ 	Statements_old_m = Search_SearchClassMethod(Globals_curr_class, Scanner_s, FALSE);
/*1377*/ 	if( Statements_old_m != NULL ){
/*1378*/ 		if( (! *(int *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 40, Statements_0err_entry_get, 294) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 20, Statements_0err_entry_get, 295) != NULL)) ){
/*1379*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"method `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"()' already defined in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 20, Statements_0err_entry_get, 296)), 1));
/*1384*/ 		}
/*1384*/ 		Statements_i = 0;
/*1385*/ 		while( (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 36, Statements_0err_entry_get, 297), Statements_i, Statements_0err_entry_get, 298) != Statements_old_m ){
/*1386*/ 			m2_inc(&Statements_i, 1);
/*1388*/ 		}
/*1388*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 36, Statements_0err_entry_get, 299), 4, 1, Statements_i, Statements_0err_entry_get, 300) = Statements_m;
/*1391*/ 	} else {
/*1391*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 36, Statements_0err_entry_get, 301), 4, 1, Statements_0err_entry_get, 302) = Statements_m;
/*1393*/ 	}
/*1393*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 8, Statements_0err_entry_get, 303) = Scanner_s;
/*1394*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 12, Statements_0err_entry_get, 304) = str_toupper(Scanner_s);
/*1396*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 20, Statements_0err_entry_get, 305) = Scanner_here();
/*1397*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 16, Statements_0err_entry_get, 306) = Statements_sign;
/*1402*/ 	if( (Globals_php_ver == 4) ){
/*1404*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 307), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") == 0 ){
/*1405*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 308), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"': this name is reserved for PHP 5 constructors", 1));
/*1408*/ 		}
/*1408*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 309), (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 12, Statements_0err_entry_get, 310)) == 0 ){
/*1409*/ 			Statements_is_constructor = TRUE;
/*1410*/ 			if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 311) == NULL ){
/*1411*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 40, Statements_0err_entry_get, 312) = Statements_m;
/*1412*/ 			} else if( ! *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 313), 40, Statements_0err_entry_get, 314) ){
/*1413*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 315), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"': constructor already declared as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 316), 8, Statements_0err_entry_get, 317), m2runtime_CHR(39), 1));
/*1418*/ 			}
/*1419*/ 		}
/*1421*/ 	} else {
/*1421*/ 		if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 318), (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 12, Statements_0err_entry_get, 319)) == 0) || (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 320), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") == 0)) ){
/*1423*/ 			Statements_is_constructor = TRUE;
/*1424*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 321), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") != 0 ){
/*1425*/ 				Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"the constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 322), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' has the same name of the class. PHP 5 states", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)" it should be called `__construct()'", 1));
/*1429*/ 			}
/*1429*/ 			if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 323) == NULL ){
/*1430*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 40, Statements_0err_entry_get, 324) = Statements_m;
/*1431*/ 			} else if( ! *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 325), 40, Statements_0err_entry_get, 326) ){
/*1432*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 327), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"': constructor already declared as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 328), 8, Statements_0err_entry_get, 329), m2runtime_CHR(39), 1));
/*1437*/ 			}
/*1439*/ 		}
/*1443*/ 	}
/*1443*/ 	Statements_is_destructor = (((Globals_php_ver == 5)) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 330), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__DESTRUCT") == 0));
/*1444*/ 	if( Statements_is_destructor ){
/*1445*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 44, Statements_0err_entry_get, 331) = Statements_m;
/*1448*/ 	}
/*1448*/ 	if( (!Accounting_report_unused || Statements_is_constructor || Statements_is_destructor || Statements_abstract) ){
/*1449*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 60, Statements_0err_entry_get, 332) = 100;
/*1452*/ 	}
/*1452*/ 	Globals_curr_method = Statements_m;
/*1453*/ 	m2_inc(&Globals_scope, 1);
/*1454*/ 	Scanner_ReadSym();
/*1460*/ 	Accounting_AccountVarLHS(m2runtime_CHR(42), FALSE);
/*1461*/ 	Statements_this = Search_SearchVar(m2runtime_CHR(42), Globals_scope);
/*1462*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 8, Statements_0err_entry_get, 333) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"this";
/*1463*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 20, Statements_0err_entry_get, 334) = (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 24, Statements_0err_entry_get, 335);
/*1468*/ 	if( Statements_ParseArgsListDecl(Statements_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"method") ){
/*1469*/ 		Statements_guess = TRUE;
/*1472*/ 	}
/*1472*/ 	if( !Statements_is_constructor ){
/*1479*/ 		if( !Statements_guess ){
/*1480*/ 			Statements_CheckSpecialMethodSignature(Statements_m);
/*1484*/ 		}
/*1490*/ 	} else {
/*1490*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m, 52, Statements_0err_entry_get, 336) ){
/*1491*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 337), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"': a constructor cannot be `static'", 1));
/*1493*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 52, Statements_0err_entry_get, 338) = FALSE;
/*1495*/ 		}
/*1495*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m, 56, Statements_0err_entry_get, 339) ){
/*1496*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 340), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"': a constructor cannot be `final'", 1));
/*1498*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 56, Statements_0err_entry_get, 341) = FALSE;
/*1500*/ 		}
/*1500*/ 		if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 342) != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 343) != Globals_void_type)) ){
/*1501*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 344), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"': a constructor cannot", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)" return a value. It must be declared `void'.", 1));
/*1504*/ 		}
/*1504*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 345) = Globals_void_type;
/*1511*/ 	}
/*1511*/ 	if( (Scanner_sym == 169) ){
/*1512*/ 		Exceptions_ParseThrows();
/*1515*/ 	}
/*1515*/ 	if( (Scanner_sym == 170) ){
/*1516*/ 		if( (((Globals_php_ver == 5)) && Statements_abstract) ){
/*1517*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"the DOC description for abstract methods must follows ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"the `;'", 1));
/*1520*/ 		}
/*1520*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 32, Statements_0err_entry_get, 346) = Scanner_s;
/*1521*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 36, Statements_0err_entry_get, 347) = Documentator_ExtractDeprecated(Scanner_s);
/*1522*/ 		Scanner_ReadSym();
/*1523*/ 	} else if( Statements_pdb != NULL ){
/*1524*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 32, Statements_0err_entry_get, 348) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 349);
/*1525*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 36, Statements_0err_entry_get, 350) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 351));
/*1526*/ 		Statements_pdb = NULL;
/*1532*/ 	}
/*1532*/ 	if( (Scanner_sym == 17) ){
/*1534*/ 		if( (Globals_php_ver == 4) ){
/*1535*/ 			if( Statements_abstract ){
/*1536*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"expected empty body `{}' for abstract method");
/*1538*/ 			} else {
/*1538*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"expected method body");
/*1541*/ 			}
/*1541*/ 		} else {
/*1541*/ 			if( !Statements_abstract ){
/*1542*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"missing method body in non abstract method");
/*1545*/ 			}
/*1546*/ 		}
/*1546*/ 		Scanner_ReadSym();
/*1548*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 48, Statements_0err_entry_get, 352) = 100;
/*1550*/ 		if( (Scanner_sym == 170) ){
/*1551*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 32, Statements_0err_entry_get, 353) = Scanner_s;
/*1552*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 36, Statements_0err_entry_get, 354) = Documentator_ExtractDeprecated(Scanner_s);
/*1553*/ 			Scanner_ReadSym();
/*1554*/ 		} else if( Statements_pdb != NULL ){
/*1555*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 72, 8, 32, Statements_0err_entry_get, 355) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 356);
/*1556*/ 			Statements_pdb = NULL;
/*1559*/ 		}
/*1559*/ 	} else if( (Scanner_sym == 10) ){
/*1561*/ 		if( (Globals_php_ver == 4) ){
/*1562*/ 			if( Statements_abstract ){
/*1563*/ 				Scanner_ReadSym();
/*1564*/ 				Scanner_Expect(11, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"expected `}'. The body of an abstract method must be empty.");
/*1565*/ 				Scanner_ReadSym();
/*1566*/ 				if( !Statements_static ){
/*1567*/ 					*(int *)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 48, Statements_0err_entry_get, 357) = 100;
/*1570*/ 				}
/*1570*/ 			} else {
/*1570*/ 				Statements_ParseBlock();
/*1574*/ 			}
/*1574*/ 		} else {
/*1574*/ 			if( Statements_abstract ){
/*1575*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"expected `;'. Abstract method cannot contain a body.");
/*1577*/ 			}
/*1577*/ 			Statements_ParseBlock();
/*1584*/ 		}
/*1584*/ 		if( (Statements_is_constructor && (Statements_ParentConstructor(Globals_curr_class) != NULL) && ! *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 80, Statements_0err_entry_get, 358)) ){
/*1588*/ 			Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 359), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\102,\0,\0,\0)"missing call to the parent constructor in overridding constructor ", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 8, Statements_0err_entry_get, 360), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 361), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1594*/ 		}
/*1594*/ 		if( (Statements_is_destructor && (Statements_ParentDestructor(Globals_curr_class) != NULL) && ! *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 84, Statements_0err_entry_get, 362)) ){
/*1598*/ 			Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 363), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\100,\0,\0,\0)"missing call to the parent destructor in overridding destructor ", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 8, Statements_0err_entry_get, 364), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 365), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1602*/ 		}
/*1602*/ 	} else {
/*1602*/ 		Scanner_UnexpectedSymbol();
/*1606*/ 	}
/*1606*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 366) == NULL ){
/*1608*/ 		Statements_guess = TRUE;
/*1609*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 367) = Globals_void_type;
/*1616*/ 	}
/*1616*/ 	if( (Statements_guess && !Statements_is_constructor) ){
/*1617*/ 		Statements_CheckSpecialMethodSignature(Statements_m);
/*1644*/ 	}
/*1644*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 48, Statements_0err_entry_get, 368) = 100;
/*1646*/ 	if( Statements_guess ){
/*1647*/ 		Scanner_Notice2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 369), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"guessed signature of the method ", Scanner_mn(Globals_curr_class, Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" as ", Types_MethodSignatureToString(Statements_m), 1));
/*1651*/ 	}
/*1651*/ 	Classes_CheckOverriddenMethod(Globals_curr_class, Statements_m);
/*1653*/ 	Expressions_CleanCurrentScope();
/*1654*/ 	m2_inc(&Globals_scope, -1);
/*1655*/ 	Globals_curr_method = NULL;
/*1657*/ 	if( Statements_old_m != NULL ){
/*1658*/ 		if( !Statements_SameMethodSignature(Statements_m, Statements_old_m) ){
/*1659*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 40, Statements_0err_entry_get, 370) ){
/*1660*/ 				Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 371), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"method ", Scanner_mn(Globals_curr_class, Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" with signature `", Types_MethodSignatureToString(Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"' does not match forward signature `", Types_MethodSignatureToString(Statements_old_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"' as declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 20, Statements_0err_entry_get, 372)), 1));
/*1667*/ 			} else {
/*1667*/ 				Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 373), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"method ", Scanner_mn(Globals_curr_class, Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" with signature `", Types_MethodSignatureToString(Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"' does not match the signature `", Types_MethodSignatureToString(Statements_old_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"' as guessed in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 24, Statements_0err_entry_get, 374)), 1));
/*1675*/ 			}
/*1677*/ 		}
/*1677*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 40, Statements_0err_entry_get, 375) ){
/*1678*/ 			Statements_err = Classes_ClassesList(Classes_Sort(Classes_OrphanClasses((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 28, Statements_0err_entry_get, 376), (ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_m, 28, Statements_0err_entry_get, 377))));
/*1679*/ 			if( m2runtime_strcmp(Statements_err, NULL) > 0 ){
/*1680*/ 				Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 378), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 379), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\112,\0,\0,\0)"()' throws more exceptions than those listed in the prototype declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 20, Statements_0err_entry_get, 380)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", Statements_err, 1));
/*1685*/ 			}
/*1686*/ 		}
/*1687*/ 	}
/*1689*/ }


/*1692*/ void
/*1692*/ Statements_ParseClass(int Statements_private_class)
/*1692*/ {
/*1693*/ 	RECORD * Statements_if = NULL;
/*1693*/ 	RECORD * Statements_parent = NULL;
/*1693*/ 	RECORD * Statements_class2 = NULL;
/*1693*/ 	RECORD * Statements_class = NULL;
/*1696*/ 	RECORD * Statements_t = NULL;
/*1696*/ 	int Statements_x_visibility_set = 0;
/*1697*/ 	int Statements_x_visibility = 0;
/*1698*/ 	int Statements_x_abstract = 0;
/*1699*/ 	int Statements_x_final = 0;
/*1700*/ 	int Statements_x_static = 0;
/*1701*/ 	int Statements_abstract = 0;
/*1701*/ 	int Statements_visibility_set = 0;
/*1702*/ 	int Statements_visibility = 0;
/*1703*/ 	int Statements_static = 0;
/*1705*/ 	int Statements_final = 0;
/*1706*/ 	int Statements_i = 0;
/*1709*/ 	RECORD * Statements_m = NULL;
/*1709*/ 	if( (Globals_php_ver == 4) ){
/*1710*/ 		Statements_DocBlockCheckAllowedLineTags(((64 | 16) | 128), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class");
/*1713*/ 	} else {
/*1713*/ 		Statements_DocBlockCheckAllowedLineTags(128, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class");
/*1717*/ 	}
/*1717*/ 	if( (Globals_scope > 0) ){
/*1718*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\171,\0,\0,\0)"class declaration inside a function. The namespace of the classes is still global so the function cannot be called twice.");
/*1721*/ 	}
/*1721*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 48, Statements_0err_entry_get, 381) = Scanner_here();
/*1723*/ 	if( !Accounting_report_unused ){
/*1724*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 88, Statements_0err_entry_get, 382) = 100;
/*1730*/ 	}
/*1730*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 64, Statements_0err_entry_get, 383) = (Statements_private_class || ((Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 40, Statements_0err_entry_get, 384)));
/*1731*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 72, Statements_0err_entry_get, 385) = ((Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 36, Statements_0err_entry_get, 386));
/*1732*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 68, Statements_0err_entry_get, 387) = ((Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 52, Statements_0err_entry_get, 388));
/*1738*/ 	do{
/*1738*/ 		if( (Scanner_sym == 164) ){
/*1739*/ 			if( (Globals_php_ver == 5) ){
/*1740*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"invalid qualifier `/*.abstract.*/', use `abstract' instead");
/*1742*/ 			}
/*1742*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 389) ){
/*1743*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"`abstract' attribute already set");
/*1745*/ 			}
/*1745*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 72, Statements_0err_entry_get, 390) = TRUE;
/*1746*/ 			Scanner_ReadSym();
/*1748*/ 		} else if( (Scanner_sym == 166) ){
/*1749*/ 			if( (Globals_php_ver == 5) ){
/*1750*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"invalid qualifier `/*.final.*/', use `final' instead");
/*1752*/ 			}
/*1752*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 68, Statements_0err_entry_get, 391) ){
/*1753*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"`final' attribute already set");
/*1755*/ 			}
/*1755*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 68, Statements_0err_entry_get, 392) = TRUE;
/*1756*/ 			Scanner_ReadSym();
/*1758*/ 		} else if( (Scanner_sym == 91) ){
/*1759*/ 			if( (Globals_php_ver == 4) ){
/*1760*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"invalid qualifier `abstract', use `/*.abstract.*/' instead");
/*1762*/ 			}
/*1762*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 393) ){
/*1763*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"`abstract' attribute already set");
/*1765*/ 			}
/*1765*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 72, Statements_0err_entry_get, 394) = TRUE;
/*1766*/ 			Scanner_ReadSym();
/*1768*/ 		} else if( (Scanner_sym == 102) ){
/*1769*/ 			if( (Globals_php_ver == 4) ){
/*1770*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"invalid qualifier `final', use `/*.final.*/' instead");
/*1772*/ 			}
/*1772*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 68, Statements_0err_entry_get, 395) ){
/*1773*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"`final' attribute already set");
/*1775*/ 			}
/*1775*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 68, Statements_0err_entry_get, 396) = TRUE;
/*1776*/ 			Scanner_ReadSym();
/*1780*/ 		} else {
/*1782*/ 			goto m2runtime_loop_1;
/*1783*/ 		}
/*1784*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1784*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 68, Statements_0err_entry_get, 397) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 398)) ){
/*1785*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"a class cannot be both final and abstract");
/*1788*/ 	}
/*1788*/ 	Scanner_Expect(93, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"expected `class'");
/*1789*/ 	Scanner_ReadSym();
/*1794*/ 	Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected class name");
/*1795*/ 	Statements_class2 = Search_SearchClass(Scanner_s, FALSE);
/*1796*/ 	if( Statements_class2 == NULL ){
/*1797*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 8, Statements_0err_entry_get, 399) = Scanner_s;
/*1798*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 12, Statements_0err_entry_get, 400) = str_toupper(Scanner_s);
/*1799*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 24, Statements_0err_entry_get, 401) = (
/*1799*/ 			push((char*) alloc_RECORD(24, 2)),
/*1799*/ 			*(int*) (tos()+16) = 9,
/*1799*/ 			*(int*) (tos()+20) = 1,
/*1799*/ 			push((char*) NULL),
/*1799*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*1799*/ 			push((char*) Statements_class),
/*1800*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*1800*/ 			(RECORD*) pop()
/*1800*/ 		);
/*1800*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_classes, 4, 1, Statements_0err_entry_get, 402) = Statements_class;
/*1802*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class2, 60, Statements_0err_entry_get, 403) ){
/*1803*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 64, Statements_0err_entry_get, 404) =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 64, Statements_0err_entry_get, 405);
/*1804*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 72, Statements_0err_entry_get, 406) =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 407);
/*1805*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 68, Statements_0err_entry_get, 408) =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 68, Statements_0err_entry_get, 409);
/*1806*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 48, Statements_0err_entry_get, 410) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_class, 48, Statements_0err_entry_get, 411);
/*1807*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 88, Statements_0err_entry_get, 412) =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 88, Statements_0err_entry_get, 413);
/*1808*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 60, Statements_0err_entry_get, 414) = FALSE;
/*1809*/ 		Statements_class = Statements_class2;
/*1812*/ 	} else {
/*1812*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_class2, 48, Statements_0err_entry_get, 415)), 1));
/*1816*/ 	}
/*1816*/ 	Globals_curr_class = Statements_class;
/*1817*/ 	Scanner_ReadSym();
/*1822*/ 	if( (Scanner_sym == 94) ){
/*1823*/ 		Scanner_ReadSym();
/*1824*/ 		Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"expected parent class name after `extend'");
/*1825*/ 		Statements_parent = Search_SearchClass(Scanner_s, TRUE);
/*1826*/ 		if( Statements_parent == NULL ){
/*1827*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"undeclared parent class `", Scanner_s, m2runtime_CHR(39), 1));
/*1828*/ 		} else if( Statements_parent == Statements_class ){
/*1829*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"can't extend itself");
/*1830*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_parent, 68, Statements_0err_entry_get, 416) ){
/*1831*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"can't extend final class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 8, Statements_0err_entry_get, 417), m2runtime_CHR(39), 1));
/*1832*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_parent, 76, Statements_0err_entry_get, 418) ){
/*1833*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"can't extend interface class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 8, Statements_0err_entry_get, 419), m2runtime_CHR(39), 1));
/*1835*/ 		} else {
/*1835*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 16, Statements_0err_entry_get, 420) = Statements_parent;
/*1836*/ 			Accounting_AccountClass(Statements_parent);
/*1837*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 56, Statements_0err_entry_get, 421), EMPTY_STRING) > 0 ){
/*1838*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"extending deprecated class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 8, Statements_0err_entry_get, 422), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 56, Statements_0err_entry_get, 423), 1));
/*1842*/ 			}
/*1842*/ 		}
/*1842*/ 		Scanner_ReadSym();
/*1848*/ 	}
/*1848*/ 	if( (Scanner_sym == 95) ){
/*1849*/ 		Scanner_ReadSym();
/*1851*/ 		do{
/*1851*/ 			Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected interface name");
/*1852*/ 			Statements_if = Search_SearchClass(Scanner_s, TRUE);
/*1853*/ 			if( Statements_if == NULL ){
/*1854*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"undeclared interface class `", Scanner_s, m2runtime_CHR(39), 1));
/*1855*/ 			} else if( ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_if, 76, Statements_0err_entry_get, 424) ){
/*1856*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"' isn't an interface", 1));
/*1858*/ 			} else {
/*1858*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 20, Statements_0err_entry_get, 425), 4, 1, Statements_0err_entry_get, 426) = Statements_if;
/*1861*/ 				Accounting_AccountClass(Statements_if);
/*1862*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 56, Statements_0err_entry_get, 427), EMPTY_STRING) > 0 ){
/*1863*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"implementing deprecated interface `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 8, Statements_0err_entry_get, 428), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 56, Statements_0err_entry_get, 429), 1));
/*1867*/ 				}
/*1867*/ 			}
/*1867*/ 			Scanner_ReadSym();
/*1868*/ 			if( (Scanner_sym == 16) ){
/*1869*/ 				Scanner_ReadSym();
/*1872*/ 			} else {
/*1873*/ 				goto m2runtime_loop_2;
/*1874*/ 			}
/*1875*/ 		}while(TRUE);
m2runtime_loop_2: ;
/*1876*/ 	}
/*1876*/ 	Classes_CheckCollisionsBetweenExtendedAndImplementedClasses(Statements_class);
/*1878*/ 	if( (Scanner_sym == 170) ){
/*1879*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 52, Statements_0err_entry_get, 430) = Scanner_s;
/*1880*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 56, Statements_0err_entry_get, 431) = Documentator_ExtractDeprecated(Scanner_s);
/*1881*/ 		Scanner_ReadSym();
/*1882*/ 	} else if( Statements_pdb != NULL ){
/*1883*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 52, Statements_0err_entry_get, 432) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 433);
/*1884*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 56, Statements_0err_entry_get, 434) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 435));
/*1885*/ 		Statements_pdb = NULL;
/*1888*/ 	}
/*1888*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"expected '{' in class declaration");
/*1889*/ 	Scanner_ReadSym();
/*1893*/ 	do{
/*1893*/ 		if( (Scanner_sym == 11) ){
/*1894*/ 			Scanner_ReadSym();
/*1897*/ 			goto m2runtime_loop_3;
/*1899*/ 		}
/*1899*/ 		Statements_x_visibility_set = FALSE;
/*1900*/ 		Statements_x_visibility = 2;
/*1901*/ 		Statements_x_abstract = FALSE;
/*1902*/ 		Statements_x_final = FALSE;
/*1903*/ 		Statements_x_static = FALSE;
/*1906*/ 		Statements_abstract = FALSE;
/*1907*/ 		Statements_visibility_set = FALSE;
/*1908*/ 		Statements_visibility = 2;
/*1909*/ 		Statements_static = FALSE;
/*1910*/ 		Statements_final = FALSE;
/*1915*/ 		while( (Scanner_sym == 171) ){
/*1916*/ 			Statements_pdb = ParseDocBlock_ParseDocBlock(Scanner_s);
/*1917*/ 			if( Statements_pdb != NULL ){
/*1918*/ 				if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 40, Statements_0err_entry_get, 436) ){
/*1919*/ 					Statements_x_visibility = 0;
/*1920*/ 					Statements_x_visibility_set = TRUE;
/*1921*/ 				} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 44, Statements_0err_entry_get, 437) ){
/*1922*/ 					Statements_x_visibility = 1;
/*1923*/ 					Statements_x_visibility_set = TRUE;
/*1924*/ 				} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 438) ){
/*1925*/ 					Statements_x_visibility = 2;
/*1926*/ 					Statements_x_visibility_set = TRUE;
/*1928*/ 				}
/*1928*/ 				Statements_x_abstract =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 36, Statements_0err_entry_get, 439);
/*1929*/ 				Statements_x_final =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 52, Statements_0err_entry_get, 440);
/*1930*/ 				Statements_x_static =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 56, Statements_0err_entry_get, 441);
/*1932*/ 			}
/*1932*/ 			Scanner_ReadSym();
/*1937*/ 		}
/*1937*/ 		do{
/*1937*/ 			switch(Scanner_sym){

/*1939*/ 			case 161:
/*1940*/ 			if( Statements_x_visibility_set ){
/*1941*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*1943*/ 			}
/*1943*/ 			Statements_x_visibility_set = TRUE;
/*1944*/ 			Statements_x_visibility = 2;
/*1946*/ 			break;

/*1946*/ 			case 162:
/*1947*/ 			if( Statements_x_visibility_set ){
/*1948*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*1950*/ 			}
/*1950*/ 			Statements_x_visibility_set = TRUE;
/*1951*/ 			Statements_x_visibility = 1;
/*1953*/ 			break;

/*1953*/ 			case 163:
/*1954*/ 			if( Statements_x_visibility_set ){
/*1955*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*1957*/ 			}
/*1957*/ 			Statements_x_visibility_set = TRUE;
/*1958*/ 			Statements_x_visibility = 0;
/*1960*/ 			break;

/*1960*/ 			case 164:
/*1961*/ 			if( Statements_x_abstract ){
/*1962*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"abstract attribute already set");
/*1964*/ 			}
/*1964*/ 			Statements_x_abstract = TRUE;
/*1966*/ 			break;

/*1966*/ 			case 166:
/*1967*/ 			if( Statements_x_final ){
/*1968*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"final attribute already set");
/*1970*/ 			}
/*1970*/ 			Statements_x_final = TRUE;
/*1972*/ 			break;

/*1972*/ 			case 165:
/*1973*/ 			if( Statements_x_static ){
/*1974*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"static attribute already set");
/*1976*/ 			}
/*1976*/ 			Statements_x_static = TRUE;
/*1978*/ 			break;

/*1978*/ 			case 91:
/*1979*/ 			if( Statements_abstract ){
/*1980*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"abstract attribute already set");
/*1982*/ 			}
/*1982*/ 			Statements_abstract = TRUE;
/*1984*/ 			break;

/*1984*/ 			case 98:
/*1985*/ 			if( Statements_visibility_set ){
/*1986*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*1988*/ 			}
/*1988*/ 			Statements_visibility = 2;
/*1989*/ 			Statements_visibility_set = TRUE;
/*1991*/ 			break;

/*1991*/ 			case 100:
/*1992*/ 			if( Statements_visibility_set ){
/*1993*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*1995*/ 			}
/*1995*/ 			Statements_visibility = 1;
/*1996*/ 			Statements_visibility_set = TRUE;
/*1998*/ 			break;

/*1998*/ 			case 99:
/*1999*/ 			if( Statements_visibility_set ){
/*2000*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*2002*/ 			}
/*2002*/ 			Statements_visibility = 0;
/*2003*/ 			Statements_visibility_set = TRUE;
/*2005*/ 			break;

/*2005*/ 			case 101:
/*2006*/ 			if( Statements_static ){
/*2007*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"static attribute already set");
/*2009*/ 			}
/*2009*/ 			Statements_static = TRUE;
/*2011*/ 			break;

/*2011*/ 			case 102:
/*2012*/ 			if( Statements_final ){
/*2013*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"final attribute already set");
/*2015*/ 			}
/*2015*/ 			Statements_final = TRUE;
/*2018*/ 			break;

/*2019*/ 			default:
/*2021*/ 			goto m2runtime_loop_4;
/*2022*/ 			}
/*2022*/ 			Scanner_ReadSym();
/*2028*/ 		}while(TRUE);
m2runtime_loop_4: ;
/*2028*/ 		Statements_t = Expressions_ParseType(FALSE);
/*2029*/ 		if( Statements_t == NULL ){
/*2030*/ 			if( Statements_pdb != NULL ){
/*2031*/ 				if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 442) != NULL ){
/*2032*/ 					Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 443);
/*2033*/ 				} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 444) != NULL ){
/*2034*/ 					Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 445);
/*2037*/ 				}
/*2038*/ 			}
/*2038*/ 		} else {
/*2038*/ 			if( ((Statements_pdb != NULL) && ((((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 446) != NULL) || ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 447) != NULL)))) ){
/*2040*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\67,\0,\0,\0)"type declaration both in DocBlock and PHPLint meta-code");
/*2043*/ 			}
/*2044*/ 		}
/*2044*/ 		if( (Scanner_sym == 133) ){
/*2045*/ 			if( Statements_pdb != NULL ){
/*2046*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"unexpected DocBlock for forward declaration");
/*2048*/ 			}
/*2048*/ 			if( Statements_t != NULL ){
/*2049*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"unexpected type for forward declaration");
/*2051*/ 			}
/*2051*/ 			if( (Statements_x_visibility_set || Statements_x_abstract || Statements_x_final || Statements_x_static || Statements_abstract || Statements_visibility_set || Statements_static || Statements_final) ){
/*2053*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"unexpected attribute for forward declaration");
/*2055*/ 			}
/*2055*/ 			Proto_ParseForwardDecl();
/*2058*/ 		} else if( (Scanner_sym == 96) ){
/*2059*/ 			if( (Globals_php_ver == 4) ){
/*2060*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"invalid `const' declaration (PHP5)");
/*2062*/ 			}
/*2062*/ 			if( Statements_t != NULL ){
/*2063*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"can't provide a type to a class constants");
/*2065*/ 			}
/*2065*/ 			if( (Statements_x_abstract || Statements_x_final || Statements_x_static || Statements_abstract || Statements_visibility_set || Statements_static || Statements_final) ){
/*2067*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\125,\0,\0,\0)"invalid attribute. Only /*.public|protected|private.*/ is allowed for class constant.");
/*2069*/ 			}
/*2069*/ 			Statements_ParseClassConstDecl(Statements_x_visibility);
/*2072*/ 		} else if( (Scanner_sym == 97) ){
/*2073*/ 			if( (Globals_php_ver == 4) ){
/*2074*/ 				if( (Statements_x_abstract || Statements_x_final || Statements_x_static || Statements_abstract || Statements_visibility_set || Statements_static || Statements_final) ){
/*2076*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\122,\0,\0,\0)"invalid attribute. Only /*.public|protected|private.*/ are allowed for a property.");
/*2079*/ 				}
/*2079*/ 			} else {
/*2079*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"invalid qualifier `var' (PHP 4), use `public'");
/*2081*/ 			}
/*2081*/ 			Scanner_ReadSym();
/*2082*/ 			if( Statements_t == NULL ){
/*2083*/ 				Statements_t = Expressions_ParseType(FALSE);
/*2085*/ 			}
/*2085*/ 			Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"expected property name $xxx");
/*2086*/ 			if( Statements_x_visibility_set ){
/*2087*/ 				Statements_visibility = Statements_x_visibility;
/*2089*/ 			}
/*2089*/ 			Statements_ParseClassPropertyDecl(Statements_visibility, (Statements_x_static || Statements_static), Statements_t);
/*2092*/ 		} else if( (Scanner_sym == 20) ){
/*2093*/ 			if( (Globals_php_ver == 4) ){
/*2094*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"missing `var' before property name");
/*2096*/ 			} else {
/*2096*/ 				if( (Statements_x_visibility_set || Statements_x_abstract || Statements_x_final || Statements_x_static) ){
/*2097*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\152,\0,\0,\0)"cannot use meta-code or DocBlock to set visibility|abstract|final attributes, use proper language keywords");
/*2098*/ 				} else if( (Statements_abstract || Statements_final) ){
/*2099*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"properties cannot be abstract nor final");
/*2100*/ 				} else if( (!Statements_visibility_set && !Statements_static) ){
/*2101*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"property requires visibility attribute or static attribute");
/*2104*/ 				}
/*2104*/ 			}
/*2104*/ 			Statements_ParseClassPropertyDecl(Statements_visibility, Statements_static, Statements_t);
/*2107*/ 		} else if( (Scanner_sym == 8) ){
/*2108*/ 			if( (Globals_php_ver == 4) ){
/*2109*/ 				if( (Statements_abstract || Statements_visibility_set || Statements_static || Statements_final) ){
/*2110*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\146,\0,\0,\0)"invalid attribute. Only /*.abstract public|protected|private final static.*/ are allowed for a method.");
/*2112*/ 				}
/*2112*/ 				if( (Statements_x_abstract && ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 448)) ){
/*2113*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"abstract method in non-abstract class");
/*2114*/ 					Statements_x_abstract = FALSE;
/*2116*/ 				}
/*2116*/ 				Statements_ParseClassMethodDecl(Statements_x_abstract, Statements_x_visibility, Statements_x_static, Statements_x_final, Statements_t);
/*2118*/ 			} else {
/*2118*/ 				if( (Statements_x_visibility_set || Statements_x_abstract || Statements_x_static || Statements_x_final) ){
/*2119*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\146,\0,\0,\0)"invalid meta-code or DocBlock visibility|abstract|static|final attribute, use proper language keywords");
/*2121*/ 				}
/*2121*/ 				if( (Statements_abstract && ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 449)) ){
/*2122*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"abstract method in non-abstract class");
/*2123*/ 					Statements_abstract = FALSE;
/*2125*/ 				}
/*2125*/ 				Statements_ParseClassMethodDecl(Statements_abstract, Statements_visibility, Statements_static, Statements_final, Statements_t);
/*2129*/ 			}
/*2129*/ 		} else {
/*2129*/ 			Scanner_UnexpectedSymbol();
/*2133*/ 		}
/*2134*/ 	}while(TRUE);
m2runtime_loop_3: ;
/*2134*/ 	if( ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 450) ){
/*2135*/ 		Classes_CheckImplementedMethods(Statements_class);
/*2138*/ 	}
/*2138*/ 	{
/*2138*/ 		int m2runtime_for_limit_1;
/*2138*/ 		Statements_i = 0;
/*2138*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_class, 36, Statements_0err_entry_get, 451)) - 1);
/*2139*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*2139*/ 			Statements_m = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_class, 36, Statements_0err_entry_get, 452), Statements_i, Statements_0err_entry_get, 453);
/*2140*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m, 40, Statements_0err_entry_get, 454) ){
/*2141*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"missing method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 455), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"()' declared forward in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 456)), 1));
/*2145*/ 			}
/*2146*/ 		}
/*2146*/ 	}
/*2146*/ 	Globals_curr_class = NULL;
/*2150*/ }


/*2153*/ void
/*2153*/ Statements_ParseInterface(int Statements_private_class)
/*2153*/ {
/*2154*/ 	RECORD * Statements_if = NULL;
/*2154*/ 	RECORD * Statements_class2 = NULL;
/*2154*/ 	RECORD * Statements_class = NULL;
/*2155*/ 	int Statements_static = 0;
/*2156*/ 	RECORD * Statements_t = NULL;
/*2158*/ 	int Statements_i = 0;
/*2158*/ 	if( (Globals_scope > 0) ){
/*2159*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\171,\0,\0,\0)"class declaration inside a function. The namespace of the classes is still global so the function cannot be called twice.");
/*2161*/ 	}
/*2161*/ 	if( (Globals_php_ver == 4) ){
/*2162*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"invalid keyword `interface' (PHP 5)");
/*2165*/ 	}
/*2165*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 64, Statements_0err_entry_get, 457) = Statements_private_class;
/*2166*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 48, Statements_0err_entry_get, 458) = Scanner_here();
/*2167*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 76, Statements_0err_entry_get, 459) = TRUE;
/*2168*/ 	if( !Accounting_report_unused ){
/*2169*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 88, Statements_0err_entry_get, 460) = 100;
/*2175*/ 	}
/*2175*/ 	Scanner_ReadSym();
/*2176*/ 	Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected class name");
/*2177*/ 	Statements_class2 = Search_SearchClass(Scanner_s, FALSE);
/*2178*/ 	if( Statements_class2 != NULL ){
/*2179*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_class2, 48, Statements_0err_entry_get, 461)), 1));
/*2186*/ 	}
/*2186*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 8, Statements_0err_entry_get, 462) = Scanner_s;
/*2187*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 12, Statements_0err_entry_get, 463) = str_toupper(Scanner_s);
/*2188*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 24, Statements_0err_entry_get, 464) = (
/*2188*/ 		push((char*) alloc_RECORD(24, 2)),
/*2188*/ 		*(int*) (tos()+16) = 9,
/*2188*/ 		*(int*) (tos()+20) = 1,
/*2188*/ 		push((char*) NULL),
/*2188*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2188*/ 		push((char*) Statements_class),
/*2189*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2189*/ 		(RECORD*) pop()
/*2189*/ 	);
/*2189*/ 	*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_classes, 4, 1, Statements_0err_entry_get, 465) = Statements_class;
/*2190*/ 	Globals_curr_class = Statements_class;
/*2191*/ 	Scanner_ReadSym();
/*2196*/ 	if( (Scanner_sym == 94) ){
/*2197*/ 		Scanner_ReadSym();
/*2199*/ 		do{
/*2199*/ 			Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"expected interface class name");
/*2200*/ 			Statements_if = Search_SearchClass(Scanner_s, TRUE);
/*2201*/ 			if( Statements_if == NULL ){
/*2202*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"undeclared interface class `", Scanner_s, m2runtime_CHR(39), 1));
/*2203*/ 			} else if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 12, Statements_0err_entry_get, 466), (STRING *)m2runtime_dereference_rhs_RECORD(Statements_class, 12, Statements_0err_entry_get, 467)) == 0 ){
/*2204*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"interface cannot extend itself");
/*2205*/ 			} else if( ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_if, 76, Statements_0err_entry_get, 468) ){
/*2206*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"interface cannot extend non-interface class `", Scanner_s, m2runtime_CHR(39), 1));
/*2208*/ 			} else {
/*2208*/ 				Statements_i = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_class, 20, Statements_0err_entry_get, 469)) - 1);
/*2209*/ 				while( (((Statements_i >= 0)) && ((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_class, 20, Statements_0err_entry_get, 470), Statements_i, Statements_0err_entry_get, 471) != Statements_if)) ){
/*2210*/ 					m2_inc(&Statements_i, -1);
/*2212*/ 				}
/*2212*/ 				if( (Statements_i >= 0) ){
/*2213*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"duplicated extended interface `", Scanner_s, m2runtime_CHR(39), 1));
/*2215*/ 				} else {
/*2215*/ 					*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 20, Statements_0err_entry_get, 472), 4, 1, Statements_0err_entry_get, 473) = Statements_if;
/*2216*/ 					Accounting_AccountClass(Statements_if);
/*2217*/ 					if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 56, Statements_0err_entry_get, 474), EMPTY_STRING) > 0 ){
/*2218*/ 						Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"extending deprecated class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 8, Statements_0err_entry_get, 475), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 56, Statements_0err_entry_get, 476), 1));
/*2222*/ 					}
/*2223*/ 				}
/*2223*/ 			}
/*2223*/ 			Scanner_ReadSym();
/*2224*/ 			if( (Scanner_sym == 16) ){
/*2225*/ 				Scanner_ReadSym();
/*2228*/ 			} else {
/*2229*/ 				goto m2runtime_loop_1;
/*2230*/ 			}
/*2231*/ 		}while(TRUE);
m2runtime_loop_1: ;
/*2231*/ 	}
/*2231*/ 	Classes_CheckCollisionsBetweenExtendedAndImplementedClasses(Statements_class);
/*2233*/ 	if( (Scanner_sym == 170) ){
/*2234*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 52, Statements_0err_entry_get, 477) = Scanner_s;
/*2235*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 56, Statements_0err_entry_get, 478) = Documentator_ExtractDeprecated(Scanner_s);
/*2236*/ 		Scanner_ReadSym();
/*2237*/ 	} else if( Statements_pdb != NULL ){
/*2238*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 52, Statements_0err_entry_get, 479) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 480);
/*2239*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 56, Statements_0err_entry_get, 481) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 482));
/*2240*/ 		Statements_pdb = NULL;
/*2243*/ 	}
/*2243*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"expected '{' in class declaration");
/*2244*/ 	Scanner_ReadSym();
/*2247*/ 	do{
/*2247*/ 		if( (Scanner_sym == 11) ){
/*2248*/ 			Scanner_ReadSym();
/*2251*/ 			goto m2runtime_loop_2;
/*2252*/ 		}
/*2252*/ 		Statements_static = FALSE;
/*2254*/ 		Statements_pdb = NULL;
/*2255*/ 		if( (Scanner_sym == 171) ){
/*2256*/ 			Statements_pdb = ParseDocBlock_ParseDocBlock(Scanner_s);
/*2257*/ 			if( Statements_pdb != NULL ){
/*2258*/ 				if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 40, Statements_0err_entry_get, 483) ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 44, Statements_0err_entry_get, 484) ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 485)) ){
/*2259*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"in DocBlock: visibility attributes not allowed in interface");
/*2261*/ 				}
/*2261*/ 				if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 52, Statements_0err_entry_get, 486) ){
/*2262*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)"in DocBlock: final attribute not allowed in interface");
/*2264*/ 				}
/*2264*/ 				if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 56, Statements_0err_entry_get, 487) ){
/*2265*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\127,\0,\0,\0)"in DocBlock: static attribute not allowed, use proper language keyword `static' instead");
/*2268*/ 				}
/*2268*/ 			}
/*2268*/ 			Scanner_ReadSym();
/*2271*/ 		}
/*2271*/ 		if( (Scanner_sym == 96) ){
/*2272*/ 			Statements_ParseClassConstDecl(2);
/*2279*/ 		} else {
/*2279*/ 			Statements_static = FALSE;
/*2281*/ 			do{
/*2281*/ 				if( (Scanner_sym == 98) ){
/*2282*/ 					Scanner_ReadSym();
/*2283*/ 				} else if( (((Scanner_sym == 100)) || ((Scanner_sym == 99))) ){
/*2284*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\130,\0,\0,\0)"invalid visibility attribute for interface method. Abstract methods are always `public'.");
/*2285*/ 					Scanner_ReadSym();
/*2286*/ 				} else if( (Scanner_sym == 102) ){
/*2287*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"invalid `final' attribute for abstract method");
/*2288*/ 					Scanner_ReadSym();
/*2289*/ 				} else if( (Scanner_sym == 101) ){
/*2290*/ 					Statements_static = TRUE;
/*2291*/ 					Scanner_ReadSym();
/*2294*/ 				} else {
/*2295*/ 					goto m2runtime_loop_3;
/*2296*/ 				}
/*2300*/ 			}while(TRUE);
m2runtime_loop_3: ;
/*2300*/ 			if( Statements_pdb != NULL ){
/*2301*/ 				Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 488);
/*2303*/ 			} else {
/*2303*/ 				Statements_t = Expressions_ParseType(FALSE);
/*2306*/ 			}
/*2306*/ 			if( (Scanner_sym == 20) ){
/*2307*/ 				Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"properties cannot be defined in interfaces");
/*2310*/ 			}
/*2310*/ 			Scanner_Expect(8, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"expected `function' declaration in interface class");
/*2311*/ 			Statements_ParseClassMethodDecl(TRUE, 2, Statements_static, FALSE, Statements_t);
/*2315*/ 		}
/*2316*/ 	}while(TRUE);
m2runtime_loop_2: ;
/*2316*/ 	Globals_curr_class = NULL;
/*2320*/ }


/*2322*/ void
/*2322*/ Statements_ParseStatic(void)
/*2322*/ {
/*2323*/ 	RECORD * Statements_r = NULL;
/*2324*/ 	STRING * Statements_id = NULL;
/*2325*/ 	RECORD * Statements_v = NULL;
/*2327*/ 	RECORD * Statements_t = NULL;
/*2327*/ 	if( (Globals_scope == 0) ){
/*2328*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"static declaration at global scope has no effect");
/*2330*/ 	}
/*2330*/ 	Scanner_ReadSym();
/*2331*/ 	Statements_t = Expressions_ParseType(FALSE);
/*2334*/ 	do{
/*2334*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"expected variable name in static declaration");
/*2335*/ 		Statements_id = Scanner_s;
/*2338*/ 		Statements_v = Search_SearchVar(Statements_id, Globals_scope);
/*2339*/ 		if( ((Statements_v != NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_v, 40, Statements_0err_entry_get, 489) == Globals_scope))) ){
/*2340*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"`static $", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"': variable already exists", 1));
/*2342*/ 		}
/*2342*/ 		Statements_v = NULL;
/*2344*/ 		Accounting_AccountVarLHS(Statements_id, FALSE);
/*2345*/ 		Statements_v = Search_SearchVar(Statements_id, Globals_scope);
/*2347*/ 		if( Statements_t != NULL ){
/*2348*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 490) = Statements_t;
/*2351*/ 		}
/*2351*/ 		Scanner_ReadSym();
/*2352*/ 		if( (Scanner_sym == 31) ){
/*2353*/ 			Scanner_ReadSym();
/*2354*/ 			Statements_r = Expressions_ParseStaticExpr();
/*2355*/ 			if( Statements_r == NULL ){
/*2359*/ 			}
/*2359*/ 			if( Statements_r != NULL ){
/*2360*/ 				if( Statements_t == NULL ){
/*2361*/ 					Statements_v = Search_SearchVar(Statements_id, Globals_scope);
/*2362*/ 					*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 491) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 492);
/*2364*/ 				} else {
/*2364*/ 					switch(Expressions_LhsMatchRhs(Statements_t, (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 493))){

/*2365*/ 					case 1:
/*2366*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"the type of the expression ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 494)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)" does not match the ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"type of the variable `", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString(Statements_t), 1));
/*2370*/ 					break;

/*2370*/ 					case 2:
/*2371*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"the type of the expression ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 495)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)" does not match the ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"type of the variable `", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString(Statements_t), 1));
/*2376*/ 					break;
/*2378*/ 					}
/*2379*/ 				}
/*2379*/ 			}
/*2379*/ 		} else if( Statements_t == NULL ){
/*2380*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"undefined type for static variable `$", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"'. Undefined static variables take the initial value NULL.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)" Hint: either specify a type (example: /*.int.*/ $", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)") or an initial value (example: $", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"=123).", 1));
/*2385*/ 		}
/*2385*/ 		if( (Scanner_sym == 16) ){
/*2386*/ 			Scanner_ReadSym();
/*2387*/ 		} else if( (Scanner_sym == 17) ){
/*2390*/ 			goto m2runtime_loop_1;
/*2390*/ 		} else {
/*2390*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\70,\0,\0,\0)"expected `=' or `,' or `;' in static declaration, found ", Scanner_SymToName(Scanner_sym), 1));
/*2393*/ 		}
/*2394*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*2396*/ }


/*2397*/ void
/*2397*/ Statements_ParseIf(void)
/*2397*/ {
/*2397*/ 	RECORD * Statements_r = NULL;
/*2399*/ 	STRING * Statements_s = NULL;
/*2399*/ 	Statements_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"`if(EXPR)'";
/*2401*/ 	do {
/*2401*/ 		Scanner_ReadSym();
/*2402*/ 		Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"expected '(' after `if' or `elseif'");
/*2403*/ 		Scanner_ReadSym();
/*2404*/ 		Statements_r = Expressions_ParseExpr();
/*2405*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"expected closing ')' after 'if' condition");
/*2406*/ 		Expressions_CheckBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"`if(EXPR)'", Statements_r);
/*2407*/ 		Scanner_ReadSym();
/*2408*/ 		Statements_ParseBlock();
/*2409*/ 		Statements_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"`elseif(EXPR)'";
/*2410*/ 	} while( !( (Scanner_sym != 27) ));
/*2411*/ 	if( (Scanner_sym == 26) ){
/*2412*/ 		Scanner_ReadSym();
/*2413*/ 		Statements_ParseBlock();
/*2416*/ 	}
/*2418*/ }


/*2420*/ void
/*2420*/ Statements_ParseDefine(int Statements_private)
/*2420*/ {
/*2421*/ 	STRING * Statements_name = NULL;
/*2422*/ 	RECORD * Statements_r = NULL;
/*2423*/ 	RECORD * Statements_t = NULL;
/*2425*/ 	RECORD * Statements_c = NULL;
/*2426*/ 	Statements_DocBlockCheckAllowedLineTags(128, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"define()");
/*2428*/ 	if( (Globals_scope > 0) ){
/*2429*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\125,\0,\0,\0)"define() inside a function: the scope of the constants defined here however is global");
/*2431*/ 	}
/*2431*/ 	Scanner_ReadSym();
/*2432*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"missing '(' after 'define'");
/*2435*/ 	Scanner_ReadSym();
/*2436*/ 	Statements_r = Expressions_ParseExprOfType(Globals_string_type);
/*2437*/ 	if( Statements_r == NULL ){
/*2439*/ 	} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 496) == NULL ){
/*2440*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\126,\0,\0,\0)"unable to parse the name of the constant as a value statically determined, will ignore");
/*2442*/ 	} else {
/*2442*/ 		Statements_name = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 497);
/*2443*/ 		if( !m2_match(Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"^[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*$") ){
/*2444*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"invalid characters in constant name `", Statements_name, m2runtime_CHR(39), 1));
/*2445*/ 		} else if( (Scanner_SearchPhpKeyword(Statements_name) != 1) ){
/*2446*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"constant name `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"' is a keyword", 1));
/*2449*/ 		}
/*2450*/ 	}
/*2450*/ 	Scanner_Expect(16, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"expexted `,' in define()");
/*2451*/ 	Scanner_ReadSym();
/*2454*/ 	Statements_r = Expressions_ParseExpr();
/*2455*/ 	if( Statements_r == NULL ){
/*2458*/ 	} else {
/*2458*/ 		Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 498);
/*2459*/ 		if( !(((Statements_t == Globals_null_type) || (Statements_t == Globals_boolean_type) || (Statements_t == Globals_int_type) || (Statements_t == Globals_float_type) || (Statements_t == Globals_string_type))) ){
/*2460*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid constant value of type ", Types_TypeToString(Statements_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)". It must be boolean, int, float or string", 1));
/*2462*/ 		} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 499) == NULL ){
/*2463*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\110,\0,\0,\0)"can't parse the value of the constant as a statically determinable value");
/*2466*/ 		}
/*2467*/ 	}
/*2467*/ 	if( Statements_name != NULL ){
/*2468*/ 		Statements_c = Accounting_AccountConstLHS(Statements_name, Statements_private, Statements_r);
/*2471*/ 	}
/*2471*/ 	if( (Scanner_sym == 16) ){
/*2472*/ 		Scanner_ReadSym();
/*2473*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\113,\0,\0,\0)"will ignore third argument of define(): constants are always case-sensitive");
/*2474*/ 		Statements_r = Expressions_ParseExprOfType(Globals_boolean_type);
/*2477*/ 	}
/*2477*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"expected closing ')' in 'define'");
/*2478*/ 	Scanner_ReadSym();
/*2480*/ 	Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `;'");
/*2481*/ 	Scanner_ReadSym();
/*2483*/ 	if( (Scanner_sym == 170) ){
/*2484*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 24, Statements_0err_entry_get, 500) = Scanner_s;
/*2485*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 28, Statements_0err_entry_get, 501) = Documentator_ExtractDeprecated(Scanner_s);
/*2486*/ 		Scanner_ReadSym();
/*2487*/ 	} else if( Statements_pdb != NULL ){
/*2488*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 24, Statements_0err_entry_get, 502) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 503);
/*2489*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 28, Statements_0err_entry_get, 504) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 505));
/*2490*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 32, Statements_0err_entry_get, 506) = ((Statements_private ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 40, Statements_0err_entry_get, 507)));
/*2491*/ 		Statements_pdb = NULL;
/*2495*/ 	}
/*2497*/ }


/*2499*/ void
/*2499*/ Statements_ParseDeclare(void)
/*2499*/ {

/*2500*/ 	void
/*2500*/ 	Statements_ParseDirective(void)
/*2500*/ 	{
/*2502*/ 		RECORD * Statements_r = NULL;
/*2502*/ 		if( (Scanner_sym != 29) ){
/*2503*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected identifier");
/*2505*/ 		}
/*2505*/ 		if( m2runtime_strcmp(Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"ticks") != 0 ){
/*2506*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"unknown directive \042", Scanner_s, m2runtime_CHR(34), 1));
/*2508*/ 		}
/*2508*/ 		Scanner_ReadSym();
/*2510*/ 		Scanner_Expect(31, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `='");
/*2511*/ 		Scanner_ReadSym();
/*2513*/ 		Statements_r = Expressions_ParseStaticExpr();
/*2517*/ 	}

/*2517*/ 	Scanner_ReadSym();
/*2518*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `('");
/*2519*/ 	Scanner_ReadSym();
/*2521*/ 	do{
/*2521*/ 		Statements_ParseDirective();
/*2522*/ 		if( (Scanner_sym == 16) ){
/*2523*/ 			Scanner_ReadSym();
/*2526*/ 		} else {
/*2527*/ 			goto m2runtime_loop_1;
/*2528*/ 		}
/*2528*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*2528*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected `,' or `)'");
/*2529*/ 	Scanner_ReadSym();
/*2530*/ 	Statements_ParseBlock();
/*2534*/ }


/*2535*/ int
/*2535*/ Statements_readable(STRING *Statements_f)
/*2535*/ {
/*2537*/ 	void * Statements_fd = NULL;
/*2537*/ 	m2runtime_ERROR_CODE = 0;
/*2537*/ 	io_Open(1, (void *)&Statements_fd, Statements_f, m2runtime_CHR(114));
/*2538*/ 	switch( m2runtime_ERROR_CODE ){

/*2538*/ 	case 0:
/*2539*/ 		m2runtime_ERROR_CODE = 0;
/*2539*/ 		io_Close(1, (void *)&Statements_fd);
/*2540*/ 		switch( m2runtime_ERROR_CODE ){

/*2540*/ 		case 0:  break;
/*2540*/ 		default:
/*2540*/ 			m2runtime_HALT(Statements_0err_entry_get, 508, m2runtime_ERROR_MESSAGE);
/*2540*/ 		}
/*2540*/ 		return TRUE;
/*2542*/ 		break;

/*2542*/ 	default:
/*2542*/ 		return FALSE;
/*2545*/ 	}
/*2545*/ 	m2runtime_missing_return(Statements_0err_entry_get, 509);
/*2545*/ 	return 0;
/*2547*/ }


/*2552*/ void
/*2552*/ Statements_AddPackageToIncludePath(STRING *Statements_p)
/*2552*/ {
/*2554*/ 	int Statements_i = 0;
/*2554*/ 	{
/*2554*/ 		int m2runtime_for_limit_1;
/*2554*/ 		Statements_i = 0;
/*2554*/ 		m2runtime_for_limit_1 = (m2runtime_count(Statements_include_path) - 1);
/*2555*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*2555*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_ARRAY(Statements_include_path, Statements_i, Statements_0err_entry_get, 510), Statements_p) == 0 ){
/*2557*/ 				return ;
/*2559*/ 			}
/*2559*/ 		}
/*2559*/ 	}
/*2559*/ 	*(STRING **)m2runtime_dereference_lhs_ARRAY_next(&Statements_include_path, 4, 1, Statements_0err_entry_get, 511) = Statements_p;
/*2563*/ }


/*2569*/ STRING *
/*2569*/ Statements_SearchFileOnPaths(STRING *Statements_name, int Statements_module)
/*2569*/ {
/*2570*/ 	STRING * Statements_n = NULL;
/*2571*/ 	ARRAY * Statements_a = NULL;
/*2573*/ 	int Statements_i = 0;
/*2574*/ 	Statements_n = FileName_Absolute(NULL, Statements_name);
/*2575*/ 	if( Statements_readable(Statements_n) ){
/*2576*/ 		return Statements_n;
/*2579*/ 	}
/*2579*/ 	if( ((m2runtime_strcmp(Statements_name, EMPTY_STRING) > 0) && (m2runtime_strcmp(m2runtime_substr(Statements_name, 0, 0, 0, Statements_0err_entry_get, 512), m2runtime_CHR(47)) != 0)) ){
/*2580*/ 		if( Statements_module ){
/*2581*/ 			Statements_a = Statements_modules_abs_path;
/*2583*/ 		} else {
/*2583*/ 			Statements_a = Statements_packages_abs_path;
/*2585*/ 		}
/*2585*/ 		{
/*2585*/ 			int m2runtime_for_limit_1;
/*2585*/ 			Statements_i = 0;
/*2585*/ 			m2runtime_for_limit_1 = (m2runtime_count(Statements_a) - 1);
/*2586*/ 			for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*2586*/ 				Statements_n = FileName_Absolute(NULL, m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_ARRAY(Statements_a, Statements_i, Statements_0err_entry_get, 513), m2runtime_CHR(47), Statements_name, 1));
/*2587*/ 				if( Statements_readable(Statements_n) ){
/*2588*/ 					if( !Statements_module ){
/*2589*/ 						Statements_AddPackageToIncludePath(FileName_Basename(Statements_name));
/*2591*/ 					}
/*2591*/ 					return Statements_n;
/*2594*/ 				}
/*2595*/ 			}
/*2595*/ 		}
/*2596*/ 	}
/*2596*/ 	if( Statements_module ){
/*2597*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"module `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"' not found", 1));
/*2599*/ 	} else {
/*2599*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"package `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"' not found", 1));
/*2602*/ 	}
/*2602*/ 	return NULL;
/*2607*/ }


/*2613*/ void
/*2613*/ Statements_RequirePackage(STRING *Statements_pathfile, int Statements_module)
/*2613*/ {
/*2614*/ 	STRING * Statements_abs_pathfile = NULL;
/*2615*/ 	void * Statements_sc = NULL;
/*2616*/ 	int Statements_s_print_notices = 0;
/*2616*/ 	int Statements_s_print_source = 0;
/*2616*/ 	int Statements_s_report_unused = 0;
/*2617*/ 	RECORD * Statements_s_curr_package = NULL;
/*2619*/ 	STRING * Statements_s = NULL;
/*2619*/ 	Statements_abs_pathfile = Statements_SearchFileOnPaths(Statements_pathfile, Statements_module);
/*2620*/ 	if( Statements_abs_pathfile == NULL ){
/*2622*/ 		return ;
/*2625*/ 	}
/*2625*/ 	Statements_sc = Scanner_Suspend();
/*2626*/ 	Statements_s_report_unused = Accounting_report_unused;
/*2627*/ 	Accounting_report_unused = FALSE;
/*2628*/ 	Statements_s_print_source = Scanner_print_source;
/*2629*/ 	Scanner_print_source = FALSE;
/*2630*/ 	Statements_s_print_notices = Scanner_print_notices;
/*2631*/ 	Scanner_print_notices = FALSE;
/*2632*/ 	Statements_s_curr_package = Statements_curr_package;
/*2633*/ 	Statements_pdb = NULL;
	Statements_curr_package = Statements_ParsePackage(Statements_abs_pathfile, Statements_module);
/*2638*/ 	Accounting_report_unused = Statements_s_report_unused;
/*2639*/ 	Scanner_print_source = Statements_s_print_source;
/*2640*/ 	Scanner_print_notices = Statements_s_print_notices;
/*2641*/ 	Scanner_Resume(Statements_sc);
/*2643*/ 	if( ((Statements_curr_package != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_curr_package, 16, Statements_0err_entry_get, 514), EMPTY_STRING) > 0)) ){
/*2644*/ 		if( Statements_module ){
/*2645*/ 			Statements_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"module";
/*2647*/ 		} else {
/*2647*/ 			Statements_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"package";
/*2649*/ 		}
/*2649*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"using deprecated ", Statements_s, m2runtime_CHR(32), Statements_abs_pathfile, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_curr_package, 16, Statements_0err_entry_get, 515), 1));
/*2653*/ 	}
/*2653*/ 	Statements_curr_package = Statements_s_curr_package;
/*2657*/ }


/*2659*/ void
/*2659*/ Statements_ParseRequireModule(void)
/*2659*/ {
/*2659*/ 	if( (Globals_scope > 0) ){
/*2660*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"found `require_module' in scope level > 0");
/*2662*/ 	}
/*2662*/ 	Scanner_ReadSym();
/*2663*/ 	Scanner_Expect(128, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"expected single quoted string after `require_module'");
/*2664*/ 	if( !m2_match(Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"^[a-zA-Z0-9_]+$") ){
/*2665*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"require_module '", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"': invalid module name", 1));
/*2667*/ 	} else {
/*2667*/ 		Statements_RequirePackage(Scanner_s, TRUE);
/*2669*/ 	}
/*2669*/ 	Scanner_ReadSym();
/*2670*/ 	Scanner_Expect(129, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"missing `;'");
/*2671*/ 	Scanner_ReadSym();
/*2675*/ }


/*2677*/ void
/*2677*/ Statements_ParseRequireOnce(void)
/*2677*/ {
/*2678*/ 	RECORD * Statements_r = NULL;
/*2680*/ 	STRING * Statements_f = NULL;
/*2680*/ 	if( (Globals_scope > 0) ){
/*2681*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"found `require_once' in scope level > 0");
/*2683*/ 	}
/*2683*/ 	Scanner_ReadSym();
/*2685*/ 	Statements_r = Expressions_ParseExprOfType(Globals_string_type);
/*2686*/ 	if( Statements_r == NULL ){
/*2688*/ 		return ;
/*2688*/ 	} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 516) == NULL ){
/*2689*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\67,\0,\0,\0)"require_once: can't check file name, value undetermined");
/*2691*/ 		return ;
/*2691*/ 	} else if( (m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 517)) == 0) ){
/*2692*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"require_once: empty file name");
/*2694*/ 		return ;
/*2695*/ 	}
/*2695*/ 	Statements_f = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 518);
/*2697*/ 	if( !Statements_recursive_parsing ){
/*2698*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"require_once '", Statements_f, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"': recursive inclusion disabled", 1));
/*2700*/ 		return ;
/*2702*/ 	}
/*2702*/ 	Statements_RequirePackage(Statements_f, FALSE);
/*2706*/ }


/*2707*/ void
/*2707*/ Statements_ParseInclude(STRING *Statements_n)
/*2707*/ {
/*2709*/ 	RECORD * Statements_r = NULL;
/*2709*/ 	Scanner_ReadSym();
/*2710*/ 	Statements_r = Expressions_ParseExprOfType(Globals_string_type);
/*2711*/ 	if( Statements_r == NULL ){
/*2713*/ 	} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 519) == NULL ){
/*2714*/ 		Scanner_Warning(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)": can't check file name, value undetermined", 1));
/*2715*/ 	} else if( (m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 520)) == 0) ){
/*2716*/ 		Scanner_Error(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)": empty file name", 1));
/*2717*/ 	} else if( m2runtime_strcmp(m2runtime_substr((STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 521), 0, 0, 0, Statements_0err_entry_get, 522), m2runtime_CHR(47)) != 0 ){
/*2718*/ 		Scanner_Warning(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" \042", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 523), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)"\042 uses relative pathfile, check `include_path' in php.ini", 1));
/*2721*/ 	} else {
/*2721*/ 		Scanner_Notice(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" \042", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 524), m2runtime_CHR(34), 1));
/*2724*/ 	}
/*2726*/ }


/*2728*/ void
/*2728*/ Statements_ParseThrow(void)
/*2728*/ {
/*2729*/ 	RECORD * Statements_r = NULL;
/*2731*/ 	RECORD * Statements_t = NULL;
/*2731*/ 	Scanner_ReadSym();
/*2732*/ 	Statements_r = Expressions_ParseExpr();
/*2733*/ 	if( Statements_r == NULL ){
/*2736*/ 		return ;
/*2737*/ 	}
/*2737*/ 	Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 525);
/*2738*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_t, 16, Statements_0err_entry_get, 526) == 9) ){
/*2739*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 527) == NULL ){
/*2740*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"the object isn't an extension of the Exception class");
/*2741*/ 		} else if( Exceptions_IsExceptionClass((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 528)) ){
/*2742*/ 			Exceptions_AddException((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 529));
/*2744*/ 		} else {
/*2744*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the class `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 530), 8, Statements_0err_entry_get, 531), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"' isn't an extension of the `Exception' class", 1));
/*2748*/ 		}
/*2748*/ 	} else {
/*2748*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"expected an object, found ", Types_TypeToString(Statements_t), 1));
/*2751*/ 	}
/*2753*/ }


/*2755*/ void
/*2755*/ Statements_ParseTry(void)
/*2755*/ {
/*2756*/ 	RECORD * Statements_try_location = NULL;
/*2757*/ 	RECORD * Statements_class = NULL;
/*2758*/ 	RECORD * Statements_v = NULL;
/*2761*/ 	ARRAY * Statements_exceptions = NULL;
/*2761*/ 	ARRAY * Statements_saved_exceptions = NULL;
/*2761*/ 	Statements_try_location = Scanner_here();
/*2762*/ 	Scanner_ReadSym();
/*2763*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"expected `{' after try");
/*2766*/ 	m2_inc(&Exceptions_try_block_nesting_level, 1);
/*2767*/ 	Statements_saved_exceptions = Exceptions_exceptions;
/*2768*/ 	Exceptions_exceptions = NULL;
/*2770*/ 	Statements_ParseBlock();
/*2773*/ 	m2_inc(&Exceptions_try_block_nesting_level, -1);
/*2774*/ 	Statements_exceptions = Exceptions_exceptions;
/*2775*/ 	Exceptions_exceptions = Statements_saved_exceptions;
/*2776*/ 	if( Statements_exceptions == NULL ){
/*2777*/ 		Scanner_Notice2(Statements_try_location, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"no exception at all thrown inside this try{} block");
/*2782*/ 	}
/*2782*/ 	Scanner_Expect(119, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"expected `catch'");
/*2784*/ 	do {
/*2784*/ 		Scanner_ReadSym();
/*2786*/ 		Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"expected `(' after `catch'");
/*2787*/ 		Scanner_ReadSym();
/*2789*/ 		Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"expected exception class name");
/*2790*/ 		Statements_class = Search_SearchClass(Scanner_s, TRUE);
/*2791*/ 		if( Statements_class == NULL ){
/*2792*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"undefined class `", Scanner_s, m2runtime_CHR(39), 1));
/*2793*/ 		} else if( Exceptions_IsExceptionClass(Statements_class) ){
/*2794*/ 			if( !Exceptions_RemoveExceptionFromSet(Statements_class, &Statements_exceptions) ){
/*2795*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"exception `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"' not thrown or already caught", 1));
/*2798*/ 			}
/*2798*/ 		} else {
/*2798*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"' isn't an extension of the `Exception' class", 1));
/*2800*/ 		}
/*2800*/ 		Scanner_ReadSym();
/*2802*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"expected variable name");
/*2803*/ 		Accounting_AccountVarLHS(Scanner_s, FALSE);
/*2804*/ 		if( Statements_class != NULL ){
/*2805*/ 			Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*2806*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 532) = (
/*2806*/ 				push((char*) alloc_RECORD(24, 2)),
/*2806*/ 				*(int*) (tos()+16) = 9,
/*2806*/ 				*(int*) (tos()+20) = 1,
/*2806*/ 				push((char*) NULL),
/*2806*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2806*/ 				push((char*) Statements_class),
/*2807*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2808*/ 				(RECORD*) pop()
/*2808*/ 			);
/*2808*/ 		}
/*2808*/ 		Scanner_ReadSym();
/*2810*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `)'");
/*2811*/ 		Scanner_ReadSym();
/*2813*/ 		Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `{'");
/*2814*/ 		Statements_ParseBlock();
/*2815*/ 	} while( !( (Scanner_sym != 119) ));
/*2818*/ 	Exceptions_ThrowExceptions(Statements_exceptions);
/*2822*/ }


/*2824*/ void
/*2824*/ Statements_ParseEchoBlock(void)
/*2824*/ {
/*2824*/ 	RECORD * Statements_r = NULL;
/*2826*/ 	RECORD * Statements_t = NULL;
/*2826*/ 	Scanner_ReadSym();
/*2828*/ 	do{
/*2828*/ 		Statements_r = Expressions_ParseExpr();
/*2829*/ 		if( Statements_r == NULL ){
/*2832*/ 		} else {
/*2832*/ 			Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 533);
/*2833*/ 			if( !(((Statements_t == Globals_int_type) || (Statements_t == Globals_float_type) || (Statements_t == Globals_string_type))) ){
/*2835*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"found ", Types_TypeToString(Statements_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)". The arguments of the `<?= ... ?>' block must be of", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" type int, float or string.", 1));
/*2840*/ 			}
/*2840*/ 		}
/*2840*/ 		if( (Scanner_sym == 16) ){
/*2841*/ 			Scanner_ReadSym();
/*2842*/ 		} else if( (Scanner_sym == 6) ){
/*2843*/ 			Scanner_ReadSym();
/*2845*/ 			return ;
/*2845*/ 		} else if( (Scanner_sym == 0) ){
/*2846*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"missing `?>'");
/*2848*/ 			return ;
/*2848*/ 		} else if( (Scanner_sym == 17) ){
/*2849*/ 			Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"unuseful `;' symbol");
/*2850*/ 			Scanner_ReadSym();
/*2851*/ 			Scanner_Expect(6, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"missing closing tag");
/*2852*/ 			Scanner_ReadSym();
/*2854*/ 			return ;
/*2855*/ 		} else {
/*2855*/ 			Scanner_UnexpectedSymbol();
/*2858*/ 		}
/*2859*/ 	}while(TRUE);
/*2861*/ }


/*2864*/ void
/*2864*/ Statements_ParseTextBlock(void)
/*2864*/ {
/*2864*/ 	Scanner_ReadSym();
/*2866*/ 	do{
/*2866*/ 		if( (Scanner_sym == 3) ){
/*2867*/ 			Scanner_ReadSym();
/*2868*/ 		} else if( (Scanner_sym == 5) ){
/*2869*/ 			Statements_ParseEchoBlock();
/*2870*/ 		} else if( (Scanner_sym == 4) ){
/*2871*/ 			Scanner_ReadSym();
/*2873*/ 			return ;
/*2874*/ 		} else {
/*2874*/ 			Scanner_UnexpectedSymbol();
/*2877*/ 		}
/*2878*/ 	}while(TRUE);
/*2880*/ }


/*2883*/ void
/*2883*/ Statements_ParseCodeBlock(void)
/*2883*/ {
/*2883*/ 	Scanner_ReadSym();
/*2885*/ 	do{
/*2885*/ 		if( (Scanner_sym == 6) ){
/*2886*/ 			Scanner_ReadSym();
/*2888*/ 			return ;
/*2888*/ 		} else if( (Scanner_sym == 0) ){
/*2889*/ 			Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"missing `?>'");
/*2891*/ 			return ;
/*2892*/ 		} else {
/*2892*/ 			Statements_ParseStatement();
/*2895*/ 		}
/*2896*/ 	}while(TRUE);
/*2898*/ }


/*2901*/ void
/*2901*/ Statements_ParserInit(void)
/*2901*/ {
/*2902*/ 	static int Statements_parser_init = 0;
/*2903*/ 	static RECORD * Statements_here = NULL;
/*2905*/ 	static RECORD * Statements_ass = NULL;
/*2905*/ 	static RECORD * Statements_asm = NULL;

/*2906*/ 	void
/*2906*/ 	Statements_add(STRING *Statements_s, RECORD *Statements_t)
/*2906*/ 	{
/*2908*/ 		RECORD * Statements_v = NULL;
/*2908*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 8, Statements_0err_entry_get, 534) = Statements_s;
/*2909*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 12, Statements_0err_entry_get, 535) = Statements_here;
/*2910*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 40, Statements_0err_entry_get, 536) = -1;
/*2911*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 44, Statements_0err_entry_get, 537) = TRUE;
/*2912*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 16, Statements_0err_entry_get, 538) = Statements_here;
/*2913*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 48, Statements_0err_entry_get, 539) = 100;
/*2914*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 540) = Statements_t;
/*2915*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Globals_vars, 4, 1, Globals_vars_n, Statements_0err_entry_get, 541) = Statements_v;
/*2916*/ 		m2_inc(&Globals_vars_n, 1);
/*2920*/ 	}

/*2920*/ 	if( Statements_parser_init ){
/*2922*/ 		return ;
/*2923*/ 	}
/*2923*/ 	Statements_parser_init = TRUE;
/*2925*/ 	Scanner_InitScanner();
/*2932*/ 	Globals_null_type = (
/*2932*/ 		push((char*) alloc_RECORD(24, 2)),
/*2932*/ 		*(int*) (tos()+16) = 0,
/*2932*/ 		*(int*) (tos()+20) = 1,
/*2932*/ 		push((char*) NULL),
/*2932*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2932*/ 		push((char*) NULL),
/*2933*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2933*/ 		(RECORD*) pop()
/*2933*/ 	);
/*2933*/ 	Globals_void_type = (
/*2933*/ 		push((char*) alloc_RECORD(24, 2)),
/*2933*/ 		*(int*) (tos()+16) = 1,
/*2933*/ 		*(int*) (tos()+20) = 1,
/*2933*/ 		push((char*) NULL),
/*2933*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2933*/ 		push((char*) NULL),
/*2934*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2934*/ 		(RECORD*) pop()
/*2934*/ 	);
/*2934*/ 	Globals_boolean_type = (
/*2934*/ 		push((char*) alloc_RECORD(24, 2)),
/*2934*/ 		*(int*) (tos()+16) = 2,
/*2934*/ 		*(int*) (tos()+20) = 1,
/*2934*/ 		push((char*) NULL),
/*2934*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2934*/ 		push((char*) NULL),
/*2935*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2935*/ 		(RECORD*) pop()
/*2935*/ 	);
/*2935*/ 	Globals_int_type = (
/*2935*/ 		push((char*) alloc_RECORD(24, 2)),
/*2935*/ 		*(int*) (tos()+16) = 3,
/*2935*/ 		*(int*) (tos()+20) = 1,
/*2935*/ 		push((char*) NULL),
/*2935*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2935*/ 		push((char*) NULL),
/*2936*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2936*/ 		(RECORD*) pop()
/*2936*/ 	);
/*2936*/ 	Globals_float_type = (
/*2936*/ 		push((char*) alloc_RECORD(24, 2)),
/*2936*/ 		*(int*) (tos()+16) = 4,
/*2936*/ 		*(int*) (tos()+20) = 1,
/*2936*/ 		push((char*) NULL),
/*2936*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2936*/ 		push((char*) NULL),
/*2937*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2937*/ 		(RECORD*) pop()
/*2937*/ 	);
/*2937*/ 	Globals_string_type = (
/*2937*/ 		push((char*) alloc_RECORD(24, 2)),
/*2937*/ 		*(int*) (tos()+16) = 5,
/*2937*/ 		*(int*) (tos()+20) = 1,
/*2937*/ 		push((char*) NULL),
/*2937*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2937*/ 		push((char*) NULL),
/*2938*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2938*/ 		(RECORD*) pop()
/*2938*/ 	);
/*2938*/ 	Globals_mixed_type = (
/*2938*/ 		push((char*) alloc_RECORD(24, 2)),
/*2938*/ 		*(int*) (tos()+16) = 7,
/*2938*/ 		*(int*) (tos()+20) = 1,
/*2938*/ 		push((char*) NULL),
/*2938*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2938*/ 		push((char*) NULL),
/*2939*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2939*/ 		(RECORD*) pop()
/*2939*/ 	);
/*2939*/ 	Globals_resource_type = (
/*2939*/ 		push((char*) alloc_RECORD(24, 2)),
/*2939*/ 		*(int*) (tos()+16) = 8,
/*2939*/ 		*(int*) (tos()+20) = 1,
/*2939*/ 		push((char*) NULL),
/*2939*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2939*/ 		push((char*) NULL),
/*2940*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2944*/ 		(RECORD*) pop()
/*2944*/ 	);
/*2944*/ 	Statements_here = (
/*2944*/ 		push((char*) alloc_RECORD(16, 1)),
/*2944*/ 		push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"standard"),
/*2944*/ 		*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*2944*/ 		*(int*) (tos()+12) = 0,
/*2945*/ 		(RECORD*) pop()
/*2945*/ 	);
/*2945*/ 	Statements_asm = (
/*2945*/ 		push((char*) alloc_RECORD(24, 2)),
/*2945*/ 		*(int*) (tos()+16) = 6,
/*2945*/ 		*(int*) (tos()+20) = 5,
/*2945*/ 		push((char*) Globals_mixed_type),
/*2945*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2945*/ 		push((char*) NULL),
/*2946*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2946*/ 		(RECORD*) pop()
/*2946*/ 	);
/*2946*/ 	Statements_ass = (
/*2946*/ 		push((char*) alloc_RECORD(24, 2)),
/*2946*/ 		*(int*) (tos()+16) = 6,
/*2946*/ 		*(int*) (tos()+20) = 5,
/*2946*/ 		push((char*) Globals_string_type),
/*2946*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2946*/ 		push((char*) NULL),
/*2947*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2947*/ 		(RECORD*) pop()
/*2947*/ 	);
/*2947*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"GLOBALS", Statements_asm);
/*2948*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"_SERVER", Statements_ass);
/*2949*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"_GET", Statements_asm);
/*2950*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"_POST", Statements_asm);
/*2951*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"_COOKIE", Statements_asm);
/*2952*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"_REQUEST", Statements_asm);
/*2953*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"_FILES", (
/*2953*/ 		push((char*) alloc_RECORD(24, 2)),
/*2953*/ 		*(int*) (tos()+16) = 6,
/*2953*/ 		*(int*) (tos()+20) = 5,
/*2953*/ 		push((char*) Statements_asm),
/*2953*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2953*/ 		push((char*) NULL),
/*2953*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2954*/ 		(RECORD*) pop()
/*2954*/ 	));
/*2954*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"_ENV", Statements_ass);
/*2955*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"_SESSION", Statements_asm);
/*2957*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"php_errormsg", Globals_string_type);
/*2964*/ }


/*2966*/ RECORD *
/*2966*/ Statements_ParsePackage(STRING *Statements_abs_pathfile, int Statements_module)
/*2966*/ {
/*2967*/ 	STRING * Statements_saved_cwd = NULL;
/*2968*/ 	int Statements_code_found = 0;
/*2969*/ 	int Statements_i = 0;
/*2970*/ 	RECORD * Statements_f = NULL;
/*2972*/ 	RECORD * Statements_c = NULL;
/*2972*/ 	{
/*2972*/ 		int m2runtime_for_limit_1;
/*2972*/ 		Statements_i = 0;
/*2972*/ 		m2runtime_for_limit_1 = (m2runtime_count(Globals_required_packages) - 1);
/*2973*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*2973*/ 			if( m2runtime_strcmp(Statements_abs_pathfile, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_required_packages, Statements_i, Statements_0err_entry_get, 542), 8, Statements_0err_entry_get, 543)) == 0 ){
/*2974*/ 				return (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_required_packages, Statements_i, Statements_0err_entry_get, 544);
/*2977*/ 			}
/*2978*/ 		}
/*2978*/ 	}
/*2978*/ 	if( !Statements_readable(Statements_abs_pathfile) ){
/*2979*/ 		Scanner_Error2(NULL, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"can't read `", Scanner_fmt_fn(Statements_abs_pathfile), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", m2runtime_ERROR_MESSAGE, 1));
/*2981*/ 		return NULL;
/*2984*/ 	}
/*2984*/ 	m2runtime_ERROR_CODE = 0;
/*2984*/ 	Statements_saved_cwd = io_GetCWD(1);
/*2985*/ 	switch( m2runtime_ERROR_CODE ){

/*2985*/ 	case 0:  break;
/*2985*/ 	default:
/*2985*/ 		m2runtime_HALT(Statements_0err_entry_get, 545, m2runtime_ERROR_MESSAGE);
/*2985*/ 	}
/*2985*/ 	m2runtime_ERROR_CODE = 0;
/*2985*/ 	io_ChDir(1, FileName_Dirname(Statements_abs_pathfile));
/*2987*/ 	switch( m2runtime_ERROR_CODE ){

/*2987*/ 	case 0:  break;
/*2987*/ 	default:
/*2987*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"can't move to the dir. of ", Statements_abs_pathfile, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", m2runtime_ERROR_MESSAGE, 1));
/*2989*/ 		return NULL;
/*2991*/ 	}
/*2991*/ 	if( !Scanner_Open(Statements_abs_pathfile) ){
/*2992*/ 		m2runtime_ERROR_CODE = 0;
/*2992*/ 		io_ChDir(1, Statements_saved_cwd);
/*2993*/ 		switch( m2runtime_ERROR_CODE ){

/*2993*/ 		case 0:  break;
/*2993*/ 		default:
/*2993*/ 			m2runtime_HALT(Statements_0err_entry_get, 546, m2runtime_ERROR_MESSAGE);
/*2993*/ 		}
/*2993*/ 		return NULL;
/*2996*/ 	}
/*2996*/ 	Statements_ParserInit();
/*2998*/ 	Statements_curr_package = NULL;
/*2999*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 8, Statements_0err_entry_get, 547) = Statements_abs_pathfile;
/*3000*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 20, Statements_0err_entry_get, 548) = Statements_module;
/*3001*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 24, Statements_0err_entry_get, 549) = 0;
/*3002*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 12, Statements_0err_entry_get, 550) = NULL;
/*3003*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 16, Statements_0err_entry_get, 551) = NULL;
/*3005*/ 	*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_required_packages, 4, 1, Statements_0err_entry_get, 552) = Statements_curr_package;
/*3007*/ 	while( (Scanner_sym != 0) ){
/*3008*/ 		if( (Scanner_sym == 4) ){
/*3009*/ 			Statements_code_found = TRUE;
/*3010*/ 			Statements_ParseCodeBlock();
/*3011*/ 		} else if( (Scanner_sym == 5) ){
/*3012*/ 			Statements_code_found = TRUE;
/*3013*/ 			Statements_ParseEchoBlock();
/*3014*/ 		} else if( (Scanner_sym == 3) ){
/*3015*/ 			Scanner_ReadSym();
/*3017*/ 		} else {
/*3017*/ 			Scanner_UnexpectedSymbol();
/*3020*/ 		}
/*3020*/ 	}
/*3020*/ 	if( !Statements_code_found ){
/*3021*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"no PHP code found at all");
/*3028*/ 	}
/*3028*/ 	{
/*3028*/ 		int m2runtime_for_limit_1;
/*3028*/ 		Statements_i = 0;
/*3028*/ 		m2runtime_for_limit_1 = (m2runtime_count(Globals_funcs) - 1);
/*3029*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*3029*/ 			Statements_f = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_funcs, Statements_i, Statements_0err_entry_get, 553);
/*3030*/ 			if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 44, Statements_0err_entry_get, 554) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 555), 8, Statements_0err_entry_get, 556), Statements_abs_pathfile) == 0)) ){
/*3031*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"missing function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 557), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"()' declared forward in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 558)), 1));
/*3035*/ 			}
/*3040*/ 		}
/*3040*/ 	}
/*3040*/ 	{
/*3040*/ 		int m2runtime_for_limit_1;
/*3040*/ 		Statements_i = 0;
/*3040*/ 		m2runtime_for_limit_1 = (m2runtime_count(Globals_classes) - 1);
/*3041*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*3041*/ 			Statements_c = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_classes, Statements_i, Statements_0err_entry_get, 559);
/*3042*/ 			if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_c, 60, Statements_0err_entry_get, 560) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 48, Statements_0err_entry_get, 561), 8, Statements_0err_entry_get, 562), Statements_abs_pathfile) == 0)) ){
/*3043*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"missing class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_c, 8, Statements_0err_entry_get, 563), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' declared forward in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 48, Statements_0err_entry_get, 564)), 1));
/*3047*/ 			}
/*3048*/ 		}
/*3048*/ 	}
/*3048*/ 	Scanner_Close();
/*3049*/ 	m2runtime_ERROR_CODE = 0;
/*3049*/ 	io_ChDir(1, Statements_saved_cwd);
/*3050*/ 	switch( m2runtime_ERROR_CODE ){

/*3050*/ 	case 0:  break;
/*3050*/ 	default:
/*3050*/ 		m2runtime_HALT(Statements_0err_entry_get, 565, m2runtime_ERROR_MESSAGE);
/*3051*/ 	}
/*3051*/ 	return Statements_curr_package;
/*3055*/ }

/*3058*/ int Statements_skip_else_php_ver = 0;

/*3064*/ int
/*3064*/ Statements_ParseSimpleStatement(void)
/*3064*/ {

/*3081*/ 	void
/*3081*/ 	Statements_ParseSimpleStatementBeginningWithVar(int Statements_private, RECORD *Statements_t)
/*3081*/ 	{
/*3082*/ 		RECORD * Statements_v = NULL;
/*3083*/ 		RECORD * Statements_r = NULL;
/*3085*/ 		STRING * Statements_vn = NULL;
/*3086*/ 		if( (((Statements_private || (Statements_t != NULL) || (Statements_pdb != NULL))) && (m2runtime_strcmp(Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"GLOBALS") == 0)) ){
/*3090*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\260,\0,\0,\0)"difining private attribute or type for $GLOBALS[] variables not supported (PHPLint limitation). Global variables can be declared in global scope in usual way `$varName = EXPR'.");
/*3093*/ 		}
/*3093*/ 		if( Statements_pdb != NULL ){
/*3094*/ 			Statements_DocBlockCheckAllowedLineTags((1024 | 128), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"variable");
/*3095*/ 			Statements_private = (Statements_private ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 40, Statements_0err_entry_get, 566));
/*3097*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 567) != NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 568), 16, Statements_0err_entry_get, 569) != 6))) ){
/*3099*/ 				Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 12, Statements_0err_entry_get, 570);
/*3102*/ 			}
/*3102*/ 			if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 16, Statements_0err_entry_get, 571) != NULL ){
/*3103*/ 				if( m2runtime_strcmp(Scanner_s, (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 16, Statements_0err_entry_get, 572)) != 0 ){
/*3104*/ 					Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"the name of the assigned variable `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"' does not match `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 16, Statements_0err_entry_get, 573), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"' as indicated in @global", 1));
/*3108*/ 				}
/*3108*/ 				if( Statements_t == NULL ){
/*3109*/ 					Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 12, Statements_0err_entry_get, 574);
/*3111*/ 				}
/*3111*/ 				if( (Globals_scope > 0) ){
/*3112*/ 					Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"@global line in inner scope level, must be at global scope");
/*3115*/ 				}
/*3117*/ 			}
/*3122*/ 		}
/*3122*/ 		if( (Statements_private || (Statements_t != NULL)) ){
/*3123*/ 			Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*3124*/ 			if( Statements_v == NULL ){
/*3125*/ 				Accounting_AccountVarLHS(Scanner_s, Statements_private);
/*3126*/ 				Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*3127*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 575) = Statements_t;
/*3128*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 36, Statements_0err_entry_get, 576) = Statements_private;
/*3131*/ 			}
/*3132*/ 		}
/*3132*/ 		Statements_vn = Scanner_s;
/*3133*/ 		Statements_r = Expressions_ParseExpr();
/*3134*/ 		Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `;'");
/*3135*/ 		Scanner_ReadSym();
/*3140*/ 		if( (((Scanner_sym == 170)) || (Statements_pdb != NULL)) ){
/*3141*/ 			if( Statements_v == NULL ){
/*3142*/ 				Statements_v = Search_SearchVar(Statements_vn, Globals_scope);
/*3144*/ 			}
/*3144*/ 			if( Statements_v == NULL ){
/*3145*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"can't apply documentation to unknown variable `$", Statements_vn, m2runtime_CHR(39), 1));
/*3148*/ 			} else if( (Scanner_sym == 170) ){
/*3149*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 28, Statements_0err_entry_get, 577) = Scanner_s;
/*3150*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 32, Statements_0err_entry_get, 578) = Documentator_ExtractDeprecated(Scanner_s);
/*3151*/ 				Scanner_ReadSym();
/*3153*/ 			} else if( Statements_pdb != NULL ){
/*3154*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 28, Statements_0err_entry_get, 579) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 580);
/*3155*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 32, Statements_0err_entry_get, 581) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 582));
/*3157*/ 			}
/*3157*/ 			Statements_pdb = NULL;
/*3161*/ 		}
/*3164*/ 	}

/*3165*/ 	int Statements_private = 0;
/*3166*/ 	RECORD * Statements_r = NULL;
/*3169*/ 	RECORD * Statements_t = NULL;
/*3170*/ 	switch(Scanner_sym){

/*3172*/ 	case 127:
/*3173*/ 	Statements_ParseRequireModule();
/*3174*/ 	return FALSE;
/*3176*/ 	break;

/*3176*/ 	case 126:
/*3177*/ 	Statements_ParseRequireOnce();
/*3178*/ 	return TRUE;
/*3180*/ 	break;

/*3180*/ 	case 125:
/*3181*/ 	if( (Globals_scope > 0) ){
/*3182*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"`require' inside a function. Suggest `require_once' instead");
/*3184*/ 	}
/*3184*/ 	Statements_ParseInclude((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"require");
/*3185*/ 	return TRUE;
/*3187*/ 	break;

/*3187*/ 	case 123:
/*3188*/ 	if( (Globals_scope > 0) ){
/*3189*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"include() inside a function. Suggest include_once() instead");
/*3191*/ 	}
/*3191*/ 	Statements_ParseInclude((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"include");
/*3192*/ 	return TRUE;
/*3194*/ 	break;

/*3194*/ 	case 124:
/*3195*/ 	Statements_ParseInclude((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"include_once");
/*3196*/ 	return TRUE;
/*3198*/ 	break;

/*3198*/ 	case 170:
/*3199*/ 	if( (Globals_scope > 0) ){
/*3200*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid scope for documentation");
/*3202*/ 	}
/*3202*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 12, Statements_0err_entry_get, 583) = Scanner_s;
/*3203*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 16, Statements_0err_entry_get, 584) = Documentator_ExtractDeprecated(Scanner_s);
/*3204*/ 	Scanner_ReadSym();
/*3205*/ 	return FALSE;
/*3207*/ 	break;

/*3207*/ 	case 171:
/*3208*/ 	if( (Globals_scope > 0) ){
/*3209*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid scope for documentation");
/*3211*/ 	}
/*3211*/ 	Statements_pdb = ParseDocBlock_ParseDocBlock(Scanner_s);
/*3215*/ 	if( ((Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 32, Statements_0err_entry_get, 585)) ){
/*3217*/ 		Statements_DocBlockCheckAllowedLineTags(1, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"package");
/*3218*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 12, Statements_0err_entry_get, 586) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 587);
/*3219*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 16, Statements_0err_entry_get, 588) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 589));
/*3220*/ 		Statements_pdb = NULL;
/*3224*/ 	} else {
/*3224*/ 	}
/*3224*/ 	Scanner_ReadSym();
/*3225*/ 	return FALSE;
/*3227*/ 	break;

/*3227*/ 	case 133:
/*3228*/ 	if( Statements_pdb != NULL ){
/*3229*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"unexpected DocBlock for forward declaration");
/*3231*/ 	}
/*3231*/ 	Proto_ParseForwardDecl();
/*3232*/ 	return FALSE;
/*3234*/ 	break;

/*3234*/ 	case 155:
/*3235*/ 	if( (Globals_php_ver == 4) ){
/*3236*/ 		Statements_skip_else_php_ver = TRUE;
/*3237*/ 		Scanner_ReadSym();
/*3239*/ 	} else {
/*3239*/ 		Statements_skip_else_php_ver = FALSE;
/*3241*/ 		do{
/*3241*/ 			Scanner_ReadSym();
/*3242*/ 			switch(Scanner_sym){

/*3244*/ 			case 157:
/*3245*/ 			Scanner_ReadSym();
/*3248*/ 			goto m2runtime_loop_1;
/*3248*/ 			break;

/*3248*/ 			case 158:
/*3249*/ 			Scanner_ReadSym();
/*3252*/ 			goto m2runtime_loop_1;
/*3252*/ 			break;

/*3252*/ 			case 0:
/*3253*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)"premature end of the file. Expected closing of `if_php_ver_4'.");
/*3256*/ 			break;
/*3259*/ 			}
/*3260*/ 		}while(TRUE);
m2runtime_loop_1: ;
/*3260*/ 	}
/*3260*/ 	return FALSE;
/*3262*/ 	break;

/*3262*/ 	case 156:
/*3263*/ 	if( (Globals_php_ver == 5) ){
/*3264*/ 		Statements_skip_else_php_ver = TRUE;
/*3265*/ 		Scanner_ReadSym();
/*3267*/ 	} else {
/*3267*/ 		Statements_skip_else_php_ver = FALSE;
/*3269*/ 		do{
/*3269*/ 			Scanner_ReadSym();
/*3270*/ 			switch(Scanner_sym){

/*3272*/ 			case 157:
/*3273*/ 			Scanner_ReadSym();
/*3276*/ 			goto m2runtime_loop_2;
/*3276*/ 			break;

/*3276*/ 			case 158:
/*3277*/ 			Scanner_ReadSym();
/*3280*/ 			goto m2runtime_loop_2;
/*3280*/ 			break;

/*3280*/ 			case 0:
/*3281*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)"premature end of the file. Expected closing of `if_php_ver_5'.");
/*3284*/ 			break;
/*3287*/ 			}
/*3288*/ 		}while(TRUE);
m2runtime_loop_2: ;
/*3288*/ 	}
/*3288*/ 	return FALSE;
/*3290*/ 	break;

/*3290*/ 	case 157:
/*3291*/ 	if( Statements_skip_else_php_ver ){
/*3292*/ 		Statements_skip_else_php_ver = FALSE;
/*3293*/ 		do {
/*3293*/ 			Scanner_ReadSym();
/*3294*/ 		} while( !( (((Scanner_sym == 158)) || ((Scanner_sym == 0))) ));
/*3295*/ 		if( (Scanner_sym == 158) ){
/*3296*/ 			Scanner_ReadSym();
/*3298*/ 		} else {
/*3298*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"missing closing `end_if_php_ver'");
/*3301*/ 		}
/*3301*/ 	} else {
/*3301*/ 		Scanner_ReadSym();
/*3303*/ 	}
/*3303*/ 	return FALSE;
/*3305*/ 	break;

/*3305*/ 	case 158:
/*3306*/ 	Scanner_ReadSym();
/*3307*/ 	return FALSE;
/*3309*/ 	break;

/*3309*/ 	case 7:
/*3310*/ 	Statements_ParseDefine(FALSE);
/*3311*/ 	return FALSE;
/*3313*/ 	break;

/*3313*/ 	case 9:
/*3314*/ 	Statements_ParseDeclare();
/*3315*/ 	return FALSE;
/*3317*/ 	break;

/*3317*/ 	case 101:
/*3318*/ 	Statements_ParseStatic();
/*3319*/ 	return TRUE;
/*3321*/ 	break;

/*3321*/ 	case 62:
/*3322*/ 	if( (Globals_scope == 0) ){
/*3323*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)"`global' declaration at global scope has no effect.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)" Accounting variables as mixed type, and continuing anyway.", 1));
/*3326*/ 	}
/*3326*/ 	Scanner_ReadSym();
/*3328*/ 	do{
/*3328*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"expected variable name in global declaration");
/*3329*/ 		if( (Globals_scope == 0) ){
/*3330*/ 			Accounting_AccountVarLHS(Scanner_s, FALSE);
/*3332*/ 		} else {
/*3332*/ 			Accounting_AccountGlobalVar(Scanner_s);
/*3334*/ 		}
/*3334*/ 		Scanner_ReadSym();
/*3335*/ 		if( (Scanner_sym == 16) ){
/*3336*/ 			Scanner_ReadSym();
/*3339*/ 		} else {
/*3340*/ 			goto m2runtime_loop_3;
/*3341*/ 		}
/*3341*/ 	}while(TRUE);
m2runtime_loop_3: ;
/*3341*/ 	return TRUE;
/*3343*/ 	break;

/*3343*/ 	case 114:
/*3344*/ 	Statements_ParseEcho();
/*3345*/ 	return TRUE;
/*3347*/ 	break;

/*3347*/ 	case 116:
/*3348*/ 	Statements_ParseTriggerError();
/*3349*/ 	return TRUE;
/*3351*/ 	break;

/*3351*/ 	case 29:
/*3351*/ 	case 59:
/*3351*/ 	case 108:
/*3351*/ 	case 115:
/*3351*/ 	case 103:
/*3352*/ 	case 104:
/*3352*/ 	case 12:
/*3352*/ 	case 52:
/*3352*/ 	case 53:
/*3352*/ 	case 105:
/*3352*/ 	case 122:
/*3353*/ 	Statements_r = Expressions_ParseExpr();
/*3354*/ 	return TRUE;
/*3356*/ 	break;

/*3356*/ 	case 113:
/*3357*/ 	Expressions_ParseExit();
/*3358*/ 	return TRUE;
/*3360*/ 	break;

/*3360*/ 	case 20:
/*3361*/ 	Statements_ParseSimpleStatementBeginningWithVar(FALSE, NULL);
/*3362*/ 	return FALSE;
/*3364*/ 	break;

/*3364*/ 	case 25:
/*3365*/ 	Statements_ParseIf();
/*3366*/ 	return FALSE;
/*3368*/ 	break;

/*3368*/ 	case 21:
/*3369*/ 	Statements_ParseFor();
/*3370*/ 	return FALSE;
/*3372*/ 	break;

/*3372*/ 	case 22:
/*3373*/ 	Statements_ParseForeach();
/*3374*/ 	return FALSE;
/*3376*/ 	break;

/*3376*/ 	case 109:
/*3377*/ 	Statements_ParseSwitch();
/*3378*/ 	return FALSE;
/*3380*/ 	break;

/*3380*/ 	case 111:
/*3381*/ 	Statements_ParseBreak();
/*3382*/ 	return TRUE;
/*3384*/ 	break;

/*3384*/ 	case 93:
/*3384*/ 	case 164:
/*3384*/ 	case 166:
/*3384*/ 	case 91:
/*3384*/ 	case 102:
/*3385*/ 	Statements_ParseClass(FALSE);
/*3386*/ 	return FALSE;
/*3388*/ 	break;

/*3388*/ 	case 92:
/*3389*/ 	Statements_ParseInterface(FALSE);
/*3390*/ 	return FALSE;
/*3392*/ 	break;

/*3392*/ 	case 24:
/*3393*/ 	Scanner_ReadSym();
/*3394*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected '('");
/*3395*/ 	Scanner_ReadSym();
/*3396*/ 	Statements_r = Expressions_ParseExpr();
/*3397*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"expected closing ')' of the 'while' statement");
/*3398*/ 	Expressions_CheckBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"`while(EXPR)'", Statements_r);
/*3399*/ 	Scanner_ReadSym();
/*3400*/ 	m2_inc(&Statements_loop_level, 1);
/*3401*/ 	Statements_ParseBlock();
/*3402*/ 	m2_inc(&Statements_loop_level, -1);
/*3403*/ 	return FALSE;
/*3405*/ 	break;

/*3405*/ 	case 117:
/*3406*/ 	Scanner_ReadSym();
/*3407*/ 	m2_inc(&Statements_loop_level, 1);
/*3408*/ 	Statements_ParseBlock();
/*3409*/ 	m2_inc(&Statements_loop_level, -1);
/*3410*/ 	Scanner_Expect(24, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"expected 'while' in do...while() statement");
/*3411*/ 	Scanner_ReadSym();
/*3412*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected '('");
/*3413*/ 	Scanner_ReadSym();
/*3414*/ 	Statements_r = Expressions_ParseExpr();
/*3415*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"expected closing ')' of while(...)");
/*3416*/ 	Expressions_CheckBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"`do ... while(EXPR)'", Statements_r);
/*3417*/ 	Scanner_ReadSym();
/*3418*/ 	return TRUE;
/*3420*/ 	break;

/*3420*/ 	case 121:
/*3421*/ 	Statements_ParseContinue();
/*3422*/ 	return TRUE;
/*3424*/ 	break;

/*3424*/ 	case 28:
/*3425*/ 	Statements_ParseReturn();
/*3426*/ 	return TRUE;
/*3428*/ 	break;

/*3428*/ 	case 17:
/*3430*/ 	return TRUE;
/*3432*/ 	break;

/*3432*/ 	case 8:
/*3433*/ 	Statements_ParseFuncDecl(FALSE, NULL);
/*3434*/ 	return FALSE;
/*3436*/ 	break;

/*3436*/ 	case 136:
/*3436*/ 	case 137:
/*3436*/ 	case 138:
/*3436*/ 	case 139:
/*3437*/ 	case 140:
/*3437*/ 	case 141:
/*3437*/ 	case 142:
/*3438*/ 	case 143:
/*3438*/ 	case 144:
/*3438*/ 	case 145:
/*3439*/ 	case 163:
/*3440*/ 	if( (Scanner_sym == 163) ){
/*3441*/ 		Statements_private = TRUE;
/*3442*/ 		Scanner_ReadSym();
/*3444*/ 	}
/*3444*/ 	if( (Scanner_sym == 7) ){
/*3445*/ 		Statements_ParseDefine(Statements_private);
/*3446*/ 		return FALSE;
/*3447*/ 	} else if( (((Scanner_sym == 93)) || ((Scanner_sym == 91)) || ((Scanner_sym == 102))) ){
/*3449*/ 		Statements_ParseClass(Statements_private);
/*3450*/ 		return FALSE;
/*3451*/ 	} else if( (Scanner_sym == 92) ){
/*3452*/ 		Statements_ParseInterface(TRUE);
/*3453*/ 		return FALSE;
/*3455*/ 	}
/*3455*/ 	Statements_t = Expressions_ParseType(FALSE);
/*3456*/ 	if( (Scanner_sym == 20) ){
/*3457*/ 		Statements_ParseSimpleStatementBeginningWithVar(Statements_private, Statements_t);
/*3458*/ 		return FALSE;
/*3459*/ 	} else if( (Scanner_sym == 8) ){
/*3460*/ 		Statements_ParseFuncDecl(Statements_private, Statements_t);
/*3461*/ 		return FALSE;
/*3463*/ 	} else {
/*3463*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"expected variable or `function' after type");
/*3466*/ 	}
/*3466*/ 	break;

/*3466*/ 	case 120:
/*3467*/ 	Statements_ParseThrow();
/*3468*/ 	return TRUE;
/*3470*/ 	break;

/*3470*/ 	case 118:
/*3471*/ 	Statements_ParseTry();
/*3472*/ 	return FALSE;
/*3474*/ 	break;

/*3474*/ 	case 6:
/*3475*/ 	Statements_ParseTextBlock();
/*3476*/ 	return FALSE;
/*3479*/ 	break;

/*3479*/ 	default:
/*3479*/ 	Scanner_UnexpectedSymbol();
/*3482*/ 	}
/*3482*/ 	if( (FALSE && Statements_ParseSimpleStatement()) ){
/*3486*/ 	}
/*3486*/ 	m2runtime_missing_return(Statements_0err_entry_get, 590);
/*3486*/ 	return 0;
/*3489*/ }


char * Statements_0func[] = {
    "ParseEcho",
    "ParseReturn",
    "ParseTriggerError",
    "DocBlockCheckAllowedLineTags",
    "ParseArgsListDecl",
    "SameSign",
    "AccountFuncDecl",
    "ParseFuncDecl",
    "ParseForeach",
    "ParseSwitch",
    "ParseClassConstDecl",
    "ParseClassPropertyDecl",
    "CheckSpecialMethodSignature",
    "SameMethodSignature",
    "ParentConstructor",
    "ParentDestructor",
    "ParseClassMethodDecl",
    "ParseClass",
    "ParseInterface",
    "ParseStatic",
    "ParseDefine",
    "readable",
    "AddPackageToIncludePath",
    "SearchFileOnPaths",
    "RequirePackage",
    "ParseRequireOnce",
    "ParseInclude",
    "ParseThrow",
    "ParseTry",
    "ParseEchoBlock",
    "add",
    "ParsePackage",
    "ParseSimpleStatementBeginningWithVar",
    "ParseSimpleStatement"
};

int Statements_0err_entry[] = {
    0 /* ParseEcho */, 28,
    0 /* ParseEcho */, 34,
    0 /* ParseEcho */, 35,
    1 /* ParseReturn */, 61,
    1 /* ParseReturn */, 62,
    1 /* ParseReturn */, 63,
    1 /* ParseReturn */, 65,
    1 /* ParseReturn */, 66,
    1 /* ParseReturn */, 83,
    1 /* ParseReturn */, 87,
    1 /* ParseReturn */, 96,
    1 /* ParseReturn */, 100,
    1 /* ParseReturn */, 104,
    1 /* ParseReturn */, 129,
    2 /* ParseTriggerError */, 166,
    2 /* ParseTriggerError */, 169,
    2 /* ParseTriggerError */, 187,
    2 /* ParseTriggerError */, 187,
    2 /* ParseTriggerError */, 189,
    2 /* ParseTriggerError */, 189,
    3 /* DocBlockCheckAllowedLineTags */, 230,
    3 /* DocBlockCheckAllowedLineTags */, 233,
    3 /* DocBlockCheckAllowedLineTags */, 236,
    3 /* DocBlockCheckAllowedLineTags */, 239,
    3 /* DocBlockCheckAllowedLineTags */, 242,
    3 /* DocBlockCheckAllowedLineTags */, 245,
    3 /* DocBlockCheckAllowedLineTags */, 248,
    3 /* DocBlockCheckAllowedLineTags */, 251,
    3 /* DocBlockCheckAllowedLineTags */, 254,
    3 /* DocBlockCheckAllowedLineTags */, 257,
    3 /* DocBlockCheckAllowedLineTags */, 260,
    4 /* ParseArgsListDecl */, 332,
    4 /* ParseArgsListDecl */, 341,
    4 /* ParseArgsListDecl */, 342,
    4 /* ParseArgsListDecl */, 350,
    4 /* ParseArgsListDecl */, 359,
    4 /* ParseArgsListDecl */, 365,
    4 /* ParseArgsListDecl */, 370,
    4 /* ParseArgsListDecl */, 370,
    4 /* ParseArgsListDecl */, 371,
    4 /* ParseArgsListDecl */, 371,
    4 /* ParseArgsListDecl */, 372,
    4 /* ParseArgsListDecl */, 372,
    4 /* ParseArgsListDecl */, 384,
    4 /* ParseArgsListDecl */, 385,
    4 /* ParseArgsListDecl */, 393,
    4 /* ParseArgsListDecl */, 401,
    4 /* ParseArgsListDecl */, 402,
    4 /* ParseArgsListDecl */, 402,
    4 /* ParseArgsListDecl */, 403,
    4 /* ParseArgsListDecl */, 403,
    4 /* ParseArgsListDecl */, 405,
    4 /* ParseArgsListDecl */, 405,
    4 /* ParseArgsListDecl */, 408,
    4 /* ParseArgsListDecl */, 409,
    4 /* ParseArgsListDecl */, 412,
    4 /* ParseArgsListDecl */, 413,
    4 /* ParseArgsListDecl */, 416,
    4 /* ParseArgsListDecl */, 416,
    4 /* ParseArgsListDecl */, 419,
    4 /* ParseArgsListDecl */, 422,
    4 /* ParseArgsListDecl */, 423,
    4 /* ParseArgsListDecl */, 425,
    4 /* ParseArgsListDecl */, 427,
    4 /* ParseArgsListDecl */, 428,
    4 /* ParseArgsListDecl */, 430,
    4 /* ParseArgsListDecl */, 430,
    4 /* ParseArgsListDecl */, 431,
    4 /* ParseArgsListDecl */, 431,
    4 /* ParseArgsListDecl */, 432,
    4 /* ParseArgsListDecl */, 432,
    4 /* ParseArgsListDecl */, 434,
    4 /* ParseArgsListDecl */, 443,
    5 /* SameSign */, 471,
    5 /* SameSign */, 471,
    5 /* SameSign */, 472,
    5 /* SameSign */, 472,
    5 /* SameSign */, 476,
    5 /* SameSign */, 476,
    5 /* SameSign */, 479,
    5 /* SameSign */, 479,
    5 /* SameSign */, 482,
    5 /* SameSign */, 483,
    5 /* SameSign */, 483,
    5 /* SameSign */, 483,
    5 /* SameSign */, 483,
    5 /* SameSign */, 483,
    5 /* SameSign */, 483,
    5 /* SameSign */, 484,
    5 /* SameSign */, 484,
    5 /* SameSign */, 484,
    5 /* SameSign */, 484,
    5 /* SameSign */, 484,
    5 /* SameSign */, 484,
    6 /* AccountFuncDecl */, 510,
    6 /* AccountFuncDecl */, 522,
    6 /* AccountFuncDecl */, 523,
    6 /* AccountFuncDecl */, 524,
    6 /* AccountFuncDecl */, 525,
    6 /* AccountFuncDecl */, 527,
    6 /* AccountFuncDecl */, 529,
    6 /* AccountFuncDecl */, 530,
    6 /* AccountFuncDecl */, 531,
    6 /* AccountFuncDecl */, 532,
    6 /* AccountFuncDecl */, 533,
    6 /* AccountFuncDecl */, 533,
    6 /* AccountFuncDecl */, 536,
    6 /* AccountFuncDecl */, 540,
    6 /* AccountFuncDecl */, 544,
    6 /* AccountFuncDecl */, 545,
    6 /* AccountFuncDecl */, 548,
    7 /* ParseFuncDecl */, 566,
    7 /* ParseFuncDecl */, 571,
    7 /* ParseFuncDecl */, 574,
    7 /* ParseFuncDecl */, 580,
    7 /* ParseFuncDecl */, 585,
    7 /* ParseFuncDecl */, 601,
    7 /* ParseFuncDecl */, 602,
    7 /* ParseFuncDecl */, 603,
    7 /* ParseFuncDecl */, 604,
    7 /* ParseFuncDecl */, 605,
    7 /* ParseFuncDecl */, 606,
    7 /* ParseFuncDecl */, 609,
    7 /* ParseFuncDecl */, 612,
    7 /* ParseFuncDecl */, 613,
    7 /* ParseFuncDecl */, 615,
    7 /* ParseFuncDecl */, 616,
    7 /* ParseFuncDecl */, 641,
    7 /* ParseFuncDecl */, 642,
    7 /* ParseFuncDecl */, 645,
    7 /* ParseFuncDecl */, 645,
    7 /* ParseFuncDecl */, 646,
    7 /* ParseFuncDecl */, 646,
    7 /* ParseFuncDecl */, 655,
    7 /* ParseFuncDecl */, 658,
    7 /* ParseFuncDecl */, 666,
    7 /* ParseFuncDecl */, 666,
    7 /* ParseFuncDecl */, 670,
    7 /* ParseFuncDecl */, 671,
    7 /* ParseFuncDecl */, 672,
    7 /* ParseFuncDecl */, 672,
    7 /* ParseFuncDecl */, 675,
    7 /* ParseFuncDecl */, 677,
    7 /* ParseFuncDecl */, 677,
    7 /* ParseFuncDecl */, 683,
    7 /* ParseFuncDecl */, 685,
    7 /* ParseFuncDecl */, 685,
    7 /* ParseFuncDecl */, 689,
    7 /* ParseFuncDecl */, 691,
    7 /* ParseFuncDecl */, 691,
    7 /* ParseFuncDecl */, 695,
    7 /* ParseFuncDecl */, 697,
    7 /* ParseFuncDecl */, 698,
    7 /* ParseFuncDecl */, 698,
    7 /* ParseFuncDecl */, 699,
    7 /* ParseFuncDecl */, 701,
    8 /* ParseForeach */, 798,
    8 /* ParseForeach */, 798,
    8 /* ParseForeach */, 799,
    8 /* ParseForeach */, 799,
    8 /* ParseForeach */, 804,
    8 /* ParseForeach */, 805,
    8 /* ParseForeach */, 805,
    8 /* ParseForeach */, 806,
    8 /* ParseForeach */, 806,
    8 /* ParseForeach */, 808,
    8 /* ParseForeach */, 808,
    8 /* ParseForeach */, 812,
    8 /* ParseForeach */, 860,
    8 /* ParseForeach */, 862,
    8 /* ParseForeach */, 865,
    8 /* ParseForeach */, 868,
    8 /* ParseForeach */, 869,
    8 /* ParseForeach */, 872,
    8 /* ParseForeach */, 873,
    8 /* ParseForeach */, 875,
    8 /* ParseForeach */, 888,
    8 /* ParseForeach */, 889,
    8 /* ParseForeach */, 891,
    8 /* ParseForeach */, 894,
    8 /* ParseForeach */, 895,
    8 /* ParseForeach */, 899,
    8 /* ParseForeach */, 900,
    8 /* ParseForeach */, 903,
    9 /* ParseSwitch */, 924,
    9 /* ParseSwitch */, 947,
    9 /* ParseSwitch */, 948,
    10 /* ParseClassConstDecl */, 1026,
    10 /* ParseClassConstDecl */, 1027,
    10 /* ParseClassConstDecl */, 1027,
    10 /* ParseClassConstDecl */, 1035,
    10 /* ParseClassConstDecl */, 1036,
    10 /* ParseClassConstDecl */, 1037,
    10 /* ParseClassConstDecl */, 1039,
    10 /* ParseClassConstDecl */, 1048,
    10 /* ParseClassConstDecl */, 1048,
    10 /* ParseClassConstDecl */, 1051,
    10 /* ParseClassConstDecl */, 1052,
    10 /* ParseClassConstDecl */, 1052,
    10 /* ParseClassConstDecl */, 1065,
    10 /* ParseClassConstDecl */, 1066,
    10 /* ParseClassConstDecl */, 1069,
    10 /* ParseClassConstDecl */, 1069,
    10 /* ParseClassConstDecl */, 1070,
    10 /* ParseClassConstDecl */, 1070,
    11 /* ParseClassPropertyDecl */, 1094,
    11 /* ParseClassPropertyDecl */, 1099,
    11 /* ParseClassPropertyDecl */, 1101,
    11 /* ParseClassPropertyDecl */, 1104,
    11 /* ParseClassPropertyDecl */, 1106,
    11 /* ParseClassPropertyDecl */, 1108,
    11 /* ParseClassPropertyDecl */, 1110,
    11 /* ParseClassPropertyDecl */, 1120,
    11 /* ParseClassPropertyDecl */, 1121,
    11 /* ParseClassPropertyDecl */, 1121,
    11 /* ParseClassPropertyDecl */, 1122,
    11 /* ParseClassPropertyDecl */, 1122,
    11 /* ParseClassPropertyDecl */, 1124,
    11 /* ParseClassPropertyDecl */, 1124,
    11 /* ParseClassPropertyDecl */, 1127,
    11 /* ParseClassPropertyDecl */, 1128,
    11 /* ParseClassPropertyDecl */, 1129,
    11 /* ParseClassPropertyDecl */, 1131,
    11 /* ParseClassPropertyDecl */, 1132,
    11 /* ParseClassPropertyDecl */, 1133,
    11 /* ParseClassPropertyDecl */, 1134,
    11 /* ParseClassPropertyDecl */, 1135,
    11 /* ParseClassPropertyDecl */, 1135,
    11 /* ParseClassPropertyDecl */, 1138,
    11 /* ParseClassPropertyDecl */, 1140,
    11 /* ParseClassPropertyDecl */, 1141,
    11 /* ParseClassPropertyDecl */, 1144,
    11 /* ParseClassPropertyDecl */, 1144,
    11 /* ParseClassPropertyDecl */, 1159,
    11 /* ParseClassPropertyDecl */, 1160,
    11 /* ParseClassPropertyDecl */, 1163,
    11 /* ParseClassPropertyDecl */, 1163,
    11 /* ParseClassPropertyDecl */, 1164,
    11 /* ParseClassPropertyDecl */, 1164,
    12 /* CheckSpecialMethodSignature */, 1181,
    12 /* CheckSpecialMethodSignature */, 1181,
    12 /* CheckSpecialMethodSignature */, 1181,
    12 /* CheckSpecialMethodSignature */, 1218,
    12 /* CheckSpecialMethodSignature */, 1218,
    12 /* CheckSpecialMethodSignature */, 1218,
    12 /* CheckSpecialMethodSignature */, 1219,
    12 /* CheckSpecialMethodSignature */, 1219,
    12 /* CheckSpecialMethodSignature */, 1219,
    12 /* CheckSpecialMethodSignature */, 1220,
    12 /* CheckSpecialMethodSignature */, 1221,
    12 /* CheckSpecialMethodSignature */, 1221,
    12 /* CheckSpecialMethodSignature */, 1229,
    12 /* CheckSpecialMethodSignature */, 1229,
    12 /* CheckSpecialMethodSignature */, 1229,
    12 /* CheckSpecialMethodSignature */, 1230,
    12 /* CheckSpecialMethodSignature */, 1230,
    12 /* CheckSpecialMethodSignature */, 1238,
    12 /* CheckSpecialMethodSignature */, 1238,
    12 /* CheckSpecialMethodSignature */, 1239,
    12 /* CheckSpecialMethodSignature */, 1239,
    12 /* CheckSpecialMethodSignature */, 1239,
    12 /* CheckSpecialMethodSignature */, 1241,
    12 /* CheckSpecialMethodSignature */, 1241,
    12 /* CheckSpecialMethodSignature */, 1242,
    12 /* CheckSpecialMethodSignature */, 1242,
    12 /* CheckSpecialMethodSignature */, 1242,
    12 /* CheckSpecialMethodSignature */, 1247,
    12 /* CheckSpecialMethodSignature */, 1247,
    12 /* CheckSpecialMethodSignature */, 1248,
    12 /* CheckSpecialMethodSignature */, 1248,
    12 /* CheckSpecialMethodSignature */, 1250,
    12 /* CheckSpecialMethodSignature */, 1250,
    13 /* SameMethodSignature */, 1257,
    13 /* SameMethodSignature */, 1257,
    13 /* SameMethodSignature */, 1258,
    13 /* SameMethodSignature */, 1258,
    13 /* SameMethodSignature */, 1259,
    13 /* SameMethodSignature */, 1259,
    13 /* SameMethodSignature */, 1260,
    13 /* SameMethodSignature */, 1260,
    14 /* ParentConstructor */, 1281,
    14 /* ParentConstructor */, 1282,
    14 /* ParentConstructor */, 1283,
    15 /* ParentDestructor */, 1294,
    15 /* ParentDestructor */, 1295,
    15 /* ParentDestructor */, 1296,
    16 /* ParseClassMethodDecl */, 1305,
    16 /* ParseClassMethodDecl */, 1316,
    16 /* ParseClassMethodDecl */, 1349,
    16 /* ParseClassMethodDecl */, 1350,
    16 /* ParseClassMethodDecl */, 1351,
    16 /* ParseClassMethodDecl */, 1352,
    16 /* ParseClassMethodDecl */, 1354,
    16 /* ParseClassMethodDecl */, 1365,
    16 /* ParseClassMethodDecl */, 1378,
    16 /* ParseClassMethodDecl */, 1378,
    16 /* ParseClassMethodDecl */, 1380,
    16 /* ParseClassMethodDecl */, 1385,
    16 /* ParseClassMethodDecl */, 1385,
    16 /* ParseClassMethodDecl */, 1388,
    16 /* ParseClassMethodDecl */, 1388,
    16 /* ParseClassMethodDecl */, 1391,
    16 /* ParseClassMethodDecl */, 1391,
    16 /* ParseClassMethodDecl */, 1393,
    16 /* ParseClassMethodDecl */, 1394,
    16 /* ParseClassMethodDecl */, 1396,
    16 /* ParseClassMethodDecl */, 1397,
    16 /* ParseClassMethodDecl */, 1404,
    16 /* ParseClassMethodDecl */, 1405,
    16 /* ParseClassMethodDecl */, 1408,
    16 /* ParseClassMethodDecl */, 1408,
    16 /* ParseClassMethodDecl */, 1410,
    16 /* ParseClassMethodDecl */, 1411,
    16 /* ParseClassMethodDecl */, 1412,
    16 /* ParseClassMethodDecl */, 1412,
    16 /* ParseClassMethodDecl */, 1413,
    16 /* ParseClassMethodDecl */, 1415,
    16 /* ParseClassMethodDecl */, 1415,
    16 /* ParseClassMethodDecl */, 1421,
    16 /* ParseClassMethodDecl */, 1421,
    16 /* ParseClassMethodDecl */, 1422,
    16 /* ParseClassMethodDecl */, 1424,
    16 /* ParseClassMethodDecl */, 1425,
    16 /* ParseClassMethodDecl */, 1429,
    16 /* ParseClassMethodDecl */, 1430,
    16 /* ParseClassMethodDecl */, 1431,
    16 /* ParseClassMethodDecl */, 1431,
    16 /* ParseClassMethodDecl */, 1432,
    16 /* ParseClassMethodDecl */, 1434,
    16 /* ParseClassMethodDecl */, 1434,
    16 /* ParseClassMethodDecl */, 1443,
    16 /* ParseClassMethodDecl */, 1445,
    16 /* ParseClassMethodDecl */, 1449,
    16 /* ParseClassMethodDecl */, 1462,
    16 /* ParseClassMethodDecl */, 1463,
    16 /* ParseClassMethodDecl */, 1463,
    16 /* ParseClassMethodDecl */, 1490,
    16 /* ParseClassMethodDecl */, 1491,
    16 /* ParseClassMethodDecl */, 1493,
    16 /* ParseClassMethodDecl */, 1495,
    16 /* ParseClassMethodDecl */, 1496,
    16 /* ParseClassMethodDecl */, 1498,
    16 /* ParseClassMethodDecl */, 1500,
    16 /* ParseClassMethodDecl */, 1500,
    16 /* ParseClassMethodDecl */, 1501,
    16 /* ParseClassMethodDecl */, 1504,
    16 /* ParseClassMethodDecl */, 1520,
    16 /* ParseClassMethodDecl */, 1521,
    16 /* ParseClassMethodDecl */, 1524,
    16 /* ParseClassMethodDecl */, 1524,
    16 /* ParseClassMethodDecl */, 1525,
    16 /* ParseClassMethodDecl */, 1525,
    16 /* ParseClassMethodDecl */, 1548,
    16 /* ParseClassMethodDecl */, 1551,
    16 /* ParseClassMethodDecl */, 1552,
    16 /* ParseClassMethodDecl */, 1555,
    16 /* ParseClassMethodDecl */, 1555,
    16 /* ParseClassMethodDecl */, 1567,
    16 /* ParseClassMethodDecl */, 1586,
    16 /* ParseClassMethodDecl */, 1588,
    16 /* ParseClassMethodDecl */, 1588,
    16 /* ParseClassMethodDecl */, 1588,
    16 /* ParseClassMethodDecl */, 1596,
    16 /* ParseClassMethodDecl */, 1598,
    16 /* ParseClassMethodDecl */, 1598,
    16 /* ParseClassMethodDecl */, 1598,
    16 /* ParseClassMethodDecl */, 1606,
    16 /* ParseClassMethodDecl */, 1609,
    16 /* ParseClassMethodDecl */, 1644,
    16 /* ParseClassMethodDecl */, 1647,
    16 /* ParseClassMethodDecl */, 1659,
    16 /* ParseClassMethodDecl */, 1660,
    16 /* ParseClassMethodDecl */, 1665,
    16 /* ParseClassMethodDecl */, 1667,
    16 /* ParseClassMethodDecl */, 1672,
    16 /* ParseClassMethodDecl */, 1677,
    16 /* ParseClassMethodDecl */, 1678,
    16 /* ParseClassMethodDecl */, 1678,
    16 /* ParseClassMethodDecl */, 1680,
    16 /* ParseClassMethodDecl */, 1680,
    16 /* ParseClassMethodDecl */, 1682,
    17 /* ParseClass */, 1721,
    17 /* ParseClass */, 1724,
    17 /* ParseClass */, 1730,
    17 /* ParseClass */, 1730,
    17 /* ParseClass */, 1731,
    17 /* ParseClass */, 1731,
    17 /* ParseClass */, 1732,
    17 /* ParseClass */, 1732,
    17 /* ParseClass */, 1742,
    17 /* ParseClass */, 1745,
    17 /* ParseClass */, 1752,
    17 /* ParseClass */, 1755,
    17 /* ParseClass */, 1762,
    17 /* ParseClass */, 1765,
    17 /* ParseClass */, 1772,
    17 /* ParseClass */, 1775,
    17 /* ParseClass */, 1784,
    17 /* ParseClass */, 1784,
    17 /* ParseClass */, 1797,
    17 /* ParseClass */, 1798,
    17 /* ParseClass */, 1799,
    17 /* ParseClass */, 1800,
    17 /* ParseClass */, 1802,
    17 /* ParseClass */, 1803,
    17 /* ParseClass */, 1803,
    17 /* ParseClass */, 1804,
    17 /* ParseClass */, 1804,
    17 /* ParseClass */, 1805,
    17 /* ParseClass */, 1805,
    17 /* ParseClass */, 1806,
    17 /* ParseClass */, 1806,
    17 /* ParseClass */, 1807,
    17 /* ParseClass */, 1807,
    17 /* ParseClass */, 1808,
    17 /* ParseClass */, 1813,
    17 /* ParseClass */, 1830,
    17 /* ParseClass */, 1831,
    17 /* ParseClass */, 1832,
    17 /* ParseClass */, 1833,
    17 /* ParseClass */, 1835,
    17 /* ParseClass */, 1837,
    17 /* ParseClass */, 1838,
    17 /* ParseClass */, 1839,
    17 /* ParseClass */, 1855,
    17 /* ParseClass */, 1858,
    17 /* ParseClass */, 1858,
    17 /* ParseClass */, 1862,
    17 /* ParseClass */, 1864,
    17 /* ParseClass */, 1864,
    17 /* ParseClass */, 1879,
    17 /* ParseClass */, 1880,
    17 /* ParseClass */, 1883,
    17 /* ParseClass */, 1883,
    17 /* ParseClass */, 1884,
    17 /* ParseClass */, 1884,
    17 /* ParseClass */, 1918,
    17 /* ParseClass */, 1921,
    17 /* ParseClass */, 1924,
    17 /* ParseClass */, 1928,
    17 /* ParseClass */, 1929,
    17 /* ParseClass */, 1930,
    17 /* ParseClass */, 2031,
    17 /* ParseClass */, 2032,
    17 /* ParseClass */, 2033,
    17 /* ParseClass */, 2034,
    17 /* ParseClass */, 2039,
    17 /* ParseClass */, 2039,
    17 /* ParseClass */, 2112,
    17 /* ParseClass */, 2121,
    17 /* ParseClass */, 2134,
    17 /* ParseClass */, 2138,
    17 /* ParseClass */, 2139,
    17 /* ParseClass */, 2140,
    17 /* ParseClass */, 2140,
    17 /* ParseClass */, 2141,
    17 /* ParseClass */, 2142,
    18 /* ParseInterface */, 2165,
    18 /* ParseInterface */, 2166,
    18 /* ParseInterface */, 2167,
    18 /* ParseInterface */, 2169,
    18 /* ParseInterface */, 2180,
    18 /* ParseInterface */, 2186,
    18 /* ParseInterface */, 2187,
    18 /* ParseInterface */, 2188,
    18 /* ParseInterface */, 2189,
    18 /* ParseInterface */, 2203,
    18 /* ParseInterface */, 2203,
    18 /* ParseInterface */, 2205,
    18 /* ParseInterface */, 2208,
    18 /* ParseInterface */, 2209,
    18 /* ParseInterface */, 2209,
    18 /* ParseInterface */, 2215,
    18 /* ParseInterface */, 2215,
    18 /* ParseInterface */, 2217,
    18 /* ParseInterface */, 2219,
    18 /* ParseInterface */, 2219,
    18 /* ParseInterface */, 2234,
    18 /* ParseInterface */, 2235,
    18 /* ParseInterface */, 2238,
    18 /* ParseInterface */, 2238,
    18 /* ParseInterface */, 2239,
    18 /* ParseInterface */, 2239,
    18 /* ParseInterface */, 2258,
    18 /* ParseInterface */, 2258,
    18 /* ParseInterface */, 2258,
    18 /* ParseInterface */, 2261,
    18 /* ParseInterface */, 2264,
    18 /* ParseInterface */, 2301,
    19 /* ParseStatic */, 2339,
    19 /* ParseStatic */, 2348,
    19 /* ParseStatic */, 2362,
    19 /* ParseStatic */, 2362,
    19 /* ParseStatic */, 2364,
    19 /* ParseStatic */, 2367,
    19 /* ParseStatic */, 2372,
    20 /* ParseDefine */, 2439,
    20 /* ParseDefine */, 2442,
    20 /* ParseDefine */, 2458,
    20 /* ParseDefine */, 2462,
    20 /* ParseDefine */, 2484,
    20 /* ParseDefine */, 2485,
    20 /* ParseDefine */, 2488,
    20 /* ParseDefine */, 2488,
    20 /* ParseDefine */, 2489,
    20 /* ParseDefine */, 2489,
    20 /* ParseDefine */, 2490,
    20 /* ParseDefine */, 2490,
    21 /* readable */, 2539,
    21 /* readable */, 2544,
    22 /* AddPackageToIncludePath */, 2555,
    22 /* AddPackageToIncludePath */, 2559,
    23 /* SearchFileOnPaths */, 2579,
    23 /* SearchFileOnPaths */, 2586,
    24 /* RequirePackage */, 2643,
    24 /* RequirePackage */, 2650,
    25 /* ParseRequireOnce */, 2688,
    25 /* ParseRequireOnce */, 2691,
    25 /* ParseRequireOnce */, 2695,
    26 /* ParseInclude */, 2713,
    26 /* ParseInclude */, 2715,
    26 /* ParseInclude */, 2717,
    26 /* ParseInclude */, 2717,
    26 /* ParseInclude */, 2718,
    26 /* ParseInclude */, 2721,
    27 /* ParseThrow */, 2737,
    27 /* ParseThrow */, 2738,
    27 /* ParseThrow */, 2739,
    27 /* ParseThrow */, 2741,
    27 /* ParseThrow */, 2742,
    27 /* ParseThrow */, 2744,
    27 /* ParseThrow */, 2744,
    28 /* ParseTry */, 2806,
    29 /* ParseEchoBlock */, 2832,
    30 /* add */, 2908,
    30 /* add */, 2909,
    30 /* add */, 2910,
    30 /* add */, 2911,
    30 /* add */, 2912,
    30 /* add */, 2913,
    30 /* add */, 2914,
    30 /* add */, 2915,
    31 /* ParsePackage */, 2973,
    31 /* ParsePackage */, 2973,
    31 /* ParsePackage */, 2975,
    31 /* ParsePackage */, 2984,
    31 /* ParsePackage */, 2992,
    31 /* ParsePackage */, 2999,
    31 /* ParsePackage */, 3000,
    31 /* ParsePackage */, 3001,
    31 /* ParsePackage */, 3002,
    31 /* ParsePackage */, 3003,
    31 /* ParsePackage */, 3005,
    31 /* ParsePackage */, 3030,
    31 /* ParsePackage */, 3030,
    31 /* ParsePackage */, 3030,
    31 /* ParsePackage */, 3030,
    31 /* ParsePackage */, 3031,
    31 /* ParsePackage */, 3032,
    31 /* ParsePackage */, 3042,
    31 /* ParsePackage */, 3042,
    31 /* ParsePackage */, 3042,
    31 /* ParsePackage */, 3042,
    31 /* ParsePackage */, 3043,
    31 /* ParsePackage */, 3044,
    31 /* ParsePackage */, 3049,
    32 /* ParseSimpleStatementBeginningWithVar */, 3095,
    32 /* ParseSimpleStatementBeginningWithVar */, 3097,
    32 /* ParseSimpleStatementBeginningWithVar */, 3098,
    32 /* ParseSimpleStatementBeginningWithVar */, 3098,
    32 /* ParseSimpleStatementBeginningWithVar */, 3099,
    32 /* ParseSimpleStatementBeginningWithVar */, 3102,
    32 /* ParseSimpleStatementBeginningWithVar */, 3103,
    32 /* ParseSimpleStatementBeginningWithVar */, 3106,
    32 /* ParseSimpleStatementBeginningWithVar */, 3109,
    32 /* ParseSimpleStatementBeginningWithVar */, 3127,
    32 /* ParseSimpleStatementBeginningWithVar */, 3128,
    32 /* ParseSimpleStatementBeginningWithVar */, 3149,
    32 /* ParseSimpleStatementBeginningWithVar */, 3150,
    32 /* ParseSimpleStatementBeginningWithVar */, 3154,
    32 /* ParseSimpleStatementBeginningWithVar */, 3154,
    32 /* ParseSimpleStatementBeginningWithVar */, 3155,
    32 /* ParseSimpleStatementBeginningWithVar */, 3155,
    33 /* ParseSimpleStatement */, 3202,
    33 /* ParseSimpleStatement */, 3203,
    33 /* ParseSimpleStatement */, 3215,
    33 /* ParseSimpleStatement */, 3218,
    33 /* ParseSimpleStatement */, 3218,
    33 /* ParseSimpleStatement */, 3219,
    33 /* ParseSimpleStatement */, 3219,
    33 /* ParseSimpleStatement */, 3485
};

void Statements_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Statements";
    *f = Statements_0func[ Statements_0err_entry[2*i] ];
    *l = Statements_0err_entry[2*i + 1];
}
