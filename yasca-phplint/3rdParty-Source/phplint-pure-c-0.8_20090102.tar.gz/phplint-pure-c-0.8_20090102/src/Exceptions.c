/* IMPLEMENTATION MODULE Exceptions */
#define M2_IMPORT_Exceptions

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif
/* 10*/ int Exceptions_try_block_nesting_level = 0;
/* 15*/ ARRAY * Exceptions_exceptions = NULL;

#ifndef M2_IMPORT_Classes
#    include "Classes.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

void Exceptions_0err_entry_get(int i, char **m, char **f, int *l);

/* 10*/ int
/* 10*/ Exceptions_IsExceptionClass(RECORD *Exceptions_c)
/* 10*/ {
/* 12*/ 	RECORD * Exceptions_t = NULL;
/* 12*/ 	Exceptions_t = Exceptions_c;
/* 13*/ 	while( Exceptions_t != NULL ){
/* 14*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_t, 8, Exceptions_0err_entry_get, 0), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"Exception") == 0 ){
/* 15*/ 			return TRUE;
/* 17*/ 		}
/* 17*/ 		Exceptions_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Exceptions_t, 16, Exceptions_0err_entry_get, 1);
/* 19*/ 	}
/* 19*/ 	return FALSE;
/* 23*/ }


/* 25*/ void
/* 25*/ Exceptions_AddExceptionToList(RECORD *Exceptions_exception, ARRAY **Exceptions_exceptions)
/* 25*/ {
/* 27*/ 	int Exceptions_i = 0;
/* 27*/ 	{
/* 27*/ 		int m2runtime_for_limit_1;
/* 27*/ 		Exceptions_i = 0;
/* 27*/ 		m2runtime_for_limit_1 = (m2runtime_count(*Exceptions_exceptions) - 1);
/* 28*/ 		for( ; Exceptions_i <= m2runtime_for_limit_1; Exceptions_i += 1 ){
/* 28*/ 			if( (RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_exceptions, Exceptions_i, Exceptions_0err_entry_get, 2) == Exceptions_exception ){
/* 30*/ 				return ;
/* 32*/ 			}
/* 32*/ 		}
/* 32*/ 	}
/* 32*/ 	*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(Exceptions_exceptions, 4, 1, Exceptions_0err_entry_get, 3) = Exceptions_exception;
/* 36*/ }


/* 38*/ void
/* 38*/ Exceptions_AddException(RECORD *Exceptions_exception)
/* 38*/ {
/* 38*/ 	if( (Exceptions_try_block_nesting_level == 0) ){
/* 39*/ 		if( Globals_curr_func != NULL ){
/* 40*/ 			Exceptions_AddExceptionToList(Exceptions_exception, (ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_func, 60, 9, 32, Exceptions_0err_entry_get, 4));
/* 41*/ 		} else if( Globals_curr_method != NULL ){
/* 42*/ 			Exceptions_AddExceptionToList(Exceptions_exception, (ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_method, 72, 8, 28, Exceptions_0err_entry_get, 5));
/* 45*/ 		}
/* 45*/ 	} else {
/* 45*/ 		Exceptions_AddExceptionToList(Exceptions_exception, &Exceptions_exceptions);
/* 48*/ 	}
/* 50*/ }


/* 52*/ void
/* 52*/ Exceptions_ThrowException(RECORD *Exceptions_exception)
/* 52*/ {
/* 52*/ 	Exceptions_AddException(Exceptions_exception);
/* 53*/ 	if( (Exceptions_try_block_nesting_level == 0) ){
/* 54*/ 		if( Globals_curr_func != NULL ){
/* 55*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"uncought exception ", (STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_exception, 8, Exceptions_0err_entry_get, 6), 1));
/* 56*/ 		} else if( Globals_curr_method != NULL ){
/* 57*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"uncought exception ", (STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_exception, 8, Exceptions_0err_entry_get, 7), 1));
/* 59*/ 		} else {
/* 59*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"uncought exception ", (STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_exception, 8, Exceptions_0err_entry_get, 8), 1));
/* 62*/ 		}
/* 62*/ 	} else {
/* 62*/ 		Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"here generating exception ", (STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_exception, 8, Exceptions_0err_entry_get, 9), 1));
/* 65*/ 	}
/* 67*/ }


/* 68*/ void
/* 68*/ Exceptions_ThrowExceptions(ARRAY *Exceptions_exceptions)
/* 68*/ {
/* 70*/ 	int Exceptions_i = 0;
/* 70*/ 	{
/* 70*/ 		int m2runtime_for_limit_1;
/* 70*/ 		Exceptions_i = 0;
/* 70*/ 		m2runtime_for_limit_1 = (m2runtime_count(Exceptions_exceptions) - 1);
/* 71*/ 		for( ; Exceptions_i <= m2runtime_for_limit_1; Exceptions_i += 1 ){
/* 71*/ 			Exceptions_ThrowException((RECORD *)m2runtime_dereference_rhs_ARRAY(Exceptions_exceptions, Exceptions_i, Exceptions_0err_entry_get, 10));
/* 74*/ 		}
/* 74*/ 	}
/* 76*/ }


/* 78*/ void
/* 78*/ Exceptions_ParseThrows(void)
/* 78*/ {
/* 80*/ 	RECORD * Exceptions_exception = NULL;
/* 80*/ 	Scanner_ReadSym();
/* 81*/ 	Scanner_Expect(145, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected exception name");
/* 83*/ 	do{
/* 83*/ 		Exceptions_exception = Search_SearchClass(Scanner_s, TRUE);
/* 84*/ 		if( Exceptions_exception == NULL ){
/* 85*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"unknown exception `", Scanner_s, m2runtime_CHR(39), 1));
/* 86*/ 		} else if( !Exceptions_IsExceptionClass(Exceptions_exception) ){
/* 87*/ 			Scanner_Error(m2runtime_concat_STRING(0, m2runtime_CHR(96), Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' is not an exception", 1));
/* 89*/ 		} else {
/* 89*/ 			Exceptions_AddException(Exceptions_exception);
/* 91*/ 		}
/* 91*/ 		Scanner_ReadSym();
/* 92*/ 		if( (Scanner_sym == 131) ){
/* 93*/ 			Scanner_ReadSym();
/* 96*/ 		} else {
/* 97*/ 			goto m2runtime_loop_1;
/* 98*/ 		}
/* 99*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*101*/ }


/*104*/ int
/*104*/ Exceptions_RemoveExceptionFromSet(RECORD *Exceptions_caught_exception, ARRAY **Exceptions_thrown_exceptions)
/*104*/ {
/*105*/ 	int Exceptions_i = 0;
/*106*/ 	int Exceptions_found = 0;
/*108*/ 	ARRAY * Exceptions_shorter = NULL;
/*108*/ 	{
/*108*/ 		int m2runtime_for_limit_1;
/*108*/ 		Exceptions_i = 0;
/*108*/ 		m2runtime_for_limit_1 = (m2runtime_count(*Exceptions_thrown_exceptions) - 1);
/*109*/ 		for( ; Exceptions_i <= m2runtime_for_limit_1; Exceptions_i += 1 ){
/*109*/ 			if( (((RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_thrown_exceptions, Exceptions_i, Exceptions_0err_entry_get, 11) != NULL) && Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_thrown_exceptions, Exceptions_i, Exceptions_0err_entry_get, 12), Exceptions_caught_exception)) ){
/*111*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY(Exceptions_thrown_exceptions, 4, 1, Exceptions_i, Exceptions_0err_entry_get, 13) = NULL;
/*112*/ 				Exceptions_found = TRUE;
/*115*/ 			}
/*116*/ 		}
/*116*/ 	}
/*116*/ 	if( Exceptions_found ){
/*117*/ 		{
/*117*/ 			int m2runtime_for_limit_1;
/*117*/ 			Exceptions_i = 0;
/*117*/ 			m2runtime_for_limit_1 = (m2runtime_count(*Exceptions_thrown_exceptions) - 1);
/*118*/ 			for( ; Exceptions_i <= m2runtime_for_limit_1; Exceptions_i += 1 ){
/*118*/ 				if( (RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_thrown_exceptions, Exceptions_i, Exceptions_0err_entry_get, 14) != NULL ){
/*119*/ 					*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Exceptions_shorter, 4, 1, Exceptions_0err_entry_get, 15) = (RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_thrown_exceptions, Exceptions_i, Exceptions_0err_entry_get, 16);
/*122*/ 				}
/*122*/ 			}
/*122*/ 		}
/*122*/ 		*Exceptions_thrown_exceptions = Exceptions_shorter;
/*125*/ 	}
/*125*/ 	return Exceptions_found;
/*130*/ }


char * Exceptions_0func[] = {
    "IsExceptionClass",
    "AddExceptionToList",
    "AddException",
    "ThrowException",
    "ThrowExceptions",
    "RemoveExceptionFromSet"
};

int Exceptions_0err_entry[] = {
    0 /* IsExceptionClass */, 14,
    0 /* IsExceptionClass */, 17,
    1 /* AddExceptionToList */, 28,
    1 /* AddExceptionToList */, 32,
    2 /* AddException */, 41,
    2 /* AddException */, 43,
    3 /* ThrowException */, 55,
    3 /* ThrowException */, 57,
    3 /* ThrowException */, 59,
    3 /* ThrowException */, 62,
    4 /* ThrowExceptions */, 71,
    5 /* RemoveExceptionFromSet */, 109,
    5 /* RemoveExceptionFromSet */, 110,
    5 /* RemoveExceptionFromSet */, 111,
    5 /* RemoveExceptionFromSet */, 118,
    5 /* RemoveExceptionFromSet */, 119,
    5 /* RemoveExceptionFromSet */, 120
};

void Exceptions_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Exceptions";
    *f = Exceptions_0func[ Exceptions_0err_entry[2*i] ];
    *l = Exceptions_0err_entry[2*i + 1];
}
