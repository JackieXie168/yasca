/* IMPLEMENTATION MODULE Globals */
#define M2_IMPORT_Globals

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif
/* 14*/ int Globals_DEBUG = 0;
/* 20*/ int Globals_php_ver = 0;
/* 29*/ RECORD * Globals_resource_type = NULL;
/* 29*/ RECORD * Globals_function_type = NULL;
/* 29*/ RECORD * Globals_mixed_type = NULL;
/* 29*/ RECORD * Globals_string_type = NULL;
/* 29*/ RECORD * Globals_float_type = NULL;
/* 29*/ RECORD * Globals_int_type = NULL;
/* 29*/ RECORD * Globals_boolean_type = NULL;
/* 29*/ RECORD * Globals_void_type = NULL;
/* 29*/ RECORD * Globals_null_type = NULL;
/* 32*/ ARRAY * Globals_required_packages = NULL;
/* 34*/ ARRAY * Globals_consts = NULL;
/* 35*/ int Globals_vars_n = 0;
/* 37*/ ARRAY * Globals_vars = NULL;
/* 39*/ ARRAY * Globals_funcs = NULL;
/* 46*/ ARRAY * Globals_classes = NULL;
/* 52*/ int Globals_scope = 0;
/* 55*/ RECORD * Globals_curr_func = NULL;
/* 58*/ RECORD * Globals_curr_class = NULL;
/* 62*/ RECORD * Globals_curr_method = NULL;

void Globals_0err_entry_get(int i, char **m, char **f, int *l);

void Globals_0err_entry_get(int i, char **m, char **f, int *l)
{}
